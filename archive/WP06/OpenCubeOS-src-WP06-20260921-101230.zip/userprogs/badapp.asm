; Open Cube OS WP-04 - bad app that tries to access kernel memory
bits 64
global _start
section .text
_start:
    mov rax, 1
    lea rsi, [rel msg1]
    mov rdx, 16
    int 0x80
    ; Try to read from kernel address (framebuffer at 0xFD000000)
    mov rsi, 0xFD000000
    mov rax, [rsi]       ; should cause #PF -> killed
    ; won't reach here
    mov rax, 0
    int 0x80
section .rodata
msg1: db "badapp: trying kernel access", 10
