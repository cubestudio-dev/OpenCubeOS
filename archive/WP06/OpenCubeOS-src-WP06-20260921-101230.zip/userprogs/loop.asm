; Open Cube OS WP-04 - infinite loop user program
bits 64
global _start
section .text
_start:
    mov rax, 1
    lea rsi, [rel msg]
    mov rdx, 12
    int 0x80
.loop:
    jmp .loop            ; infinite loop - scheduler should preempt
section .rodata
msg: db "loop: running", 10
