; Open Cube OS WP-04 - hello world user program
; Uses syscall 2 (write_and_exit) to print a message and exit in one call
bits 64
global _start
section .text
_start:
    mov rax, 2           ; syscall: write_and_exit
    lea rsi, [rel msg]   ; string pointer
    mov rdx, 19          ; length
    int 0x80
    ; won't reach here - kernel exits the process
section .rodata
msg: db "hello from userspace", 10
