/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-05
 * File: kernel/ramfs.h
 */
#ifndef OC_RAMFS_H
#define OC_RAMFS_H
void ramfs_init(void);
void ramfs_get_stats(int *total_nodes, int *total_size);
#endif
