/* SPDX-License-Identifier: Apache-2.0 */
#include "file_cmds.h"
#include "shell.h"
#include "vfs.h"
#include "console.h"
#include "string.h"

/* Minimal file commands - just register the names so kmain can link. */
static int cmd_ls(const char *args) {
    (void)args;
    /* Use ramfs via VFS - list root. */
    vfs_dirent_t entry;
    int idx = 0;
    while (vfs_readdir("/", idx, &entry) == 0) {
        oc_console_puts("  ");
        if (entry.type == VFS_TYPE_DIR) oc_console_puts("[D] ");
        oc_console_puts(entry.name);
        oc_console_putc('\n');
        idx++;
    }
    return 0;
}

static int cmd_cat(const char *args) {
    if (!args[0]) return 1;
    int fd = vfs_open(args, VFS_O_RDONLY);
    if (fd < 0) { oc_console_puts("cat: cannot open\n"); return 1; }
    char buf[256];
    int n;
    while ((n = vfs_read(fd, buf, sizeof(buf))) > 0) {
        for (int i = 0; i < n; i++) oc_console_putc(buf[i]);
    }
    vfs_close(fd);
    return 0;
}

static int cmd_pwd(const char *args) { (void)args; oc_console_puts("/\n"); return 0; }
static int cmd_cd(const char *args) { (void)args; return 0; }
static int cmd_mkdir(const char *args) { return vfs_mkdir(args); }
static int cmd_rmdir(const char *args) { return vfs_rmdir(args); }
static int cmd_touch(const char *args) { (void)args; return 0; }
static int cmd_rm(const char *args) { (void)args; return 0; }
static int cmd_mv(const char *args) { (void)args; return 0; }
static int cmd_cp(const char *args) { (void)args; return 0; }
static int cmd_tree(const char *args) { (void)args; return 0; }
static int cmd_df(const char *args) { (void)args; return 0; }
static int cmd_du(const char *args) { (void)args; return 0; }
static int cmd_mount(const char *args) { (void)args; return 0; }
static int cmd_umount(const char *args) { (void)args; return 0; }

void file_cmds_register(void) {
    shell_register_command("ls", cmd_ls, "list directory");
    shell_register_command("cat", cmd_cat, "display file");
    shell_register_command("pwd", cmd_pwd, "print working directory");
    shell_register_command("cd", cmd_cd, "change directory");
    shell_register_command("mkdir", cmd_mkdir, "create directory");
    shell_register_command("rmdir", cmd_rmdir, "remove directory");
    shell_register_command("touch", cmd_touch, "create empty file");
    shell_register_command("rm", cmd_rm, "remove file");
    shell_register_command("mv", cmd_mv, "move/rename");
    shell_register_command("cp", cmd_cp, "copy");
    shell_register_command("tree", cmd_tree, "tree view");
    shell_register_command("df", cmd_df, "disk free");
    shell_register_command("du", cmd_du, "directory usage");
    shell_register_command("mount", cmd_mount, "mount filesystem");
    shell_register_command("umount", cmd_umount, "unmount");
}
