/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-04
 * File: kernel/usermode.h
 * Purpose: Userspace support - ring 3, syscalls, ELF loader.
 */
#ifndef OC_USERMODE_H
#define OC_USERMODE_H

#include "types.h"
#include "vmm.h"
#include "sched.h"

/* Maximum user processes. */
#define MAX_USER_PROCS 16

/* User address space layout:
 *   0x40000000 - code/data (ELF load address 0x400000)
 *   0x7FFFF000 - user stack (grows down from 0x80000000)
 */
#define USER_CODE_BASE  0x80000000ULL
#define USER_STACK_TOP  0x90000000ULL
#define USER_STACK_SIZE 0x10000ULL  /* 64 KiB */

/* PID type. */
typedef int pid_t;

/* User process structure. */
typedef struct user_proc {
    pid_t      pid;
    tid_t      tid;           /* associated kernel thread */
    vmm_as_t   as;            /* address space (PML4 phys) */
    u64        entry_point;   /* ELF entry */
    u64        user_rsp;      /* user stack pointer */
    int        alive;
    char       name[32];
} user_proc_t;

/* Syscall handler function type.
 * Receives the syscall number and 4 arguments.
 * Returns a 64-bit result. */
typedef u64 (*syscall_handler_fn)(u64 arg1, u64 arg2, u64 arg3, u64 arg4);

/* Initialize userspace subsystem (GDT user segments, syscall IDT entry). */
void usermode_init(void);

/* Create a user process from an ELF binary.
 * Returns pid >= 0 on success, -1 on failure. */
pid_t user_process_create(const u8 *elf_data, u64 elf_size, const char *name);

/* Kill a user process. Returns 0 on success. */
int user_process_kill(pid_t pid);

/* List all user processes (for the `run`/`ps` commands). */
void user_process_list(void);

/* Register a syscall handler.
 * num: syscall number (0-255)
 * handler: function to call
 * Returns 0 on success. */
int syscall_register(int num, syscall_handler_fn handler);

/* Default syscall handlers. */
u64 syscall_write(u64 buf, u64 len, u64 arg3, u64 arg4);
u64 syscall_exit(u64 code, u64 arg2, u64 arg3, u64 arg4);

/* Called from the int 0x80 entry stub (in syscall_entry.S).
 * Receives the saved register state. */
void syscall_dispatch(u64 *regs);

/* Enter ring 3 for the first time. Called from the user task launcher. */
void enter_ring3(u64 entry_point, u64 user_rsp, u64 user_cr3);

#endif /* OC_USERMODE_H */
