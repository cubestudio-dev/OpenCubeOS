/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-05
 * File: kernel/vfs.h
 * Purpose: VFS abstraction layer (restored from server).
 */
#ifndef OC_VFS_H
#define OC_VFS_H

#include "types.h"

#define VFS_TYPE_FILE  1
#define VFS_TYPE_DIR   2

#define VFS_O_RDONLY 0x01
#define VFS_O_WRONLY 0x02
#define VFS_O_RDWR   0x03
#define VFS_O_CREAT  0x04
#define VFS_O_APPEND 0x08

#define VFS_SEEK_SET 0
#define VFS_SEEK_CUR 1
#define VFS_SEEK_END 2

#define VFS_PATH_LEN 256
#define VFS_NAME_LEN 64

typedef struct {
    u8  type;
    u64 size;
    char name[64];
} vfs_stat_t;

typedef struct {
    char name[64];
    u8  type;
    u32 inode;
} vfs_dirent_t;

typedef u64 vmm_as_t;  /* reuse for vfs_as_t */

void vfs_init(void);
int vfs_register_fs(const char *name, void *fs_ops, void *file_ops, void *dir_ops);
int vfs_mount(const char *fs_type, const char *mount_point, const char *device);
int vfs_umount(const char *mount_point);
int vfs_open(const char *path, int flags);
int vfs_read(int fd, void *buf, int size);
int vfs_write(int fd, const void *buf, int size);
int vfs_seek(int fd, int offset, int whence);
int vfs_close(int fd);
int vfs_stat(const char *path, vfs_stat_t *st);
int vfs_mkdir(const char *path);
int vfs_rmdir(const char *path);
int vfs_readdir(const char *path, int index, vfs_dirent_t *entry);
int vfs_register_hook(void *hook);
void vfs_list_mounts(void);

#endif /* OC_VFS_H */
