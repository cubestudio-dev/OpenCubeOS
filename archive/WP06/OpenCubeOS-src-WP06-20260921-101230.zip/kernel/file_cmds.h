/* SPDX-License-Identifier: Apache-2.0 */
#ifndef OC_FILE_CMDS_H
#define OC_FILE_CMDS_H
void file_cmds_register(void);
#endif
