/* SPDX-License-Identifier: Apache-2.0 */
#ifndef OC_FAT32_H
#define OC_FAT32_H
#include "types.h"
void fat32_init(void);
int fat32_mount(const char *device, const char *mount_point);
void fat32_get_stats(u64 *total_sectors, u64 *free_clusters, u32 *cluster_size);
#endif
