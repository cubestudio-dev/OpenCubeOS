/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-03
 * File: kernel/shell.h
 * Purpose: Shell command registration - lets L1 extend the oc> prompt.
 */
#ifndef OC_SHELL_H
#define OC_SHELL_H

#include "types.h"

/* Command handler: receives the argument string (everything after the command
 * name) and returns 0 on success. */
typedef int (*shell_cmd_fn)(const char *args);

/* Register a command. name is the command word (e.g. "mem").
 * help is a short description shown by the `help` command.
 * Returns 0 on success, -1 on bad args, -2 if table full. */
int shell_register_command(const char *name, shell_cmd_fn handler, const char *help);

/* Unregister a command. */
int shell_unregister_command(const char *name);

/* Look up and execute a command. Called by the interactive loop.
 * Returns 1 if a command was found and executed, 0 if not found. */
int shell_execute(const char *line);

/* Print all registered commands (for the `help` command). */
void shell_print_help(void);

/* WP-05 shell enhancements (stubs for compilation). */
typedef int (*shell_hook_fn_t)(void *ctx, u8 ch);
void shell_init(void);
void shell_install_console_hook(shell_hook_fn_t hook, void *ctx);
int shell_execute_line(const char *line);
const char *shell_getenv(const char *name);
int shell_setenv(const char *name, const char *value);
const char *shell_get_cwd(void);
int shell_set_cwd(const char *path);
int shell_resolve_path(const char *path, char *out, int out_len);
const char *shell_resolve_path_static(const char *path);

#endif /* OC_SHELL_H */
