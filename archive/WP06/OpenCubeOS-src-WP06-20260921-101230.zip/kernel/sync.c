/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-04
 * File: kernel/sync.c
 * Purpose: Synchronization primitives implementation.
 */
#include "sync.h"
#include "sched.h"
#include "string.h"

/* Global stats. */
static sync_stats_t g_stats;

void sync_get_stats(sync_stats_t *out) {
    if (!out) return;
    u64 flags;
    __asm__ volatile("pushfq; popq %0; cli" : "=r"(flags));
    *out = g_stats;
    if (!(flags & 0x200)) __asm__ volatile("sti");
}

/* ---- Spinlock ---- */
void spin_init(spinlock_t *lock) {
    lock->locked = 0;
    lock->lock_count = 0;
}

void spin_lock(spinlock_t *lock) {
    while (__sync_lock_test_and_set(&lock->locked, 1)) {
        /* Spin. In a real kernel we'd pause here. */
        __asm__ volatile("pause");
    }
    lock->lock_count++;
    g_stats.spin_locks++;
}

void spin_unlock(spinlock_t *lock) {
    __sync_lock_release(&lock->locked);
    g_stats.spin_unlocks++;
}

int spin_trylock(spinlock_t *lock) {
    if (__sync_lock_test_and_set(&lock->locked, 1) == 0) {
        lock->lock_count++;
        g_stats.spin_locks++;
        return 1;
    }
    return 0;
}

/* ---- Semaphore ---- */
void sem_init(sem_t *sem, int initial) {
    sem->count = initial;
    spin_init(&sem->lock);
    sem->wait_count = 0;
    sem->post_count = 0;
}

void sem_wait(sem_t *sem) {
    for (;;) {
        spin_lock(&sem->lock);
        if (sem->count > 0) {
            sem->count--;
            spin_unlock(&sem->lock);
            g_stats.sem_waits++;
            return;
        }
        spin_unlock(&sem->lock);
        /* Block and wait to be woken. */
        sem->wait_count++;
        kthread_block();
    }
}

void sem_post(sem_t *sem) {
    spin_lock(&sem->lock);
    sem->count++;
    spin_unlock(&sem->lock);
    sem->post_count++;
    g_stats.sem_posts++;
    /* Wake one waiting task. (Simple: wake all blocked tasks; they'll
     * re-check the semaphore.) */
    /* For now, just yield so others can run. */
    sched_yield();
}

/* ---- Mutex ---- */
void mutex_init(mutex_t *m) {
    m->locked = 0;
    m->owner = -1;
    m->owner_prio = 0;
    m->lock_count = 0;
}

void mutex_lock(mutex_t *m) {
    tid_t my_tid = kthread_current_tid();
    while (__sync_lock_test_and_set(&m->locked, 1)) {
        /* Contended: yield and retry. */
        sched_yield();
    }
    m->owner = my_tid;
    m->owner_prio = kthread_current()->priority;
    m->lock_count++;
    g_stats.mutex_locks++;
}

void mutex_unlock(mutex_t *m) {
    m->owner = -1;
    __sync_lock_release(&m->locked);
    g_stats.mutex_unlocks++;
    sched_yield();
}

/* ---- Condition variable ---- */
void cond_init(cond_t *c) {
    spin_init(&c->lock);
    c->waiters = 0;
    c->signal_count = 0;
}

void cond_wait(cond_t *c, mutex_t *m) {
    spin_lock(&c->lock);
    c->waiters++;
    spin_unlock(&c->lock);

    mutex_unlock(m);
    kthread_block();
    g_stats.cond_waits++;

    mutex_lock(m);

    spin_lock(&c->lock);
    c->waiters--;
    spin_unlock(&c->lock);
}

void cond_signal(cond_t *c) {
    spin_lock(&c->lock);
    if (c->waiters > 0) {
        c->signal_count++;
        g_stats.cond_signals++;
        /* Wake one blocked task. We don't know which one, so wake
         * by yielding. In a real implementation we'd track waiters. */
    }
    spin_unlock(&c->lock);
    sched_yield();
}

void cond_broadcast(cond_t *c) {
    spin_lock(&c->lock);
    if (c->waiters > 0) {
        c->signal_count += c->waiters;
        g_stats.cond_signals += c->waiters;
    }
    spin_unlock(&c->lock);
    sched_yield();
}
