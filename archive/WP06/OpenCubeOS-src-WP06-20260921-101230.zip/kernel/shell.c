/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-03
 * File: kernel/shell.c
 * Purpose: Shell command registration system.
 */
#include "shell.h"
#include "console.h"
#include "string.h"

#define SHELL_MAX_COMMANDS 64

typedef struct {
    char name[32];
    shell_cmd_fn handler;
    char help[80];
    int in_use;
} shell_cmd_t;

static shell_cmd_t g_commands[SHELL_MAX_COMMANDS];

int shell_register_command(const char *name, shell_cmd_fn handler, const char *help) {
    if (!name || !handler) return -1;
    /* Check if already registered (replace). */
    for (int i = 0; i < SHELL_MAX_COMMANDS; i++) {
        if (g_commands[i].in_use && oc_strcmp(g_commands[i].name, name) == 0) {
            g_commands[i].handler = handler;
            if (help) oc_strncpy(g_commands[i].help, help, sizeof(g_commands[i].help) - 1);
            return 0;
        }
    }
    /* Find a free slot. */
    for (int i = 0; i < SHELL_MAX_COMMANDS; i++) {
        if (!g_commands[i].in_use) {
            oc_strncpy(g_commands[i].name, name, sizeof(g_commands[i].name) - 1);
            g_commands[i].name[sizeof(g_commands[i].name) - 1] = 0;
            g_commands[i].handler = handler;
            if (help) {
                oc_strncpy(g_commands[i].help, help, sizeof(g_commands[i].help) - 1);
                g_commands[i].help[sizeof(g_commands[i].help) - 1] = 0;
            } else {
                g_commands[i].help[0] = 0;
            }
            g_commands[i].in_use = 1;
            return 0;
        }
    }
    return -2;  /* table full */
}

int shell_unregister_command(const char *name) {
    if (!name) return -1;
    for (int i = 0; i < SHELL_MAX_COMMANDS; i++) {
        if (g_commands[i].in_use && oc_strcmp(g_commands[i].name, name) == 0) {
            g_commands[i].in_use = 0;
            return 0;
        }
    }
    return -2;
}

int shell_execute(const char *line) {
    /* Extract the command word. */
    char cmd[32];
    int i = 0;
    while (line[i] && line[i] != ' ' && line[i] != '\t' && i < 31) {
        cmd[i] = line[i];
        i++;
    }
    cmd[i] = 0;

    /* Skip whitespace to get args. */
    const char *args = line + i;
    while (*args == ' ' || *args == '\t') args++;

    /* Find and execute the command. */
    for (int j = 0; j < SHELL_MAX_COMMANDS; j++) {
        if (g_commands[j].in_use && oc_strcmp(g_commands[j].name, cmd) == 0) {
            g_commands[j].handler(args);
            return 1;
        }
    }
    return 0;  /* not found */
}

void shell_print_help(void) {
    for (int i = 0; i < SHELL_MAX_COMMANDS; i++) {
        if (g_commands[i].in_use) {
            oc_console_puts("  ");
            oc_console_puts(g_commands[i].name);
            oc_console_puts(" - ");
            oc_console_puts(g_commands[i].help);
            oc_console_putc('\n');
        }
    }
}

/* WP-05 shell enhancement stubs. */
void shell_init(void) {
    shell_setenv("PS1", "oc> ");
    shell_setenv("SHELL", "/bin/ocsh");
    shell_setenv("PATH", "/bin:/sbin");
}

int shell_execute_line(const char *line) {
    return shell_execute(line);
}

static char g_cwd[256] = "/";
static char g_env_buf[256];

const char *shell_getenv(const char *name) {
    (void)name;
    /* Minimal: return PS1 for the prompt. */
    if (oc_strcmp(name, "PS1") == 0) return "oc> ";
    return NULL;
}

int shell_setenv(const char *name, const char *value) {
    (void)name; (void)value;
    return 0;
}

const char *shell_get_cwd(void) {
    return g_cwd;
}

int shell_set_cwd(const char *path) {
    oc_strncpy(g_cwd, path, sizeof(g_cwd) - 1);
    return 0;
}

int shell_resolve_path(const char *path, char *out, int out_len) {
    if (path[0] == '/') {
        oc_strncpy(out, path, out_len - 1);
        out[out_len - 1] = 0;
    } else {
        oc_strcpy(out, g_cwd);
        int len = oc_strlen(out);
        if (len > 0 && out[len - 1] != '/') {
            if (len < out_len - 1) { out[len] = '/'; out[len + 1] = 0; len++; }
        }
        oc_strncpy(out + len, path, out_len - len - 1);
        out[out_len - 1] = 0;
    }
    return 0;
}

const char *shell_resolve_path_static(const char *path) {
    shell_resolve_path(path, g_env_buf, sizeof(g_env_buf));
    return g_env_buf;
}

void shell_install_console_hook(shell_hook_fn_t hook, void *ctx) {
    /* Forward to the ext console hook system. */
    extern void oc_ext_set_console_hook(void *hook, void *ctx);
    oc_ext_set_console_hook((void*)hook, ctx);
}
