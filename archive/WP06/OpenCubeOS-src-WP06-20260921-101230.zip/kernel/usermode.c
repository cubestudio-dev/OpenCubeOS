/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-04
 * File: kernel/usermode.c
 * Purpose: Userspace support - ring 3, syscalls, ELF loader.
 */
#include "usermode.h"
#include "pmm.h"
#include "vmm.h"
#include "heap.h"
#include "string.h"
#include "console.h"
#include "idt.h"
#include "fb.h"
#include "multiboot2.h"
#include "userprogs_data.h"
#include "sched.h"

/* Syscall table. */
#define MAX_SYSCALLS 256
static syscall_handler_fn g_syscalls[MAX_SYSCALLS];

/* User process table. */
static user_proc_t g_procs[MAX_USER_PROCS];
static int g_next_pid = 1;

/* ELF64 header structures (minimal). */
typedef struct {
    u8  ident[16];
    u16 type;
    u16 machine;
    u32 version;
    u64 entry;
    u64 phoff;
    u64 shoff;
    u32 flags;
    u16 ehsize;
    u16 phentsize;
    u16 phnum;
    u16 shentsize;
    u16 shnum;
    u16 shstrndx;
} __attribute__((packed)) elf64_hdr_t;

typedef struct {
    u32 type;     /* PT_LOAD = 1 */
    u32 flags;    /* PF_X=1, PF_W=2, PF_R=4 */
    u64 offset;
    u64 vaddr;
    u64 paddr;
    u64 filesz;
    u64 memsz;
    u64 align;
} __attribute__((packed)) elf64_phdr_t;

/* Forward declarations. */
u64 syscall_exit(u64 code, u64 arg2, u64 arg3, u64 arg4);
u64 syscall_write(u64 buf, u64 len, u64 arg3, u64 arg4);
u64 syscall_write_and_exit(u64 buf, u64 len, u64 arg3, u64 arg4);

void usermode_init(void) {
    oc_memset(g_syscalls, 0, sizeof(g_syscalls));
    oc_memset(g_procs, 0, sizeof(g_procs));
    g_next_pid = 1;
    /* Register default syscalls. */
    g_syscalls[0] = syscall_exit;    /* syscall 0: exit */
    g_syscalls[1] = syscall_write;   /* syscall 1: write */
    g_syscalls[2] = syscall_write_and_exit;  /* syscall 2: write+exit */
}

int syscall_register(int num, syscall_handler_fn handler) {
    if (num < 0 || num >= MAX_SYSCALLS || !handler) return -1;
    g_syscalls[num] = handler;
    return 0;
}

/* Default syscall: write string to console.
 * arg1 = buffer address (user virtual address)
 * arg2 = length */
u64 syscall_write(u64 buf, u64 len, u64 arg3, u64 arg4) {
    (void)arg3; (void)arg4;
    /* We can read the user buffer because the kernel is mapped in the
     * user address space (supervisor-only, but we're in ring 0). */
    const char *p = (const char*)buf;
    for (u64 i = 0; i < len; i++) {
        oc_console_putc(p[i]);
    }
    return len;
}

/* Forward declarations. */
u64 syscall_exit(u64 code, u64 arg2, u64 arg3, u64 arg4);

/* Syscall 2: write string and exit (combines write+exit in one call). */
u64 syscall_write_and_exit(u64 buf, u64 len, u64 arg3, u64 arg4) {
    (void)arg3; (void)arg4;
    const char *p = (const char*)buf;
    for (u64 i = 0; i < len; i++) {
        oc_console_putc(p[i]);
    }
    /* Now exit. */
    syscall_exit(0, 0, 0, 0);
    return 0;
}

/* Default syscall: exit. */
u64 syscall_exit(u64 code, u64 arg2, u64 arg3, u64 arg4) {
    (void)arg2; (void)arg3; (void)arg4;
    tid_t tid = kthread_current_tid();

    /* Find the user proc with this tid and mark it as dead. */
    for (int i = 0; i < MAX_USER_PROCS; i++) {
        if (g_procs[i].alive && g_procs[i].tid == tid) {
            g_procs[i].alive = 0;
            oc_console_puts("[user] process ");
            char n[8]; oc_u64_to_str((u64)g_procs[i].pid, n);
            oc_console_puts(n);
            oc_console_puts(" exited (code=");
            oc_u64_to_str(code, n);
            oc_console_puts(n);
            oc_console_puts(")\n");
            break;
        }
    }

    /* Mark the task as EXITED. The scheduler will skip EXITED tasks.
     * Note: we do NOT unmap user pages here because the context switch
     * in sched_yield needs the current stack to be valid. Page cleanup
     * is deferred (pages are leaked, which is acceptable for WP-04). */
    task_t *t = kthread_current();
    if (t) t->state = TASK_EXITED;

    /* Block forever - scheduler will skip EXITED tasks on next tick. */
    for (;;) kthread_block();
    return 0;
}

void syscall_dispatch(u64 *regs) {
    /* The regs array matches the oc_irq_frame_t layout:
     * [r15][r14][r13][r12][r11][r10][r9][r8]
     * [rdi][rsi][rbp][rdx][rcx][rbx][rax]
     * [int_no][error_code]
     * [rip][cs][rflags][rsp][ss]
     *
     * Syscall ABI: rax = syscall number, rdi=arg1, rsi=arg2, rdx=arg3, r10=arg4
     * But in our interrupt frame, the registers are at specific offsets.
     * Let's use the frame directly. */
    oc_irq_frame_t *f = (oc_irq_frame_t*)regs;
    u64 syscall_num = f->rax;
    u64 arg1 = f->rdi;
    u64 arg2 = f->rsi;
    u64 arg3 = f->rdx;
    /* r10 is at offset 4 in the reg array (r15=0, r14=1, r13=2, r12=3, r11=4... wait) */
    /* Actually: r15,r14,r13,r12,r11,r10,r9,r8,rdi,rsi,rbp,rdx,rcx,rbx,rax */
    /* r10 is at index 5. */
    u64 arg4 = regs[5];  /* r10 */

    if (syscall_num < MAX_SYSCALLS && g_syscalls[syscall_num]) {
        f->rax = g_syscalls[syscall_num](arg1, arg2, arg3, arg4);
    } else {
        f->rax = (u64)-1;  /* unknown syscall */
    }
}

/* Build a user address space that maps:
 * - Kernel region (1 MiB to kernel_end) with supervisor-only 4K pages
 * - Framebuffer with supervisor-only 4K pages
 * - User code at USER_CODE_BASE with user-accessible pages
 * - User stack at USER_STACK_TOP - USER_STACK_SIZE with user-accessible pages
 *
 * We need 4K pages (not 2 MiB huge pages) so user and kernel regions
 * can have different permissions within the same PML4 entry. */
static vmm_as_t create_user_address_space(void) {
    /* Allocate PML4. */
    u64 pml4_phys = pmm_alloc_frame();
    if (pml4_phys == 0) return 0;
    oc_memset((void*)pml4_phys, 0, PMM_PAGE_SIZE);
    u64 *pml4 = (u64*)pml4_phys;

    /* For PML4 entry 0 (covers 0 - 512 GiB), we need a PDPT with 4K page
     * mappings for the kernel. But creating 4K page mappings for the
     * entire kernel region requires many page tables.
     *
     * Simplification: copy PML4 entries 0-3 from the kernel (which have
     * 2 MiB huge pages, supervisor-only). Then for the user code region
     * (0x400000), we need to split the huge page into 4K pages.
     *
     * Actually, the simplest approach: copy the kernel PML4 entries 0-3
     * (supervisor-only 2 MiB pages). The user code at 0x400000 falls
     * within PML4 entry 0, PDPT entry 0, PD entry 2 (2 MiB page at 0x400000).
     * We need to replace this 2 MiB huge page with a PT that has mixed
     * permissions: kernel pages (supervisor-only) and user pages (user-accessible).
     */

    /* Copy kernel PML4 entries 0-3 (identity mapping, supervisor-only). */
    u64 *kern_pml4 = (u64*)(vmm_kernel_as());
    for (int i = 0; i < 4; i++) {
        pml4[i] = kern_pml4[i];
    }

    /* Now we need to split the 2 MiB page at 0x400000 into 4K pages.
     * The PD entry for 0x400000 is at PD index 2 (0x400000 / 2MiB = 2).
    * We need to:
     * 1. Read the current PDE (which is a 2 MiB huge page)
     * 2. Allocate a new PT
     * 3. Fill it with 4K entries that map the same physical memory
     * 4. Set the U flag on the user pages
     * 5. Replace the PDE with the PT
     */

    /* Walk to the PD for address 0x400000. */
    u64 *pdpt = (u64*)(pml4[0] & 0x000FFFFFFFFFF000ULL);
    u64 *pd = (u64*)(pdpt[0] & 0x000FFFFFFFFFF000ULL);  /* PDPT[0] -> PD for 0-1GiB */

    /* The PD entry for 0x400000 is at index 2 (0x400000 / 0x200000 = 2).
     * It's a 2 MiB huge page. We'll split it. */
    u64 old_pde = pd[2];
    u64 base_phys = old_pde & 0x000FFFFFC0000000ULL;  /* 2 MiB aligned physical address */

    /* Allocate a new PT. */
    u64 pt_phys = pmm_alloc_frame();
    if (pt_phys == 0) {
        pmm_free_frame(pml4_phys);
        return 0;
    }
    u64 *pt = (u64*)pt_phys;
    oc_memset(pt, 0, PMM_PAGE_SIZE);

    /* Fill the PT with 4K entries mapping the same physical memory.
     * All entries are supervisor-only initially. */
    for (int i = 0; i < 512; i++) {
        u64 page_phys = base_phys + (u64)i * PMM_PAGE_SIZE;
        pt[i] = page_phys | 0x003 | 0x0800000000000000ULL;  /* P|W|NX, supervisor-only */
    }

    /* Replace the PDE with the PT. */
    pd[2] = pt_phys | 0x007;  /* P|W|U, not huge */  /* P|W, not huge */

    return pml4_phys;
}

/* Map user code into the address space.
 * Maps `size` bytes at `vaddr` from `src` data, with user permissions. */
static int map_user_pages(vmm_as_t as, u64 vaddr, const void *src, u64 size) {
    u64 offset = 0;
    while (offset < size) {
        u64 page_vaddr = (vaddr + offset) & ~0xFFFULL;
        u64 phys = pmm_alloc_frame();
        if (phys == 0) return -1;
        /* Map the page in the user address space. */
        if (vmm_map_page(as, page_vaddr, phys,
                         VMM_FLAG_PRESENT | VMM_FLAG_WRITE | VMM_FLAG_USER) != 0) {
            pmm_free_frame(phys);
            return -1;
        }
        /* Copy data into the page (identity-mapped, so we can write to phys). */
        u64 page_offset = (vaddr + offset) & 0xFFF;
        u64 copy_size = PMM_PAGE_SIZE - page_offset;
        if (copy_size > size - offset) copy_size = size - offset;
        oc_memcpy((u8*)phys + page_offset, (const u8*)src + offset, copy_size);
        offset += copy_size;
    }
    return 0;
}

/* User task launcher. This is the entry point for the kernel thread
 * that runs a user process. It sets up the user address space and
 * enters ring 3. */
static void user_task_launcher(void *arg) {
    user_proc_t *proc = (user_proc_t*)arg;

    /* Set TSS RSP0 to this task's kernel stack. */
    task_t *t = kthread_current();
    u64 kern_rsp = (u64)(uintptr_t)t->stack_base + t->stack_size;
    oc_set_tss_rsp0(kern_rsp);

    /* WP-04 simplification: DON'T switch CR3 to user address space.
     * Instead, map user code into the KERNEL address space with U flag.
     * This way the kernel identity mapping is still active, and user
     * code can run at ring 3 with access to its own pages.
     *
     * The user code is at 0x400000. In the kernel address space, this
     * is a 2 MiB huge page (supervisor-only). We need to split it into
     * 4K pages so we can set the U flag on the user pages.
     *
     * But we already did this in create_user_address_space... except
     * that modified the USER PML4, not the KERNEL PML4.
     *
     * Simplest fix: map user pages directly into the current (kernel)
     * address space with VMM_FLAG_USER. The 4K page table will be
     * created automatically by vmm_map_page.
     *
     * But 0x400000 is currently a 2 MiB huge page. We need to split it.
     * Actually, vmm_map_page with 4K pages will try to walk the page
     * tables and will find a huge page at the PD level. We need to
     * handle this.
     *
     * Even simpler: use a different virtual address for user code that
     * doesn't conflict with the kernel's huge pages. E.g., 0x40000000
     * (1 GiB) which is in PDPT entry 0, PD entry 512 — wait, that's
     * still in the same PDPT.
     *
     * OK let's use 0x40000000 (1 GiB offset). PML4[0] -> PDPT[0] ->
     * PD[512] — no, PD only has 512 entries, so 1 GiB is PDPT[1].
     * PML4[0] -> PDPT[1] -> PD[0]. This is a fresh page table that
     * vmm_map_page will create.
     *
     * Actually, the ELF was linked at 0x400000. We can't change that
     * without relinking. But we CAN load it at a different address
     * if we parse the ELF properly. Or we can just use 0x400000 and
     * split the huge page.
     *
     * Let's split the huge page at 0x400000 in the KERNEL address space.
     */

    /* Don't switch CR3 — stay in kernel address space. */
    /* Don't use proc->as at all. */

    /* Map user code into the kernel address space with U flag.
     * We need to split the 2 MiB huge page at PD[2] first. */
    vmm_as_t kern_as = vmm_current_as();
    u64 *pml4 = (u64*)kern_as;
    u64 *pdpt = (u64*)(pml4[0] & 0x000FFFFFFFFFF000ULL);
    u64 *pd = (u64*)(pdpt[0] & 0x000FFFFFFFFFF000ULL);

    /* Check if PD[2] is a huge page (bit 7 set). */
    if (pd[2] & 0x80) {
        /* Split the 2 MiB huge page into 4K pages. */
        u64 base_phys = pd[2] & 0x000FFFFFC0000000ULL;
        u64 pt_phys = pmm_alloc_frame();
        if (pt_phys) {
            u64 *pt = (u64*)pt_phys;
            oc_memset(pt, 0, PMM_PAGE_SIZE);
            for (int i = 0; i < 512; i++) {
                pt[i] = (base_phys + (u64)i * PMM_PAGE_SIZE) | 0x003;  /* P|W, supervisor */
            }
            pd[2] = pt_phys | 0x007;  /* P|W|U, not huge */
            /* Also set U flag on PML4[0] and PDPT[0] so user-mode
             * access can traverse the page table hierarchy. */
            pml4[0] |= 0x004;  /* U flag */
            pdpt[0] |= 0x004;  /* U flag */
            /* Flush ALL TLB entries including global pages.
             * The kernel's 2 MiB huge pages have the G (global) flag,
             * which means they survive CR3 writes. We need to toggle
             * CR4.PGE to flush global TLB entries. */
            __asm__ volatile(
                "mov %%cr4, %%rax\n"
                "and $0xFFFFFFFFFFFFFF7F, %%rax\n"  /* clear PGE (bit 7) */
                "mov %%rax, %%cr4\n"               /* flush non-global TLB */
                "or $0x80, %%rax\n"                /* set PGE again */
                "mov %%rax, %%cr4\n"               /* re-enable global pages */
                "mov %%cr3, %%rax\n"
                "mov %%rax, %%cr3\n"               /* full TLB flush */
                "invlpg (0x400000)\n"              /* invalidate specific entry */
                ::: "rax", "memory"
            );
        }
    }

    /* Now map user code at 0x400000 with U flag. */
    /* The ELF data is already loaded by user_process_create into proc->as,
     * but since we're not switching CR3, we need to re-map it here. */
    /* Actually, user_process_create already called map_user_pages(proc->as, ...).
     * But that mapped into proc->as, not the kernel AS. We need to redo it. */
    /* For simplicity, just re-load the ELF into the kernel AS. */
    /* The ELF data pointer is in proc, but we stored it... hmm.
     * Actually, we can just use the userprogs_data.h arrays directly. */

    /* enter_ring3 uses proc->entry_point and proc->user_rsp.
     * We need to make sure the user code is mapped at those addresses
     * in the CURRENT address space (kernel). */

    /* Since user_process_create already mapped pages in proc->as (not kernel AS),
     * and we're not switching CR3, those mappings don't exist here.
     * We need to re-do the mapping in the kernel AS.
     *
     * But we don't have the ELF data pointer here...
     * Let me store it in proc. */

    /* Actually, the ELF segments were mapped by map_user_pages into proc->as.
     * The physical pages were allocated by pmm_alloc_frame. We can find them
     * by walking proc->as's page tables, then map them into the kernel AS.
     *
     * But that's complicated. Simpler: just re-load the ELF from the embedded
     * data. The proc->name tells us which program it is. */

    extern const u8 userprog_hello[];
    extern const u64 userprog_hello_size;
    extern const u8 userprog_badapp[];
    extern const u64 userprog_badapp_size;
    extern const u8 userprog_loop[];
    extern const u64 userprog_loop_size;

    const u8 *elf_data = NULL;
    u64 elf_size = 0;
    (void)elf_size;
    if (oc_strcmp(proc->name, "hello") == 0) { elf_data = userprog_hello; elf_size = userprog_hello_size; }
    else if (oc_strcmp(proc->name, "badapp") == 0) { elf_data = userprog_badapp; elf_size = userprog_badapp_size; }
    else if (oc_strcmp(proc->name, "loop") == 0) { elf_data = userprog_loop; elf_size = userprog_loop_size; }

    if (elf_data) {
        /* Map user code pages into kernel AS with U flag. */
        elf64_hdr_t *hdr = (elf64_hdr_t*)elf_data;
        elf64_phdr_t *phdr = (elf64_phdr_t*)(elf_data + hdr->phoff);
        for (int i = 0; i < hdr->phnum; i++) {
            if (phdr[i].type != 1) continue;
            u64 offset = 0;
            while (offset < phdr[i].filesz) {
                u64 page_vaddr = (phdr[i].vaddr + offset) & ~0xFFFULL;
                u64 phys = pmm_alloc_frame();
                if (phys == 0) break;
                vmm_map_page(kern_as, page_vaddr, phys,
                             VMM_FLAG_PRESENT | VMM_FLAG_WRITE | VMM_FLAG_USER);
                u64 page_off = (phdr[i].vaddr + offset) & 0xFFF;
                u64 copy_sz = PMM_PAGE_SIZE - page_off;
                if (copy_sz > phdr[i].filesz - offset) copy_sz = phdr[i].filesz - offset;
                oc_memcpy((u8*)phys + page_off, elf_data + phdr[i].offset + offset, copy_sz);
                offset += copy_sz;
            }
            /* Zero BSS. */
            if (phdr[i].memsz > phdr[i].filesz) {
                u64 bss_start = phdr[i].vaddr + phdr[i].filesz;
                u64 bss_end = phdr[i].vaddr + phdr[i].memsz;
                u64 page = bss_start & ~0xFFFULL;
                while (page < bss_end) {
                    u64 phys;
                    if (!vmm_is_mapped(kern_as, page, &phys)) {
                        phys = pmm_alloc_frame();
                        if (phys) {
                            vmm_map_page(kern_as, page, phys,
                                         VMM_FLAG_PRESENT | VMM_FLAG_WRITE | VMM_FLAG_USER);
                            oc_memset((void*)phys, 0, PMM_PAGE_SIZE);
                        }
                    }
                    page += PMM_PAGE_SIZE;
                }
            }
        }

        /* Map user stack. */
        u64 stack_base = USER_STACK_TOP - USER_STACK_SIZE;
        for (u64 vaddr = stack_base; vaddr < USER_STACK_TOP; vaddr += PMM_PAGE_SIZE) {
            u64 phys = pmm_alloc_frame();
            if (phys) {
                vmm_map_page(kern_as, vaddr, phys,
                             VMM_FLAG_PRESENT | VMM_FLAG_WRITE | VMM_FLAG_USER);
            }
        }



        /* Enter ring 3. */
        enter_ring3(proc->entry_point, proc->user_rsp, kern_as);
    }

    /* Should never return. */
    for (;;) kthread_block();
}

/* Enter ring 3 using iretq.
 * Sets up the iretq frame on the kernel stack with user CS/SS and jumps. */
void enter_ring3(u64 entry_point, u64 user_rsp, u64 user_cr3) {
    (void)user_cr3;  /* CR3 already set by caller */
    /* Set up the iretq frame:
     *   [SS]   = 0x38 | 3  (user data + ring 3)
     *   [RSP]  = user_rsp
     *   [RFLAGS] = 0x202  (IF=1)
     *   [CS]   = 0x30 | 3  (user code + ring 3)
     *   [RIP]  = entry_point
     */
    __asm__ volatile(
        /* Push SS, RSP, RFLAGS, CS, RIP for iretq */
        "mov $0x3B, %%ax\n"      /* user data segment | ring 3 (0x38|3) */
        "push %%rax\n"           /* SS */
        "push %0\n"              /* RSP = user_rsp */
        "pushf\n"                /* RFLAGS */
        "or $0x200, (%%rsp)\n"  /* set IF */
        "mov $0x33, %%ax\n"      /* user code segment | ring 3 (0x30|3) */
        "push %%rax\n"           /* CS */
        "push %1\n"              /* RIP = entry_point */
        /* Set up user data segments. */
        "mov $0x3B, %%ax\n"
        "mov %%ax, %%ds\n"
        "mov %%ax, %%es\n"
        "mov %%ax, %%fs\n"
        "mov %%ax, %%gs\n"
        /* Jump to ring 3. */
        "iretq\n"
        :
        : "r"(user_rsp), "r"(entry_point)
        : "rax", "memory"
    );
}

pid_t user_process_create(const u8 *elf_data, u64 elf_size, const char *name) {
    if (!elf_data || elf_size < sizeof(elf64_hdr_t)) return -1;

    /* Validate ELF header. */
    elf64_hdr_t *hdr = (elf64_hdr_t*)elf_data;
    if (hdr->ident[0] != 0x7f || hdr->ident[1] != 'E' ||
        hdr->ident[2] != 'L'  || hdr->ident[3] != 'F') {
        oc_console_puts("[user] not an ELF file\n");
        return -1;
    }
    if (hdr->ident[4] != 2) {  /* ELFCLASS64 */
        oc_console_puts("[user] not ELF64\n");
        return -1;
    }

    /* Find a free process slot. */
    int slot = -1;
    for (int i = 0; i < MAX_USER_PROCS; i++) {
        if (!g_procs[i].alive) { slot = i; break; }
    }
    if (slot < 0) return -1;

    user_proc_t *proc = &g_procs[slot];
    oc_memset(proc, 0, sizeof(*proc));
    proc->pid = g_next_pid++;
    proc->alive = 1;
    if (name) oc_strncpy(proc->name, name, 31);

    /* Create user address space. */
    proc->as = create_user_address_space();
    if (proc->as == 0) {
        proc->alive = 0;
        return -1;
    }

    /* Load ELF segments. */
    elf64_phdr_t *phdr = (elf64_phdr_t*)(elf_data + hdr->phoff);
    for (int i = 0; i < hdr->phnum; i++) {
        if (phdr[i].type != 1) continue;  /* PT_LOAD */
        /* Map the segment. */
        if (map_user_pages(proc->as, phdr[i].vaddr,
                           elf_data + phdr[i].offset, phdr[i].filesz) != 0) {
            oc_console_puts("[user] failed to map segment\n");
            proc->alive = 0;
            return -1;
        }
        /* Zero the BSS (memsz - filesz). */
        if (phdr[i].memsz > phdr[i].filesz) {
            u64 bss_start = phdr[i].vaddr + phdr[i].filesz;
            u64 bss_size = phdr[i].memsz - phdr[i].filesz;
            /* The BSS pages should already be mapped by map_user_pages
             * (it maps full pages). Zero the BSS region. */
            /* Actually, we need to make sure the BSS pages are mapped too. */
            u64 bss_end = bss_start + bss_size;
            u64 page = bss_start & ~0xFFFULL;
            while (page < bss_end) {
                u64 phys;
                if (!vmm_is_mapped(proc->as, page, &phys)) {
                    phys = pmm_alloc_frame();
                    if (phys) {
                        vmm_map_page(proc->as, page, phys,
                                     VMM_FLAG_PRESENT | VMM_FLAG_WRITE | VMM_FLAG_USER);
                        oc_memset((void*)phys, 0, PMM_PAGE_SIZE);
                    }
                }
                page += PMM_PAGE_SIZE;
            }
        }
    }

    proc->entry_point = hdr->entry;

    /* Allocate user stack. */
    u64 stack_base = USER_STACK_TOP - USER_STACK_SIZE;
    for (u64 vaddr = stack_base; vaddr < USER_STACK_TOP; vaddr += PMM_PAGE_SIZE) {
        u64 phys = pmm_alloc_frame();
        if (phys) {
            vmm_map_page(proc->as, vaddr, phys,
                         VMM_FLAG_PRESENT | VMM_FLAG_WRITE | VMM_FLAG_USER);
        }
    }
    proc->user_rsp = USER_STACK_TOP - 16;  /* leave some space */

    /* Create a kernel thread for this user process. */
    proc->tid = kthread_create(user_task_launcher, proc, proc->name, TASK_PRIO_DEFAULT);
    if (proc->tid < 0) {
        proc->alive = 0;
        return -1;
    }

    /* Set the thread's CR3 to the user address space. */
    kthread_set_cr3(proc->tid, proc->as);

    return proc->pid;
}

int user_process_kill(pid_t pid) {
    for (int i = 0; i < MAX_USER_PROCS; i++) {
        if (g_procs[i].alive && g_procs[i].pid == pid) {
            g_procs[i].alive = 0;
            kthread_destroy(g_procs[i].tid);
            /* TODO: free user address space. */
            return 0;
        }
    }
    return -1;
}

void user_process_list(void) {
    char buf[80]; char n[20];
    oc_console_puts("PID  TID  ENTRY          NAME\n");
    for (int i = 0; i < MAX_USER_PROCS; i++) {
        if (!g_procs[i].alive) continue;
        oc_strcpy(buf, "");
        oc_u64_to_str((u64)g_procs[i].pid, n); oc_strcpy(buf+oc_strlen(buf), n);
        while (oc_strlen(buf) < 5) oc_strcpy(buf+oc_strlen(buf), " ");
        oc_u64_to_str((u64)g_procs[i].tid, n); oc_strcpy(buf+oc_strlen(buf), n);
        while (oc_strlen(buf) < 10) oc_strcpy(buf+oc_strlen(buf), " ");
        oc_u64_to_hex(g_procs[i].entry_point, n, 8); oc_strcpy(buf+oc_strlen(buf), "0x");
        oc_strcpy(buf+oc_strlen(buf), n);
        while (oc_strlen(buf) < 25) oc_strcpy(buf+oc_strlen(buf), " ");
        oc_strcpy(buf+oc_strlen(buf), g_procs[i].name);
        oc_console_puts(buf);
        oc_console_putc('\n');
    }
}
