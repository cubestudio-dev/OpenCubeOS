/* SPDX-License-Identifier: Apache-2.0 */
#ifndef OC_ATA_H
#define OC_ATA_H
#include "types.h"
void ata_init(void);
int ata_read_sectors(int drive, u64 lba, int count, void *buf);
int ata_write_sectors(int drive, u64 lba, int count, const void *buf);
int ata_detect(int drive);
#endif
