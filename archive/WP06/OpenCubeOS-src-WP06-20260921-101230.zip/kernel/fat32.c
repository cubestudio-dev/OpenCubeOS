/* SPDX-License-Identifier: Apache-2.0 */
#include "fat32.h"
#include "vfs.h"
#include "ata.h"
#include "console.h"

void fat32_init(void) {
    vfs_register_fs("fat32", NULL, NULL, NULL);
}

int fat32_mount(const char *device, const char *mount_point) {
    (void)device; (void)mount_point;
    return -1;
}

void fat32_get_stats(u64 *total_sectors, u64 *free_clusters, u32 *cluster_size) {
    if (total_sectors) *total_sectors = 0;
    if (free_clusters) *free_clusters = 0;
    if (cluster_size) *cluster_size = 0;
}
