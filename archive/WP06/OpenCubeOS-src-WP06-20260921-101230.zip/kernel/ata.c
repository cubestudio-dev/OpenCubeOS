/* SPDX-License-Identifier: Apache-2.0 */
#include "ata.h"
#include "console.h"
#include "string.h"

static inline void outb(u16 p, u8 v) { __asm__ volatile("outb %0, %1" :: "a"(v), "Nd"(p)); }
static inline u8  inb(u16 p) { u8 v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v; }

void ata_init(void) {
    /* Detect drives. */
    for (int drive = 0; drive < 4; drive++) {
        ata_detect(drive);
    }
}

int ata_detect(int drive) {
    u16 base = (drive < 2) ? 0x1F0 : 0x170;
    u8 slave = (drive % 2);
    outb(base + 6, 0xA0 | (slave << 4));
    for (volatile int i = 0; i < 1000; i++);
    outb(base + 2, 0);
    outb(base + 3, 0);
    outb(base + 4, 0);
    outb(base + 5, 0);
    outb(base + 7, 0xEC);  /* IDENTIFY */
    u8 status = inb(base + 7);
    if (status == 0) return 0;  /* no drive */
    for (int i = 0; i < 1000; i++) {
        status = inb(base + 7);
        if (status & 0x01) return 0;  /* error */
        if (status & 0x08) break;  /* DRQ */
    }
    return 1;
}

int ata_read_sectors(int drive, u64 lba, int count, void *buf) {
    (void)drive; (void)lba; (void)count; (void)buf;
    return -1;
}

int ata_write_sectors(int drive, u64 lba, int count, const void *buf) {
    (void)drive; (void)lba; (void)count; (void)buf;
    return -1;
}
