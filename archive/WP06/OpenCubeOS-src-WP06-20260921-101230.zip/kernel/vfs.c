/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-05
 * File: kernel/vfs.c - Minimal VFS implementation (restored stub).
 */
#include "vfs.h"
#include "heap.h"
#include "string.h"
#include "console.h"

void vfs_init(void) {
    /* Minimal: no-op for now. ramfs_init handles the root mount. */
}

int vfs_register_fs(const char *name, void *fs_ops, void *file_ops, void *dir_ops) {
    (void)name; (void)fs_ops; (void)file_ops; (void)dir_ops;
    return 0;
}

int vfs_mount(const char *fs_type, const char *mount_point, const char *device) {
    (void)fs_type; (void)mount_point; (void)device;
    return 0;
}

int vfs_umount(const char *mount_point) { (void)mount_point; return 0; }

int vfs_open(const char *path, int flags) { (void)path; (void)flags; return -1; }
int vfs_read(int fd, void *buf, int size) { (void)fd; (void)buf; (void)size; return -1; }
int vfs_write(int fd, const void *buf, int size) { (void)fd; (void)buf; (void)size; return -1; }
int vfs_seek(int fd, int offset, int whence) { (void)fd; (void)offset; (void)whence; return -1; }
int vfs_close(int fd) { (void)fd; return 0; }
int vfs_stat(const char *path, vfs_stat_t *st) { (void)path; (void)st; return -1; }
int vfs_mkdir(const char *path) { (void)path; return -1; }
int vfs_rmdir(const char *path) { (void)path; return -1; }
int vfs_readdir(const char *path, int index, vfs_dirent_t *entry) { (void)path; (void)index; (void)entry; return -1; }
int vfs_register_hook(void *hook) { (void)hook; return 0; }
void vfs_list_mounts(void) { oc_console_puts("VFS mount table:\n  /  ramfs\n"); }
