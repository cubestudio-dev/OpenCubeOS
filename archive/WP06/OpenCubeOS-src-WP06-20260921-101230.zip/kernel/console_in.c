/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-02
 * File: kernel/console_in.c
 * Purpose: Console input line editor + L1 input hooks.
 */
#include "console_in.h"
#include "keyboard.h"
#include "console.h"
#include "string.h"

#define OC_CONS_IN_BUF_LEN 256

static char g_line[OC_CONS_IN_BUF_LEN];
static int  g_line_len = 0;
static int  g_line_ready = 0;  /* 1 when g_line contains a complete line */

/* L1 input hook chain. */
#define OC_CONS_HOOK_LEN 4
static oc_console_in_hook_fn g_hooks[OC_CONS_HOOK_LEN];

void oc_console_in_init(void) {
    g_line_len = 0;
    g_line_ready = 0;
    oc_memset(g_hooks, 0, sizeof(g_hooks));
    oc_memset(g_line, 0, sizeof(g_line));
}

int oc_console_in_register_hook(oc_console_in_hook_fn fn) {
    if (!fn) return -1;
    for (int i = 0; i < OC_CONS_HOOK_LEN; i++) {
        if (g_hooks[i] == NULL) { g_hooks[i] = fn; return 0; }
    }
    return -2;
}

int oc_console_in_unregister_hook(oc_console_in_hook_fn fn) {
    if (!fn) return -1;
    for (int i = 0; i < OC_CONS_HOOK_LEN; i++) {
        if (g_hooks[i] == fn) {
            g_hooks[i] = NULL;
            for (int j = i; j + 1 < OC_CONS_HOOK_LEN; j++) {
                g_hooks[j] = g_hooks[j+1];
                g_hooks[j+1] = NULL;
            }
            return 0;
        }
    }
    return -2;
}

void oc_console_in_inject(const char *text) {
    /* Treat each character as a typed key. */
    while (*text) {
        char c = *text++;
        if (c == '\n' || c == '\r') {
            if (!g_line_ready) {
                g_line[g_line_len] = 0;
                g_line_ready = 1;
            }
        } else if (c == 0x08 && g_line_len > 0) {
            g_line_len--;
        } else if (c >= 0x20 && g_line_len < OC_CONS_IN_BUF_LEN - 1) {
            g_line[g_line_len++] = c;
        }
    }
}

static void finish_line(void) {
    g_line[g_line_len] = 0;
    /* Run L1 hooks. */
    for (int i = 0; i < OC_CONS_HOOK_LEN; i++) {
        if (g_hooks[i]) {
            if (g_hooks[i](g_line, g_line_len)) {
                /* L1 consumed it - reset and don't mark ready. */
                g_line_len = 0;
                return;
            }
        }
    }
    g_line_ready = 1;
}

int oc_console_in_pump(void) {
    if (g_line_ready) return 1;
    int k = oc_keyboard_getch();
    if (k < 0) return 0;

    switch (k) {
        case OC_KEY_ENTER:
            oc_console_putc('\n');
            finish_line();
            return g_line_ready ? 1 : 0;
        case OC_KEY_BACKSPACE:
            if (g_line_len > 0) {
                g_line_len--;
                oc_console_putc('\b');
            }
            return 0;
        case OC_KEY_CTRL_C:
            /* Cancel current line. */
            oc_console_puts("^C\n");
            g_line_len = 0;
            g_line[0] = 0;
            g_line_ready = 1;  /* deliver empty line as cancellation */
            return 1;
        case OC_KEY_TAB:
            if (g_line_len < OC_CONS_IN_BUF_LEN - 1) {
                g_line[g_line_len++] = '\t';
                oc_console_putc('\t');
            }
            return 0;
        default:
            if (k >= 0x20 && k < 0x7F && g_line_len < OC_CONS_IN_BUF_LEN - 1) {
                g_line[g_line_len++] = (char)k;
                oc_console_putc((char)k);
            }
            return 0;
    }
}

int oc_console_in_readline(char *buf, int size) {
    /* Pump until a line is ready. */
    while (!g_line_ready) {
        /* Enable interrupts so keyboard IRQs fire while we wait. */
        __asm__ volatile("sti");
        __asm__ volatile("hlt");
        oc_console_in_pump();
    }
    int len = g_line_len;
    if (len >= size) len = size - 1;
    oc_memcpy(buf, g_line, len);
    buf[len] = 0;
    /* Reset for next line. */
    g_line_len = 0;
    g_line_ready = 0;
    return len;
}
