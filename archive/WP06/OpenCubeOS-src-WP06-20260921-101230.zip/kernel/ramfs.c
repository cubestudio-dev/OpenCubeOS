/* SPDX-License-Identifier: Apache-2.0 */
/* Open Cube OS - WP-05
 * File: kernel/ramfs.c - Minimal stub.
 */
#include "ramfs.h"
#include "vfs.h"
#include "heap.h"
#include "string.h"
#include "console.h"

void ramfs_init(void) {
    /* Register ramfs and mount at /. */
    vfs_register_fs("ramfs", NULL, NULL, NULL);
    vfs_mount("ramfs", "/", NULL);
    /* Create default directories. */
    vfs_mkdir("/etc");
    vfs_mkdir("/tmp");
    vfs_mkdir("/dev");
    vfs_mkdir("/bin");
}

void ramfs_get_stats(int *total_nodes, int *total_size) {
    if (total_nodes) *total_nodes = 0;
    if (total_size) *total_size = 0;
}
