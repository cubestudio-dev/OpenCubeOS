/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
/* Open Cube OS - host link stub for tests/host_wifi_test.c.
 *
 * WP-10-tui: the wireless core now carries a driver_nic bridge
 * (wl_nic_bridge_register) that calls driver_nic_register().  The
 * host wifi harness exercises the 802.11 core only, so instead of
 * linking the whole NIC family tree we provide a recording stub:
 * the bridge never registers hardware in a host run (no probe), and
 * the stub keeps that honest by returning "registered" like the real
 * framework would for an empty table entry. */
#include "driver_nic.h"

int driver_nic_register(driver_nic_device_t *dev, const driver_nic_ops_t *ops) {
    (void)dev;
    (void)ops;
    return 0;
}
