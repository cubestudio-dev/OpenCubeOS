/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
/* Open Cube OS - WP-02
 * File: kernel/arch/x86_64/arch_exceptions.h
 * Purpose: CPU exception dispatch + L1 exception-handler registration.
 */
#ifndef OC_EXCEPTIONS_H
#define OC_EXCEPTIONS_H

#include "arch_idt.h"

/* Initialize the default exception handler table. Called from arch_idt_init. */
void arch_exc_init(void);

/* Dispatch a CPU exception (vector 0..31). Called from arch_isr_dispatch. */
void arch_exc_dispatch(arch_irq_frame_t *f);

/* ---- L1 extension: exception handler registration ----
 *
 * L1 can register a handler for any exception vector (0..31). The handler
 * receives the full interrupt frame (including error code, faulting RIP,
 * etc.). If the handler returns 0, L0 prints a diagnostic and halts the
 * kernel. If it returns non-zero, L0 assumes L1 handled the fault (e.g.
 * by fixing up the RIP for a JIT) and resumes.
 *
 * signature:
 *   int (*arch_exc_handler_fn)(arch_irq_frame_t *f);
 *   return 0 = let L0 halt; non-zero = L1 handled, resume.
 */
typedef int (*arch_exc_handler_fn)(arch_irq_frame_t *f);

/* Register a handler for `vector` (0..31). Returns 0 on success.
 * Multiple registrations on the same vector form a chain; the most recently
 * registered handler runs first. */
int arch_exc_register_handler(int vector, arch_exc_handler_fn handler);

/* Unregister a handler. Returns 0 on success. */
int arch_exc_unregister_handler(int vector, arch_exc_handler_fn handler);

#endif /* OC_EXCEPTIONS_H */
