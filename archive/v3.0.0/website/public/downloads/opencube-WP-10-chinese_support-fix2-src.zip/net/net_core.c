/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
/* Open Cube OS - WP-06
 * File: net/net_core.c
 * Purpose: Network stack implementation - e1000 driver + TCP/IP + socket API.
 *
 * Architecture:
 *   e1000 NIC (MMIO) -> Ethernet frame -> ARP/IP -> ICMP/UDP/TCP
 *   -> DHCP/DNS/socket
 *
 * Uses polling mode (no IRQ). net_poll() must be called periodically.
 */
#include "net_core.h"
#include "shell.h"  /* WP-10d-fix2: shell_register_command_ex */
#include "driver_pci.h"
#include "driver_nic.h"   /* WP-10b: NIC driver framework (e1000e/igb/rtl8139/...) */
#include "mem_heap.h"
#include "mem_pmm.h"
#include "lib_string.h"
#include "screen_console.h"
#include "core_timer.h"
#include "net_tcp_cc.h"
#include "fs_vfs.h"   /* P1-3 FIX: for fs_vfs_open / VFS_O_WRONLY in shell_cmd_wget */

/* Allocate identity-mapped memory for DMA (e1000 needs physical addresses).
 * kmalloc returns heap memory at 0xC0000000 which is NOT identity-mapped.
 * We use PMM to allocate 4KB pages from the identity-mapped region.
 * For small allocations (< 4KB), we sub-allocate from a single page.
 * For larger allocations, we allocate a full page. */
static u8 *g_dma_page = NULL;
static int g_dma_page_offset = 0;

static void *dma_alloc(int size) {
    if (size <= 0) return NULL;
    if (size > PMM_PAGE_SIZE) {
        /* BUG-0201: a single frame cannot back a request larger than the
         * frame itself. Use a physically-contiguous multi-frame run (the
         * low identity-mapped region covers all PMM frames, so the DMA
         * address stays valid); fail when PMM cannot provide one. */
        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
        u64 pa = mem_pmm_alloc_contig((u64)npages);
        if (pa == 0) return NULL;
        return (void *)(uintptr_t)pa;
    }
    /* BUG-0201: sub-allocate from the current page. The alignment must be
     * applied BEFORE the bounds check: the old order checked
     * "offset + size <= 4096" on the unaligned offset and only then
     * aligned, so up to 15+size bytes could be handed out past the end
     * of the frame. */
    int aligned = (g_dma_page_offset + 15) & ~15;
    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
        /* Need a fresh page. */
        g_dma_page = (u8 *)mem_pmm_alloc_frame();
        if (g_dma_page == NULL) return NULL;
        aligned = 0;
    }
    void *p = g_dma_page + aligned;
    g_dma_page_offset = aligned + size;
    return p;
}

static char n_tmp[20];  /* shared buffer for number formatting */

/* Forward declarations. */
int net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
                           const void *data, int len);
void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
/* Returns 1 when the datagram was consumed (handler table or socket),
 * 0 when no listener owns the destination port (caller answers with an
 * ICMP port-unreachable, BUG-0217). */
int net_udp_handle_packet(u32 src_ip, const void *data, int len);
void net_tcp_handle_packet(u32 src_ip, const void *data, int len);

/* ============================================================
 * Utility: I/O port access
 * ============================================================ */
static inline void outb(u16 p, u8 v) { __asm__ volatile("outb %0, %1" :: "a"(v), "Nd"(p)); }
static inline void outw(u16 p, u16 v) { __asm__ volatile("outw %0, %1" :: "a"(v), "Nd"(p)); }
static inline void outl(u16 p, u32 v) { __asm__ volatile("outl %0, %1" :: "a"(v), "Nd"(p)); }
static inline u8  inb(u16 p) { u8 v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v; }
static inline u16 inw(u16 p) { u16 v; __asm__ volatile("inw %1, %0" : "=a"(v) : "Nd"(p)); return v; }
static inline u32 inl(u16 p) { u32 v; __asm__ volatile("inl %1, %0" : "=a"(v) : "Nd"(p)); return v; }

/* MMIO read/write (volatile pointer) */
static inline u32 mmio_read32(volatile void *addr) {
    return *(volatile u32 *)addr;
}
static inline void mmio_write32(volatile void *addr, u32 val) {
    *(volatile u32 *)addr = val;
}

/* ============================================================
 * Internet checksum
 * ============================================================ */
static u16 internet_checksum(const void *data, int len, u32 sum) {
    const u16 *p = (const u16 *)data;
    while (len > 1) {
        sum += *p++;
        len -= 2;
    }
    if (len == 1) {
        sum += *(const u8 *)p;
    }
    while (sum >> 16) {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    return (u16)(~sum);
}

/* RFC 1071-style raw accumulator WITHOUT the final complement. Use this
 * (checksum_fold included) when a checksum must span several buffers
 * (pseudo-header + segment), because internet_checksum() complements on
 * every call and two chained calls complement twice - the verification
 * then fails for EVERY valid packet. That was the BUG-0072 regression
 * found while re-running the SSH/HTTPS end-to-end suites on p1fix3:
 * every inbound TCP segment was dropped as "bad checksum", so sshd,
 * the kernel ssh client and the TLS server all starved. */
static u32 checksum_raw_add(const void *data, int len, u32 sum) {
    const u16 *p = (const u16 *)data;
    while (len > 1) {
        sum += *p++;
        len -= 2;
    }
    if (len == 1) {
        sum += *(const u8 *)p;
    }
    return sum;   /* caller folds with checksum_fold() */
}

static u16 checksum_fold(u32 sum) {
    while (sum >> 16) {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    return (u16)sum;
}

/* ============================================================
 * Network configuration state
 * ============================================================ */
static u8  g_mac[6] = {0,0,0,0,0,0};
static u32 g_ip      = 0;
static u32 g_mask    = 0;
static u32 g_gateway = 0;
static u32 g_dns     = 0;
static int g_nic_ok  = 0;
static net_stats_t g_stats;

/* ============================================================
 * virtio-net driver (legacy transport via PCI I/O ports)
 * ============================================================ */

/* virtio-net PCI device IDs */
#define VIRTIO_NET_VENDOR_ID  0x1AF4
#define VIRTIO_NET_DEVICE_ID  0x1000  /* legacy */

/* virtio PCI I/O port offsets (from BAR0 I/O base) */
#define VIRTIO_PCI_HOST_FEATURES  0
#define VIRTIO_PCI_GUEST_FEATURES 4
#define VIRTIO_PCI_QUEUE_PFN      8
#define VIRTIO_PCI_QUEUE_SIZE     12
#define VIRTIO_PCI_QUEUE_SELECT   14
#define VIRTIO_PCI_QUEUE_NOTIFY   16
#define VIRTIO_PCI_STATUS         18
#define VIRTIO_PCI_ISR            19

/* virtio status bits */
#define VIRTIO_STATUS_ACK        0x01
#define VIRTIO_STATUS_DRIVER     0x02
#define VIRTIO_STATUS_DRIVER_OK  0x04
#define VIRTIO_STATUS_FEATURES_OK 0x08

/* virtio-net feature bits */
#define VIRTIO_NET_F_MAC         (1 << 5)

/* virtio-net header (10 bytes) */
typedef struct __attribute__((packed)) {
    u8  flags;
    u8  gso_type;
    u16 hdr_len;
    u16 gso_size;
    u16 csum_start;
    u16 csum_offset;
} net_virtio_hdr_t;

/* virtqueue descriptor (16 bytes) */
typedef struct {
    u64 addr;       /* physical address of buffer */
    u32 len;        /* length of buffer */
    u16 flags;      /* VIRTQ_DESC_F_NEXT, etc. */
    u16 next;       /* index of next descriptor (if flags & NEXT) */
} __attribute__((packed)) net_virtq_desc_t;

#define VIRTQ_DESC_F_NEXT  1
#define VIRTQ_DESC_F_WRITE 2

/* virtqueue available ring */
typedef struct {
    u16 flags;
    u16 idx;
    u16 ring[256];  /* up to 256 entries */
} __attribute__((packed)) net_virtq_avail_t;

/* virtqueue used ring */
typedef struct __attribute__((packed)) {
    u16 flags;
    u16 idx;
    struct {
        u32 id;
        u32 len;
    } ring[256];
} net_virtq_used_t;

#define VIRTIO_NET_Q_RX  0
#define VIRTIO_NET_Q_TX  1
#define VIRTIO_NUM_DESC  256  /* Match QEMU's typical virtio-net queue size */
#define VIRTIO_BUF_SIZE  2048

/* virtio-net state */
static u32 g_virtio_io_base = 0;
static int g_virtio_ok = 0;
static int g_use_virtio = 0;  /* 1 = use virtio-net, 0 = use e1000 */
/* BUG-0202: negotiated queue sizes. Every ring index must be taken modulo
 * the size the DEVICE actually negotiated (VIRTIO_PCI_QUEUE_SIZE), which
 * may legally be smaller than our VIRTIO_NUM_DESC cap — indexing the
 * descriptor table or the avail/used rings with a hardcoded 256 wraps
 * past the real ring when qsz < 256. */
static u16 g_virtio_rx_size = 0;
static u16 g_virtio_tx_size = 0;

/* RX virtqueue */
static net_virtq_desc_t *g_vrx_descs = NULL;
static net_virtq_avail_t *g_vrx_avail = NULL;
static net_virtq_used_t *g_vrx_used = NULL;
static u8 *g_vrx_bufs[VIRTIO_NUM_DESC];
static u16 g_vrx_avail_idx = 0;
static u16 g_vrx_used_idx = 0;
static u8 *g_vrx_pages = NULL;

/* TX virtqueue */
static net_virtq_desc_t *g_vtx_descs = NULL;
static net_virtq_avail_t *g_vtx_avail = NULL;
static net_virtq_used_t *g_vtx_used = NULL;
static u8 *g_vtx_bufs[VIRTIO_NUM_DESC];
static u16 g_vtx_avail_idx = 0;
static u16 g_vtx_used_idx = 0;
static u8 *g_vtx_pages = NULL;

/* Allocate a virtqueue: descriptor table + avail ring + used ring.
 * Per virtio legacy spec, the layout is contiguous:
 *   - Descriptor table: at offset 0, size = 16 * qsz, aligned to 16
 *   - Available ring: at offset 16*qsz, size = 2 + 2 + 2*qsz
 *   - Used ring: at offset (16*qsz + 2 + 2 + 2*qsz) rounded up to 4, size = 2 + 2 + 8*qsz
 * QUEUE_PFN = phys_addr_of_base / 4096
 * For qsz=256: desc=4096 + avail=514 + used=2054 = ~6.7KB, needs 2 pages. */
static int net_virtio_alloc_virtq(net_virtq_desc_t **descs, net_virtq_avail_t **avail,
                              net_virtq_used_t **used, u8 **pages_out, u16 qsz) {
    u32 desc_size = 16 * qsz;
    u32 avail_size = 2 + 2 + 2 * qsz;
    u32 used_off = (desc_size + avail_size + 3) & ~3u;
    u32 used_size = 2 + 2 + 8 * qsz;
    u32 total = used_off + used_size;

    /* P0-6 FIX: the virtqueue (desc table + avail ring + used ring) must be
     * physically contiguous. For qsz=256 the total is ~6.7 KiB (2 pages).
     * Previously we allocated individual 4 KiB pages that were NOT
     * contiguous, so the used ring pointer (at offset ~4612) ended up
     * outside the allocation — an out-of-bounds write that corrupted
     * random kernel memory. Now we use mem_pmm_alloc_contig to get a proper
     * contiguous run. */
    int npages = (int)((total + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
    u8 *base = (u8 *)mem_pmm_alloc_contig((u64)npages);
    if (!base) {
        /* Fallback: try single page (only works for qsz <= ~170). */
        base = (u8 *)mem_pmm_alloc_frame();
        if (!base) return -1;
        if (npages > 1) {
            /* Not enough contiguous memory — fail gracefully. */
            mem_pmm_free_frame((u64)base);
            return -1;
        }
    }
    memset(base, 0, (u64)npages * PMM_PAGE_SIZE);

    *descs = (net_virtq_desc_t *)base;
    *avail = (net_virtq_avail_t *)(base + desc_size);
    *used = (net_virtq_used_t *)(base + used_off);
    *pages_out = base;
    return 0;
}

static int net_virtio_init(void) {
    /* Find virtio-net on PCI bus. */
    u8 bus, dev, func;
    if (driver_pci_find_device(VIRTIO_NET_VENDOR_ID, VIRTIO_NET_DEVICE_ID,
                        &bus, &dev, &func) != 0) {
        screen_console_puts("virtio-net: no device found\n");
        return -1;
    }

    /* Read BAR0 (I/O port base for legacy virtio). */
    u32 bar0_raw = driver_pci_read_config(bus, dev, func, 0x10);
    u32 bar0 = driver_pci_read_bar(bus, dev, func, 0);
    if (bar0 == 0) {
        screen_console_puts("virtio-net: BAR0 is zero\n");
        return -1;
    }
    g_virtio_io_base = bar0;

    char buf[80]; char n[20];
    strcpy(buf, "virtio-net: found at "); u64_to_str(bus, n); strcat(buf, n);
    strcat(buf, ":"); u64_to_str(dev, n); strcat(buf, n);
    strcat(buf, "."); u64_to_str(func, n); strcat(buf, n);
    strcat(buf, " BAR0_raw=0x"); u64_to_hex(bar0_raw, n, 8); strcat(buf, n);
    strcat(buf, " I/O=0x"); u64_to_hex(bar0, n, 4); strcat(buf, n);
    strcat(buf, "\n");
    screen_console_puts(buf);

    /* Enable bus mastering and I/O access. */
    u32 cmd = driver_pci_read_config(bus, dev, func, 0x04);
    cmd |= 0x05;  /* BM + IO enable */
    driver_pci_write_config(bus, dev, func, 0x04, cmd);

    /* Read MAC address from device config (at I/O offset 20-25 for virtio-net). */
    for (int i = 0; i < 6; i++) {
        g_mac[i] = inb(g_virtio_io_base + 20 + i);
    }

    /* Reset device: write 0 to status. */
    outb(g_virtio_io_base + VIRTIO_PCI_STATUS, 0);

    /* Acknowledge device. */
    outb(g_virtio_io_base + VIRTIO_PCI_STATUS,
         VIRTIO_STATUS_ACK | VIRTIO_STATUS_DRIVER);

    /* Read host features and negotiate (only MAC feature). */
    u32 host_features = inl(g_virtio_io_base + VIRTIO_PCI_HOST_FEATURES);
    u32 guest_features = 0;
    if (host_features & VIRTIO_NET_F_MAC) {
        guest_features |= VIRTIO_NET_F_MAC;
    }
    outl(g_virtio_io_base + VIRTIO_PCI_GUEST_FEATURES, guest_features);

    /* NOTE: For legacy virtio, FEATURES_OK bit doesn't exist. We just set
     * ACK | DRIVER now, and set DRIVER_OK after queues are initialized. */

    /* Initialize RX virtqueue (queue 0). */
    outw(g_virtio_io_base + VIRTIO_PCI_QUEUE_SELECT, VIRTIO_NET_Q_RX);
    u16 rx_size = inw(g_virtio_io_base + VIRTIO_PCI_QUEUE_SIZE);
    if (rx_size == 0) return -1;
    /* Use the actual device queue size. Cap at 256 to limit memory usage. */
    if (rx_size > 256) rx_size = 256;
    g_virtio_rx_size = rx_size;   /* BUG-0202: remember the negotiated size */

    if (net_virtio_alloc_virtq(&g_vrx_descs, &g_vrx_avail, &g_vrx_used,
                           &g_vrx_pages, rx_size) != 0) return -1;

    /* Allocate RX buffers and populate descriptors. */
    for (int i = 0; i < rx_size; i++) {
        g_vrx_bufs[i] = (u8 *)mem_pmm_alloc_frame();
        if (!g_vrx_bufs[i]) return -1;
        g_vrx_descs[i].addr = (u64)(uintptr_t)g_vrx_bufs[i];
        g_vrx_descs[i].len = VIRTIO_BUF_SIZE;
        g_vrx_descs[i].flags = VIRTQ_DESC_F_WRITE;
        g_vrx_descs[i].next = 0;
        g_vrx_avail->ring[g_vrx_avail_idx % rx_size] = (u16)i;
        g_vrx_avail_idx++;
    }
    g_vrx_avail->idx = g_vrx_avail_idx;
    g_vrx_used_idx = 0;

    /* Set queue PFN. */
    u32 rx_pfn = (u32)(uintptr_t)g_vrx_pages / PMM_PAGE_SIZE;
    outl(g_virtio_io_base + VIRTIO_PCI_QUEUE_PFN, rx_pfn);

    /* Debug: print queue info. */
    {
        char buf2[80]; char n2[20];
        strcpy(buf2, "virtio-net: RX qsz="); u64_to_str(rx_size, n2); strcat(buf2, n2);
        strcat(buf2, " PFN="); u64_to_str(rx_pfn, n2); strcat(buf2, n2);
        strcat(buf2, " page=0x"); u64_to_hex((u64)(uintptr_t)g_vrx_pages, n2, 8); strcat(buf2, n2);
        strcat(buf2, "\n");
        screen_console_puts(buf2);
    }

    outw(g_virtio_io_base + VIRTIO_PCI_QUEUE_NOTIFY, VIRTIO_NET_Q_RX);

    /* Initialize TX virtqueue (queue 1). */
    outw(g_virtio_io_base + VIRTIO_PCI_QUEUE_SELECT, VIRTIO_NET_Q_TX);
    u16 tx_size = inw(g_virtio_io_base + VIRTIO_PCI_QUEUE_SIZE);
    if (tx_size == 0) return -1;
    if (tx_size > VIRTIO_NUM_DESC) tx_size = VIRTIO_NUM_DESC;
    g_virtio_tx_size = tx_size;   /* BUG-0202: remember the negotiated size */

    if (net_virtio_alloc_virtq(&g_vtx_descs, &g_vtx_avail, &g_vtx_used,
                           &g_vtx_pages, tx_size) != 0) return -1;

    for (int i = 0; i < tx_size; i++) {
        g_vtx_bufs[i] = (u8 *)mem_pmm_alloc_frame();
        if (!g_vtx_bufs[i]) return -1;
    }
    g_vtx_avail_idx = 0;
    g_vtx_used_idx = 0;

    u32 tx_pfn = (u32)(uintptr_t)g_vtx_pages / PMM_PAGE_SIZE;
    outl(g_virtio_io_base + VIRTIO_PCI_QUEUE_PFN, tx_pfn);

    /* Debug: verify TX queue setup. */
    {
        char buf2[100]; char n2[20];
        u16 tx_qsz_verify = inw(g_virtio_io_base + VIRTIO_PCI_QUEUE_SIZE);
        u32 tx_pfn_verify = inl(g_virtio_io_base + VIRTIO_PCI_QUEUE_PFN);
        u16 tx_qsel = inw(g_virtio_io_base + VIRTIO_PCI_QUEUE_SELECT);
        strcpy(buf2, "virtio-net: TX qsz="); u64_to_str(tx_size, n2); strcat(buf2, n2);
        strcat(buf2, "("); u64_to_str(tx_qsz_verify, n2); strcat(buf2, n2); strcat(buf2, ")");
        strcat(buf2, " PFN="); u64_to_str(tx_pfn, n2); strcat(buf2, n2);
        strcat(buf2, "("); u64_to_str(tx_pfn_verify, n2); strcat(buf2, n2); strcat(buf2, ")");
        strcat(buf2, " QSEL="); u64_to_str(tx_qsel, n2); strcat(buf2, n2);
        strcat(buf2, " page=0x"); u64_to_hex((u64)(uintptr_t)g_vtx_pages, n2, 8); strcat(buf2, n2);
        strcat(buf2, "\n");
        screen_console_puts(buf2);
    }

    /* NOW set DRIVER_OK — device starts processing queues. */
    outb(g_virtio_io_base + VIRTIO_PCI_STATUS,
         VIRTIO_STATUS_ACK | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_DRIVER_OK);

    g_virtio_ok = 1;
    g_use_virtio = 1;
    return 0;
}

static int net_virtio_send(const void *data, int len) {
    if (!g_virtio_ok || len <= 0)
        return -1;
    if ((u32)len > VIRTIO_BUF_SIZE - sizeof(net_virtio_hdr_t))
        return -1;

    if (g_virtio_tx_size == 0) return -1;   /* queue not initialised */
    /* BUG-0202: modulo the NEGOTIATED tx queue size, not VIRTIO_NUM_DESC. */
    u16 desc_idx = g_vtx_avail_idx % g_virtio_tx_size;

    u8 *buf = g_vtx_bufs[desc_idx];
    net_virtio_hdr_t *hdr = (net_virtio_hdr_t *)buf;
    memset(hdr, 0, sizeof(net_virtio_hdr_t));
    memcpy(buf + sizeof(net_virtio_hdr_t), data, len);

    g_vtx_descs[desc_idx].addr = (u64)(uintptr_t)buf;
    g_vtx_descs[desc_idx].len = sizeof(net_virtio_hdr_t) + len;
    g_vtx_descs[desc_idx].flags = 0;
    g_vtx_descs[desc_idx].next = 0;

    /* Add to avail ring. Memory barriers are critical for virtio. */
    u16 avail_slot = g_vtx_avail_idx % g_virtio_tx_size;   /* BUG-0202 */
    g_vtx_avail->ring[avail_slot] = desc_idx;
    __asm__ volatile("sfence" ::: "memory");  /* wmb: ensure desc + ring write */
    g_vtx_avail->idx = g_vtx_avail_idx + 1;
    __asm__ volatile("sfence" ::: "memory");  /* wmb: ensure idx write visible */
    g_vtx_avail_idx++;

    /* Notify the device (kick the TX queue). */
    outw(g_virtio_io_base + VIRTIO_PCI_QUEUE_NOTIFY, VIRTIO_NET_Q_TX);

    /* Wait for the device to process (poll used ring). */
    u16 old_used = g_vtx_used_idx;
    for (int timeout = 0; timeout < 1000000; timeout++) {
        __asm__ volatile("lfence" ::: "memory");  /* rmb: ensure fresh read */
        u16 cur_used = g_vtx_used->idx;
        if (cur_used != old_used) {
            g_vtx_used_idx = cur_used;
            break;
        }
    }

    /* Debug: if TX didn't complete, dump state. */
    if (g_vtx_used->idx == old_used) {
        u8 isr = inb(g_virtio_io_base + VIRTIO_PCI_ISR);
        u8 status = inb(g_virtio_io_base + VIRTIO_PCI_STATUS);
        char buf[120]; char n[20];
        strcpy(buf, "virtio TX timeout: avail_idx="); u64_to_str(g_vtx_avail_idx, n); strcat(buf, n);
        strcat(buf, " used_idx="); u64_to_str(g_vtx_used->idx, n); strcat(buf, n);
        strcat(buf, " ISR=0x"); u64_to_hex(isr, n, 2); strcat(buf, n);
        strcat(buf, " STATUS=0x"); u64_to_hex(status, n, 2); strcat(buf, n);
        strcat(buf, " desc_addr=0x"); u64_to_hex(g_vtx_descs[desc_idx].addr, n, 16); strcat(buf, n);
        strcat(buf, "\n");
        screen_console_puts(buf);
    }

    g_stats.tx_packets++;
    g_stats.tx_bytes += len;
    return len;
}

static int net_virtio_recv(void *buf, int maxlen) {
    if (!g_virtio_ok) return -1;
    if (g_vrx_used->idx == g_vrx_used_idx) return 0;

    if (g_virtio_rx_size == 0) return -1;   /* queue not initialised */
    /* BUG-0202: modulo the NEGOTIATED rx queue size, not VIRTIO_NUM_DESC. */
    u16 used_idx = g_vrx_used_idx % g_virtio_rx_size;
    u32 desc_id = g_vrx_used->ring[used_idx].id;
    u32 used_len = g_vrx_used->ring[used_idx].len;
    g_vrx_used_idx++;

    /* BUG-0202: the used-ring id is device-controlled — bounds-check it
     * against the negotiated queue size before indexing our arrays. */
    if (desc_id < (u32)g_virtio_rx_size && g_vrx_bufs[desc_id] != NULL) {
        int data_len = (int)used_len - (int)sizeof(net_virtio_hdr_t);
        if (data_len < 0) data_len = 0;
        if (data_len > maxlen) data_len = maxlen;

        u8 *src = g_vrx_bufs[desc_id] + sizeof(net_virtio_hdr_t);
        memcpy(buf, src, data_len);

        /* Recycle the descriptor. */
        g_vrx_descs[desc_id].addr = (u64)(uintptr_t)g_vrx_bufs[desc_id];
        g_vrx_descs[desc_id].len = VIRTIO_BUF_SIZE;
        g_vrx_descs[desc_id].flags = VIRTQ_DESC_F_WRITE;
        g_vrx_avail->ring[g_vrx_avail_idx % g_virtio_rx_size] = desc_id;
        g_vrx_avail_idx++;
        g_vrx_avail->idx = g_vrx_avail_idx;
        outw(g_virtio_io_base + VIRTIO_PCI_QUEUE_NOTIFY, VIRTIO_NET_Q_RX);

        g_stats.rx_packets++;
        g_stats.rx_bytes += data_len;
        return data_len;
    }
    /* Invalid descriptor id from the device: drop the frame (fail closed)
     * without touching the descriptor table or the recycle path. */
    return 0;
}

/* ============================================================
 * e1000 NIC driver
 * ============================================================ */

/* e1000 MMIO register offsets */
#define E1000_CTRL   0x0000
#define E1000_STATUS 0x0008
#define E1000_RCTL   0x0100
#define E1000_TCTL   0x0400
#define E1000_RDBAL  0x2800
#define E1000_RDBAH  0x2804
#define E1000_RDLEN  0x2808
#define E1000_RDH    0x2810
#define E1000_RDT    0x2818
#define E1000_TDBAL  0x3800
#define E1000_TDBAH  0x3804
#define E1000_TDLEN  0x3808
#define E1000_TDH    0x3810
#define E1000_TDT    0x3818
#define E1000_RA     0x5400
#define E1000_IMC    0x00D8  /* Interrupt Mask Clear */

/* RCTL (Receive Control) bit flags -- per Intel 8254x datasheet / QEMU e1000x_regs.h */
#define E1000_RCTL_RST    0x00000001u  /* software reset (self-clearing) */
#define E1000_RCTL_EN     0x00000002u  /* receiver enable */
#define E1000_RCTL_SBP    0x00000004u  /* store bad packets */
#define E1000_RCTL_UPE    0x00000008u  /* unicast promiscuous enable */
#define E1000_RCTL_MPE    0x00000010u  /* multicast promiscuous enable */
#define E1000_RCTL_BAM    0x00008000u  /* broadcast accept mode (REQUIRED for ARP) */
#define E1000_RCTL_SECRC  0x04000000u  /* strip Ethernet CRC from received packets */

/* RX/TX descriptor (legacy format, 16 bytes).
 * For RX: addr(8) + length(2) + checksum(2) + status(1) + errors(1) + special(2)
 * For TX: addr(8) + length(2) + cso(1) + cmd(1) + status(1) + errors(1) + special(2)
 * We use a single struct; the interpretation differs for RX vs TX. */
typedef struct {
    u64 addr;       /* buffer address */
    u16 length;     /* length of data */
    union {
        u16 csum;       /* RX: checksum */
        struct {
            u8 cso;     /* TX: checksum offset */
            u8 cmd;     /* TX: command bits */
        };
    };
    u8  status;     /* status bits */
    u8  errors;     /* error bits */
    u16 special;
} __attribute__((packed)) e1000_desc_t;

#define E1000_NUM_DESC 16
#define E1000_BUF_SIZE 2048

static volatile u32 *g_e1000_mmio = NULL;
static volatile e1000_desc_t *g_rx_descs = NULL;
static volatile e1000_desc_t *g_tx_descs = NULL;
static u8 *g_rx_bufs[E1000_NUM_DESC];
static u8 *g_tx_bufs[E1000_NUM_DESC];
static int g_rx_tail = 0;
static int g_tx_tail = 0;
static u8 g_e1000_bus, g_e1000_dev, g_e1000_func;  /* saved for re-enabling bus master */

static int e1000_init(void) {
    /* Find e1000 on PCI bus. e1000: vendor=0x8086, device=0x100E (or 0x100F, 0x10D3). */
    u8 bus, dev, func;
    int found = -1;
    /* Try common e1000 device IDs */
    u16 devices[] = {0x100E, 0x100F, 0x10D3, 0x10EA};
    for (int i = 0; i < 4; i++) {
        if (driver_pci_find_device(0x8086, devices[i], &bus, &dev, &func) == 0) {
            found = 0;
            break;
        }
    }
    if (found != 0) {
        screen_console_puts("e1000: no NIC found\n");
        return -1;
    }

    /* Save PCI address for later bus master re-enabling. */
    g_e1000_bus = bus;
    g_e1000_dev = dev;
    g_e1000_func = func;

    /* Read BAR0 for MMIO base. */
    u32 bar0 = driver_pci_read_bar(bus, dev, func, 0);
    if (bar0 == 0) {
        screen_console_puts("e1000: BAR0 is zero\n");
        return -1;
    }

    /* Debug: print PCI info. */
    {
        /* BUG-0064 FIX: buf was an uninitialised 80-byte stack array and
         * the debug block started with strcat() - the string length came
         * from whatever garbage was on the stack, so the write could run
         * past the end of the buffer. Start with buf[0]=0. */
        char buf[80]; char n[20];
        u32 shell_cmd_reg = driver_pci_read_config(bus, dev, func, 0x04);
        buf[0] = 0;
        strcat(buf, " dev="); u64_to_str(dev, n); strcat(buf, n);
        strcat(buf, " func="); u64_to_str(func, n); strcat(buf, n);
        strcat(buf, " cmd=0x"); u64_to_hex(shell_cmd_reg, n, 4); strcat(buf, n);
        strcat(buf, "\n");
        screen_console_puts(buf);
    }

    /* Enable bus mastering and MMIO access.
     * Write the FULL 32-bit value to the PCI command register (offset 0x04).
     * The command register is 16-bit at offset 0x04, and the status register
     * is 16-bit at offset 0x06. We write 0x0000x107 where x107 = IO|MEM|BM|SERR.
     * Preserve the status register (high 16 bits) by reading first. */
    u32 shell_cmd_stat = driver_pci_read_config(bus, dev, func, 0x04);
    u32 shell_cmd_only = shell_cmd_stat & 0x0000FFFF;
    u32 stat_only = shell_cmd_stat & 0xFFFF0000;
    shell_cmd_only = 0x0107;  /* IO + MEM + BM + SERR# */
    driver_pci_write_config(bus, dev, func, 0x04, stat_only | shell_cmd_only);

    g_e1000_mmio = (volatile u32 *)(uintptr_t)bar0;

    /* Read MAC address from EEPROM (RA register array). */
    /* For e1000, MAC is at offset 0x5400 (RA[0] low) and 0x5404 (RA[0] high). */
    u32 mac_low = mmio_read32((volatile void *)((u8 *)g_e1000_mmio + E1000_RA));
    u32 mac_high = mmio_read32((volatile void *)((u8 *)g_e1000_mmio + E1000_RA + 4));
    g_mac[0] = mac_low & 0xFF;
    g_mac[1] = (mac_low >> 8) & 0xFF;
    g_mac[2] = (mac_low >> 16) & 0xFF;
    g_mac[3] = (mac_low >> 24) & 0xFF;
    g_mac[4] = mac_high & 0xFF;
    g_mac[5] = (mac_high >> 8) & 0xFF;

    /* If MAC is all zeros, try reading from EEPROM via EERD register. */
    if (g_mac[0] == 0 && g_mac[1] == 0 && g_mac[2] == 0) {
        /* Read EEPROM word 0 and 1. */
        for (int word = 0; word < 3; word++) {
            mmio_write32((volatile void *)((u8 *)g_e1000_mmio + 0x0014),  /* EERD */
                        (u32)(1) | ((u32)word << 8) | (1 << 4));  /* START + addr */
            u32 val = 0;
            for (int timeout = 0; timeout < 1000; timeout++) {
                val = mmio_read32((volatile void *)((u8 *)g_e1000_mmio + 0x0014));
                if (val & (1 << 9)) break;  /* DONE */
            }
            u16 data = (u16)((val >> 16) & 0xFFFF);
            if (word == 0) {
                g_mac[0] = data & 0xFF;
                g_mac[1] = (data >> 8) & 0xFF;
            } else if (word == 1) {
                g_mac[2] = data & 0xFF;
                g_mac[3] = (data >> 8) & 0xFF;
            } else {
                g_mac[4] = data & 0xFF;
                g_mac[5] = (data >> 8) & 0xFF;
            }
        }
    }

    /* Skip the e1000 software reset — it clears the PCI command register
     * which disables bus mastering. Instead, just set CTRL directly. */

    /* Set CTRL register:
     *   bit 0: FD (Full Duplex)
     *   bit 5: ASDE (Auto-Speed Detect Enable)
     *   bit 6: SLU (Set Link Up)
     *   bit 11: FRCSPD (Force Speed)
     *   bit 12: FRCFD (Force Full Duplex)
     * Don't set RST (bit 26) — it clears PCI command register.
     */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_CTRL),
                (1u << 0) | (1u << 6) | (1u << 11) | (1u << 12));

    /* Disable interrupts. */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_IMC), 0xFFFFFFFF);

    /* CRITICAL: Enable PCI bus master. This MUST be done after any device
     * reset, because the reset clears the PCI command register.
     * Without bus master, QEMU's e1000 reports driver_pci_master=0 and refuses
     * to process any TX/RX descriptors (no DMA). */
    {
        u32 shell_cmd_before = driver_pci_read_config(bus, dev, func, 0x04);
        u32 shell_cmd_new = shell_cmd_before | 0x07;
        driver_pci_write_config(bus, dev, func, 0x04, shell_cmd_new);
        u32 shell_cmd_after = driver_pci_read_config(bus, dev, func, 0x04);
        char dbuf[100]; char dn[20];
        dbuf[0] = 0;   /* BUG-0064 FIX: same uninitialised-strcat issue */
            strcat(dbuf, " wrote=0x"); u64_to_hex(shell_cmd_new, dn, 4); strcat(dbuf, dn);
        strcat(dbuf, " after=0x"); u64_to_hex(shell_cmd_after, dn, 4); strcat(dbuf, dn);
        strcat(dbuf, " bus="); u64_to_str(bus, dn); strcat(dbuf, dn);
        strcat(dbuf, " dev="); u64_to_str(dev, dn); strcat(dbuf, dn);
        strcat(dbuf, " func="); u64_to_str(func, dn); strcat(dbuf, dn);
        strcat(dbuf, "\n");
        screen_console_puts(dbuf);
    }

    /* Set Receive Address Register (RA[0]) to our MAC. */
    u32 ra_lo = g_mac[0] | ((u32)g_mac[1] << 8) | ((u32)g_mac[2] << 16) | ((u32)g_mac[3] << 24);
    u32 ra_hi = g_mac[4] | ((u32)g_mac[5] << 8) | (1u << 31);  /* AV bit */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RA), ra_lo);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RA + 4), ra_hi);

    /* Clear the Multicast Table Array (MTA) - 128 entries at 0x5200.
     * All zeros = accept no multicast (but we have MPE set in RCTL). */
    for (int i = 0; i < 128; i++) {
        mmio_write32((volatile void *)((u8 *)g_e1000_mmio + 0x5200 + i * 4), 0);
    }

    /* Allocate RX descriptors as a full page (page-aligned, identity-mapped). */
    g_rx_descs = (volatile e1000_desc_t *)mem_pmm_alloc_frame();
    if (!g_rx_descs) return -1;
    memset((void*)g_rx_descs, 0, PMM_PAGE_SIZE);
    uintptr_t rx_descs_phys = (uintptr_t)g_rx_descs;

    /* Allocate RX buffers (identity-mapped). */
    for (int i = 0; i < E1000_NUM_DESC; i++) {
        g_rx_bufs[i] = (u8 *)dma_alloc(E1000_BUF_SIZE);
        if (!g_rx_bufs[i]) return -1;
        g_rx_descs[i].addr = (u64)(uintptr_t)g_rx_bufs[i];
        g_rx_descs[i].status = 0;
    }
    g_rx_tail = 0;

    /* Disable RX before programming (RCTL.EN = 0). */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RCTL), 0);

    /* Configure RX registers. */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDBAL), (u32)rx_descs_phys);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDBAH), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDLEN),
                sizeof(e1000_desc_t) * E1000_NUM_DESC);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDH), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDT), E1000_NUM_DESC - 1);

    /* NOW enable RX.
     * RCTL bit layout (per Intel 8254x datasheet / QEMU e1000x_regs.h):
     *   RST=0x01  EN=0x02  SBP=0x04  UPE=0x08  MPE=0x10
     *   BAM=0x8000 (broadcast accept)  SECRC=0x04000000 (strip CRC)
     *
     * BAM (Broadcast Accept Mode) is REQUIRED: without it the e1000 silently
     * drops Ethernet broadcast frames, which breaks ARP (ARP requests are
     * broadcasts).  This was the root cause why slirp (unicast-only) worked
     * but direct L2 networking (socket-mode / TAP) failed -- the NIC never
     * saw ARP requests, so net_arp_resolve() always timed out.
     *
     * UPE+MPE put the NIC in promiscuous mode (accept all unicast/multicast),
     * which is fine for this hobby OS and makes it robust to any MAC.
     */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RCTL),
                E1000_RCTL_EN | E1000_RCTL_UPE | E1000_RCTL_MPE |
                E1000_RCTL_BAM | E1000_RCTL_SECRC);

    /* Allocate TX descriptor ring as a full page (page-aligned, identity-mapped). */
    g_tx_descs = (volatile e1000_desc_t *)mem_pmm_alloc_frame();
    if (!g_tx_descs) return -1;
    memset((void*)g_tx_descs, 0, PMM_PAGE_SIZE);
    uintptr_t tx_descs_phys = (uintptr_t)g_tx_descs;

    /* Allocate TX buffers (identity-mapped). */
    for (int i = 0; i < E1000_NUM_DESC; i++) {
        g_tx_bufs[i] = (u8 *)dma_alloc(E1000_BUF_SIZE);
        if (!g_tx_bufs[i]) return -1;
    }
    g_tx_tail = 0;

    /* Disable TX before programming (TCTL.EN = 0). */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TCTL), 0);

    /* Configure TX descriptor ring registers. */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDBAL), (u32)tx_descs_phys);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDBAH), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDLEN),
                sizeof(e1000_desc_t) * E1000_NUM_DESC);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDH), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDT), 0);

    /* Set TIPG (Transmit Inter-Packet Gap).
     * IPGT=9, IPGR1=8, IPGR2=6. */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + 0x0410), 0x0060200A);

    /* Enable TX.
     * TCTL register bits for e1000 (82540EM):
     *   bit 1: EN (Enable) = 0x02
     *   bit 3: PSP (Pad Short Packets)
     *   bits 4-7: CT (Collision Threshold) = 0x0F
     *   bits 12-21: COLD (Collision Distance) = 0x3F for full-duplex */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TCTL),
                (1u << 1)       /* EN = bit 1, NOT bit 0! */
                | (1u << 3)     /* PSP */
                | (0x0F << 4)   /* CT = 15 */
                | (0x3F << 12)); /* COLD = 63 (full-duplex) */

    /* CRITICAL: Enable PCI bus master as the VERY LAST step.
     * QEMU's e1000 device model caches the driver_pci_master flag from the PCI
     * command register. Any MMIO write (especially CTRL) may trigger
     * internal state changes that reset this cache. By enabling bus master
     * last, we ensure it's set when we start sending packets. */
    {
        u32 cs = driver_pci_read_config(bus, dev, func, 0x04);
        cs = (cs & 0xFFFF0000) | 0x0107;  /* preserve status, set cmd */
        driver_pci_write_config(bus, dev, func, 0x04, cs);
    }

    g_nic_ok = 1;
    return 0;
}

static int e1000_send(const void *data, int len) {
    if (!g_nic_ok || len <= 0 || len > E1000_BUF_SIZE) return -1;

    /* Copy data to TX buffer. */
    memcpy(g_tx_bufs[g_tx_tail], data, len);

    /* Set up TX descriptor. */
    g_tx_descs[g_tx_tail].addr = (u64)(uintptr_t)g_tx_bufs[g_tx_tail];
    g_tx_descs[g_tx_tail].length = (u16)len;
    g_tx_descs[g_tx_tail].cso = 0;
    g_tx_descs[g_tx_tail].cmd = 0x0B;  /* EOP | IFCS | RS */
    g_tx_descs[g_tx_tail].status = 0;
    g_tx_descs[g_tx_tail].errors = 0;
    g_tx_descs[g_tx_tail].special = 0;

    /* Advance tail. */
    int old_tail = g_tx_tail;
    g_tx_tail = (g_tx_tail + 1) % E1000_NUM_DESC;

    /* Re-assert PCI bus master right before writing TDT. QEMU's e1000
     * checks driver_pci_bus_master() on every TX attempt; some MMIO writes to
     * CTRL can clear the PCI command register. */
    {
        u32 cs = driver_pci_read_config(g_e1000_bus, g_e1000_dev, g_e1000_func, 0x04);
        if (!(cs & 0x04)) {
            cs = (cs & 0xFFFF0000) | 0x0107;
            driver_pci_write_config(g_e1000_bus, g_e1000_dev, g_e1000_func, 0x04, cs);
        }
    }

    /* Make sure descriptor writes are visible before TDT write. */
    __asm__ volatile("sfence" ::: "memory");

    /* P2-07 FIX: removed the TCTL.EN toggle and all the debug
     * screen_console_puts() / u64_to_str() dumping that ran on every TX
     * path. The toggle was a debug rescue mechanism, not part of the
     * normal hardware path — the e1000 datasheet says TDT writes alone
     * are sufficient to launch a TX descriptor. */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDT), (u32)g_tx_tail);
    __asm__ volatile("mfence" ::: "memory");

    /* Wait for TX to complete (DD bit in status). Poll for up to 1 s. */
    for (int timeout = 0; timeout < 1000000; timeout++) {
        if (g_tx_descs[old_tail].status & 0x01) break;
    }

    g_stats.tx_packets++;
    g_stats.tx_bytes += len;
    return len;
}

static int e1000_recv(void *buf, int maxlen) {
    if (!g_nic_ok) return -1;

    /* Check if RX descriptor has a packet (DD bit = bit0 of status). */
    if (!(g_rx_descs[g_rx_tail].status & 0x01)) {
        return 0;  /* no packet */
    }

    int len = g_rx_descs[g_rx_tail].length;
    if (len > maxlen) len = maxlen;
    if (len > 0) {
        memcpy(buf, g_rx_bufs[g_rx_tail], len);
    }

    /* Reset descriptor and advance tail. */
    g_rx_descs[g_rx_tail].status = 0;
    g_rx_descs[g_rx_tail].addr = (u64)(uintptr_t)g_rx_bufs[g_rx_tail];
    g_rx_descs[g_rx_tail].length = 0;
    g_rx_descs[g_rx_tail].errors = 0;
    g_rx_tail = (g_rx_tail + 1) % E1000_NUM_DESC;
    /* CRITICAL: RDT must point to the LAST AVAILABLE descriptor (one before g_rx_tail).
     * If we set RDT = g_rx_tail, and RDH == g_rx_tail, QEMU thinks the ring is full
     * and stops receiving. Setting RDT = (g_rx_tail - 1 + N) % N ensures there's
     * always at least one available descriptor between RDH and RDT. */
    u32 new_rdt = (g_rx_tail + E1000_NUM_DESC - 1) % E1000_NUM_DESC;
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDT), new_rdt);

    g_stats.rx_packets++;
    g_stats.rx_bytes += len;
    return len;
}

/* ============================================================
 * Ethernet layer
 * ============================================================ */
typedef struct __attribute__((packed)) {
    u8 dst[6];
    u8 src[6];
    u16 ethertype;
} eth_hdr_t;

static int eth_send(const u8 *dst, u16 ethertype, const void *payload, int len) {
    if (!g_nic_ok) return -1;
    /* P0-7 FIX: bound payload to the Ethernet MTU (1500). */
    if (len < 0) return -1;
    if (len > 1500) len = 1500;
    u8 frame[ETH_FRAME_MAX];
    eth_hdr_t *eh = (eth_hdr_t *)frame;
    memcpy(eh->dst, dst, 6);
    memcpy(eh->src, g_mac, 6);
    eh->ethertype = htons(ethertype);
    int total = 14 + len;
    if (total < 60) total = 60;  /* minimum frame size */
    memcpy(frame + 14, payload, len);
    for (int i = 14 + len; i < total; i++) frame[i] = 0;
    /* WP-10b: route through the nic framework when one of the WP-10b
     * drivers owns the hardware. */
    {
        driver_nic_device_t *nd = driver_nic_active();
        if (nd) return driver_nic_send(nd, frame, total);
    }
    if (g_use_virtio) {
        return net_virtio_send(frame, total);
    }
    return e1000_send(frame, total);
}

/* ============================================================
 * ARP layer
 * ============================================================ */
typedef struct __attribute__((packed)) {
    u16 htype;
    u16 ptype;
    u8  hlen;
    u8  plen;
    u16 op;
    u8  sha[6];
    u32 spa;
    u8  tha[6];
    u32 tpa;
} net_arp_pkt_t;

#define ARP_CACHE_SIZE 16
/* BUG-0204: ARP cache entry lifetime. Entries older than 5 minutes are
 * aged out (lazy expiry on lookup + list); a stale MAC must never be
 * used to deliver frames forever (hosts move / IPs get reassigned). */
#define ARP_CACHE_TTL_TICKS (300u * OC_TIMER_HZ)   /* 300 s @ 100 Hz */
/* net_arp_entry_t is defined in net.h */

static net_arp_entry_t g_arp_cache[ARP_CACHE_SIZE];
static int g_arp_reply_received = 0;
static u8  g_arp_reply_mac[6];

/* WP-09: Routing table */
#define ROUTE_TABLE_SIZE 16
/* route_entry_t is defined in net.h */

static route_entry_t g_routes[ROUTE_TABLE_SIZE];

static void route_init(void) {
    memset(g_routes, 0, sizeof(g_routes));
}

/* WP-09: route_add — add a route entry */
int route_add(u32 dst, u32 mask, u32 gateway) {
    for (int i = 0; i < ROUTE_TABLE_SIZE; i++) {
        if (g_routes[i].in_use && g_routes[i].dst == dst && g_routes[i].mask == mask) {
            g_routes[i].gateway = gateway;  /* update existing */
            return 0;
        }
    }
    for (int i = 0; i < ROUTE_TABLE_SIZE; i++) {
        if (!g_routes[i].in_use) {
            g_routes[i].dst = dst;
            g_routes[i].mask = mask;
            g_routes[i].gateway = gateway;
            g_routes[i].in_use = 1;
            return 0;
        }
    }
    return -1;  /* table full */
}

/* WP-09: route_del — remove a route entry */
int route_del(u32 dst, u32 mask) {
    for (int i = 0; i < ROUTE_TABLE_SIZE; i++) {
        if (g_routes[i].in_use && g_routes[i].dst == dst && g_routes[i].mask == mask) {
            g_routes[i].in_use = 0;
            return 0;
        }
    }
    return -1;  /* not found */
}

/* WP-09: route_list — list all routes (returns count) */
int route_list(route_entry_t *out, int max) {
    int count = 0;
    for (int i = 0; i < ROUTE_TABLE_SIZE && count < max; i++) {
        if (g_routes[i].in_use) {
            out[count++] = g_routes[i];
        }
    }
    return count;
}

/* WP-09: route_lookup — find next hop for a destination IP.
 * Returns gateway IP (0 = direct/deliver), or -1 if no route found. */
static int route_lookup(u32 dst_ip, u32 *gateway_out) {
    u32 best_mask = 0;
    u32 best_gw = 0;
    int found = 0;
    for (int i = 0; i < ROUTE_TABLE_SIZE; i++) {
        if (!g_routes[i].in_use) continue;
        if ((dst_ip & g_routes[i].mask) == (g_routes[i].dst & g_routes[i].mask)) {
            if (g_routes[i].mask >= best_mask) {
                best_mask = g_routes[i].mask;
                best_gw = g_routes[i].gateway;
                found = 1;
            }
        }
    }
    if (found) {
        *gateway_out = best_gw;
        return 0;
    }
    return -1;
}

/* WP-09: net_arp_refresh — proactively refresh an ARP entry */
int net_arp_refresh(u32 ip) {
    /* Invalidate cache entry and re-resolve */
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (g_arp_cache[i].valid && g_arp_cache[i].ip == ip) {
            g_arp_cache[i].valid = 0;  /* invalidate */
        }
    }
    u8 mac[6];
    return net_arp_resolve(ip, mac);  /* re-resolve (sends ARP request) */
}

/* WP-09: net_arp_list — list ARP cache entries */
int net_arp_list(net_arp_entry_t *out, int max) {
    int count = 0;
    for (int i = 0; i < ARP_CACHE_SIZE && count < max; i++) {
        if (g_arp_cache[i].valid) {
            out[count++] = g_arp_cache[i];
        }
    }
    return count;
}

static void net_arp_init(void) {
    memset(g_arp_cache, 0, sizeof(g_arp_cache));
    route_init();
}

static int net_arp_cache_lookup(u32 ip, u8 *mac) {
    u64 now = core_timer_ticks();
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (g_arp_cache[i].valid && g_arp_cache[i].ip == ip) {
            /* BUG-0204(a): age out entries past the TTL. */
            if (now - g_arp_cache[i].timestamp >= ARP_CACHE_TTL_TICKS) {
                g_arp_cache[i].valid = 0;
                continue;
            }
            memcpy(mac, g_arp_cache[i].mac, 6);
            return 0;
        }
    }
    return -1;
}

static void net_arp_cache_add(u32 ip, const u8 *mac) {
    u64 now = core_timer_ticks();
    /* Refresh an existing entry (BUG-0204(a): timestamp always updated). */
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (g_arp_cache[i].valid && g_arp_cache[i].ip == ip) {
            memcpy(g_arp_cache[i].mac, mac, 6);
            g_arp_cache[i].timestamp = now;
            return;
        }
    }
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (!g_arp_cache[i].valid) {
            g_arp_cache[i].ip = ip;
            memcpy(g_arp_cache[i].mac, mac, 6);
            g_arp_cache[i].valid = 1;
            g_arp_cache[i].timestamp = now;
            return;
        }
    }
    /* BUG-0204(b): cache full — evict the OLDEST entry (smallest
     * timestamp), not slot 0, so hot recent mappings survive. */
    int oldest = 0;
    for (int i = 1; i < ARP_CACHE_SIZE; i++) {
        if (g_arp_cache[i].timestamp < g_arp_cache[oldest].timestamp) oldest = i;
    }
    g_arp_cache[oldest].ip = ip;
    memcpy(g_arp_cache[oldest].mac, mac, 6);
    g_arp_cache[oldest].valid = 1;
    g_arp_cache[oldest].timestamp = now;
}

static void net_arp_handle_packet(const net_arp_pkt_t *pkt, int len) {
    /* BUG-0204(d): the frame length was previously discarded with
     * (void)len; a truncated Ethernet frame could be parsed past its end
     * (the ARP packet struct is 28 bytes). Bounds-check before parse. */
    if (len < (int)sizeof(net_arp_pkt_t)) return;
    if (ntohs(pkt->htype) != 1 || ntohs(pkt->ptype) != ETH_TYPE_IP) return;
    if (pkt->hlen != 6 || pkt->plen != 4) return;

    u16 op = ntohs(pkt->op);
    u32 sender_ip = ntohl(pkt->spa);
    u32 target_ip = ntohl(pkt->tpa);

    /* Add sender to cache. */
    net_arp_cache_add(sender_ip, pkt->sha);

    if (op == 2) {
        /* ARP reply: save MAC for net_arp_resolve. */
        memcpy(g_arp_reply_mac, pkt->sha, 6);
        g_arp_reply_received = 1;
        g_stats.net_arp_replies++;
    } else if (op == 1) {
        /* ARP request: if target is us, send reply. */
        g_stats.net_arp_requests++;
        if (target_ip == g_ip && g_ip != 0) {
            u8 reply[sizeof(net_arp_pkt_t)];
            net_arp_pkt_t *r = (net_arp_pkt_t *)reply;
            r->htype = htons(1);
            r->ptype = htons(ETH_TYPE_IP);
            r->hlen = 6;
            r->plen = 4;
            r->op = htons(2);  /* reply */
            memcpy(r->sha, g_mac, 6);
            r->spa = htonl(g_ip);
            memcpy(r->tha, pkt->sha, 6);
            r->tpa = pkt->spa;
            eth_send(pkt->sha, ETH_TYPE_ARP, reply, sizeof(net_arp_pkt_t));
        }
    }
}

int net_arp_resolve(u32 ip, u8 *mac_out) {
    /* Check cache first. */
    if (net_arp_cache_lookup(ip, mac_out) == 0) return 0;

    /* Send ARP request. */
    u8 broadcast[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    u8 req_buf[sizeof(net_arp_pkt_t)];
    net_arp_pkt_t *req = (net_arp_pkt_t *)req_buf;
    req->htype = htons(1);
    req->ptype = htons(ETH_TYPE_IP);
    req->hlen = 6;
    req->plen = 4;
    req->op = htons(1);  /* request */
    memcpy(req->sha, g_mac, 6);
    req->spa = htonl(g_ip);
    memset(req->tha, 0, 6);
    req->tpa = htonl(ip);

    /* Send the first ARP request; up to two retries are sent while the
     * resolve is still pending (BUG-0204(c): a single request that gets
     * lost used to burn the whole 3-second timeout). */
    g_arp_reply_received = 0;

    /* Wait for reply with timeout (3 seconds at 100Hz = 300 ticks). */
    u64 start = core_timer_ticks();
    int requests = 0;
    while ((core_timer_ticks() - start) < 300) {
        u64 now = core_timer_ticks();
        /* Bounded re-request: one request every 100 ticks, max 3 total. */
        if (requests < 3 && (u32)(now - start) >= (u32)requests * 100) {
            eth_send(broadcast, ETH_TYPE_ARP, req_buf, sizeof(net_arp_pkt_t));
            requests++;
        }
        net_poll();
        if (g_arp_reply_received) {
            memcpy(mac_out, g_arp_reply_mac, 6);
            return 0;
        }
    }
    return -1;  /* timeout */
}

int net_arp_get_cache(int index, u32 *ip, u8 *mac) {
    int count = 0;
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (g_arp_cache[i].valid) {
            if (count == index) {
                *ip = g_arp_cache[i].ip;
                memcpy(mac, g_arp_cache[i].mac, 6);
                return 0;
            }
            count++;
        }
    }
    return -1;
}

/* ============================================================
 * IP layer
 * ============================================================ */
typedef struct __attribute__((packed)) {
    u8  ver_ihl;
    u8  tos;
    u16 total_len;
    u16 id;
    u16 flags_frag;
    u8  ttl;
    u8  protocol;
    u16 checksum;
    u32 src_ip;
    u32 dst_ip;
} net_ip_hdr_t;

static u16 g_ip_id = 1;

/* forward declarations: the OUTPUT hook runs inside net_ip_send, which is
 * defined before the netfilter helpers below */
static u8 net_netfilter_check(u8 chain, u32 src_ip, u32 dst_ip, u8 protocol,
                          u16 sport, u16 dport, u8 state);
static void net_netfilter_send_icmp_unreachable(u32 src_ip, const void *orig_pkt, int orig_len);
/* BUG-0217: rate-limited ICMP port-unreachable, defined near the ICMP layer. */
static void net_icmp_send_port_unreachable(u32 dst_ip, const void *orig_pkt, int orig_len);

static int net_ip_send(u32 dst_ip, u8 protocol, const void *payload, int len) {
    /* P2-08 FIX: use a consistent IP payload MTU. The Ethernet frame
     * payload is 1500 bytes (ETH_FRAME_MAX 1514 - 14 eth header). The
     * IP header is 20 bytes, so the IP *payload* MTU is 1500 - 20 = 1480
     * bytes. The previous code clamped to 1494 with a comment that
     * contradicted the math ("... = 1480, use 1494 to be safe").
     * This matches net_udp_send (clamp to 1492 so 1492 + 8 = 1500) and
     * net_tcp_send_raw (clamp to 1480 so 1480 + 20 = 1500). */
    if (len < 0) return -1;
    if (len > 1480) len = 1480;  /* 1500 - 20 (IP header) */
    /* Unspecified destination: drop silently (used by the CC simulation,
     * which must not inject real packets or attract peer RSTs). */
    if (dst_ip == 0) return -1;

    /* WP-09 mainstream: Netfilter OUTPUT chain — parse transport ports and
     * classify the outbound flow before it leaves the kernel. */
    {
        u8 proto = protocol;
        const u8 *pl = (const u8 *)payload;
        u16 sport = 0, dport = 0;
        u16 out_flags = 0;
        if ((proto == IP_PROTO_TCP || proto == IP_PROTO_UDP) && len >= 4) {
            sport = (u16)((pl[0] << 8) | pl[1]);
            dport = (u16)((pl[2] << 8) | pl[3]);
        }
        if (proto == IP_PROTO_TCP && len >= 14) {
            out_flags = pl[13];
        }
        u8 state = net_netfilter_ct_classify(proto, g_ip, sport, dst_ip, dport, 1,
                                         out_flags);
        u8 verdict = net_netfilter_check(NF_CHAIN_OUTPUT, g_ip, dst_ip,
                                     proto, sport, dport, state);
        if (verdict != NF_ACTION_ACCEPT) {
            if (verdict == NF_ACTION_REJECT) g_stats.net_netfilter_reject++;
            else g_stats.net_netfilter_drop++;
            return -1;   /* blocked by firewall */
        }
    }

    /* Resolve destination MAC (via gateway if needed). */
    u32 next_hop = dst_ip;
    /* Broadcast addresses (255.255.255.255 or subnet broadcast) go directly,
     * not through the gateway. This is critical for DHCP. */
    if (dst_ip == 0xFFFFFFFF || ((dst_ip & g_mask) == (g_ip & g_mask) && (dst_ip & ~g_mask) == ~g_mask)) {
        /* Broadcast: send to FF:FF:FF:FF:FF:FF directly. */
        u8 bcast[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
        u8 buf[ETH_FRAME_MAX];
        net_ip_hdr_t *iph = (net_ip_hdr_t *)buf;
        iph->ver_ihl = 0x45;
        iph->tos = 0;
        iph->total_len = htons((u16)(20 + len));
        iph->id = htons(g_ip_id++);
        iph->flags_frag = htons(0x4000);
        iph->ttl = 64;
        iph->protocol = protocol;
        iph->src_ip = htonl(g_ip);
        iph->dst_ip = htonl(dst_ip);
        iph->checksum = 0;
        iph->checksum = internet_checksum(iph, 20, 0);
        memcpy(buf + 20, payload, len);
        return eth_send(bcast, ETH_TYPE_IP, buf, 20 + len);
    }
    if ((dst_ip & g_mask) != (g_ip & g_mask)) {
        /* WP-09: Use routing table first, then fall back to default gateway */
        u32 gw = 0;
        if (route_lookup(dst_ip, &gw) == 0 && gw != 0) {
            next_hop = gw;  /* route found via routing table */
        } else if (g_gateway != 0) {
            next_hop = g_gateway;  /* default gateway */
        } else {
            return -1;  /* no route */
        }
    }

    u8 dst_mac[6];
    if (net_arp_resolve(next_hop, dst_mac) != 0) return -1;

    u8 buf[ETH_FRAME_MAX];
    net_ip_hdr_t *iph = (net_ip_hdr_t *)buf;
    iph->ver_ihl = 0x45;
    iph->tos = 0;
    iph->total_len = htons((u16)(20 + len));
    iph->id = htons(g_ip_id++);
    iph->flags_frag = htons(0x4000);  /* Don't Fragment */
    iph->ttl = 64;
    iph->protocol = protocol;
    iph->src_ip = htonl(g_ip);
    iph->dst_ip = htonl(dst_ip);
    iph->checksum = 0;
    iph->checksum = internet_checksum(iph, 20, 0);

    memcpy(buf + 20, payload, len);

    return eth_send(dst_mac, ETH_TYPE_IP, buf, 20 + len);
}

/* WP-09 mainstream: Netfilter firewall subsystem
 * Three chains (INPUT/OUTPUT/FORWARD), per-chain default policy, stateful
 * rules (NEW/ESTABLISHED) backed by a connection-tracking table, per-rule
 * hit counters, L1 hooks, and REJECT (drop + ICMP dest-unreachable on
 * INPUT). FORWARD is enforced on any transit traffic if IP forwarding is
 * ever enabled (g_ip_forward; the L0 image ships with one NIC and no
 * forwarding path, so the chain is wired but dormant). */
#define NF_MAX_RULES 32
#define NF_CT_MAX 32
#define NF_CT_TIMEOUT 600   /* 60 s flow idle timeout (ticks) */
/* net_netfilter_rule_t, net_netfilter_hook_fn, NF_CHAIN_*, NF_ACTION_* are defined in net.h */

static net_netfilter_rule_t g_nf_rules[NF_MAX_RULES];
static net_netfilter_hook_fn g_nf_hooks[4];  /* L1 hooks */
static int g_nf_hook_count = 0;
static u8 g_nf_policy[NF_CHAIN_COUNT] = { NF_ACTION_ACCEPT, NF_ACTION_ACCEPT, NF_ACTION_ACCEPT };
int g_ip_forward = 0;   /* IP forwarding off (single-NIC L0) */


typedef struct {
    u8  protocol;
    u32 src_ip, dst_ip;
    u16 src_port, dst_port;
    u64 last_seen;
    u8  established;   /* 1 = flow seen in both directions */
    int in_use;
} net_netfilter_ct_t;
static net_netfilter_ct_t g_nf_ct[NF_CT_MAX];

/* net_netfilter_ct_classify — look up (and refresh/insert) a flow.
 * Returns NF_STATE_ESTABLISHED when the flow has been seen in both
 * directions, else NF_STATE_NEW. `outbound` marks the direction of THIS
 * packet relative to the kernel (1 = we are the source). */
u8 net_netfilter_ct_classify(u8 protocol, u32 src_ip, u16 src_port,
                         u32 dst_ip, u16 dst_port, int outbound,
                         u16 net_tcp_flags) {
    (void)outbound;   /* direction handled via tuple reversal below */
    net_netfilter_ct_t *free_slot = 0;
    net_netfilter_ct_t *match = 0;
    u64 now = core_timer_ticks();
    for (int i = 0; i < NF_CT_MAX; i++) {
        if (!g_nf_ct[i].in_use) { if (!free_slot) free_slot = &g_nf_ct[i]; continue; }
        if (now - g_nf_ct[i].last_seen > NF_CT_TIMEOUT) {   /* expired */
            g_nf_ct[i].in_use = 0;
            if (!free_slot) free_slot = &g_nf_ct[i];
            continue;
        }
        if (g_nf_ct[i].protocol == protocol &&
            g_nf_ct[i].src_ip == src_ip && g_nf_ct[i].src_port == src_port &&
            g_nf_ct[i].dst_ip == dst_ip && g_nf_ct[i].dst_port == dst_port) {
            match = &g_nf_ct[i];
            break;
        }
    }
    if (!match) {
        /* Also match the reversed tuple so one table row covers both
         * directions of the same flow. */
        for (int i = 0; i < NF_CT_MAX; i++) {
            if (!g_nf_ct[i].in_use) continue;
            if (g_nf_ct[i].protocol == protocol &&
                g_nf_ct[i].src_ip == dst_ip && g_nf_ct[i].src_port == dst_port &&
                g_nf_ct[i].dst_ip == src_ip && g_nf_ct[i].dst_port == src_port) {
                match = &g_nf_ct[i];
                break;
            }
        }
    }
    if (!match) {
        /* New flow: insert in the direction this packet was seen. */
        if (!free_slot) return NF_STATE_NEW;
        free_slot->protocol = protocol;
        free_slot->src_ip = src_ip;
        free_slot->src_port = src_port;
        free_slot->dst_ip = dst_ip;
        free_slot->dst_port = dst_port;
        free_slot->last_seen = now;
        free_slot->established = 0;
        free_slot->in_use = 1;
        return NF_STATE_NEW;
    }
    /* Existing entry. If this packet travels the opposite direction of the
     * stored tuple, the flow is now confirmed bidirectional. A bare SYN
     * (SYN set, ACK clear) does NOT confirm — it is the initial connect
     * attempt. SYN-ACK, data and FIN all do (Linux conntrack semantics). */
    int reversed = (match->src_ip == dst_ip && match->src_port == dst_port &&
                    match->dst_ip == src_ip && match->dst_port == src_port);
    if (reversed && !match->established) {
        int bare_syn = (protocol == IP_PROTO_TCP &&
                        (net_tcp_flags & 0x12) == 0x02);
        if (!bare_syn) match->established = 1;
    }
    match->last_seen = now;
    return match->established ? NF_STATE_ESTABLISHED : NF_STATE_NEW;
}

int net_netfilter_ct_count(void) {
    int n = 0;
    for (int i = 0; i < NF_CT_MAX; i++) if (g_nf_ct[i].in_use) n++;
    return n;
}

void net_netfilter_ct_flush(void) {
    memset(g_nf_ct, 0, sizeof(g_nf_ct));
}

/* WP-09: net_netfilter_register_hook — register an L1 hook function */
void net_netfilter_register_hook(net_netfilter_hook_fn fn) {
    if (g_nf_hook_count < 4) g_nf_hooks[g_nf_hook_count++] = fn;
}

/* WP-09: net_netfilter_add_rule (legacy signature: state = ANY) */
int net_netfilter_add_rule(u8 chain, u32 src_ip, u32 src_mask, u32 dst_ip, u32 dst_mask,
                       u8 protocol, u16 port, u8 action) {
    return net_netfilter_add_rule_st(chain, src_ip, src_mask, dst_ip, dst_mask,
                                 protocol, port, action, NF_STATE_ANY);
}

/* WP-09 mainstream: stateful rule add */
int net_netfilter_add_rule_st(u8 chain, u32 src_ip, u32 src_mask, u32 dst_ip, u32 dst_mask,
                          u8 protocol, u16 port, u8 action, u8 state) {
    if (chain >= NF_CHAIN_COUNT) return -1;
    for (int i = 0; i < NF_MAX_RULES; i++) {
        if (!g_nf_rules[i].in_use) {
            g_nf_rules[i].src_ip = src_ip;
            g_nf_rules[i].src_mask = src_mask;
            g_nf_rules[i].dst_ip = dst_ip;
            g_nf_rules[i].dst_mask = dst_mask;
            g_nf_rules[i].protocol = protocol;
            g_nf_rules[i].port = port;
            g_nf_rules[i].chain = chain;
            g_nf_rules[i].action = action;
            g_nf_rules[i].state = state;
            g_nf_rules[i].hits = 0;
            g_nf_rules[i].in_use = 1;
            return 0;
        }
    }
    return -1;
}

/* WP-09: net_netfilter_del_rule — remove a rule by index */
int net_netfilter_del_rule(int index) {
    if (index < 0 || index >= NF_MAX_RULES) return -1;
    g_nf_rules[index].in_use = 0;
    return 0;
}

void net_netfilter_reset(void) {
    memset(g_nf_rules, 0, sizeof(g_nf_rules));
    memset(g_nf_ct, 0, sizeof(g_nf_ct));
    for (int i = 0; i < NF_CHAIN_COUNT; i++) g_nf_policy[i] = NF_ACTION_ACCEPT;
}

void net_netfilter_set_policy(u8 chain, u8 action) {
    if (chain < NF_CHAIN_COUNT) g_nf_policy[chain] = action;
}

u8 net_netfilter_get_policy(u8 chain) {
    return (chain < NF_CHAIN_COUNT) ? g_nf_policy[chain] : NF_ACTION_ACCEPT;
}

/* WP-09: net_netfilter_list_rules — list all rules */
int net_netfilter_list_rules(net_netfilter_rule_t *out, int max) {
    int count = 0;
    for (int i = 0; i < NF_MAX_RULES && count < max; i++) {
        if (g_nf_rules[i].in_use) out[count++] = g_nf_rules[i];
    }
    return count;
}

/* WP-09 mainstream: net_netfilter_check — check a packet against the rules.
 * sport/dport carry the transport-layer ports (0 for non-TCP/UDP).
 * state is the conntrack classification for this flow.
 * Returns NF_ACTION_ACCEPT/DROP/REJECT. */
static u8 net_netfilter_check(u8 chain, u32 src_ip, u32 dst_ip, u8 protocol,
                          u16 sport, u16 dport, u8 state) {
    /* Call L1 hooks first */
    for (int i = 0; i < g_nf_hook_count; i++) {
        if (g_nf_hooks[i]) {
            int verdict = g_nf_hooks[i](chain, src_ip, dst_ip, protocol, dport);
            if (verdict == NF_ACTION_DROP) return NF_ACTION_DROP;
            if (verdict == NF_ACTION_ACCEPT) return NF_ACTION_ACCEPT;
        }
    }
    /* Check rules in order */
    for (int i = 0; i < NF_MAX_RULES; i++) {
        if (!g_nf_rules[i].in_use) continue;
        if (g_nf_rules[i].chain != chain) continue;
        /* Match source IP */
        if (g_nf_rules[i].src_mask != 0) {
            if ((src_ip & g_nf_rules[i].src_mask) != (g_nf_rules[i].src_ip & g_nf_rules[i].src_mask))
                continue;
        }
        /* Match dest IP */
        if (g_nf_rules[i].dst_mask != 0) {
            if ((dst_ip & g_nf_rules[i].dst_mask) != (g_nf_rules[i].dst_ip & g_nf_rules[i].dst_mask))
                continue;
        }
        /* Match protocol */
        if (g_nf_rules[i].protocol != 0 && g_nf_rules[i].protocol != protocol)
            continue;
        /* Match port (either direction of the connection) */
        if (g_nf_rules[i].port != 0 && g_nf_rules[i].port != sport &&
            g_nf_rules[i].port != dport)
            continue;
        /* Match connection state */
        if (g_nf_rules[i].state != NF_STATE_ANY && g_nf_rules[i].state != state)
            continue;
        /* Rule matched — count and return action */
        g_nf_rules[i].hits++;
        return g_nf_rules[i].action;
    }
    /* Per-chain default policy */
    return g_nf_policy[chain];
}

/* Parse transport ports for the firewall (0 for non-TCP/UDP). */
static void net_netfilter_parse_ports(const void *payload, int payload_len, u8 protocol,
                           u16 *sport, u16 *dport) {
    *sport = 0;
    *dport = 0;
    if (payload_len < 4) return;
    if (protocol == IP_PROTO_TCP || protocol == IP_PROTO_UDP) {
        const u8 *p = (const u8 *)payload;
        *sport = (u16)((p[0] << 8) | p[1]);
        *dport = (u16)((p[2] << 8) | p[3]);
    }
}

static void net_ip_handle_packet(const void *data, int len);

/* ============================================================
 * BUG-0210 (P2 tactical re-fix): bounded IPv4 fragment reassembly
 * ============================================================
 * p1fix1 deliberately DROPPED every fragmented IPv4 datagram
 * (fail-closed: no reassembly existed, and handing a partial
 * datagram to L4 would deliver truncated PDUs to TCP/UDP/ICMP).
 * This re-adds fragmented reception with hard bounds so a normal
 * Ethernet-MTU fragment stream (e.g. a large UDP DNS answer)
 * works again, without reopening a memory-exhaustion vector:
 *   - at most IP_FRAG_SLOTS datagrams under reassembly at once;
 *   - at most IP_FRAG_MAX_FRAGS fragments stored per datagram and
 *     every fragment confined to the slot buffer (11840 B);
 *   - 5 s idle timeout, swept from net_poll() (the timer tick);
 *   - a datagram needing a slot while the table is full evicts the
 *     OLDEST slot (drop-oldest, counted);
 *   - a partially overlapping fragment rejects the whole datagram
 *     (Teardrop-style offset games never enter the cache); exact
 *     duplicate fragments are ignored.
 * Completeness proof: stored fragments are pairwise non-overlapping
 * and confined to [0, total_len); when their lengths sum to
 * total_len they exactly tile the datagram (pigeonhole), so a byte
 * counter plus the last fragment's total_len is sufficient.
 * Delivery rebuilds a synthetic 20-byte unfragmented IP header
 * (flags_frag = 0, correct total_len, fresh checksum) around the
 * reassembled payload and recurses ONCE into net_ip_handle_packet:
 * recursion depth is 1 (the synthetic header is never fragmented)
 * and the recursive pass re-runs the full netfilter INPUT /
 * transport-checksum / demux validation on the COMPLETE datagram —
 * filtering the reassembled whole instead of individual fragments
 * also defeats tiny-fragment port-splitting evasion.
 * The unfragmented hot path is untouched: one branch on the frag
 * bits exactly where the p1fix1 drop used to sit, after header
 * validation. net_poll's g_net_polling reentrancy guard makes the
 * whole RX path (and this table) single-threaded. */
#define IP_FRAG_SLOTS         4
#define IP_FRAG_MAX_FRAGS     8
#define IP_FRAG_BUF_SIZE      (IP_FRAG_MAX_FRAGS * 1480)
#define IP_FRAG_TIMEOUT_TICKS (5u * OC_TIMER_HZ)
typedef struct {
    int  in_use;
    u32  src_ip, dst_ip;
    u16  id;
    u8   protocol;
    u16  frag_off[IP_FRAG_MAX_FRAGS];  /* stored fragment offsets */
    u16  frag_len[IP_FRAG_MAX_FRAGS];  /* and lengths */
    int  frag_count;
    u32  covered;          /* sum of stored fragment lengths */
    u16  total_len;        /* offset+len of the last fragment */
    int  have_last;
    u64  last_tick;        /* idle clock for timeout + drop-oldest */
    u8   buf[IP_FRAG_BUF_SIZE];
} net_ip_frag_slot_t;

static net_ip_frag_slot_t g_ip_frag_slots[IP_FRAG_SLOTS];
static u8 g_ip_frag_synth[20 + IP_FRAG_BUF_SIZE];   /* reassembly output */

static void net_ip_frag_reset_slot(net_ip_frag_slot_t *s) {
    s->in_use = 0;
    s->frag_count = 0;
    s->covered = 0;
    s->total_len = 0;
    s->have_last = 0;
}

/* BUG-0210: idle-eviction sweep, called from net_poll (timer tick). */
static void net_ip_frag_gc(void) {
    u64 now = core_timer_ticks();
    for (int i = 0; i < IP_FRAG_SLOTS; i++) {
        if (g_ip_frag_slots[i].in_use &&
            now - g_ip_frag_slots[i].last_tick > IP_FRAG_TIMEOUT_TICKS) {
            g_stats.net_ip_frag_evicted++;
            net_ip_frag_reset_slot(&g_ip_frag_slots[i]);
        }
    }
}

static void net_ip_frag_reassemble(u32 src_ip, u32 dst_ip, u8 protocol, u16 id,
                                   const u8 *payload, int payload_len,
                                   u16 frag_off, int more_frags) {
    if (payload_len <= 0) return;
    if ((u32)frag_off + (u32)payload_len > (u32)IP_FRAG_BUF_SIZE) {
        g_stats.net_ip_frag_rx_dropped++;
        return;
    }
    /* Find this datagram's slot (tuple: src, dst, id, protocol); keep
     * the oldest in-use slot index for drop-oldest eviction. */
    net_ip_frag_slot_t *s = NULL;
    int oldest = -1;
    for (int i = 0; i < IP_FRAG_SLOTS; i++) {
        net_ip_frag_slot_t *t = &g_ip_frag_slots[i];
        if (!t->in_use) {
            if (!s) s = t;
            continue;
        }
        if (t->src_ip == src_ip && t->dst_ip == dst_ip &&
            t->id == id && t->protocol == protocol) {
            s = t;
            break;
        }
        if (oldest < 0 || t->last_tick < g_ip_frag_slots[oldest].last_tick)
            oldest = i;
    }
    if (s == NULL) {
        /* Table full of OTHER datagrams: evict the OLDEST slot. (A
         * free slot always exists when oldest < 0, so this is
         * unreachable with a full table — guarded anyway.) */
        if (oldest < 0) return;
        s = &g_ip_frag_slots[oldest];
        g_stats.net_ip_frag_evicted++;
        net_ip_frag_reset_slot(s);
    }
    if (!s->in_use) {
        net_ip_frag_reset_slot(s);
        s->in_use = 1;
        s->src_ip = src_ip;
        s->dst_ip = dst_ip;
        s->id = id;
        s->protocol = protocol;
    }
    s->last_tick = core_timer_ticks();
    /* Duplicate / overlap check against the stored fragments. */
    {
        u32 fb = frag_off, fe = frag_off + (u32)payload_len;
        for (int i = 0; i < s->frag_count; i++) {
            u32 b = s->frag_off[i], e = b + (u32)s->frag_len[i];
            if (fb == b && fe == e) return;   /* exact duplicate: keep it */
            if (fb < e && b < fe) {
                /* Partial overlap: reject the whole datagram. */
                g_stats.net_ip_frag_rx_dropped++;
                net_ip_frag_reset_slot(s);
                return;
            }
        }
    }
    if (s->frag_count >= IP_FRAG_MAX_FRAGS) {
        g_stats.net_ip_frag_rx_dropped++;
        net_ip_frag_reset_slot(s);
        return;
    }
    memcpy(s->buf + frag_off, payload, (usize)payload_len);
    s->frag_off[s->frag_count] = frag_off;
    s->frag_len[s->frag_count] = (u16)payload_len;
    s->frag_count++;
    s->covered += (u32)payload_len;
    if (!more_frags) {
        s->total_len = (u16)(frag_off + (u32)payload_len);
        s->have_last = 1;
    }
    if (!s->have_last || s->covered != (u32)s->total_len) return;

    /* Complete: wrap the reassembled payload in a synthetic
     * unfragmented header and hand the whole datagram back to the
     * normal IP input path (one recursion level, full validation). */
    {
        net_ip_hdr_t *nh = (net_ip_hdr_t *)g_ip_frag_synth;
        memset(g_ip_frag_synth, 0, 20);
        nh->ver_ihl = 0x45;
        nh->total_len = htons((u16)(20 + s->total_len));
        nh->id = htons(s->id);
        nh->ttl = 64;
        nh->protocol = s->protocol;
        nh->src_ip = htonl(s->src_ip);
        nh->dst_ip = htonl(s->dst_ip);
        memcpy(g_ip_frag_synth + 20, s->buf, (usize)s->total_len);
        nh->checksum = 0;
        nh->checksum = internet_checksum(nh, 20, 0);
        int total = 20 + (int)s->total_len;
        net_ip_frag_reset_slot(s);
        g_stats.net_ip_frag_reassembled++;
        net_ip_handle_packet(g_ip_frag_synth, total);
    }
}

static void net_ip_handle_packet(const void *data, int len) {
    if (len < 20) return;
    const net_ip_hdr_t *iph = (const net_ip_hdr_t *)data;

    /* BUG-035 FIX: Remove per-packet debug output that floods the console. */
    /* DEBUG removed: RX IP/RX ICMP/RX UDP prints */

    /* BUG-0210: validate the IP version before anything else. A non-IPv4
     * header (garbage or IPv6 mis-delivered here) must not be parsed. */
    if ((iph->ver_ihl >> 4) != 4) return;

    /* BUG-0210: the fragment gate used to sit here, before any header
     * validation, and simply dropped every fragmented datagram (the
     * p1fix1 fail-closed decision). It moved below — after the
     * header/destination/length/checksum checks — so that only
     * validated for-us fragments enter the bounded reassembly engine
     * (see net_ip_frag_reassemble above); the reassembled datagram
     * re-enters here through a synthetic unfragmented header. */
    /* BUG-0210: honour IHL — the header is 20..60 bytes including options;
     * the L4 payload starts only after the FULL header. */
    int hdr_len = (iph->ver_ihl & 0x0F) * 4;
    if (hdr_len < 20 || hdr_len > 60 || len < hdr_len) return;

    /* BUG-0210: strict destination acceptance. Accept only: our own
     * address, the limited broadcast 255.255.255.255, or the subnet
     * broadcast when a netmask is known. The old "low byte == 0xFF"
     * heuristic accepted 29/256 of the address space as "broadcast". */
    u32 dst = ntohl(iph->dst_ip);
    int for_us;
    if (g_ip == 0) {
        /* Pre-configuration (DHCP): the stack has no address yet, so the
         * destination cannot be classified — accept (a DHCP OFFER may be
         * unicast to the address being offered). */
        for_us = 1;
    } else {
        for_us = (dst == g_ip) ||
                 (dst == 0xFFFFFFFF) ||
                 (g_mask != 0 && (dst & g_mask) == (g_ip & g_mask) &&
                  (dst & ~g_mask) == ~g_mask);
    }
    if (!for_us) {
        /* WP-09 mainstream: FORWARD chain — transit traffic. The L0
         * image has one NIC and no forwarding path (g_ip_forward = 0),
         * so packets are counted and dropped either way; the chain is
         * wired so a forwarding datapath can be added without touching
         * the filter logic again. */
        if (g_ip_forward) {
            u16 fsport, fdport;
            net_netfilter_parse_ports((const u8 *)data + hdr_len,
                           ntohs(iph->total_len) - hdr_len,
                           iph->protocol, &fsport, &fdport);
            g_stats.net_netfilter_forward++;
            u8 state = net_netfilter_ct_classify(iph->protocol,
                                             ntohl(iph->src_ip), fsport,
                                             dst, fdport, 0, 0);
            u8 verdict = net_netfilter_check(NF_CHAIN_FORWARD,
                                         ntohl(iph->src_ip), dst,
                                         iph->protocol, fsport, fdport,
                                         state);
            if (verdict != NF_ACTION_ACCEPT) g_stats.net_netfilter_drop++;
        }
        return;
    }

    /* BUG-0066 FIX: cross-check the IP header length field against the
     * actual frame length before trusting payload_len. A crafted
     * total_len larger than the frame made every transport parser read
     * past the end of the receive buffer (remote OOB read). */
    {
        u16 claimed = ntohs(iph->total_len);
        if (claimed < (u16)hdr_len || claimed > len) return;
    }
    /* BUG-0072 FIX: verify the IP header checksum and drop corrupt
     * datagrams. The RX path previously accepted everything unchecked. */
    if (internet_checksum(iph, hdr_len, 0) != 0) {
        g_stats.net_rx_bad_checksum++;
        return;
    }

    const void *payload = (const u8 *)data + hdr_len;
    int payload_len = ntohs(iph->total_len) - hdr_len;
    u32 src_ip = ntohl(iph->src_ip);

    /* BUG-0210 (P2 re-fix): fragmented datagrams go through the bounded
     * reassembly engine instead of being dropped. Reached only after
     * version/IHL/destination/total_len/checksum validation, so the
     * (bounded) cache only ever sees validated for-us fragments. */
    {
        u16 frag = ntohs(iph->flags_frag);
        u16 frag_off = (u16)((frag & 0x1FFF) * 8);
        int more_frags = (frag & 0x2000) != 0;   /* MF bit */
        if (frag_off != 0 || more_frags) {
            net_ip_frag_reassemble(src_ip, dst, iph->protocol, ntohs(iph->id),
                                   (const u8 *)payload, payload_len,
                                   frag_off, more_frags);
            return;
        }
    }

    /* WP-09 mainstream: Netfilter INPUT chain — transport ports + conntrack */
    {
        u16 sport, dport;
        net_netfilter_parse_ports(payload, payload_len, iph->protocol, &sport, &dport);
        u16 in_flags = 0;
        if (iph->protocol == IP_PROTO_TCP && payload_len >= 14) {
            const u8 *tp = (const u8 *)payload;
            in_flags = tp[13];   /* flags byte (after the data-offset byte) */
        }
        u8 state = net_netfilter_ct_classify(iph->protocol, src_ip, sport,
                                         dst, dport, 0, in_flags);
        u8 verdict = net_netfilter_check(NF_CHAIN_INPUT, src_ip, dst,
                                     iph->protocol, sport, dport, state);
        if (verdict == NF_ACTION_REJECT) {
            g_stats.net_netfilter_reject++;
            net_netfilter_send_icmp_unreachable(src_ip, data, len);
            return;
        }
        if (verdict == NF_ACTION_DROP) {
            g_stats.net_netfilter_drop++;
            return;  /* packet dropped by firewall */
        }
    }

    switch (iph->protocol) {
        case IP_PROTO_ICMP:
            net_icmp_handle_packet(src_ip, payload, payload_len);
            break;
        case IP_PROTO_UDP: {
            /* BUG-0072 FIX: UDP checksum is optional (0 = none) but must
             * verify when present. The RX path used to skip it entirely. */
            if (payload_len >= 8) {
                /* checksum field = bytes 6..7, network byte order
                   (net_udp_hdr_t is defined further down in this file) */
                const u8 *up = (const u8 *)payload;
                u16 rx_sum = (u16)((up[6] << 8) | up[7]);
                if (rx_sum != 0) {
                    /* UDP checksum covers the pseudo-header (RFC 768):
                     * src IP, dst IP, zero, protocol, UDP length. */
                    u8 ph[12];
                    ph[0]=(u8)(src_ip>>24); ph[1]=(u8)(src_ip>>16);
                    ph[2]=(u8)(src_ip>>8);  ph[3]=(u8)src_ip;
                    ph[4]=(u8)(dst>>24);    ph[5]=(u8)(dst>>16);
                    ph[6]=(u8)(dst>>8);     ph[7]=(u8)dst;
                    ph[8]=0; ph[9]=IP_PROTO_UDP;
                    ph[10]=(u8)(payload_len>>8); ph[11]=(u8)payload_len;
                    /* BUG-0072 FIX (checksum chain): accumulate pseudo-header
                     * and segment into ONE raw sum and fold once; the old
                     * chained internet_checksum() calls complemented twice
                     * and rejected every valid datagram. */
                    u32 raw = checksum_raw_add(ph, 12, 0);
                    raw = checksum_raw_add(payload, payload_len, raw);
                    if (checksum_fold(raw) != 0xFFFFu) {
                        g_stats.net_rx_bad_checksum++;
                        return;
                    }
                }
            }
            /* BUG-0217(a): nobody owns this UDP port → answer with an
             * ICMP destination-unreachable / port-unreachable (RFC 792
             * "Destination Unreachable", code 3), rate-limited. Only for
             * unicast datagrams addressed to us — never for broadcast or
             * the pre-configuration window (RFC 1122 3.2.2). */
            if (net_udp_handle_packet(src_ip, payload, payload_len) == 0 &&
                dst == g_ip) {
                net_icmp_send_port_unreachable(src_ip, data, len);
            }
            break;
        }
        case IP_PROTO_TCP: {
            /* BUG-0072 FIX: verify the TCP checksum (pseudo-header +
             * segment). The RX path never checked it. */
            if (payload_len >= 20) {
                u8 ph[12];
                ph[0]=(u8)(src_ip>>24); ph[1]=(u8)(src_ip>>16);
                ph[2]=(u8)(src_ip>>8);  ph[3]=(u8)src_ip;
                ph[4]=(u8)(dst>>24);    ph[5]=(u8)(dst>>16);
                ph[6]=(u8)(dst>>8);     ph[7]=(u8)dst;
                ph[8]=0; ph[9]=IP_PROTO_TCP;
                ph[10]=(u8)(payload_len>>8); ph[11]=(u8)payload_len;
                /* BUG-0072 FIX (checksum chain): one raw sum across the
                 * pseudo-header and the segment, folded ONCE. The old
                 * chained internet_checksum() calls complemented twice,
                 * so every valid segment was rejected: inbound TCP was
                 * completely dead (sshd never answered a SYN). */
                u32 raw = checksum_raw_add(ph, 12, 0);
                raw = checksum_raw_add(payload, payload_len, raw);
                if (checksum_fold(raw) != 0xFFFFu) {
                    g_stats.net_rx_bad_checksum++;
                    return;
                }
            }
            net_tcp_handle_packet(src_ip, payload, payload_len);
            break;
        }
    }
}

/* ============================================================
 * ICMP layer
 * ============================================================ */
typedef struct __attribute__((packed)) {
    u8  type;
    u8  code;
    u16 checksum;
    u16 id;
    u16 seq;
} net_icmp_hdr_t;

static u16 g_ping_id = 0;
static u16 g_ping_seq = 0;
static int g_ping_reply_received = 0;

void net_icmp_handle_packet(u32 src_ip, const void *data, int len) {
    if (len < 8) return;
    const net_icmp_hdr_t *h = (const net_icmp_hdr_t *)data;

    /* BUG-0072 FIX: verify the ICMP checksum (RFC 792) — one internet
     * checksum fold over the whole message as delivered by the IP layer
     * (header + payload; len is already clamped to the IP total_len).
     * A valid message folds to 0 exactly like the IP header check in
     * net_ip_handle_packet. The RX path used to accept every ICMP
     * datagram unchecked (a forged Echo Request could elicit a reply);
     * a mismatching datagram is dropped and counted in the shared
     * BUG-0072 bad-checksum counter (there is no separate ICMP stat). */
    if (internet_checksum(data, len, 0) != 0) {
        g_stats.net_rx_bad_checksum++;
        return;
    }

    /* BUG-035 FIX: Remove ICMP debug output */

    if (h->type == 0) {
        /* Echo reply. */
        g_ping_reply_received = 1;
        g_stats.net_icmp_echo_recv++;
    } else if (h->type == 8) {
        /* Echo request: send reply. */
        u8 buf[64];
        net_icmp_hdr_t *r = (net_icmp_hdr_t *)buf;
        r->type = 0;  /* reply */
        r->code = 0;
        r->id = h->id;
        r->seq = h->seq;
        int plen = len - 8;
        if (plen > 56) plen = 56;
        if (plen > 0) memcpy(buf + 8, (const u8 *)data + 8, plen);
        r->checksum = 0;
        r->checksum = internet_checksum(r, 8 + plen, 0);
        net_ip_send(src_ip, IP_PROTO_ICMP, buf, 8 + plen);
    }
}

/* Send ICMP destination-unreachable for REJECT (INPUT only). */
static void net_netfilter_send_icmp_unreachable(u32 src_ip, const void *orig_pkt, int orig_len) {
    u8 buf[8 + 28];
    net_icmp_hdr_t *r = (net_icmp_hdr_t *)buf;
    r->type = 3;   /* destination unreachable */
    r->code = 0;   /* net unreachable */
    r->id = 0;
    r->seq = 0;
    /* ICMP error body: original IP header + first 8 bytes of payload */
    int copy = orig_len > 28 ? 28 : orig_len;
    memset(buf + 8, 0, 28);
    memcpy(buf + 8, orig_pkt, copy);
    r->checksum = 0;
    r->checksum = internet_checksum(r, 8 + 28, 0);
    net_ip_send(src_ip, IP_PROTO_ICMP, buf, 8 + 28);
}

/* BUG-0217(a): ICMP port-unreachable (type 3, code 3) with token-bucket
 * rate limiting (RFC 1812 4.3.2.7: ICMP errors must be rate-limited).
 * Bucket: burst of 8, refilled at 1 token per second (OC_TIMER_HZ ticks). */
#define ICMP_UNREACH_BURST 8
#define ICMP_UNREACH_REFILL_TICKS OC_TIMER_HZ
static u32 g_icmp_unreach_tokens = ICMP_UNREACH_BURST;
static u64 g_icmp_unreach_last = 0;

static int net_icmp_unreach_allow(void) {
    u64 now = core_timer_ticks();
    if (g_icmp_unreach_last == 0) g_icmp_unreach_last = now;
    u64 elapsed = now - g_icmp_unreach_last;
    if (elapsed >= ICMP_UNREACH_REFILL_TICKS) {
        u64 add = elapsed / ICMP_UNREACH_REFILL_TICKS;
        g_icmp_unreach_tokens += (u32)add;
        if (g_icmp_unreach_tokens > ICMP_UNREACH_BURST)
            g_icmp_unreach_tokens = ICMP_UNREACH_BURST;
        g_icmp_unreach_last = now;
    }
    if (g_icmp_unreach_tokens == 0) return 0;
    g_icmp_unreach_tokens--;
    return 1;
}

static void net_icmp_send_port_unreachable(u32 dst_ip, const void *orig_pkt, int orig_len) {
    if (!g_nic_ok || dst_ip == 0) return;
    if (!net_icmp_unreach_allow()) return;
    u8 buf[8 + 28];
    net_icmp_hdr_t *r = (net_icmp_hdr_t *)buf;
    r->type = 3;   /* destination unreachable */
    r->code = 3;   /* port unreachable */
    r->id = 0;
    r->seq = 0;
    /* ICMP error body: original IP header + first 8 bytes of the
     * datagram (RFC 792), so the sender can match the error to its
     * socket (the UDP source port is inside the quoted bytes). */
    int copy = orig_len > 28 ? 28 : orig_len;
    memset(buf + 8, 0, 28);
    memcpy(buf + 8, orig_pkt, copy);
    r->checksum = 0;
    r->checksum = internet_checksum(r, 8 + 28, 0);
    net_ip_send(dst_ip, IP_PROTO_ICMP, buf, 8 + 28);
}


int net_icmp_ping(u32 dst_ip, int timeout_ms) {
    u8 buf[8 + 32];
    net_icmp_hdr_t *h = (net_icmp_hdr_t *)buf;
    h->type = 8;  /* echo request */
    h->code = 0;
    h->id = htons(++g_ping_id);
    h->seq = htons(++g_ping_seq);
    /* Fill payload with pattern. */
    for (int i = 0; i < 32; i++) buf[8 + i] = (u8)(i & 0xFF);
    h->checksum = 0;
    h->checksum = internet_checksum(h, 8 + 32, 0);

    g_ping_reply_received = 0;
    g_stats.net_icmp_echo_sent++;

    if (net_ip_send(dst_ip, IP_PROTO_ICMP, buf, 8 + 32) < 0) return -1;

    /* Wait for reply. */
    u64 start = core_timer_ticks();
    u64 timeout_ticks = (u64)timeout_ms / 10;
    while ((core_timer_ticks() - start) < timeout_ticks) {
        net_poll();
        if (g_ping_reply_received) return 0;
    }
    return -1;  /* timeout */
}

/* ============================================================
 * UDP layer
 * ============================================================ */
typedef struct __attribute__((packed)) {
    u16 src_port;
    u16 dst_port;
    u16 length;
    u16 checksum;
} net_udp_hdr_t;

#define UDP_MAX_HANDLERS 32
typedef struct {
    u16 port;
    net_udp_handler_fn handler;
} net_udp_handler_t;

static net_udp_handler_t g_udp_handlers[UDP_MAX_HANDLERS];

void net_udp_init(void) {
    memset(g_udp_handlers, 0, sizeof(g_udp_handlers));
}

int net_udp_bind(u16 port, net_udp_handler_fn handler) {
    /* BUG-0070 FIX: reject a duplicate bind first (the DNS client used
     * to silently pile up one binding per lookup until the table was
     * exhausted); the caller has no way to know a second handler for
     * the same port can never be delivered. */
    for (int i = 0; i < UDP_MAX_HANDLERS; i++) {
        if (g_udp_handlers[i].handler != NULL && g_udp_handlers[i].port == port)
            return -1;
    }
    for (int i = 0; i < UDP_MAX_HANDLERS; i++) {
        if (g_udp_handlers[i].handler == NULL) {
            g_udp_handlers[i].port = port;
            g_udp_handlers[i].handler = handler;
            return 0;
        }
    }
    return -1;
}

int net_udp_unbind(u16 port) {
    /* BUG-0070 FIX: provide the missing unbind so repeated clients can
     * release their port binding. */
    for (int i = 0; i < UDP_MAX_HANDLERS; i++) {
        if (g_udp_handlers[i].handler != NULL && g_udp_handlers[i].port == port) {
            g_udp_handlers[i].handler = NULL;
            g_udp_handlers[i].port = 0;
            return 0;
        }
    }
    return -1;
}

int net_udp_send(u32 dst_ip, u16 dst_port, u16 src_port, const void *data, int len) {
    /* P0-7 FIX: bound the payload to the MTU. Previously any len > 1492
     * overflowed the 1500-byte stack buffer. */
    if (len < 0) return -1;
    if (len > 1492) len = 1492;  /* 1500 - 8 (UDP header) - leave room */
    u8 buf[1500];
    net_udp_hdr_t *h = (net_udp_hdr_t *)buf;
    h->src_port = htons(src_port);
    h->dst_port = htons(dst_port);
    h->length = htons((u16)(8 + len));
    h->checksum = 0;
    memcpy(buf + 8, data, len);
    return net_ip_send(dst_ip, IP_PROTO_UDP, buf, 8 + len);
}

int net_udp_handle_packet(u32 src_ip, const void *data, int len) {
    if (len < 8) return 0;
    const net_udp_hdr_t *h = (const net_udp_hdr_t *)data;
    u16 dst_port = ntohs(h->dst_port);
    u16 src_port = ntohs(h->src_port);
    /* BUG-0066 FIX: clamp the UDP length field to the bytes the IP layer
     * actually delivered (len is already cross-checked against the IP
     * total_len and the frame length by net_ip_handle_packet). A forged
     * h->length — e.g. 0xFFFF with checksum 0, exploiting the RFC 768
     * optional-checksum exemption — used to be trusted as-is, so the
     * DHCP options loop and the DNS resolver read past the delivered
     * data (remote OOB read). */
    u16 udp_len = ntohs(h->length);
    if (udp_len > (u16)len) udp_len = (u16)len;
    int payload_len = (int)udp_len - 8;
    if (payload_len < 0) return 0;
    const void *payload = (const u8 *)data + 8;

    for (int i = 0; i < UDP_MAX_HANDLERS; i++) {
        if (g_udp_handlers[i].handler && g_udp_handlers[i].port == dst_port) {
            g_udp_handlers[i].handler(src_ip, src_port, payload, payload_len);
            return 1;
        }
    }
    /* Also check socket layer. Returns 1 when a bound socket took (or
     * dropped-by-overflow) the datagram, 0 when no socket owns the port
     * (BUG-0217: caller then emits a rate-limited ICMP port-unreach). */
    return net_udp_socket_handler(src_ip, src_port, dst_port, payload, payload_len);
}

/* ============================================================
 * TCP layer (simplified state machine)
 * ============================================================ */
typedef struct __attribute__((packed)) {
    u16 src_port;
    u16 dst_port;
    u32 seq;
    u32 ack;
    u16 data_offset_flags;
    u16 window;
    u16 checksum;
    u16 urgent;
} net_tcp_hdr_t;

#define TCP_MAX_CONNS 32
typedef enum {
    TCP_CLOSED = 0,
    TCP_SYN_SENT,
    TCP_SYN_RCVD,
    TCP_ESTABLISHED,
    TCP_FIN_WAIT_1,
    TCP_FIN_WAIT_2,
    TCP_CLOSE_WAIT,
    TCP_LAST_ACK,
    TCP_CLOSING,
    TCP_TIME_WAIT,   /* BUG-0208: active-close terminal state, 2*MSL-bounded */
} net_tcp_state_t;

/* BUG-0208: TIME_WAIT duration. The full Linux 60 s does not fit this
 * hobby stack's 32-conn table well; 10 s (~2*MSL for a LAN, RFC 793
 * suggestion scaled down) keeps old duplicate segments from leaking into
 * a reused 4-tuple while still recycling quickly. */
#define TCP_TIME_WAIT_TICKS (10u * OC_TIMER_HZ)   /* 10 s @ 100 Hz */

/* WP-09: TCP reliability fields. */
#define TCP_RTX_BUF_SIZE 4096
/* WP-09 fix: out-of-order receive cache sizing */
#define TCP_OOO_MAX 4
#define TCP_OOO_SEG 1024
typedef struct {
    net_tcp_state_t state;
    u32 remote_ip;
    u16 local_port;
    u16 remote_port;
    u32 our_seq;        /* next seq to send */
    u32 our_ack;        /* ack we send to peer */
    u32 driver_snd_una;        /* oldest unacknowledged seq (WP-09) */
    u32 driver_snd_wnd;        /* peer's advertised window (WP-09) */
    u32 cwnd;           /* congestion window (WP-09) */
    u32 ssthresh;       /* slow-start threshold (WP-09) */
    u32 rto;            /* retransmission timeout in ticks (WP-09) */
    u64 rto_deadline;   /* timer tick when RTO fires (WP-09) */
    int dup_ack_count;  /* duplicate ACK counter (WP-09) */
    u16 mss;            /* maximum segment size (WP-09) */
    u8  win_scale_sent; /* window scale we offered (WP-09) */
    u8  win_scale_recv; /* window scale peer offered (WP-09) */
    u32 ts_recent;      /* latest timestamp from peer (WP-09) */
    u32 ts_echo;        /* timestamp to echo back (WP-09) */
    int ts_enabled;     /* timestamps negotiated (WP-09) */
    int in_use;
    int sock_fd;
    /* WP-09-FIX BUG-002: 8 KiB receive buffer (was 2048 — less than two
     * MSS segments, so any bulk transfer immediately overflowed). */
    u8  rx_buf[8192];
    int rx_len;
    /* WP-09: retransmission buffer */
    u8  rtx_buf[TCP_RTX_BUF_SIZE];
    int rtx_len;         /* bytes in rtx_buf awaiting ACK */
    /* BUG-0205: split of the send/retransmission buffer. Bytes
     * [0, rtx_sent) have been TRANSMITTED (and are unacked -> in flight);
     * bytes [rtx_sent, rtx_len) are ACCEPTED but not yet sent (queued by
     * Nagle / peer zero window / cwnd). rtx_sent therefore equals the
     * in-flight byte count at all times. */
    int rtx_sent;
    u32 rtx_seq;         /* seq of first byte in rtx_buf */
    int rtt_measured;    /* have we measured RTT yet */
    u32 srtt;            /* smoothed RTT in ticks */
    u32 rttvar;          /* RTT variance */
    u64 send_tick;       /* tick when the oldest unacked data was sent */
    int rtx_retransmitted; /* oldest unacked data was re-sent (Karn: no RTT) */
    /* WP-09 mainstream: SACK blocks seen on the latest ACKs, per 256-byte
     * block of the retransmission buffer. 1 = fully covered by a SACK block. */
    u8  rtx_sacked[TCP_RTX_BUF_SIZE / 256];
    u8  sack_permitted;  /* peer negotiated SACK-Permitted */
    u8  fr_active;       /* fast recovery in progress */
    /* SACK blocks from the most recent ACK (left/right seq, host order) */
    u32 sack_l[3];
    u32 sack_r[3];
    int sack_count;
    cubic_state_t cc;    /* CUBIC state (RFC 8312) */
    /* WP-09 fix: out-of-order segment cache. Segments arriving with seq >
     * our_ack are held here and drained in order when the gap fills. */
    u32 ooo_seq[TCP_OOO_MAX];
    u16 ooo_len[TCP_OOO_MAX];
    u8  ooo_data[TCP_OOO_MAX][TCP_OOO_SEG];
    int ooo_count;
} net_tcp_conn_t;

/* WP-10-wireless_bluetooth: this table is 32 * sizeof(net_tcp_conn_t)
 * (~520 KiB) and the linker.ld ASSERT pins the whole kernel image below
 * the 0x400000 identity window.  The table therefore lives on the kernel
 * heap instead of static .bss: same layout, same indexing, allocated
 * once before any connection exists (net_tcp_init runs from net_init,
 * well after mem_heap_init). */
static net_tcp_conn_t *g_tcp_conns;

int net_tcp_init(void) {
    if (!g_tcp_conns) {
        g_tcp_conns = (net_tcp_conn_t *)kmalloc(
            (u64)sizeof(net_tcp_conn_t) * TCP_MAX_CONNS);
        if (!g_tcp_conns) return -1;   /* honest: no TCP without memory */
    }
    memset(g_tcp_conns, 0, (u64)sizeof(net_tcp_conn_t) * TCP_MAX_CONNS);
    return 0;
}

static net_tcp_conn_t *net_tcp_find_conn(u32 ip, u16 local_port, u16 remote_port) {
    for (int i = 0; i < TCP_MAX_CONNS; i++) {
        if (g_tcp_conns[i].in_use &&
            g_tcp_conns[i].remote_ip == ip &&
            g_tcp_conns[i].local_port == local_port &&
            g_tcp_conns[i].remote_port == remote_port) {
            return &g_tcp_conns[i];
        }
    }
    return NULL;
}

static net_tcp_conn_t *net_tcp_alloc_conn(void) {
    for (int i = 0; i < TCP_MAX_CONNS; i++) {
        if (!g_tcp_conns[i].in_use) {
            memset(&g_tcp_conns[i], 0, sizeof(net_tcp_conn_t));
            g_tcp_conns[i].in_use = 1;
            /* WP-09 fix: memset leaves sock_fd == 0, which looks like a valid
             * socket. Initialize to -1 ("not bound to any socket") so that
             * net_accept() can find freshly-handshaked server-side
             * connections via its sock_fd < 0 predicate. */
            g_tcp_conns[i].sock_fd = -1;
            return &g_tcp_conns[i];
        }
    }
    /* BUG-0208: bounded table — if TIME_WAIT connections are starving the
     * table, retire the OLDEST one (earliest TIME_WAIT start, parked in
     * rto_deadline) and reuse its slot. A lingering passive waiter must
     * never permanently block new connections. */
    net_tcp_conn_t *victim = NULL;
    u64 oldest = 0;
    for (int i = 0; i < TCP_MAX_CONNS; i++) {
        if (g_tcp_conns[i].in_use && g_tcp_conns[i].state == TCP_TIME_WAIT) {
            if (!victim || g_tcp_conns[i].rto_deadline < oldest) {
                victim = &g_tcp_conns[i];
                oldest = g_tcp_conns[i].rto_deadline;
            }
        }
    }
    if (victim) {
        memset(victim, 0, sizeof(net_tcp_conn_t));
        victim->in_use = 1;
        victim->sock_fd = -1;
        return victim;
    }
    return NULL;
}

static u16 net_tcp_checksum(u32 src_ip, u32 dst_ip, const void *data, int len) {
    /* BUG-003 FIX (revised): Construct the pseudo-header in network byte
     * order (as bytes), compute its RAW sum (NOT the one's complement
     * checksum), and pass that raw sum as the initial value to
     * internet_checksum for the TCP segment data.
     *
     * The previous attempt called internet_checksum(ph, 12, 0) which
     * returns ~sum (the checksum), then passed that as the initial
     * value to the second call. But the second call needs the RAW sum,
     * not the one's complement. This produced wrong checksums
     * (0xdc57 instead of the correct 0xac01), which SLIRP silently
     * dropped.
     *
     * src_ip and dst_ip are stored as u32 in network byte order
     * (IP4 macro: (a<<24)|(b<<16)|(c<<8)|d). Extracting
     * (>> 24, >> 16, >> 8, >> 0) gives the bytes in network order. */
    u8 ph[12];
    ph[0] = (u8)((src_ip >> 24) & 0xFF);
    ph[1] = (u8)((src_ip >> 16) & 0xFF);
    ph[2] = (u8)((src_ip >> 8) & 0xFF);
    ph[3] = (u8)(src_ip & 0xFF);
    ph[4] = (u8)((dst_ip >> 24) & 0xFF);
    ph[5] = (u8)((dst_ip >> 16) & 0xFF);
    ph[6] = (u8)((dst_ip >> 8) & 0xFF);
    ph[7] = (u8)(dst_ip & 0xFF);
    ph[8] = 0;           /* zero */
    ph[9] = 6;            /* protocol = TCP */
    ph[10] = (u8)((len >> 8) & 0xFF);   /* TCP length high byte */
    ph[11] = (u8)(len & 0xFF);           /* TCP length low byte */
    /* Compute the RAW sum of the pseudo-header (do NOT take one's
     * complement). internet_checksum will add this to the TCP data
     * sum, fold carries, and return the final ~sum at the end. */
    const u16 *p = (const u16 *)(const void *)ph;
    u32 sum = 0;
    for (int i = 0; i < 6; i++)
        sum += p[i];
    return internet_checksum(data, len, sum);
}

/* WP-09: TCP option kind codes */
#define TCP_OPT_MSS      2
#define TCP_OPT_WSCALE   3
#define TCP_OPT_SACK_PERM 4
#define TCP_OPT_SACK     5
#define TCP_OPT_TS       8
#define TCP_OPT_END      0
#define TCP_OPT_NOP      1

/* WP-09: Build TCP options for SYN packets (MSS, Window Scale, SACK-Permitted, Timestamps)
 * P7-FIX: total must be multiple of 4 (20 bytes = 5 words) */
static int net_tcp_build_syn_options(net_tcp_conn_t *c, u8 *opts) {
    int i = 0;
    /* MSS option (4 bytes) */
    opts[i++] = TCP_OPT_MSS;
    opts[i++] = 4;
    opts[i++] = (u8)(c->mss >> 8);
    opts[i++] = (u8)(c->mss & 0xFF);
    /* Window Scale option (3 bytes + 1 NOP for alignment = 4 bytes) */
    opts[i++] = TCP_OPT_NOP;
    opts[i++] = TCP_OPT_WSCALE;
    opts[i++] = 3;
    opts[i++] = c->win_scale_sent;
    /* SACK-Permitted option (2 bytes + 2 NOP for alignment = 4 bytes) */
    opts[i++] = TCP_OPT_NOP;
    opts[i++] = TCP_OPT_NOP;
    opts[i++] = TCP_OPT_SACK_PERM;
    opts[i++] = 2;
    /* Timestamps option (10 bytes + 2 NOP for alignment = 12 bytes) */
    opts[i++] = TCP_OPT_NOP;
    opts[i++] = TCP_OPT_NOP;
    opts[i++] = TCP_OPT_TS;
    opts[i++] = 10;
    u32 tsval = (u32)core_timer_ticks();
    opts[i++] = (u8)(tsval >> 24);
    opts[i++] = (u8)(tsval >> 16);
    opts[i++] = (u8)(tsval >> 8);
    opts[i++] = (u8)(tsval & 0xFF);
    opts[i++] = 0; opts[i++] = 0; opts[i++] = 0; opts[i++] = 0;
    return i;  /* 4 + 4 + 4 + 12 = 24 bytes (multiple of 4) */
}

/* WP-09 mainstream: TCP Timestamp option on data packets (RFC 7323) */
static int net_tcp_build_ts_option(net_tcp_conn_t *c, u8 *opts) {
    if (!c->ts_enabled) return 0;
    int i = 0;
    opts[i++] = TCP_OPT_NOP;
    opts[i++] = TCP_OPT_NOP;
    opts[i++] = TCP_OPT_TS;
    opts[i++] = 10;
    u32 tsval = (u32)core_timer_ticks();
    opts[i++] = (u8)(tsval >> 24);
    opts[i++] = (u8)(tsval >> 16);
    opts[i++] = (u8)(tsval >> 8);
    opts[i++] = (u8)(tsval & 0xFF);
    u32 echo = c->ts_recent;
    opts[i++] = (u8)(echo >> 24);
    opts[i++] = (u8)(echo >> 16);
    opts[i++] = (u8)(echo >> 8);
    opts[i++] = (u8)(echo & 0xFF);
    return 12;
}

/* WP-09: Parse TCP options from incoming packet */
static void net_tcp_parse_options(net_tcp_conn_t *c, const u8 *opts, int opt_len, int is_syn) {
    int i = 0;
    while (i < opt_len) {
        u8 kind = opts[i++];
        if (kind == TCP_OPT_END) break;
        if (kind == TCP_OPT_NOP) continue;
        if (i >= opt_len) break;
        u8 len = opts[i++];
        if (len < 2 || i + len - 2 > opt_len) break;
        switch (kind) {
            case TCP_OPT_MSS:
                if (len == 4 && is_syn) {
                    u16 mss = ((u16)opts[i] << 8) | opts[i+1];
                    if (mss > 536 && mss < 9000) c->mss = mss;
                }
                break;
            case TCP_OPT_WSCALE:
                if (len == 3 && is_syn) {
                    c->win_scale_recv = opts[i];
                }
                break;
            case TCP_OPT_SACK_PERM:
                if (is_syn) { c->sack_permitted = 1; }
                break;
            case TCP_OPT_SACK:
                if (!is_syn && len >= 10 && ((len - 2) % 8) == 0) {
                    int nb = (len - 2) / 8;
                    if (nb > 3) nb = 3;
                    for (int b = 0; b < nb; b++) {
                        int p = i + b * 8;
                        c->sack_l[b] = ((u32)opts[p] << 24) | ((u32)opts[p+1] << 16)
                                     | ((u32)opts[p+2] << 8) | opts[p+3];
                        c->sack_r[b] = ((u32)opts[p+4] << 24) | ((u32)opts[p+5] << 16)
                                     | ((u32)opts[p+6] << 8) | opts[p+7];
                    }
                    c->sack_count = nb;
                }
                break;
            case TCP_OPT_TS:
                if (len == 10) {
                    u32 tsval = ((u32)opts[i] << 24) | ((u32)opts[i+1] << 16)
                              | ((u32)opts[i+2] << 8) | opts[i+3];
                    u32 tsecr = ((u32)opts[i+4] << 24) | ((u32)opts[i+5] << 16)
                              | ((u32)opts[i+6] << 8) | opts[i+7];
                    c->ts_recent = tsval;
                    if (is_syn) c->ts_enabled = 1;
                    (void)tsecr;
                }
                break;
        }
        i += len - 2;
    }
}

static int net_tcp_send_raw(net_tcp_conn_t *c, u8 flags, const void *data, int len) {
    /* P0-7 FIX: bound the payload to the MTU. */
    if (len < 0) len = 0;
    if (len > 1480) len = 1480;

    u8 buf[1500];
    net_tcp_hdr_t *h = (net_tcp_hdr_t *)buf;
    h->src_port = htons(c->local_port);
    h->dst_port = htons(c->remote_port);
    h->seq = htonl(c->our_seq);
    h->ack = htonl(c->our_ack);

    /* WP-09: Build options. For SYN, include MSS/WScale/SACK/TS.
     * For data, include Timestamps if enabled. */
    int hdr_len = 20;
    int opt_len = 0;
    if (flags & TCP_SYN) {
        opt_len = net_tcp_build_syn_options(c, buf + 20);
    } else if ((flags & TCP_ACK) && c->sack_permitted && c->ooo_count > 0) {
        /* SACK option (RFC 2018): report up to 3 out-of-order blocks
         * (the cached segments beyond our_ack). */
        u8 *o = buf + 20;
        int i = 0;
        o[i++] = TCP_OPT_NOP;
        o[i++] = TCP_OPT_NOP;
        o[i++] = TCP_OPT_SACK;
        int lenpos = i; i++;                 /* length byte filled later */
        int n = 0;
        for (int k = 0; k < c->ooo_count && n < 3; k++) {
            if (c->ooo_len[k] == 0) continue;
            u32 l = c->ooo_seq[k];
            u32 r = l + (u32)c->ooo_len[k];
            if (r <= c->our_ack) continue;
            o[i++] = (u8)(l >> 24); o[i++] = (u8)(l >> 16);
            o[i++] = (u8)(l >> 8);  o[i++] = (u8)(l);
            o[i++] = (u8)(r >> 24); o[i++] = (u8)(r >> 16);
            o[i++] = (u8)(r >> 8);  o[i++] = (u8)(r);
            n++;
        }
        if (n > 0) {
            o[lenpos] = (u8)(i - 2);   /* kind + length + 8*n bytes */
            opt_len = i;               /* 4 + 8*n, always a multiple of 4 */
        }
    }
    if (opt_len == 0 && (flags & TCP_ACK) && !(flags & TCP_SYN) &&
        c->ts_enabled && c->state == TCP_ESTABLISHED) {
        opt_len = net_tcp_build_ts_option(c, buf + 20);
    }
    /* keep header + payload within the 1500-byte frame */
    if (opt_len > 0 && len > 1480 - opt_len) len = 1480 - opt_len;
    hdr_len = 20 + opt_len;
    int data_offset = (hdr_len / 4) << 12;
    h->data_offset_flags = htons((u16)data_offset | flags);

    /* WP-09-FIX BUG-002: advertise our REAL receive window (free space in
     * rx_buf) instead of the send window. The old code never shrank the
     * advertised window, so the peer kept a full send pipeline running
     * while our rx buffer was already full. With a truthful window the
     * peer throttles itself before we ever have to drop a segment. */
    u32 rcv_free = (u32)sizeof(c->rx_buf) - (u32)(c->rx_len < 0 ? 0 : c->rx_len);
    u16 win = (u16)(rcv_free > 65535 ? 65535 : rcv_free);
    if (win == 0) {
        /* Advertise a tiny non-zero window: keeps the window open in the
         * peer's eyes so it resumes on the next window update instead of
         * falling into a 5s+ zero-window probe loop. */
        win = 64;
    }
    h->window = htons(win);
    h->urgent = 0;
    if (len > 0 && data) memcpy(buf + hdr_len, data, len);
    h->checksum = 0;
    h->checksum = net_tcp_checksum(g_ip, c->remote_ip, h, hdr_len + len);
    return net_ip_send(c->remote_ip, IP_PROTO_TCP, h, hdr_len + len);
}

/* BUG-0207: is a local TCP port already taken? Defined after the listener
 * table (which lives further down, next to net_tcp_listen). */
static int net_tcp_port_in_use(u16 port);

int net_tcp_connect(u32 dst_ip, u16 dst_port) {
    net_tcp_conn_t *c = net_tcp_alloc_conn();
    if (!c) return -1;
    c->state = TCP_SYN_SENT;
    c->remote_ip = dst_ip;
    /* BUG-0207: pick a local port that is NOT in use by any live
     * connection or listener. The old "counter modulo 10000" scheme
     * silently collided with surviving connections (same 4-tuple), and
     * find_conn then routed the new SYN into the OLD connection's state
     * machine. Scan the ephemeral range starting from the counter value,
     * bounded at 10000 tries. */
    {
        u16 lport = (u16)(40000 + (g_stats.net_tcp_connections % 10000));
        int tries = 0;
        while (net_tcp_port_in_use(lport) && tries < 10000) {
            lport = (u16)(40000 + ((lport - 40000 + 1) % 10000));
            tries++;
        }
        if (net_tcp_port_in_use(lport)) {
            /* Entire ephemeral range busy — fail honestly instead of
             * creating a shadowed connection. */
            c->in_use = 0;
            return -1;
        }
        c->local_port = lport;
    }
    c->remote_port = dst_port;
    c->our_seq = 0x1000;
    c->our_ack = 0;
    c->sock_fd = -1;
    /* WP-09: init reliability fields */
    c->driver_snd_una = c->our_seq;
    c->driver_snd_wnd = 8192;
    c->cwnd = 1;           /* slow start: 1 MSS */
    c->ssthresh = 65535;   /* high threshold → slow start phase */
    c->rto = 30;           /* 300ms initial RTO (30 ticks @ 100Hz) */
    c->rto_deadline = 0;
    c->dup_ack_count = 0;
    c->mss = 1460;         /* default MSS (Ethernet MTU - 40) */
    c->win_scale_sent = 0;   /* BUG-0071: do not advertise a scale we never apply */ /* window scale: 2^7 = 128 → 8192*128 = 1MB */
    c->win_scale_recv = 0;
    c->ts_recent = 0;
    c->ts_echo = 0;
    c->ts_enabled = 0;
    c->rtx_len = 0;
    c->rtx_sent = 0;   /* BUG-0205: nothing queued or in flight */
    c->rtx_seq = 0;
    c->rtt_measured = 0;
    c->srtt = 0;
    c->rttvar = 0;
    /* WP-09 mainstream: CUBIC + SACK + fast recovery init */
    net_tcp_cc_init(&c->cc);
    c->fr_active = 0;
    c->sack_permitted = 0;
    c->send_tick = 0;
    c->rtx_retransmitted = 0;
    memset(c->rtx_sacked, 0, sizeof(c->rtx_sacked));

    /* Send SYN with options. */
    net_tcp_send_raw(c, TCP_SYN, NULL, 0);
    c->our_seq += 1;
    c->driver_snd_una = c->our_seq;

    g_stats.net_tcp_connections++;

    /* Wait for SYN-ACK. */
    u64 start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 300) {  /* 3 second timeout */
        net_poll();
        if (c->state == TCP_ESTABLISHED) {
            return (int)(c - g_tcp_conns);
        }
    }
    c->in_use = 0;
    return -1;
}

/* WP-09: Update RTT estimate and RTO (RFC 6298 algorithm) */
static void net_tcp_update_rtt(net_tcp_conn_t *c, u32 rtt_ticks) {
    if (!c->rtt_measured) {
        /* First measurement: SRTT = RTT, RTTVAR = RTT/2 */
        c->srtt = rtt_ticks;
        c->rttvar = rtt_ticks / 2;
        c->rtt_measured = 1;
    } else {
        /* Subsequent: RTTVAR = 0.75*RTTVAR + 0.25*|SRTT-RTT| */
        u32 diff = (c->srtt > rtt_ticks) ? (c->srtt - rtt_ticks) : (rtt_ticks - c->srtt);
        c->rttvar = (3 * c->rttvar + diff) / 4;
        /* SRTT = 0.875*SRTT + 0.125*RTT */
        c->srtt = (7 * c->srtt + rtt_ticks) / 8;
    }
    /* RTO = max(SRTT + 4*RTTVAR, 10 ticks = 100ms) */
    u32 rto = c->srtt + 4 * c->rttvar;
    if (rto < 10) rto = 10;
    if (rto > 600) rto = 600;  /* cap at 6 seconds */
    c->rto = rto;
}

/* BUG-0067 FIX: sequence/ack comparison helpers with wrap-around
 * protection (RFC 793 3.3). The bare comparisons below (ack > una,
 * seq < our_ack) silently misbehave once 32-bit sequence numbers wrap. */
#define SEQ_LT(a, b) ((i32)((a) - (b)) <  0)
#define SEQ_LE(a, b) ((i32)((a) - (b)) <= 0)
#define SEQ_GT(a, b) ((i32)((a) - (b)) >  0)
#define SEQ_GE(a, b) ((i32)((a) - (b)) >= 0)

/* WP-09: Check and handle RTO timer for all connections */
static void net_tcp_check_rto(void) {
    /* BUG-0063 FIX: this sweep runs from the timer IRQ while thread
     * context mutates the very same rtx state (ACK sliding the window,
     * senders appending to rtx_buf). A torn read of rtx_len/rtx_seq
     * retransmitted garbage. Interrupts are disabled for the whole
     * (short) sweep and the rflags saved on entry are restored at the
     * end (sti only when interrupts were enabled on entry). Nothing
     * inside the sweep changes the interrupt state — the old comment
     * claiming "net_tcp_send_raw itself re-enables" was false: send_raw
     * never touches rflags, the only re-enable is the restore below. */
    u64 irq_flags;
    __asm__ volatile("pushfq; pop %0; cli" : "=r"(irq_flags) :: "memory");
    u64 now = core_timer_ticks();
    for (int i = 0; i < TCP_MAX_CONNS; i++) {
        net_tcp_conn_t *c = &g_tcp_conns[i];
        if (!c->in_use) continue;
        /* BUG-0208: retire TIME_WAIT connections once the 10 s dwell
         * (rto_deadline holds the TIME_WAIT start tick) expires. */
        if (c->state == TCP_TIME_WAIT) {
            if (now >= c->rto_deadline) {
                c->state = TCP_CLOSED;
                c->in_use = 0;
            }
            continue;
        }
        /* BUG-0069 FIX (p1fix4 ordering repair): the SYN_RCVD recycle
         * MUST run before the ESTABLISHED-only filter below. The
         * p1fix1..p1fix3 revisions placed it after the
         * `state != TCP_ESTABLISHED` continue, which fires first for
         * every SYN_RCVD connection — the recycle was dead code, so 32
         * forged SYNs permanently filled the 32-slot connection table
         * (remote DoS; outbound connect() died with it too, no free
         * slot left). The handshake deadline is parked in rto_deadline
         * at SYN time (30 s); an expired SYN_RCVD is reaped here. */
        if (c->state == TCP_SYN_RCVD && now >= c->rto_deadline) {
            c->state = TCP_CLOSED;
            c->in_use = 0;
            continue;
        }
        if (c->state != TCP_ESTABLISHED) continue;
        /* BUG-0205: only data that was actually transmitted can time out.
         * rtx_sent == the in-flight byte count; rtx_len may additionally
         * hold queued-unsent bytes (Nagle / zero window) — those have no
         * RTO. */
        if (c->rtx_sent == 0 || c->rto_deadline == 0) continue;
        if (now < c->rto_deadline) continue;
        /* RTO expired! Retransmit oldest unacked (already-sent) data. */
        {
            int rtx = c->rtx_sent;
            if (rtx > c->mss) rtx = c->mss;
            /* Retransmit from rtx_buf */
            c->our_seq = c->rtx_seq;  /* go back to oldest unacked */
            net_tcp_send_raw(c, TCP_ACK | TCP_PSH, c->rtx_buf, rtx);
            c->our_seq = c->rtx_seq + (u32)rtx;
            c->rtx_retransmitted = 1;
        }
        /* CUBIC RTO response (RFC 8312 4.6): ssthresh = 0.7*cwnd,
         * cwnd = 1 MSS, back to slow start. */
        {
            u32 in_flight = (u32)c->rtx_sent;
            c->ssthresh = net_tcp_cc_on_rto(&c->cc, in_flight ? in_flight
                                                      : c->cwnd * c->mss);
            c->cwnd = 1;
            c->fr_active = 0;
            c->dup_ack_count = 0;
            memset(c->rtx_sacked, 0, sizeof(c->rtx_sacked));
        }
        /* Exponential backoff: double RTO */
        c->rto *= 2;
        if (c->rto > 600) c->rto = 600;
        c->rto_deadline = now + c->rto;
    }

    /* BUG-0063: restore the interrupt state saved on entry. */
    if (irq_flags & 0x200) __asm__ volatile("sti" ::: "memory");
}


/* BUG-0205/BUG-0212: transmit as much queued data as Nagle, the peer's
 * advertised window and the CUBIC congestion window allow. Called after
 * data is accepted into the send buffer and from the ACK path (every ACK
 * may open window/cwnd). Nagle rule (conservative, RFC 1122 4.2.3.4 /
 * RFC 9293 3.7.2): with unacked data in flight only FULL segments are
 * sent; when nothing is in flight even a small tail goes out immediately. */
static void net_tcp_flush_queued(net_tcp_conn_t *c) {
    if (!c->in_use) return;
    if (c->state != TCP_ESTABLISHED && c->state != TCP_CLOSE_WAIT) return;
    u32 mss = (c->mss > 0) ? (u32)c->mss : 1460u;
    while (c->rtx_len > c->rtx_sent && c->driver_snd_wnd > 0) {
        u32 queued = (u32)(c->rtx_len - c->rtx_sent);
        /* Nagle: coalesce when in-flight > 0 and the tail < MSS. */
        if (c->rtx_sent > 0 && queued < mss) break;
        /* Congestion window (bytes) minus the in-flight amount:
         * sendable = min(peer_window, cwnd - in_flight, queued). */
        u64 cwnd_bytes = (u64)c->cwnd * mss;
        u64 in_flight = (u64)c->rtx_sent;   /* bytes sent, unacked */
        u64 cwnd_avail = (cwnd_bytes > in_flight) ? (cwnd_bytes - in_flight) : 0;
        u64 budget = queued;
        if (budget > c->driver_snd_wnd) budget = c->driver_snd_wnd;
        if (budget > cwnd_avail) budget = cwnd_avail;
        if (budget == 0) break;   /* zero window or cwnd full: stay queued */
        int seg = (budget > mss) ? (int)mss : (int)budget;
        int was_first = (c->rtx_sent == 0);
        c->our_seq = c->rtx_seq + (u32)c->rtx_sent;
        net_tcp_send_raw(c, TCP_ACK | TCP_PSH, c->rtx_buf + c->rtx_sent, seg);
        c->rtx_sent += seg;
        c->our_seq = c->rtx_seq + (u32)c->rtx_sent;
        if (was_first) {
            /* Arm the RTO for the newly started unacked run. */
            u64 nowt = core_timer_ticks();
            c->rto_deadline = nowt + c->rto;
            c->send_tick = nowt;
            c->rtx_retransmitted = 0;
        }
        /* A partial segment means window/cwnd-limited; wait for the next
         * ACK (which flushes again) instead of pushing tiny segments. */
        if (seg < (int)mss) break;
    }
}

int net_tcp_send(int sock, const void *data, int len) {
    if (sock < 0 || sock >= TCP_MAX_CONNS) return -1;
    net_tcp_conn_t *c = &g_tcp_conns[sock];
    if (!c->in_use ||
        (c->state != TCP_ESTABLISHED && c->state != TCP_CLOSE_WAIT)) {
        /* WP-09 SSH debug: log why net_tcp_send failed */
        static const char *state_names[] = {
            "CLOSED", "SYN_SENT", "SYN_RCVD", "ESTABLISHED",
            "FIN_WAIT_1", "FIN_WAIT_2", "CLOSE_WAIT", "LAST_ACK", "CLOSING",
            "TIME_WAIT"
        };
        const char *sn = c->state < 10 ? state_names[c->state] : "?";
        char dbg[100];
        strcpy(dbg, "[tcp] send fail: sock=");
        char num[10];
        u64_to_str((u64)sock, num); strcat(dbg, num);
        strcat(dbg, " in_use="); u64_to_str((u64)c->in_use, num); strcat(dbg, num);
        strcat(dbg, " state="); u64_to_str((u64)c->state, num); strcat(dbg, num);
        strcat(dbg, " ("); strcat(dbg, sn); strcat(dbg, ")");
        strcat(dbg, "\n");
        screen_console_puts(dbg);
        return -1;
    }
    if (len < 0) return -1;
    if (len == 0) return 0;

    /* BUG-0205: data is FIRST accepted into the retransmission/send
     * buffer and only then transmitted (as far as Nagle, the peer window
     * and the congestion window allow). The old code transmitted
     * unconditionally and silently dropped the copy when rtx_buf was
     * full — sent-but-unrecorded data could never be retransmitted
     * (silent reliability loss). Now:
     *   - accept what fits; return -1 only when the buffer cannot take
     *     the whole payload (would-block, EAGAIN-like);
     *   - a peer zero-window keeps the data queued; it is retried
     *     automatically when the window re-opens (ACK path flush);
     *   - Nagle coalesces small writes while a previous segment is
     *     unacked; the ACK path flushes the tail (also covers SSH). */
    if (c->rtx_len < 0 || c->rtx_len > TCP_RTX_BUF_SIZE) c->rtx_len = 0;
    int space = TCP_RTX_BUF_SIZE - c->rtx_len;
    if (len > space) return -1;   /* would not fit: let the caller retry */
    /* BUG-0063 FIX: the memcpy into the retransmit buffer plus the
     * rtx_seq/rtx_len publish race against the IRQ-side ACK window
     * slide in net_tcp_handle_packet (net_poll runs from the timer IRQ
     * every 10 ms): that path memmoves rtx_buf and rewrites rtx_len/
     * rtx_seq, so an ACK landing between our copy and the length
     * publish would memmove a half-written buffer and subtract from a
     * stale rtx_len. Close the thread-vs-IRQ race with a cli window
     * around exactly the buffer copy + publish (single core: IRQs-off
     * makes it atomic; the space check above may only be optimistic
     * because the IRQ side can only SHRINK rtx_len, never grow it).
     * net_tcp_flush_queued runs after the window with IRQs restored —
     * it transmits and must not keep interrupts off. */
    u64 irq_flags;
    __asm__ volatile("pushfq; pop %0; cli" : "=r"(irq_flags) :: "memory");
    memcpy(c->rtx_buf + c->rtx_len, data, (usize)len);
    if (c->rtx_len == 0) c->rtx_seq = c->our_seq;
    c->rtx_len += len;
    if (irq_flags & 0x200) __asm__ volatile("sti" ::: "memory");
    net_tcp_flush_queued(c);
    return len;
}

int net_tcp_close(int sock) {
    if (sock < 0 || sock >= TCP_MAX_CONNS) return -1;
    net_tcp_conn_t *c = &g_tcp_conns[sock];
    if (!c->in_use) return -1;

    /* BUG-0208: real close semantics (RFC 9293 3.5).
     * Active close:  ESTABLISHED -> FIN_WAIT_1 -> FIN_WAIT_2 ->
     *                TIME_WAIT (10 s, bounded) -> CLOSED.
     * Simultaneous:  FIN_WAIT_1 -> CLOSING -> TIME_WAIT.
     * Passive close: CLOSE_WAIT -> LAST_ACK -> CLOSED.
     * The connection slot stays allocated through the FIN_WAIT, CLOSING,
     * LAST_ACK and TIME_WAIT linger states so late segments are answered
     * instead of hitting a freed conn (the old code zeroed in_use after
     * ~1 s unconditionally, so a FIN whose ACK had not arrived left the
     * peer's FIN answerless and LAST_ACK was unreachable).
     * net_tcp_check_rto() retires TIME_WAIT after the dwell; the ACK
     * state machine retires the CLOSED states. */
    switch (c->state) {
        case TCP_ESTABLISHED:
        case TCP_SYN_RCVD:
            /* Flush whatever is still queued so the FIN follows ALL data
             * (bounded effort — the close wait loop below also polls). */
            net_tcp_flush_queued(c);
            net_tcp_send_raw(c, TCP_FIN | TCP_ACK, NULL, 0);
            c->our_seq += 1;
            c->state = TCP_FIN_WAIT_1;
            break;
        case TCP_CLOSE_WAIT:
            /* Passive close: we already ACKed the peer's FIN. Flush any
             * data the app queued in CLOSE_WAIT (e.g. a TLS close_notify),
             * then send our FIN and go to LAST_ACK (previously never
             * entered). */
            net_tcp_flush_queued(c);
            net_tcp_send_raw(c, TCP_FIN | TCP_ACK, NULL, 0);
            c->our_seq += 1;
            c->state = TCP_LAST_ACK;
            break;
        case TCP_SYN_SENT:
            /* Connect never completed: just release the slot. */
            c->state = TCP_CLOSED;
            c->in_use = 0;
            return 0;
        case TCP_FIN_WAIT_1:
        case TCP_FIN_WAIT_2:
        case TCP_CLOSING:
        case TCP_LAST_ACK:
        case TCP_TIME_WAIT:
            /* Already closing — keep waiting for the peer. */
            return 0;
        case TCP_CLOSED:
        default:
            c->in_use = 0;
            return 0;
    }

    /* Wait briefly for the teardown to progress. On success the state
     * machine has moved us at least to FIN_WAIT_2 / TIME_WAIT (active)
     * or CLOSED (passive). The slot is intentionally NOT released here;
     * the linger states keep replying to peer traffic until retired. */
    u64 start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 100) {   /* 1 s @ 100 Hz */
        net_poll();
        if (!c->in_use) break;                        /* retired */
        if (c->state == TCP_CLOSED) break;
        if (c->state == TCP_TIME_WAIT) break;         /* full teardown seen */
    }
    return 0;
}

/* P1-13 FIX: implement net_tcp_listen — register a handler for incoming
 * connections on a port. When a SYN arrives, net_tcp_handle_packet will
 * create a connection and call the handler. */
#define TCP_MAX_LISTENERS 8
static struct {
    u16 port;
    net_tcp_handler_fn handler;
    int in_use;
} g_tcp_listeners[TCP_MAX_LISTENERS];

int net_tcp_listen(u16 port, net_tcp_handler_fn handler) {
    for (int i = 0; i < TCP_MAX_LISTENERS; i++) {
        if (!g_tcp_listeners[i].in_use) {
            g_tcp_listeners[i].port = port;
            g_tcp_listeners[i].handler = handler;
            g_tcp_listeners[i].in_use = 1;
            return 0;
        }
    }
    return -1;  /* table full */
}

/* BUG-0207: is a local TCP port already taken by a live connection
 * (any state, including TIME_WAIT) or a listener? */
static int net_tcp_port_in_use(u16 port) {
    for (int i = 0; i < TCP_MAX_CONNS; i++) {
        if (g_tcp_conns[i].in_use && g_tcp_conns[i].local_port == port) return 1;
    }
    for (int i = 0; i < TCP_MAX_LISTENERS; i++) {
        if (g_tcp_listeners[i].in_use && g_tcp_listeners[i].port == port) return 1;
    }
    return 0;
}

void net_tcp_handle_packet(u32 src_ip, const void *data, int len) {
    if (len < 20) return;
    const net_tcp_hdr_t *h = (const net_tcp_hdr_t *)data;
    u16 src_port = ntohs(h->src_port);
    u16 dst_port = ntohs(h->dst_port);
    u32 seq = ntohl(h->seq);
    u32 ack = ntohl(h->ack);
    u16 flags = ntohs(h->data_offset_flags) & 0x1FF;
    u16 win = ntohs(h->window);
    int hdr_len = (ntohs(h->data_offset_flags) >> 12) * 4;
    /* BUG-0203: validate data offset. doff < 5 means the header is
     * shorter than the mandatory 20 bytes (payload would point into the
     * header itself); doff*4 > len means the header claims more bytes
     * than the segment carries. Either way the segment is malformed —
     * drop it before options/payload parsing. */
    if (hdr_len < 20 || hdr_len > len) return;
    int payload_len = len - hdr_len;
    const void *payload = (const u8 *)data + hdr_len;
    const u8 *opts = (const u8 *)data + 20;
    int opt_len = hdr_len - 20;


    net_tcp_conn_t *c = net_tcp_find_conn(src_ip, dst_port, src_port);

    /* WP-09 mainstream: stale SACK blocks from previous packets are invalid */
    if (c) c->sack_count = 0;

    /* WP-09: Parse TCP options if present */
    int is_syn = (flags & TCP_SYN) ? 1 : 0;
    if (opt_len > 0 && c) {
        net_tcp_parse_options(c, opts, opt_len, is_syn);
    }
    if (!c) {
        /* P1-13 FIX: check if this is a SYN to a listening port. If so,
         * create a new connection, send SYN-ACK, and call the handler. */
        if (flags & TCP_SYN) {
            for (int i = 0; i < TCP_MAX_LISTENERS; i++) {
                if (g_tcp_listeners[i].in_use && g_tcp_listeners[i].port == dst_port) {
                    c = net_tcp_alloc_conn();
                    if (!c) return;
                    c->remote_ip = src_ip;
                    c->remote_port = src_port;
                    c->local_port = dst_port;
                    c->state = TCP_SYN_RCVD;
                    c->our_seq = 1000;
                    c->our_ack = seq + 1;
                    /* WP-09: init reliability fields for server-side conn */
                    c->driver_snd_una = c->our_seq;
                    c->driver_snd_wnd = 8192;
                    c->cwnd = 1;
                    c->ssthresh = 65535;
                    c->rto = 30;
                    c->mss = 1460;
                    c->win_scale_sent = 0;   /* BUG-0071: do not advertise a scale we never apply */
                    c->rtx_len = 0;
                    /* BUG-0069 FIX (timeout side): 30 s handshake deadline
                     * stored in rto_deadline; net_tcp_check_rto() reaps
                     * half-open connections when it fires. */
                    c->rto_deadline = core_timer_ticks() + 3000;
                    c->rtt_measured = 0;
                    /* BUG-0069 FIX: the SYN's options were parsed only for
                     * connections that already existed, so a new server-side
                     * connection never learned the peer's MSS or window
                     * scale. Re-run option parsing now that the connection
                     * object exists. */
                    {
                        u8 off5 = opts && opt_len ? opt_len : 0;
                        (void)off5;
                        net_tcp_parse_options(c, opts, opt_len, 1);
                    }
                    /* Send SYN-ACK. */
                    net_tcp_send_raw(c, TCP_SYN | TCP_ACK, NULL, 0);
                    c->our_seq += 1;
                    /* Call the handler to notify of new connection. */
                    if (g_tcp_listeners[i].handler) {
                        g_tcp_listeners[i].handler(src_ip, src_port);
                    }
                    return;
                }
            }
        }
        return;
    }

    if (flags & TCP_RST) {
        /* BUG-0068 FIX: a RST used to be accepted from anyone regardless
         * of its sequence number (blind-reset injection). RFC 793 3.4:
         * in SYN-RECEIVED only a RST with SEG.SEQ == SND.UNA is legal;
         * in established states the RST sequence must fall inside the
         * receive window. We check the same window inequality before
         * tearing the connection down. */
        u32 rcv_next = c->our_ack;
        u32 rcv_wnd  = 8192;   /* receive window as advertised */
        int in_window = SEQ_LE(rcv_next, seq) && SEQ_LT(seq, rcv_next + rcv_wnd);
        if (c->state == TCP_SYN_RCVD)
            in_window = (seq == rcv_next);
        if (in_window) {
            c->state = TCP_CLOSED;
            c->in_use = 0;
        }
        return;
    }

    switch (c->state) {
        case TCP_SYN_SENT:
            if ((flags & TCP_SYN) && (flags & TCP_ACK)) {
                /* BUG-0209: a SYN-ACK must acknowledge OUR SYN
                 * (SEG.ACK == SND.NXT, RFC 9293 3.10.7.2 SEGMENT ARRIVES).
                 * No data can have been sent in SYN_SENT, so SND.NXT is
                 * exactly our_seq (ISN + 1). Without this check any
                 * spoofed SYN-ACK completed the "handshake". */
                if (ack != c->our_seq) break;
                c->our_ack = seq + 1;
                /* Send ACK. */
                net_tcp_send_raw(c, TCP_ACK, NULL, 0);
                c->state = TCP_ESTABLISHED;
            }
            break;
        case TCP_SYN_RCVD:
            /* P1-12 FIX: handle SYN_RCVD — ACK completes the handshake. */
            if (flags & TCP_ACK) {
                c->state = TCP_ESTABLISHED;
            }
            break;
        case TCP_ESTABLISHED:
            /* WP-09: Handle ACK for sent data */
            if (flags & TCP_ACK) {
                /* Update driver_snd_una (slide window) */
                if (SEQ_GT(ack, c->driver_snd_una)) {   /* BUG-0067 */
                    /* WP-09: New data ACKed — slide retransmission buffer */
                    u32 acked_bytes = ack - c->driver_snd_una;
                    if (c->rtx_len > 0 && acked_bytes <= (u32)c->rtx_len) {
                        /* Slide rtx_buf forward by acked_bytes */
                        int remaining = c->rtx_len - (int)acked_bytes;
                        if (remaining > 0) {
                            memmove(c->rtx_buf, c->rtx_buf + acked_bytes, remaining);
                        }
                        c->rtx_len = remaining;
                        /* BUG-0205: the sent/unsent split slides too — the
                         * ACKed bytes were by definition sent, so in-flight
                         * shrinks by acked_bytes. */
                        c->rtx_sent = (c->rtx_sent > (int)acked_bytes)
                                    ? (c->rtx_sent - (int)acked_bytes) : 0;
                        c->rtx_seq = ack;
                        if (c->rtx_len == 0) {
                            c->rto_deadline = 0;  /* disarm RTO */
                        } else {
                            c->rto_deadline = core_timer_ticks() + c->rto;
                        }
                        /* Slide the SACK bitmap: drop blocks fully covered by
                         * the ack, keep partial ones conservatively cleared. */
                        {
                            int shift_blocks = (int)(acked_bytes / 256);
                            int total = TCP_RTX_BUF_SIZE / 256;
                            int partial = ((int)(acked_bytes % 256) != 0) ? 1 : 0;
                            for (int bi = 0; bi < total; bi++) {
                                int src = bi + shift_blocks;
                                u8 v = 0;
                                if (src < total && bi < total - shift_blocks) {
                                    v = c->rtx_sacked[src];
                                }
                                if (src < total && partial) v = 0;
                                c->rtx_sacked[bi] = v;
                            }
                        }
                    } else if (c->rtx_len > 0) {
                        /* All data ACKed */
                        c->rtx_len = 0;
                        c->rtx_sent = 0;   /* BUG-0205 */
                        c->rto_deadline = 0;
                    }
                    c->driver_snd_una = ack;

                    /* WP-09 mainstream: end fast recovery (deflate cwnd) */
                    if (c->fr_active) {
                        c->cwnd = c->ssthresh / (c->mss ? c->mss : 1);
                        if (c->cwnd < 1) c->cwnd = 1;
                        c->fr_active = 0;
                        c->cc.epoch_start = 0;  /* start a new CUBIC epoch */
                    } else {
                        /* CUBIC congestion control (RFC 8312) */
                        u32 now = core_timer_ticks();
                        u32 new_bytes = net_tcp_cc_on_ack(&c->cc,
                                                  c->cwnd * c->mss,
                                                  c->ssthresh, now, c->mss,
                                                  acked_bytes);
                        c->cwnd = new_bytes / c->mss;
                        if (c->cwnd < 1) c->cwnd = 1;
                    }
                    c->dup_ack_count = 0;  /* reset dup ACK counter */

                    /* RTT sample (Karn's rule: skip retransmitted segments) */
                    if (c->rtx_len > 0 && !c->rtx_retransmitted &&
                        c->send_tick != 0) {
                        u64 nowt = core_timer_ticks();
                        u32 rtt = (u32)(nowt - c->send_tick);
                        if (rtt > 0 && rtt < 600) {
                            net_tcp_update_rtt(c, rtt);
                        }
                    }
                } else if (ack == c->driver_snd_una && payload_len == 0) {
                    /* WP-09 mainstream: duplicate ACK → fast retransmit +
                     * fast recovery (RFC 8312 4.5 / RFC 5681 3.2) */
                    c->dup_ack_count++;
                    if (c->dup_ack_count == 3) {
                        u32 ss = net_tcp_cc_on_fast_recovery_enter(&c->cc,
                                                           c->cwnd * c->mss);
                        c->ssthresh = ss;
                        c->fr_active = 1;
                        c->cwnd = ss / c->mss + 3;  /* inflate: 3 dup ACKs */
                        /* Fast retransmit the FIRST not-yet-sacked segment
                         * (BUG-0205: only already-SENT data is a
                         * retransmission candidate — bound by rtx_sent). */
                        if (c->rtx_sent > 0) {
                            int off = 0;
                            if (c->sack_count > 0) {
                                int total = TCP_RTX_BUF_SIZE / 256;
                                while (off < c->rtx_sent) {
                                    int blk = off / 256;
                                    int overrun = blk >= total;
                                    if (!overrun && c->rtx_sacked[blk]) {
                                        off = (blk + 1) * 256;
                                        if (off > c->rtx_sent) off = c->rtx_sent;
                                        continue;
                                    }
                                    break;
                                }
                            }
                            if (off < c->rtx_sent) {
                                int rtx = c->rtx_sent - off;
                                if (rtx > c->mss) rtx = c->mss;
                                u32 saved_seq = c->our_seq;
                                c->our_seq = c->rtx_seq + (u32)off;
                                net_tcp_send_raw(c, TCP_ACK | TCP_PSH,
                                             c->rtx_buf + off, rtx);
                                c->our_seq = saved_seq;
                                c->rtx_retransmitted = 1;
                            }
                        }
                    } else if (c->dup_ack_count > 3 && c->fr_active) {
                        c->cwnd++;  /* window inflation per dup ACK */
                    }
                }
            }

            /* WP-09: Update send window from peer's advertised window */
            if (c->win_scale_recv > 0) {
                c->driver_snd_wnd = (u32)win << c->win_scale_recv;
            } else {
                c->driver_snd_wnd = win;
            }

            if (payload_len > 0) {
                /* WP-09 fix: proper receive-side segmentation handling.
                 * - fully-duplicate segments are re-ACKed, not re-buffered
                 * - in-order segments are appended to rx_buf
                 * - future (out-of-order) segments are cached and drained in
                 *   order when the gap fills (real TCP reliability) */
                if (SEQ_LE(seq + payload_len, c->our_ack)) {   /* BUG-0067 */
                    /* WP-10u: per-duplicate console print removed (same
                     * serial-throughput problem as the in-order print). */
                    net_tcp_send_raw(c, TCP_ACK, NULL, 0);
                    break;
                }
                if (SEQ_LT(seq, c->our_ack)) {   /* BUG-0067 */
                    /* partially-duplicate segment: trim overlapped head */
                    int skip = (int)(c->our_ack - seq);
                    payload += skip;
                    payload_len -= skip;
                    seq = c->our_ack;
                    if (payload_len <= 0) { net_tcp_send_raw(c, TCP_ACK, NULL, 0); break; }
                }
                if (seq != c->our_ack) {
                    /* future segment: cache it, then re-ACK the left edge so
                     * the peer fills the gap */
                    int slot = c->ooo_count;
                    int dup = 0;
                    for (int k = 0; k < c->ooo_count; k++) {
                        if (c->ooo_seq[k] == seq) { dup = 1; break; }
                    }
                    if (!dup && slot < TCP_OOO_MAX && payload_len <= TCP_OOO_SEG) {
                        c->ooo_seq[slot] = seq;
                        c->ooo_len[slot] = (u16)payload_len;
                        memcpy(c->ooo_data[slot], payload, payload_len);
                        c->ooo_count++;
                    }
                    net_tcp_send_raw(c, TCP_ACK, NULL, 0);
                    break;
                }
                /* WP-10u: the per-segment "[tcp] in-order" console print
                 * used to live here.  A bulk transfer (update package
                 * download) produces thousands of segments and each serial
                 * print costs ~4 ms at 115200 baud, throttling transfers to
                 * ~35 KB/s and starving the poll loop.  Removed; the dup /
                 * ooo paths below still report anomalies. */
                if (c->rx_len + payload_len < (int)sizeof(c->rx_buf)) {
                    memcpy(c->rx_buf + c->rx_len, payload, payload_len);
                    c->rx_len += payload_len;
                    c->our_ack = seq + payload_len;
                    /* drain cached segments that are now in order */
                    int drained = 1;
                    while (drained) {
                        drained = 0;
                        for (int k = 0; k < c->ooo_count; k++) {
                            if (c->ooo_seq[k] == c->our_ack && c->ooo_len[k] > 0) {
                                if (c->rx_len + c->ooo_len[k] < (int)sizeof(c->rx_buf)) {
                                    memcpy(c->rx_buf + c->rx_len, c->ooo_data[k], c->ooo_len[k]);
                                    c->rx_len += c->ooo_len[k];
                                    c->our_ack += c->ooo_len[k];
                                    for (int j = k; j < c->ooo_count - 1; j++) {
                                        c->ooo_seq[j] = c->ooo_seq[j+1];
                                        c->ooo_len[j] = c->ooo_len[j+1];
                                        memcpy(c->ooo_data[j], c->ooo_data[j+1], TCP_OOO_SEG);
                                    }
                                    c->ooo_count--;
                                    drained = 1;
                                }
                                break;
                            }
                        }
                    }
                    net_tcp_send_raw(c, TCP_ACK, NULL, 0);
                } else {
                    /* WP-09-FIX BUG-002: rx_buf full — do NOT consume this
                     * segment, do NOT advance our_ack, do NOT ACK. The peer
                     * retransmits once the app drains rx_buf (acts as a zero
                     * window). Previously the payload was silently dropped
                     * yet still ACKed (fake ACK) → 98% data loss on bulk
                     * transfer. */
                    break;
                }
            }
            if (flags & TCP_FIN) {
                /* P1-12 FIX: remote sent FIN → go to CLOSE_WAIT, not LAST_ACK.
                 * The standard TCP state machine: ESTABLISHED + FIN → CLOSE_WAIT.
                 * We ACK the FIN and wait for our side to close. */
                c->our_ack = seq + payload_len + 1;
                net_tcp_send_raw(c, TCP_ACK, NULL, 0);
                c->state = TCP_CLOSE_WAIT;
            }
            /* BUG-0205/BUG-0212: the ACK may have freed in-flight bytes
             * (cwnd grows) or re-opened the peer's window — push any
             * queued-unsent data now. This is the "flush on ACK" that
             * makes Nagle and the effective congestion window work. */
            net_tcp_flush_queued(c);
            break;
        case TCP_CLOSE_WAIT:
            /* P1-12 FIX: handle CLOSE_WAIT — remote already closed.
             * We can still send data. When we're done, we send FIN. */
            if (flags & TCP_RST) {
                c->state = TCP_CLOSED;
                c->in_use = 0;
            }
            break;
        case TCP_FIN_WAIT_1:
            if (flags & TCP_ACK && !(flags & TCP_FIN)) {
                c->state = TCP_FIN_WAIT_2;
            } else if (flags & TCP_FIN) {
                /* Simultaneous close: both sent FIN. */
                c->our_ack = seq + 1;
                net_tcp_send_raw(c, TCP_ACK, NULL, 0);
                c->state = TCP_CLOSING;
            }
            break;
        case TCP_FIN_WAIT_2:
            if (flags & TCP_FIN) {
                c->our_ack = seq + 1;
                net_tcp_send_raw(c, TCP_ACK, NULL, 0);
                /* BUG-0208: both FINs done — enter TIME_WAIT (bounded) so
                 * old duplicate segments cannot poison a reused 4-tuple.
                 * rto_deadline parks the TIME_WAIT start tick. */
                c->state = TCP_TIME_WAIT;
                c->rto_deadline = core_timer_ticks() + TCP_TIME_WAIT_TICKS;
            }
            break;
        case TCP_CLOSING:
            /* P1-12 FIX: handle CLOSING — waiting for ACK of our FIN. */
            if (flags & TCP_ACK) {
                /* BUG-0208: simultaneous close completes → TIME_WAIT. */
                c->state = TCP_TIME_WAIT;
                c->rto_deadline = core_timer_ticks() + TCP_TIME_WAIT_TICKS;
            }
            break;
        case TCP_TIME_WAIT:
            /* BUG-0208: the peer's FIN retransmission arrived — re-ACK it
             * and restart the dwell (RFC 9293 3.5: TIME_WAIT restarts on
             * a duplicated FIN so the peer never hangs in LAST_ACK). */
            if (flags & TCP_FIN) {
                c->our_ack = seq + 1;
                net_tcp_send_raw(c, TCP_ACK, NULL, 0);
                c->rto_deadline = core_timer_ticks() + TCP_TIME_WAIT_TICKS;
            }
            break;
        case TCP_LAST_ACK:
            if (flags & TCP_ACK) {
                c->state = TCP_CLOSED;
                c->in_use = 0;
            }
            break;
        default:
            break;
    }
}

/* ============================================================
 * Socket API
 * ============================================================ */
#define MAX_SOCKETS 32
typedef struct {
    int type;       /* SOCK_TCP or SOCK_UDP */
    u32 remote_ip;
    u16 local_port;
    u16 remote_port;
    int in_use;
    int net_tcp_conn;   /* index into g_tcp_conns for TCP sockets */
    /* UDP receive buffer */
    u8  rx_buf[2048];
    int rx_len;
    u32 rx_from_ip;
    u16 rx_from_port;
} net_socket_t;

static net_socket_t g_sockets[MAX_SOCKETS];

/* Called from UDP handler to deliver data to bound sockets.
 * Returns 1 when a socket with a matching port exists (BUG-0217(b): an
 * overflowing socket buffer drops the NEW datagram and counts it in
 * stats — the previously-buffered datagram is kept), 0 when no socket
 * owns the port. */
int net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
                           const void *data, int len) {
    for (int i = 0; i < MAX_SOCKETS; i++) {
        if (g_sockets[i].in_use && g_sockets[i].type == SOCK_UDP &&
            g_sockets[i].local_port == dst_port) {
            if (g_sockets[i].rx_len == 0) {
                int n = len;
                if (n > (int)sizeof(g_sockets[i].rx_buf)) n = sizeof(g_sockets[i].rx_buf);
                memcpy(g_sockets[i].rx_buf, data, n);
                g_sockets[i].rx_len = n;
                g_sockets[i].rx_from_ip = src_ip;
                g_sockets[i].rx_from_port = src_port;
            } else {
                /* BUG-0217(b): rx buffer still full — drop the NEW datagram
                 * and count it (the app keeps its buffered datagram). */
                g_stats.net_udp_rx_dropped++;
            }
            return 1;
        }
    }
    return 0;
}

int net_socket(int type) {
    for (int i = 0; i < MAX_SOCKETS; i++) {
        if (!g_sockets[i].in_use) {
            memset(&g_sockets[i], 0, sizeof(net_socket_t));
            g_sockets[i].in_use = 1;
            g_sockets[i].type = type;
            g_sockets[i].net_tcp_conn = -1;
            return i;
        }
    }
    return -1;
}

int net_bind(int fd, u32 ip, u16 port) {
    if (fd < 0 || fd >= MAX_SOCKETS || !g_sockets[fd].in_use) return -1;
    /* BUG-0217 FIX: reject a conflicting bind. The socket layer keeps no
     * per-socket local IP (the ip argument is and remains ignored — the
     * NIC's single address is used, see docs/EXTENSIONS_WP06.md), so an
     * "exact (ip, port)" conflict is necessarily a PORT conflict within
     * the same socket type (TCP and UDP port spaces are separate, as in
     * mainstream stacks): delivery demuxes on local_port alone and the
     * FIRST open match wins exclusively, so a second same-type socket on
     * the same port could never receive anything anyway. EADDRINUSE
     * equivalent, returned as this function's only error code (-1, the
     * convention used by net_socket / net_udp_bind). Port 0 ("no
     * specific port", never a demux key) does not conflict. Rebinding
     * the same fd is allowed (idempotent rebind). */
    if (port != 0) {
        for (int i = 0; i < MAX_SOCKETS; i++) {
            if (i != fd && g_sockets[i].in_use &&
                g_sockets[i].type == g_sockets[fd].type &&
                g_sockets[i].local_port == port) {
                return -1;
            }
        }
    }
    g_sockets[fd].local_port = port;
    (void)ip;
    return 0;
}

int net_connect(int fd, u32 ip, u16 port) {
    if (fd < 0 || fd >= MAX_SOCKETS || !g_sockets[fd].in_use) return -1;
    g_sockets[fd].remote_ip = ip;
    g_sockets[fd].remote_port = port;

    if (g_sockets[fd].type == SOCK_TCP) {
        int conn = net_tcp_connect(ip, port);
        if (conn < 0) return -1;
        g_sockets[fd].net_tcp_conn = conn;
        g_tcp_conns[conn].sock_fd = fd;
    }
    return 0;
}

/* WP-09: Accept an incoming TCP connection on a listening socket.
 * net_tcp_listen() registered the port; the SYN path creates a conn with
 * sock_fd == -1. When its handshake completes (ESTABLISHED) we claim it
 * here, allocate a fresh socket for it, and return the new fd. */

/* BUG-0132 FIX: cooperative cancellation hook, see net_core.h. */
static net_accept_cancel_fn g_accept_cancel_fn = 0;

void net_accept_set_cancel_fn(net_accept_cancel_fn fn) {
    g_accept_cancel_fn = fn;
}

int net_accept(int listen_fd, u32 *client_ip, u16 *client_port) {
    if (listen_fd < 0 || listen_fd >= MAX_SOCKETS || !g_sockets[listen_fd].in_use) return -1;
    u16 lport = g_sockets[listen_fd].local_port;
    u64 start = core_timer_ticks();
    for (int loop = 0; ; loop++) {                       /* bounded by tick timeout */
        /* BUG-0132 FIX: give the registered cancel-check callback a chance
         * to run on every poll iteration. sshd's callback drains the
         * keyboard queue and returns non-zero on Ctrl+C, so the console
         * stays responsive and the blocking wait can be interrupted. */
        if (g_accept_cancel_fn && g_accept_cancel_fn() != 0) {
            return -2;  /* cancelled by caller; caller closes the socket */
        }
        for (int i = 0; i < TCP_MAX_CONNS; i++) {
            net_tcp_conn_t *c = &g_tcp_conns[i];
            if (c->in_use && c->local_port == lport && c->sock_fd < 0 &&
                c->state == TCP_ESTABLISHED) {
                int fd = net_socket(SOCK_TCP);
                if (fd < 0) return -1;
                c->sock_fd = fd;
                g_sockets[fd].net_tcp_conn = i;
                g_sockets[fd].local_port = lport;
                g_sockets[fd].remote_ip = c->remote_ip;
                g_sockets[fd].remote_port = c->remote_port;
                if (client_ip) *client_ip = c->remote_ip;
                if (client_port) *client_port = c->remote_port;
                return fd;
            }
        }
        net_poll();
        for (volatile int d = 0; d < 30000; d++) { /* brief yield */ }
        /* BUG-0206: the timeout is in TICKS, and the kernel timer runs at
         * OC_TIMER_HZ (=100, core_timer.h) — not 1000. "120 * 1000" was
         * 1200 s (20 minutes); the intended 120 s is 120 * OC_TIMER_HZ. */
        if (core_timer_ticks() - start > 120 * (u64)OC_TIMER_HZ) {   /* 120 s @ OC_TIMER_HZ */
            return -1;  /* timed out */
        }
    }
}

int net_send(int fd, const void *data, int len) {
    if (fd < 0 || fd >= MAX_SOCKETS || !g_sockets[fd].in_use) return -1;
    if (g_sockets[fd].type == SOCK_TCP) {
        return net_tcp_send(g_sockets[fd].net_tcp_conn, data, len);
    } else {
        return net_udp_send(g_sockets[fd].remote_ip, g_sockets[fd].remote_port,
                       g_sockets[fd].local_port, data, len);
    }
}

int net_recv(int fd, void *buf, int len) {
    if (fd < 0 || fd >= MAX_SOCKETS || !g_sockets[fd].in_use) return -1;

    if (g_sockets[fd].type == SOCK_TCP) {
        int conn = g_sockets[fd].net_tcp_conn;
        if (conn < 0 || !g_tcp_conns[conn].in_use) return -1;
        /* Wait for data. */
        u64 start = core_timer_ticks();
        while ((core_timer_ticks() - start) < 1500) {
            net_poll();
            if (g_tcp_conns[conn].rx_len > 0) {
                int n = g_tcp_conns[conn].rx_len;
                if (n > len) n = len;
                memcpy(buf, g_tcp_conns[conn].rx_buf, n);
                /* WP-09 fix: support partial reads — instead of clearing the
                 * entire rx_buf, only consume n bytes by shifting the rest
                 * forward. This lets callers do "read 5-byte header, then read
                 * body" without losing the body bytes that arrived in the
                 * same TCP segment. */
                if (n < g_tcp_conns[conn].rx_len) {
                    int remaining = g_tcp_conns[conn].rx_len - n;
                    /* memmove the rest to the front */
                    u8 *p = g_tcp_conns[conn].rx_buf;
                    for (int i = 0; i < remaining; i++) p[i] = p[n + i];
                    g_tcp_conns[conn].rx_len = remaining;
                } else {
                    g_tcp_conns[conn].rx_len = 0;
                }
                /* WP-09-FIX BUG-002: send a window-update ACK after
                 * consuming data so a peer that throttled itself on our
                 * shrunken advertised window resumes sending. */
                net_tcp_send_raw(&g_tcp_conns[conn], TCP_ACK, NULL, 0);
                /* BUG-0205: the drained buffer re-opened our advertised
                 * window — give the send queue a chance to flush too. */
                net_tcp_flush_queued(&g_tcp_conns[conn]);
                return n;
            }
        }
        return -1;
    } else {
        /* UDP: wait for data. */
        u64 start = core_timer_ticks();
        while ((core_timer_ticks() - start) < 500) {
            net_poll();
            if (g_sockets[fd].rx_len > 0) {
                int n = g_sockets[fd].rx_len;
                if (n > len) n = len;
                memcpy(buf, g_sockets[fd].rx_buf, n);
                g_sockets[fd].rx_len = 0;
                return n;
            }
        }
        return -1;
    }
}

int net_close(int fd) {
    if (fd < 0 || fd >= MAX_SOCKETS || !g_sockets[fd].in_use) return -1;
    if (g_sockets[fd].type == SOCK_TCP && g_sockets[fd].net_tcp_conn >= 0) {
        net_tcp_close(g_sockets[fd].net_tcp_conn);
    }
    g_sockets[fd].in_use = 0;
    return 0;
}

int net_tcp_established(int fd) {
    if (fd < 0 || fd >= MAX_SOCKETS || !g_sockets[fd].in_use) return 0;
    if (g_sockets[fd].type != SOCK_TCP || g_sockets[fd].net_tcp_conn < 0) return 0;
    return (g_tcp_conns[g_sockets[fd].net_tcp_conn].state == TCP_ESTABLISHED)
               ? 1 : 0;
}

/* Returns 1 if the TCP connection for fd is in ESTABLISHED or CLOSE_WAIT
 * state (i.e. sending a close_notify alert is still legal), 0 otherwise. */
int net_tcp_established_or_close_wait(int fd) {
    if (fd < 0 || fd >= MAX_SOCKETS || !g_sockets[fd].in_use) return 0;
    if (g_sockets[fd].type != SOCK_TCP || g_sockets[fd].net_tcp_conn < 0) return 0;
    net_tcp_state_t st = g_tcp_conns[g_sockets[fd].net_tcp_conn].state;
    return (st == TCP_ESTABLISHED || st == TCP_CLOSE_WAIT) ? 1 : 0;
}

/* ============================================================
 * DHCP client
 * ============================================================ */
typedef struct __attribute__((packed)) {
    u8  op;
    u8  htype;
    u8  hlen;
    u8  hops;
    u32 xid;
    u16 secs;
    u16 flags;
    u32 ciaddr;
    u32 yiaddr;
    u32 siaddr;
    u32 giaddr;
    u8  chaddr[16];
    u8  sname[64];
    u8  file[128];
    u32 magic;
    u8  options[312];
} net_dhcp_pkt_t;

static u32 g_dhcp_offered_ip = 0;
static u32 g_dhcp_server_ip = 0;
static int g_dhcp_got_offer = 0;
static int g_dhcp_got_ack = 0;

static void net_dhcp_handler(u32 src_ip, u16 src_port, const void *data, int len) {
    (void)src_ip;
    (void)src_port;
    if (len < (int)sizeof(net_dhcp_pkt_t) - 312) return;
    const net_dhcp_pkt_t *p = (const net_dhcp_pkt_t *)data;
    if (ntohl(p->magic) != 0x63825363) return;

    /* Parse options. */
    int opt_len = len - ((const u8 *)p->options - (const u8 *)data);
    const u8 *opts = p->options;
    int i = 0;
    u8 msg_type = 0;

    while (i < opt_len && opts[i] != 0xFF) {
        u8 opt = opts[i++];
        if (opt == 0) continue;  /* pad */
        if (i >= opt_len) break;
        u8 olen = opts[i++];
        if (i + olen > opt_len) break;
        if (opt == 53 && olen >= 1) {
            msg_type = opts[i];
        }
        i += olen;
    }

    if (msg_type == 2) {
        /* DHCP OFFER. */
        g_dhcp_offered_ip = ntohl(p->yiaddr);
        g_dhcp_got_offer = 1;
    } else if (msg_type == 5) {
        /* DHCP ACK. */
        g_dhcp_got_ack = 1;
        g_dhcp_offered_ip = ntohl(p->yiaddr);
        /* Parse options for mask/gateway/dns. */
        i = 0;
        u32 mask = 0, gw = 0, dns = 0;
        while (i < opt_len && opts[i] != 0xFF) {
            u8 opt = opts[i++];
            if (opt == 0) continue;
            if (i >= opt_len) break;
            u8 olen = opts[i++];
            if (i + olen > opt_len) break;
            if (opt == 1 && olen >= 4) {
                mask = ntohl(*(u32 *)(opts + i));
            } else if (opt == 3 && olen >= 4) {
                gw = ntohl(*(u32 *)(opts + i));
            } else if (opt == 6 && olen >= 4) {
                dns = ntohl(*(u32 *)(opts + i));
            }
            i += olen;
        }
        if (mask) g_mask = mask;
        if (gw) g_gateway = gw;
        if (dns) g_dns = dns;
    }
}

int net_dhcp_discover(void) {
    if (!g_nic_ok) return -1;

    /* Bind UDP port 68 for DHCP responses. */
    net_udp_bind(DHCP_CLIENT_PORT, net_dhcp_handler);

    u8 buf[sizeof(net_dhcp_pkt_t)];
    net_dhcp_pkt_t *p = (net_dhcp_pkt_t *)buf;
    memset(p, 0, sizeof(net_dhcp_pkt_t));
    p->op = 1;  /* BOOTREQUEST */
    p->htype = 1;  /* Ethernet */
    p->hlen = 6;
    p->hops = 0;
    p->xid = htonl(0x12345678);
    p->secs = 0;
    p->flags = htons(0x8000);  /* broadcast */
    p->ciaddr = 0;
    p->yiaddr = 0;
    p->siaddr = 0;
    p->giaddr = 0;
    memcpy(p->chaddr, g_mac, 6);
    p->magic = htonl(0x63825363);

    /* Options: 53(msg type)=1(discover), 55(param req list), 0xFF(end). */
    int oi = 0;
    p->options[oi++] = 53; p->options[oi++] = 1; p->options[oi++] = 1;  /* DISCOVER */
    p->options[oi++] = 55; p->options[oi++] = 4;
    p->options[oi++] = 1;  /* subnet mask */
    p->options[oi++] = 3;  /* router */
    p->options[oi++] = 6;  /* DNS */
    p->options[oi++] = 0xFF;  /* end */

    int pkt_len = (int)((u8 *)(p->options + oi) - buf);
    /* Pad to minimum BOOTP size (300 bytes) - some DHCP servers require this. */
    while (pkt_len < 300) {
        p->options[oi++] = 0;  /* PAD option */
        pkt_len++;
    }
    g_dhcp_got_offer = 0;
    g_dhcp_got_ack = 0;

    /* Send DHCP DISCOVER with src IP 0.0.0.0 (per DHCP spec).
     * Temporarily set g_ip=0 so net_ip_send uses 0.0.0.0 as src. */
    u32 saved_ip = g_ip;
    u32 saved_mask = g_mask;
    g_ip = 0;
    g_mask = 0;

    /* Send DHCPDISCOVER (broadcast). */
    /* Debug: dump first 64 bytes of DHCP packet */
    {
        char dbuf[200]; char dn[20];
        strcpy(dbuf, "DHCP DISCOVER hex:\n");
        screen_console_puts(dbuf);
        for (int i = 0; i < 64; i++) {
            if (i % 16 == 0) {
                strcpy(dbuf, "  ");
                u64_to_hex((u64)i, dn, 2); strcat(dbuf, dn);
                strcat(dbuf, ": ");
            }
            u64_to_hex(buf[i], dn, 2);
            strcat(dbuf, dn); strcat(dbuf, " ");
            if (i % 16 == 15) {
                strcat(dbuf, "\n");
                screen_console_puts(dbuf);
                dbuf[0] = 0;
            }
        }
        if (64 % 16 != 0) { strcat(dbuf, "\n"); screen_console_puts(dbuf); }
    }
    net_udp_send(0xFFFFFFFF, DHCP_SERVER_PORT, DHCP_CLIENT_PORT, buf, pkt_len);
    
    /* Restore IP and mask for receiving the reply. */
    g_ip = saved_ip;
    g_mask = saved_mask;

    /* Wait for DHCPOFFER. */
    u64 start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 500) {
        net_poll();
        if (g_dhcp_got_offer) break;
    }
    if (!g_dhcp_got_offer) return -1;

    /* Send DHCPREQUEST. */
    memset(p, 0, sizeof(net_dhcp_pkt_t));
    p->op = 1;
    p->htype = 1;
    p->hlen = 6;
    p->xid = htonl(0x12345678);
    p->flags = htons(0x8000);
    memcpy(p->chaddr, g_mac, 6);
    p->magic = htonl(0x63825363);
    p->ciaddr = 0;
    p->yiaddr = 0;

    oi = 0;
    p->options[oi++] = 53; p->options[oi++] = 1; p->options[oi++] = 3;  /* REQUEST */
    p->options[oi++] = 50; p->options[oi++] = 4;  /* requested IP */
    *(u32 *)(p->options + oi) = htonl(g_dhcp_offered_ip); oi += 4;
    p->options[oi++] = 54; p->options[oi++] = 4;  /* server ID */
    *(u32 *)(p->options + oi) = htonl(g_dhcp_server_ip); oi += 4;
    p->options[oi++] = 0xFF;

    pkt_len = (int)((u8 *)(p->options + oi) - buf);

    g_dhcp_got_ack = 0;
    /* DHCP REQUEST also uses src 0.0.0.0 */
    g_ip = 0;
    g_mask = 0;
    net_udp_send(0xFFFFFFFF, DHCP_SERVER_PORT, DHCP_CLIENT_PORT, buf, pkt_len);
    g_ip = saved_ip;
    g_mask = saved_mask;

    /* Wait for DHCPACK. */
    start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 500) {
        net_poll();
        if (g_dhcp_got_ack) {
            g_ip = g_dhcp_offered_ip;
            return 0;
        }
    }
    return -1;
}

/* ============================================================
 * DNS client
 * ============================================================ */
typedef struct __attribute__((packed)) {
    u16 id;
    u16 flags;
    u16 qdcount;
    u16 ancount;
    u16 nscount;
    u16 arcount;
} net_dns_hdr_t;

static u32 g_dns_result_ip = 0;
static int g_dns_got_response = 0;
/* WP-09: DNS CNAME + AAAA support */
static u8  g_dns_result_aaaa[16];  /* IPv6 address */
static int g_dns_got_aaaa = 0;
static char g_dns_cname[256];      /* CNAME target */
static int g_dns_got_cname = 0;
/* WP-09 mainstream: MX / TXT / NS / SRV results */
#define DNS_MAX_MX 4
static u16 g_dns_mx_pref[DNS_MAX_MX];
static char g_dns_mx_host[DNS_MAX_MX][256];
static int  g_dns_mx_count = 0;
static char g_dns_result_txt[512];
static int  g_dns_txt_len = 0;
static int  g_dns_got_txt = 0;
static char g_dns_result_ns[256];
static int  g_dns_got_ns = 0;
static u16  g_dns_srv_pri, g_dns_srv_wgt, g_dns_srv_port;
static char g_dns_srv_target[256];
static int  g_dns_got_srv = 0;

/* Decode a DNS name at `off` (handles compression pointers, 128-jump cap).
 * Writes dotted text into out (out_len capped). Returns the offset just
 * past the name, or -1 on error. */
static int net_dns_decode_name(const u8 *pkt, int pkt_len, int off,
                           char *out, int out_len) {
    int ci = 0;
    int jumps = 0;
    int pos = off;
    int end = pkt_len;
    int advanced = 0;   /* offset after a followed pointer chain */
    for (;;) {
        if (pos < 0 || pos >= end) return -1;
        u8 b = pkt[pos];
        if ((b & 0xC0) == 0xC0) {
            if (pos + 1 >= end) return -1;
            u16 ptr = (u16)(((b & 0x3F) << 8) | pkt[pos + 1]);
            if (!advanced) advanced = pos + 2;
            if (++jumps > 128) return -1;
            pos = ptr;
            continue;
        }
        if (b == 0) {
            pos++;
            break;
        }
        int lablen = b;
        pos++;
        if (pos + lablen > end) return -1;
        if (ci > 0 && ci < out_len - 1) out[ci++] = '.';
        for (int l = 0; l < lablen; l++) {
            if (ci < out_len - 1) out[ci++] = pkt[pos + l];
        }
        pos += lablen;
    }
    out[ci] = 0;
    return advanced ? advanced : pos;
}

static void net_dns_handler(u32 src_ip, u16 src_port, const void *data, int len) {
    (void)src_ip;
    (void)src_port;
    if (len < (int)sizeof(net_dns_hdr_t)) return;
    const net_dns_hdr_t *h = (const net_dns_hdr_t *)data;
    if (ntohs(h->ancount) == 0) return;

    /* P1-14 FIX: add bounds checks throughout DNS parsing to prevent
     * OOB reads on truncated/malicious DNS responses. */
    const u8 *p = (const u8 *)data + sizeof(net_dns_hdr_t);
    const u8 *end = (const u8 *)data + len;

    /* Skip question name (labels until 0). */
    while (p < end && *p != 0) {
        if (*p & 0xC0) { p += 2; break; }
        p += *p + 1;
        if (p >= end) return;  /* P1-14: bounds */
    }
    if (p < end && *p == 0) p++;  /* skip null terminator */
    p += 4;  /* skip QTYPE and QCLASS */
    if (p > end) return;  /* P1-14: bounds */

    /* Parse first answer. */
    while (p < end) {
        /* Name (may be compressed). */
        if (*p & 0xC0) { p += 2; }
        else {
            while (p < end && *p != 0) { p += *p + 1; if (p >= end) return; }
            if (p < end) p++;
        }
        if (p + 10 > end) return;  /* P1-14: bounds */
        u16 type = ntohs(*(u16 *)(p)); p += 2;
        u16 cls = ntohs(*(u16 *)(p)); p += 2;
        (void)cls;
        p += 4;  /* TTL */
        if (p + 2 > end) return;  /* P1-14: bounds */
        u16 rdlen = ntohs(*(u16 *)(p)); p += 2;
        if (p + rdlen > end) return;  /* P1-14: bounds */
        if (type == 1 && rdlen == 4) {
            /* A record. */
            if (p + 4 > end) return;
            g_dns_result_ip = ntohl(*(u32 *)p);
            g_dns_got_response = 1;
        } else if (type == 28 && rdlen == 16) {
            /* WP-09: AAAA record (IPv6). */
            if (p + 16 > end) return;
            memcpy(g_dns_result_aaaa, p, 16);
            g_dns_got_aaaa = 1;
        } else if (type == 2 && rdlen > 0 && !g_dns_got_ns) {
            /* WP-09 mainstream: NS record — authoritative name server. */
            int no = net_dns_decode_name((const u8 *)data, len,
                                     (int)(p - (const u8 *)data),
                                     g_dns_result_ns, (int)sizeof(g_dns_result_ns));
            if (no > 0) g_dns_got_ns = 1;
        } else if (type == 15 && rdlen >= 3) {
            /* WP-09 mainstream: MX record — 2-byte preference + name. */
            if (g_dns_mx_count < DNS_MAX_MX) {
                int mi = g_dns_mx_count;
                g_dns_mx_pref[mi] = ntohs(*(u16 *)p);
                int no = net_dns_decode_name((const u8 *)data, len,
                                         (int)(p + 2 - (const u8 *)data),
                                         g_dns_mx_host[mi],
                                         (int)sizeof(g_dns_mx_host[mi]));
                if (no > 0) g_dns_mx_count++;
            }
        } else if (type == 16 && rdlen > 0) {
            /* WP-09 mainstream: TXT record — character-strings. */
            int ti = 0;
            const u8 *rdata = p;
            const u8 *rend = p + rdlen;
            while (rdata < rend && ti < (int)sizeof(g_dns_result_txt) - 1) {
                u8 slen = *rdata++;
                if (rdata + slen > rend) break;
                for (int l = 0; l < slen && ti < (int)sizeof(g_dns_result_txt) - 1; l++)
                    g_dns_result_txt[ti++] = rdata[l];
                rdata += slen;
            }
            g_dns_result_txt[ti] = 0;
            g_dns_txt_len = ti;
            g_dns_got_txt = 1;
        } else if (type == 33 && rdlen >= 7) {
            /* WP-09 mainstream: SRV record — pri(2) weight(2) port(2) target. */
            g_dns_srv_pri = ntohs(*(u16 *)p);
            g_dns_srv_wgt = ntohs(*(u16 *)(p + 2));
            g_dns_srv_port = ntohs(*(u16 *)(p + 4));
            int no = net_dns_decode_name((const u8 *)data, len,
                                     (int)(p + 6 - (const u8 *)data),
                                     g_dns_srv_target,
                                     (int)sizeof(g_dns_srv_target));
            if (no > 0) g_dns_got_srv = 1;
        } else if (type == 5 && rdlen > 0) {
            /* WP-09: CNAME record — extract the target name. */
            const u8 *rdata = p;
            int ci = 0;
            while (rdata < p + rdlen && rdata < end && ci < 255) {
                if (*rdata & 0xC0) {
                    /* Compression pointer — follow it. */
                    u16 offset = ((u16)(*rdata & 0x3F) << 8) | *(rdata + 1);
                    const u8 *ptr = (const u8 *)data + offset;
                    if (ptr >= (const u8 *)data && ptr < end) {
                        while (ptr < end && *ptr != 0 && ci < 255) {
                            if (*ptr & 0xC0) break;
                            int lablen = *ptr;
                            if (ci > 0) g_dns_cname[ci++] = '.';
                            for (int l = 0; l < lablen && ci < 255 && ptr + 1 + l < end; l++)
                                g_dns_cname[ci++] = ptr[1 + l];
                            ptr += lablen + 1;
                        }
                    }
                    break;
                } else if (*rdata == 0) {
                    break;
                } else {
                    int lablen = *rdata;
                    if (ci > 0) g_dns_cname[ci++] = '.';
                    for (int l = 0; l < lablen && ci < 255 && rdata + 1 + l < end; l++)
                        g_dns_cname[ci++] = rdata[1 + l];
                    rdata += lablen + 1;
                }
            }
            g_dns_cname[ci] = 0;
            g_dns_got_cname = 1;
        }
        p += rdlen;
    }
}

int net_dns_resolve(const char *name, u32 *net_ip_out) {
    if (!g_nic_ok || g_dns == 0) return -1;

    net_udp_bind(DNS_PORT, net_dns_handler);  /* We'll use port 53 as "source" (simplified) */

    u8 buf[512];
    net_dns_hdr_t *h = (net_dns_hdr_t *)buf;
    h->id = htons(0x1234);
    h->flags = htons(0x0100);  /* standard query, recursion desired */
    h->qdcount = htons(1);
    h->ancount = 0;
    h->nscount = 0;
    h->arcount = 0;

    /* Encode domain name as DNS labels. */
    u8 *q = buf + sizeof(net_dns_hdr_t);
    const char *p = name;
    while (*p) {
        const char *dot = p;
        while (*dot && *dot != '.') dot++;
        int labellen = dot - p;
        if (labellen > 63) return -1;
        /* BUG-0211: bounds-check every write (length byte + label + the
         * trailing NUL and the 4-byte QTYPE/QCLASS that must still fit). */
        if (q + 1 + labellen + 5 > buf + sizeof(buf)) return -1;
        *q++ = (u8)labellen;
        for (int i = 0; i < labellen; i++) *q++ = p[i];
        if (*dot == '.') p = dot + 1;
        else { p = dot; break; }
    }
    if (q + 5 > buf + sizeof(buf)) return -1;  /* BUG-0211: NUL + qtype + qclass */
    *q++ = 0;  /* end of name */
    *(u16 *)q = htons(1);  /* QTYPE = A */
    q += 2;
    *(u16 *)q = htons(1);  /* QCLASS = IN */
    q += 2;

    int pkt_len = (int)(q - buf);

    g_dns_got_response = 0;
    /* Use a fixed source port and bind to it so the response is received. */
    u16 net_dns_src_port = 1024 + DNS_PORT;
    net_udp_bind(net_dns_src_port, net_dns_handler);
    net_udp_send(g_dns, DNS_PORT, net_dns_src_port, buf, pkt_len);

    /* Wait for response. */
    u64 start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 500) {
        net_poll();
        if (g_dns_got_response) {
            *net_ip_out = g_dns_result_ip;
            return 0;
        }
    }
    return -1;
}

/* WP-09: net_dns_resolve_cname — resolve a CNAME chain and return the canonical name.
 * Also resolves the final A record if available. */
int net_dns_resolve_cname(const char *name, char *cname_out, int cname_len, u32 *net_ip_out) {
    if (!g_nic_ok || g_dns == 0) return -1;
    /* First do a normal A query — the response often includes CNAME records
     * if the name is a CNAME. */
    g_dns_got_cname = 0;
    g_dns_got_response = 0;
    g_dns_cname[0] = 0;
    u32 ip;
    if (net_dns_resolve(name, &ip) == 0) {
        /* Got an A record directly. Name is not a CNAME. */
        if (cname_len > 0) {
            strncpy(cname_out, name, cname_len - 1);
            cname_out[cname_len - 1] = 0;
        }
        if (net_ip_out) *net_ip_out = ip;
        return 0;
    }
    if (g_dns_got_cname && cname_out && cname_len > 0) {
        strncpy(cname_out, g_dns_cname, cname_len - 1);
        cname_out[cname_len - 1] = 0;
        /* Try to resolve the CNAME target */
        if (net_dns_resolve(g_dns_cname, &ip) == 0) {
            if (net_ip_out) *net_ip_out = ip;
            return 0;
        }
        return 0;  /* CNAME found but no A record for target */
    }
    return -1;
}

/* WP-09: net_dns_resolve_aaaa — resolve an AAAA record (IPv6).
 * Returns 16 bytes of IPv6 address, or -1 on failure. */
int net_dns_resolve_aaaa(const char *name, u8 *ipv6_out) {
    if (!g_nic_ok || g_dns == 0) return -1;

    u8 buf[512];
    net_dns_hdr_t *h = (net_dns_hdr_t *)buf;
    h->id = htons(0x5678);
    h->flags = htons(0x0100);
    h->qdcount = htons(1);
    h->ancount = 0; h->nscount = 0; h->arcount = 0;

    u8 *q = buf + sizeof(net_dns_hdr_t);
    const char *p = name;
    while (*p) {
        const char *dot = p;
        while (*dot && *dot != '.') dot++;
        int labellen = dot - p;
        if (labellen > 63) return -1;
        /* BUG-0211: bounds-check every write against the real buffer. */
        if (q + 1 + labellen + 5 > buf + sizeof(buf)) return -1;
        *q++ = (u8)labellen;
        for (int i = 0; i < labellen; i++) *q++ = p[i];
        if (*dot == '.') p = dot + 1;
        else { p = dot; break; }
    }
    if (q + 5 > buf + sizeof(buf)) return -1;  /* BUG-0211: NUL + qtype + qclass */
    *q++ = 0;
    *(u16 *)q = htons(28);  /* QTYPE = AAAA */
    q += 2;
    *(u16 *)q = htons(1);   /* QCLASS = IN */
    q += 2;

    int pkt_len = (int)(q - buf);
    g_dns_got_aaaa = 0;
    u16 net_dns_src_port = 2048 + DNS_PORT;
    net_udp_bind(net_dns_src_port, net_dns_handler);
    net_udp_send(g_dns, DNS_PORT, net_dns_src_port, buf, pkt_len);

    u64 start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 500) {
        net_poll();
        if (g_dns_got_aaaa) {
            if (ipv6_out) memcpy(ipv6_out, g_dns_result_aaaa, 16);
            return 0;
        }
    }
    return -1;
}

/* WP-09 mainstream: generic DNS query builder (name labels + QTYPE + IN).
 * BUG-0211: buf_len is the REAL output size — the old builder discarded it
 * with (void)buf_len and trusted the caller's "bounded" hostname, so any
 * future caller with a long name silently overran the buffer. The header
 * plus qname plus the 4-byte QTYPE/QCLASS trailer must all fit. */
static int net_dns_build_query(const char *name, u16 qtype, u16 id, u8 *buf, int buf_len) {
    if (buf == NULL || buf_len < (int)sizeof(net_dns_hdr_t) + 5) return -1;
    net_dns_hdr_t *h = (net_dns_hdr_t *)buf;
    h->id = htons(id);
    h->flags = htons(0x0100);  /* standard query, recursion desired */
    h->qdcount = htons(1);
    h->ancount = 0; h->nscount = 0; h->arcount = 0;
    u8 *q = buf + sizeof(net_dns_hdr_t);
    u8 *end = buf + buf_len;
    const char *p = name;
    while (*p) {
        const char *dot = p;
        while (*dot && *dot != '.') dot++;
        int labellen = dot - p;
        if (labellen > 63) return -1;
        /* length byte + label + room for the NUL and the 4-byte trailer */
        if (q + 1 + labellen + 5 > end) return -1;
        *q++ = (u8)labellen;
        for (int i = 0; i < labellen; i++) *q++ = p[i];
        if (*dot == '.') p = dot + 1;
        else { p = dot; break; }
    }
    if (q + 5 > end) return -1;  /* BUG-0211: NUL + qtype + qclass must fit */
    *q++ = 0;
    *(u16 *)q = htons(qtype); q += 2;
    *(u16 *)q = htons(1);     /* QCLASS = IN */ q += 2;
    return (int)(q - buf);
}

/* WP-09 mainstream: net_dns_resolve_mx — mail exchangers, sorted by preference.
 * mx_host_out receives up to max entries of "pref host" pairs. */
int net_dns_resolve_mx(const char *name, u16 *pref_out, char *host_out,
                   int host_stride, int max) {
    if (!g_nic_ok || g_dns == 0) return -1;
    u8 buf[512];
    int pkt_len = net_dns_build_query(name, 15, 0x2468, buf, (int)sizeof(buf));
    if (pkt_len < 0) return -1;
    g_dns_mx_count = 0;
    u16 net_dns_src_port = 4096 + DNS_PORT;
    net_udp_bind(net_dns_src_port, net_dns_handler);
    net_udp_send(g_dns, DNS_PORT, net_dns_src_port, buf, pkt_len);
    u64 start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 500) {
        net_poll();
        if (g_dns_mx_count > 0) break;
    }
    if (g_dns_mx_count == 0) return -1;
    int n = g_dns_mx_count < max ? g_dns_mx_count : max;
    for (int i = 0; i < n; i++) {
        pref_out[i] = g_dns_mx_pref[i];
        char *dst = host_out + i * host_stride;
        strncpy(dst, g_dns_mx_host[i], host_stride - 1);
        dst[host_stride - 1] = 0;
    }
    return n;
}

/* WP-09 mainstream: net_dns_resolve_txt — first TXT record string. */
int net_dns_resolve_txt(const char *name, char *txt_out, int txt_len) {
    if (!g_nic_ok || g_dns == 0) return -1;
    u8 buf[512];
    int pkt_len = net_dns_build_query(name, 16, 0x3690, buf, (int)sizeof(buf));
    if (pkt_len < 0) return -1;
    g_dns_got_txt = 0;
    u16 net_dns_src_port = 5120 + DNS_PORT;
    net_udp_bind(net_dns_src_port, net_dns_handler);
    net_udp_send(g_dns, DNS_PORT, net_dns_src_port, buf, pkt_len);
    u64 start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 500) {
        net_poll();
        if (g_dns_got_txt) break;
    }
    if (!g_dns_got_txt) return -1;
    int n = g_dns_txt_len < txt_len - 1 ? g_dns_txt_len : txt_len - 1;
    memcpy(txt_out, g_dns_result_txt, n);
    txt_out[n] = 0;
    return n;
}

/* WP-09 mainstream: net_dns_resolve_ns — authoritative name server. */
int net_dns_resolve_ns(const char *name, char *ns_out, int ns_len) {
    if (!g_nic_ok || g_dns == 0) return -1;
    u8 buf[512];
    int pkt_len = net_dns_build_query(name, 2, 0x4271, buf, (int)sizeof(buf));
    if (pkt_len < 0) return -1;
    g_dns_got_ns = 0;
    u16 net_dns_src_port = 6144 + DNS_PORT;
    net_udp_bind(net_dns_src_port, net_dns_handler);
    net_udp_send(g_dns, DNS_PORT, net_dns_src_port, buf, pkt_len);
    u64 start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 500) {
        net_poll();
        if (g_dns_got_ns) break;
    }
    if (!g_dns_got_ns) return -1;
    strncpy(ns_out, g_dns_result_ns, ns_len - 1);
    ns_out[ns_len - 1] = 0;
    return 0;
}

/* WP-09 mainstream: net_dns_resolve_srv — SRV record for _service._proto.name.
 * Returns 0 and fills pri/wgt/port/target on success. */
int net_dns_resolve_srv(const char *name, u16 *pri, u16 *wgt, u16 *port,
                    char *target_out, int target_len) {
    if (!g_nic_ok || g_dns == 0) return -1;
    u8 buf[512];
    int pkt_len = net_dns_build_query(name, 33, 0x52A1, buf, (int)sizeof(buf));
    if (pkt_len < 0) return -1;
    g_dns_got_srv = 0;
    u16 net_dns_src_port = 7168 + DNS_PORT;
    net_udp_bind(net_dns_src_port, net_dns_handler);
    net_udp_send(g_dns, DNS_PORT, net_dns_src_port, buf, pkt_len);
    u64 start = core_timer_ticks();
    while ((core_timer_ticks() - start) < 500) {
        net_poll();
        if (g_dns_got_srv) break;
    }
    if (!g_dns_got_srv) return -1;
    if (pri) *pri = g_dns_srv_pri;
    if (wgt) *wgt = g_dns_srv_wgt;
    if (port) *port = g_dns_srv_port;
    strncpy(target_out, g_dns_srv_target, target_len - 1);
    target_out[target_len - 1] = 0;
    return 0;
}

/* ============================================================
 * Network configuration getters/setters
 * ============================================================ */
u32 net_get_ip(void) { return g_ip; }
u32 net_get_mask(void) { return g_mask; }
u32 net_get_gateway(void) { return g_gateway; }
u32 net_get_dns(void) { return g_dns; }

void net_set_ip(u32 ip, u32 mask, u32 gateway) {
    g_ip = ip;
    g_mask = mask;
    g_gateway = gateway;
}

void net_set_dns(u32 dns) { g_dns = dns; }

void net_get_mac(u8 mac[6]) {
    memcpy(mac, g_mac, 6);
}

int net_get_link_status(void) {
    if (!g_nic_ok) return 0;
    /* WP-10b: a framework driver owns the NIC - ask it. */
    {
        driver_nic_device_t *nd = driver_nic_active();
        if (nd) {
            int ls = driver_nic_link_status(nd);
            return (ls == 1) ? 1 : 0;
        }
    }
    if (g_use_virtio) return 1;  /* virtio-net link is always up after init */
    u32 status = mmio_read32((volatile void *)((u8 *)g_e1000_mmio + E1000_STATUS));
    return (status & 0x02) ? 1 : 0;  /* LU bit */
}

void net_get_stats(net_stats_t *out) {
    *out = g_stats;
}

/* ============================================================
 * Network init and poll
 * ============================================================ */
void net_init(void) {
    memset(&g_stats, 0, sizeof(g_stats));
    driver_pci_init();
    net_arp_init();
    net_udp_init();
    if (net_tcp_init() != 0) return;   /* honest: net stays down */
    memset(g_sockets, 0, sizeof(g_sockets));

    /* WP-10b: probe the nic-framework families first (e1000e, igb,
     * rtl8168/8125/810x, rtl8139, bcm57xx, ixgbe, legacy others).  The
     * legacy built-in e1000/virtio-net paths below remain as fallbacks
     * so WP-06..WP-09 behaviour is unchanged when no WP-10b driver
     * claims the hardware. */
    if (driver_nic_probe_all() == 0) {
        g_nic_ok = 1;
        /* Publish the WP-10b NIC's station address to the stack (the
         * Ethernet layer uses g_mac as the frame source address). */
        driver_nic_device_t *nd = driver_nic_active();
        if (nd) driver_nic_get_mac(nd, g_mac);
        g_ip = IP4(10,0,2,15);
        g_mask = IP4(255,255,255,0);
        g_gateway = IP4(10,0,2,2);
        g_dns = IP4(10,0,2,3);
        return;
    }

    /* Try virtio-net first (it works better in QEMU), then fall back to e1000. */
    if (net_virtio_init() == 0) {
        screen_console_puts("virtio-net: initialized\n");
        g_nic_ok = 1;
        g_ip = IP4(10,0,2,15);
        g_mask = IP4(255,255,255,0);
        g_gateway = IP4(10,0,2,2);
        g_dns = IP4(10,0,2,3);
    } else if (e1000_init() == 0) {
        g_ip = IP4(10,0,2,15);
        g_mask = IP4(255,255,255,0);
        g_gateway = IP4(10,0,2,2);
        g_dns = IP4(10,0,2,3);
    }
}

static int g_net_polling = 0;  /* WP-09-FIX BUG-002: reentrancy guard */

void net_poll(void) {
    if (!g_nic_ok) return;
    /* WP-09-FIX BUG-002: net_poll runs BOTH from the timer IRQ
     * (net_timer_cb, every 10ms) and from thread context (net_recv's
     * wait loop). Without this guard the two contexts raced on the
     * e1000 RX/TX rings — outgoing pure-ACK window updates were
     * silently lost, the peer's send window never advanced and bulk
     * downloads stalled. */
    if (g_net_polling) return;
    g_net_polling = 1;
    /* WP-09: Check TCP RTO timers on every poll */
    net_tcp_check_rto();
    /* BUG-0210: evict timed-out IP fragment-reassembly slots. */
    net_ip_frag_gc();
    u8 buf[ETH_FRAME_MAX];
    for (int i = 0; i < 8; i++) {
        int len = 0;
        int polled_nic = 0;
        /* WP-10b: poll the nic-framework drivers first.
         * WP-10-tui: drain EVERY present framework NIC, not just the
         * first - the wireless bridge registers "wl0" alongside the
         * wired families and its RX ring would starve otherwise.  TX
         * routing stays on driver_nic_active() (single-TX semantics). */
        for (int k = 0; k < NIC_MAX_DEVICES; k++) {
            driver_nic_device_t *nd = driver_nic_get_device(k);
            if (!nd) continue;
            polled_nic = 1;
            len = driver_nic_recv(nd, buf, sizeof(buf));
            if (len > 0) break;
        }
        if (!polled_nic) {
            if (g_use_virtio) {
                len = net_virtio_recv(buf, sizeof(buf));
            } else {
                len = e1000_recv(buf, sizeof(buf));
            }
        }
        if (len <= 0) break;
        if (len < 14) continue;
        eth_hdr_t *eh = (eth_hdr_t *)buf;
        u16 ethertype = ntohs(eh->ethertype);
        const void *payload = buf + 14;
        int payload_len = len - 14;
        if (ethertype == ETH_TYPE_ARP) {
            net_arp_handle_packet((const net_arp_pkt_t *)payload, payload_len);
        } else if (ethertype == ETH_TYPE_IP) {
            net_ip_handle_packet(payload, payload_len);
        }
    }
    g_net_polling = 0;  /* WP-09-FIX BUG-002: release reentrancy guard */
}

/* ============================================================
 * Shell commands
 * ============================================================ */

/* Helper: parse IP address "10.0.2.15" -> u32 (host order). */
static u32 parse_ip(const char *s) {
    u32 a=0, b=0, c=0, d=0;
    int n = 0;
    /* Simple manual parse. */
    int i = 0;
    a = 0; while (s[i] && s[i] >= '0' && s[i] <= '9') { a = a*10 + (s[i]-'0'); i++; }
    if (s[i] == '.') i++; else return 0;
    b = 0; while (s[i] && s[i] >= '0' && s[i] <= '9') { b = b*10 + (s[i]-'0'); i++; }
    if (s[i] == '.') i++; else return 0;
    c = 0; while (s[i] && s[i] >= '0' && s[i] <= '9') { c = c*10 + (s[i]-'0'); i++; }
    if (s[i] == '.') i++; else return 0;
    d = 0; while (s[i] && s[i] >= '0' && s[i] <= '9') { d = d*10 + (s[i]-'0'); i++; }
    (void)n;
    return IP4(a, b, c, d);
}
/* WP-09-fix5: public wrapper so the update-check module can accept both
 * dotted-quad IPs and hostnames in ota_update_url without duplicating logic. */
u32 net_parse_ip(const char *s) {
    return parse_ip(s);
}


/* Helper: format IP address. */
static void format_ip(u32 ip, char *out) {
    char n[12];
    u64_to_str((ip >> 24) & 0xFF, n); strcpy(out, n); strcat(out, ".");
    u64_to_str((ip >> 16) & 0xFF, n); strcat(out, n); strcat(out, ".");
    u64_to_str((ip >> 8) & 0xFF, n); strcat(out, n); strcat(out, ".");
    u64_to_str(ip & 0xFF, n); strcat(out, n);
}

/* Helper: format MAC address. */
static void format_mac(const u8 *mac, char *out) {
    char n[4];
    for (int i = 0; i < 6; i++) {
        u64_to_hex(mac[i], n, 2);
        strcat(out, n);
        if (i < 5) strcat(out, ":");
    }
}

int shell_cmd_ifconfig(const char *args) {
    (void)args;
    char buf[80];
    char ipstr[20], macstr[24];

    if (!g_nic_ok) {
        screen_console_puts("no NIC detected\n");
        return 0;
    }

    /* BUG-035 FIX: Remove e1000 debug register dump from ifconfig.
     * Old code printed rx_descs/tx_descs/RDBAL/TDBAL/CTRL — internal
     * debug info not useful to users. */

    /* WP-10b: report the actual driver in use. */
    {
        driver_nic_device_t *nd = driver_nic_active();
        if (nd) {
            screen_console_puts(nd->name);
            screen_console_puts(":\n");
        } else {
            screen_console_puts(g_use_virtio ? "virtio-net:\n" : "e1000:\n");
        }
    }

    /* MAC address. */
    macstr[0] = 0;
    format_mac(g_mac, macstr);
    strcpy(buf, "  HWaddr "); strcat(buf, macstr); strcat(buf, "\n");
    screen_console_puts(buf);

    /* IP address. */
    ipstr[0] = 0;
    format_ip(g_ip, ipstr);
    strcpy(buf, "  inet "); strcat(buf, ipstr); strcat(buf, "\n");
    screen_console_puts(buf);

    /* Netmask. */
    ipstr[0] = 0;
    format_ip(g_mask, ipstr);
    strcpy(buf, "  mask "); strcat(buf, ipstr); strcat(buf, "\n");
    screen_console_puts(buf);

    /* Gateway. */
    ipstr[0] = 0;
    format_ip(g_gateway, ipstr);
    strcpy(buf, "  gateway "); strcat(buf, ipstr); strcat(buf, "\n");
    screen_console_puts(buf);

    /* DNS. */
    ipstr[0] = 0;
    format_ip(g_dns, ipstr);
    strcpy(buf, "  DNS "); strcat(buf, ipstr); strcat(buf, "\n");
    screen_console_puts(buf);

    /* Link status. */
    int link = net_get_link_status();
    strcpy(buf, "  link: "); strcat(buf, link ? "UP" : "DOWN"); strcat(buf, "\n");
    screen_console_puts(buf);

    /* Stats. */
    net_stats_t st;
    net_get_stats(&st);
    strcpy(buf, "  RX packets: "); u64_to_str(st.rx_packets, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "  TX packets: "); u64_to_str(st.tx_packets, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "\n");
    screen_console_puts(buf);

    return 0;
}

int shell_cmd_ip(const char *args) {
    if (!args[0]) {
        /* Show current config. */
        char buf[80]; char ipstr[20];
        ipstr[0] = 0; format_ip(g_ip, ipstr);
        strcpy(buf, "IP: "); strcat(buf, ipstr); strcat(buf, "\n");
        screen_console_puts(buf);
        ipstr[0] = 0; format_ip(g_mask, ipstr);
        strcpy(buf, "Mask: "); strcat(buf, ipstr); strcat(buf, "\n");
        screen_console_puts(buf);
        ipstr[0] = 0; format_ip(g_gateway, ipstr);
        strcpy(buf, "Gateway: "); strcat(buf, ipstr); strcat(buf, "\n");
        screen_console_puts(buf);
        return 0;
    }
    /* Parse "ip mask gateway" */
    char net_ip_str[20], mask_str[20], gw_str[20];
    int i = 0, j = 0;
    while (args[i] && args[i] != ' ' && j < 19) net_ip_str[j++] = args[i++];
    net_ip_str[j] = 0;
    while (args[i] == ' ') i++;
    j = 0;
    while (args[i] && args[i] != ' ' && j < 19) mask_str[j++] = args[i++];
    mask_str[j] = 0;
    while (args[i] == ' ') i++;
    j = 0;
    while (args[i] && args[i] != ' ' && j < 19) gw_str[j++] = args[i++];
    gw_str[j] = 0;
    u32 ip = parse_ip(net_ip_str);
    u32 mask = parse_ip(mask_str);
    u32 gw = parse_ip(gw_str);
    net_set_ip(ip, mask, gw);
    screen_console_puts("IP set.\n");
    return 0;
}

int shell_cmd_route(const char *args) {
    char buf[120]; char ipstr[20];
    /* WP-09: show full routing table + support add/del */
    if (args[0] == 'a' && args[1] == 'd' && args[2] == 'd') {
        /* route add <dst> <mask> <gw> */
        /* Parse: route add 10.0.0.0 255.0.0.0 10.0.2.2 */
        const char *p = args + 4;
        while (*p == ' ') p++;
        u32 dst = parse_ip(p);
        while (*p && *p != ' ') p++;
        while (*p == ' ') p++;
        u32 mask = parse_ip(p);
        while (*p && *p != ' ') p++;
        while (*p == ' ') p++;
        u32 gw = parse_ip(p);
        if (dst == 0 && mask == 0) {
            screen_console_puts("usage: route add <dst> <mask> <gw>\n");
            return 1;
        }
        if (route_add(dst, mask, gw) == 0) {
            screen_console_puts("route added\n");
        } else {
            screen_console_puts("route table full\n");
        }
        return 0;
    }
    if (args[0] == 'd' && args[1] == 'e' && args[2] == 'l') {
        const char *p = args + 4;
        while (*p == ' ') p++;
        u32 dst = parse_ip(p);
        while (*p && *p != ' ') p++;
        while (*p == ' ') p++;
        u32 mask = parse_ip(p);
        route_del(dst, mask);
        screen_console_puts("route deleted\n");
        return 0;
    }
    /* Show routing table */
    screen_console_puts("Routing table:\n");
    /* Default route */
    ipstr[0] = 0; format_ip(0, ipstr);
    strcpy(buf, "  "); strcat(buf, ipstr);
    strcat(buf, " mask=0.0.0.0 gw=");
    ipstr[0] = 0; format_ip(g_gateway, ipstr);
    strcat(buf, ipstr); strcat(buf, " (default)\n");
    screen_console_puts(buf);
    /* WP-09: show route table entries */
    route_entry_t routes[16];
    int n = route_list(routes, 16);
    for (int i = 0; i < n; i++) {
        ipstr[0] = 0; format_ip(routes[i].dst, ipstr);
        strcpy(buf, "  dst="); strcat(buf, ipstr);
        strcat(buf, " mask=");
        ipstr[0] = 0; format_ip(routes[i].mask, ipstr);
        strcat(buf, ipstr);
        strcat(buf, " gw=");
        ipstr[0] = 0; format_ip(routes[i].gateway, ipstr);
        strcat(buf, ipstr); strcat(buf, "\n");
        screen_console_puts(buf);
    }
    if (n == 0) screen_console_puts("  (no custom routes)\n");
    return 0;
}

/* WP-09: arp command — show ARP cache */
int shell_cmd_arp(const char *args) {
    (void)args;
    char buf[80]; char ipstr[20];
    screen_console_puts("ARP cache:\n");
    net_arp_entry_t entries[16];
    int n = net_arp_list(entries, 16);
    for (int i = 0; i < n; i++) {
        ipstr[0] = 0; format_ip(entries[i].ip, ipstr);
        strcpy(buf, "  "); strcat(buf, ipstr);
        strcat(buf, " -> ");
        /* format MAC */
        char macstr[20];
        int mi = 0;
        for (int j = 0; j < 6; j++) {
            u8 b = entries[i].mac[j];
            macstr[mi++] = "0123456789abcdef"[b >> 4];
            macstr[mi++] = "0123456789abcdef"[b & 0xF];
            if (j < 5) macstr[mi++] = ':';
        }
        macstr[mi] = 0;
        strcat(buf, macstr); strcat(buf, "\n");
        screen_console_puts(buf);
    }
    if (n == 0) screen_console_puts("  (cache empty)\n");
    return 0;
}

/* WP-09: firewall command — add/del/list rules */
int shell_cmd_firewall(const char *args) {
    char buf[140]; char ipstr[20];
    if (args[0] == 0) {
        /* List rules + policies */
        screen_console_puts("Firewall rules:\n");
        net_netfilter_rule_t rules[32];
        int n = net_netfilter_list_rules(rules, 32);
        for (int i = 0; i < n; i++) {
            strcpy(buf, "  [");
            char n2[8]; u64_to_str((u64)i, n2); strcat(buf, n2);
            strcat(buf, "] ");
            strcat(buf, rules[i].chain == NF_CHAIN_INPUT ? "INPUT  " :
                            rules[i].chain == NF_CHAIN_OUTPUT ? "OUTPUT " : "FWD    ");
            strcat(buf, rules[i].action == 0 ? "ACCEPT" :
                            rules[i].action == 1 ? "DROP  " : "REJECT");
            if (rules[i].protocol) {
                strcat(buf, rules[i].protocol == 6 ? " tcp" :
                                 rules[i].protocol == 17 ? " udp" : " icmp");
            } else {
                strcat(buf, " any");
            }
            if (rules[i].port) {
                strcat(buf, " port=");
                char p2[8]; u64_to_str(rules[i].port, p2);
                strcat(buf, p2);
            }
            if (rules[i].src_mask) {
                ipstr[0] = 0; format_ip(rules[i].src_ip, ipstr);
                strcat(buf, " src="); strcat(buf, ipstr);
            }
            if (rules[i].state == NF_STATE_ESTABLISHED) strcat(buf, " state=est");
            else if (rules[i].state == NF_STATE_NEW) strcat(buf, " state=new");
            strcat(buf, " hits=");
            char h2[16]; u64_to_str(rules[i].hits, h2); strcat(buf, h2);
            strcat(buf, "\n");
            screen_console_puts(buf);
        }
        if (n == 0) screen_console_puts("  (no rules)\n");
        screen_console_puts("policies: input=");
        screen_console_puts(net_netfilter_get_policy(NF_CHAIN_INPUT) == NF_ACTION_ACCEPT ? "ACCEPT" : "DROP");
        screen_console_puts(" output=");
        screen_console_puts(net_netfilter_get_policy(NF_CHAIN_OUTPUT) == NF_ACTION_ACCEPT ? "ACCEPT" : "DROP");
        screen_console_puts(" forward=");
        screen_console_puts(net_netfilter_get_policy(NF_CHAIN_FORWARD) == NF_ACTION_ACCEPT ? "ACCEPT" : "DROP");
        screen_console_puts("\n");
        screen_console_puts("conntrack: ");
        char ctn[12];
        u64_to_str((u64)net_netfilter_ct_count(), ctn);
        screen_console_puts(ctn);
        screen_console_puts(" flows (firewall ct for details)\n");
        return 0;
    }
    if (args[0] == 'c' && args[1] == 't') {
        /* firewall ct — dump connection tracking table (external link) */
        extern int shell_cmd_firewall_ct(const char *args);
        return shell_cmd_firewall_ct(args + 3);
    }
    if (args[0] == 'r' && args[1] == 'e' && args[2] == 's') {
        net_netfilter_reset();
        screen_console_puts("firewall reset (rules, conntrack, policies)\n");
        return 0;
    }
    if (args[0] == 'p' && args[1] == 'o') {
        /* firewall policy <input|output|forward> <accept|drop> */
        const char *p = args + 7;
        while (*p == ' ') p++;
        u8 chain;
        if (p[0] == 'i') chain = NF_CHAIN_INPUT;
        else if (p[0] == 'o') chain = NF_CHAIN_OUTPUT;
        else if (p[0] == 'f') chain = NF_CHAIN_FORWARD;
        else { screen_console_puts("usage: firewall policy <input|output|forward> <accept|drop>\n"); return 1; }
        while (*p && *p != ' ') p++;
        while (*p == ' ') p++;
        u8 act;
        if (p[0] == 'a') act = NF_ACTION_ACCEPT;
        else if (p[0] == 'd') act = NF_ACTION_DROP;
        else { screen_console_puts("usage: firewall policy <input|output|forward> <accept|drop>\n"); return 1; }
        net_netfilter_set_policy(chain, act);
        screen_console_puts("policy updated\n");
        return 0;
    }
    if (args[0] == 'a' && args[1] == 'd' && args[2] == 'd') {
        /* firewall add [input|output|forward] <drop|accept|reject> <tcp|udp|icmp|any>
         *            [port <n>] [src <ip>] [dst <ip>] [state <new|est|any>] */
        const char *p = args + 4;
        while (*p == ' ') p++;
        u8 chain = NF_CHAIN_INPUT;
        /* optional chain word */
        if (p[0] == 'i' && p[1] == 'n') { chain = NF_CHAIN_INPUT; p += 6; }
        else if (p[0] == 'o' && p[1] == 'u') { chain = NF_CHAIN_OUTPUT; p += 7; }
        else if (p[0] == 'f' && p[1] == 'o') { chain = NF_CHAIN_FORWARD; p += 8; }
        while (*p == ' ') p++;
        u8 action;
        if (p[0] == 'd') { action = NF_ACTION_DROP; p += 4; }
        else if (p[0] == 'a') { action = NF_ACTION_ACCEPT; p += 6; }
        else if (p[0] == 'r') { action = NF_ACTION_REJECT; p += 6; }
        else { screen_console_puts("usage: firewall add [chain] <drop|accept|reject> <tcp|udp|icmp|any> [port <n>] [src <ip>] [dst <ip>] [state <new|est|any>]\n"); return 1; }
        while (*p == ' ') p++;
        u8 proto = 0;
        if (p[0] == 't') { proto = 6; p += 3; }
        else if (p[0] == 'u') { proto = 17; p += 3; }
        else if (p[0] == 'i') { proto = 1; p += 4; }
        else if (p[0] == 'a') { proto = 0; p += 3; }
        while (*p == ' ') p++;
        u16 port = 0;
        u32 src_ip = 0, src_mask = 0, dst_ip = 0, dst_mask = 0;
        u8 state = NF_STATE_ANY;
        while (*p) {
            if (*p == 'p') {
                p += 5;
                while (*p == ' ') p++;
                int v = 0;
                while (*p >= '0' && *p <= '9') { v = v*10 + (*p - '0'); p++; }
                port = (u16)v;
            } else if (*p == 's' && p[1] == 'r') {
                p += 4;
                while (*p == ' ') p++;
                src_ip = parse_ip(p);
                src_mask = 0xFFFFFFFF;
                while (*p && *p != ' ') p++;
            } else if (*p == 'd' && p[1] == 's') {
                p += 4;
                while (*p == ' ') p++;
                dst_ip = parse_ip(p);
                dst_mask = 0xFFFFFFFF;
                while (*p && *p != ' ') p++;
            } else if (*p == 's' && p[1] == 't') {
                p += 6;
                while (*p == ' ') p++;
                if (p[0] == 'n') { state = NF_STATE_NEW; p += 3; }
                else if (p[0] == 'e') { state = NF_STATE_ESTABLISHED; p += 3; }
                else { state = NF_STATE_ANY; p += 3; }
            } else { p++; }
            while (*p == ' ') p++;
        }
        if (net_netfilter_add_rule_st(chain, src_ip, src_mask, dst_ip, dst_mask,
                                  proto, port, action, state) == 0) {
            screen_console_puts("firewall rule added\n");
        } else {
            screen_console_puts("firewall rule table full\n");
        }
        return 0;
    }
    if (args[0] == 'd' && args[1] == 'e' && args[2] == 'l') {
        int idx = 0;
        const char *p = args + 4;
        while (*p == ' ') p++;
        while (*p >= '0' && *p <= '9') { idx = idx*10 + (*p - '0'); p++; }
        if (net_netfilter_del_rule(idx) == 0) {
            screen_console_puts("rule deleted\n");
        } else {
            screen_console_puts("rule not found\n");
        }
        return 0;
    }
    screen_console_puts("usage: firewall | firewall add [in|out|fwd] <drop|accept|reject> <tcp|udp|icmp|any> [port <n>] [src <ip>] [dst <ip>] [state <new|est|any>] | del <n> | policy <in|out|fwd> <accept|drop> | ct | reset\n");
    return 1;
}

/* firewall ct — connection tracking table dump */
int shell_cmd_firewall_ct(const char *args) {
    (void)args;
    screen_console_puts("conntrack table:\n");
    int n = 0;
    for (int i = 0; i < NF_CT_MAX; i++) {
        if (!g_nf_ct[i].in_use) continue;
        n++;
        char b[140]; char ipstr[20]; char n2[12];
        strcpy(b, "  [");
        u64_to_str((u64)i, n2); strcat(b, n2);
        strcat(b, "] ");
        strcat(b, g_nf_ct[i].protocol == 6 ? "tcp" :
                     g_nf_ct[i].protocol == 17 ? "udp" : "icmp");
        ipstr[0] = 0; format_ip(g_nf_ct[i].src_ip, ipstr);
        strcat(b, " "); strcat(b, ipstr);
        strcat(b, ":");
        u64_to_str(g_nf_ct[i].src_port, n2); strcat(b, n2);
        strcat(b, " > ");
        ipstr[0] = 0; format_ip(g_nf_ct[i].dst_ip, ipstr);
        strcat(b, ipstr);
        strcat(b, ":");
        u64_to_str(g_nf_ct[i].dst_port, n2); strcat(b, n2);
        strcat(b, g_nf_ct[i].established ? " ESTABLISHED" : " NEW");
        strcat(b, "\n");
        screen_console_puts(b);
    }
    if (n == 0) screen_console_puts("  (no active flows)\n");
    return 0;
}

/* WP-09: tcpstats command — show TCP reliability stats */
int shell_cmd_tcpstats(const char *args) {
    (void)args;
    char buf[120]; char n[20];
    screen_console_puts("TCP reliability stats:\n");
    for (int i = 0; i < TCP_MAX_CONNS; i++) {
        net_tcp_conn_t *c = &g_tcp_conns[i];
        if (!c->in_use) continue;
        strcpy(buf, "  conn[");
        u64_to_str((u64)i, n); strcat(buf, n);
        strcat(buf, "] state=");
        u64_to_str((u64)c->state, n); strcat(buf, n);
        strcat(buf, " cwnd=");
        u64_to_str(c->cwnd, n); strcat(buf, n);
        strcat(buf, " ssthresh=");
        u64_to_str(c->ssthresh, n); strcat(buf, n);
        strcat(buf, " mss=");
        u64_to_str(c->mss, n); strcat(buf, n);
        strcat(buf, " rto=");
        u64_to_str(c->rto, n); strcat(buf, n);
        strcat(buf, " rtx_len=");
        u64_to_str((u64)c->rtx_len, n); strcat(buf, n);
        strcat(buf, " dup_acks=");
        u64_to_str((u64)c->dup_ack_count, n); strcat(buf, n);
        strcat(buf, " ts=");
        strcat(buf, c->ts_enabled ? "on" : "off");
        strcat(buf, " cc=cubic");
        strcat(buf, " w_max=");
        u64_to_str(c->cc.w_max, n); strcat(buf, n);
        strcat(buf, " sack=");
        strcat(buf, c->sack_permitted ? "on" : "off");
        strcat(buf, " fr=");
        strcat(buf, c->fr_active ? "1" : "0");
        strcat(buf, " srtt=");
        u64_to_str(c->srtt, n); strcat(buf, n);
        strcat(buf, " rttvar=");
        u64_to_str(c->rttvar, n); strcat(buf, n);
        strcat(buf, "\n");
        screen_console_puts(buf);
    }
    if (TCP_MAX_CONNS == 0) screen_console_puts("  (no connections)\n");
    /* Check if any connections exist */
    int any = 0;
    for (int i = 0; i < TCP_MAX_CONNS; i++) if (g_tcp_conns[i].in_use) any = 1;
    if (!any) screen_console_puts("  (no active TCP connections)\n");
    return 0;
}

int shell_cmd_ping(const char *args) {
    if (!args[0]) {
        screen_console_puts("usage: ping <host|ip>\n");
        return 1;
    }
    u32 ip = parse_ip(args);
    if (ip == 0) {
        /* Not an IP address, try DNS resolution */
        screen_console_puts("Resolving ");
        screen_console_puts(args);
        screen_console_puts("...\n");
        if (net_dns_resolve(args, &ip) != 0) {
            screen_console_puts("DNS resolution failed\n");
            return 1;
        }
        char rbuf[80]; char ripstr[20];
        ripstr[0] = 0; format_ip(ip, ripstr);
        strcpy(rbuf, "Resolved to "); strcat(rbuf, ripstr); strcat(rbuf, "\n");
        screen_console_puts(rbuf);
    }
    char buf[80]; char ipstr[20];
    ipstr[0] = 0; format_ip(ip, ipstr);
    strcpy(buf, "PING "); strcat(buf, ipstr); strcat(buf, " ...\n");
    screen_console_puts(buf);

    /* fix2: the exit code reflects the outcome - scripts (and the E2E)
     * could not tell a failed ping from a successful one. */
    int got = 0;
    for (int i = 0; i < 4; i++) {
        screen_console_puts("  ");
        int rc = net_icmp_ping(ip, 3000);
        if (rc == 0) {
            got++;
            screen_console_puts("reply received\n");
        } else {
            screen_console_puts("timeout\n");
        }
        for (volatile int j = 0; j < 500000; j++);
    }
    return got > 0 ? 0 : 1;
}

int shell_cmd_netstat(const char *args) {
    (void)args;
    char buf[80];

    /* BUG-035 FIX: Remove e1000 debug register dump from netstat.
     * Old code printed RDH/RDT/TDH/TDT/STATUS/RCTL/TCTL — internal
     * debug info not useful to users. */

    net_stats_t st;
    net_get_stats(&st);
    screen_console_puts("Network statistics:\n");
    strcpy(buf, "  TX: "); u64_to_str(st.tx_packets, n_tmp); strcat(buf, n_tmp);
    strcat(buf, " packets, "); u64_to_str(st.tx_bytes, n_tmp); strcat(buf, n_tmp);
    strcat(buf, " bytes\n");
    screen_console_puts(buf);
    strcpy(buf, "  RX: "); u64_to_str(st.rx_packets, n_tmp); strcat(buf, n_tmp);
    strcat(buf, " packets, "); u64_to_str(st.rx_bytes, n_tmp); strcat(buf, n_tmp);
    strcat(buf, " bytes\n");
    screen_console_puts(buf);
    strcpy(buf, "  ARP requests: "); u64_to_str(st.net_arp_requests, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "  replies: "); u64_to_str(st.net_arp_replies, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "\n");
    screen_console_puts(buf);
    strcpy(buf, "  ICMP echo sent: "); u64_to_str(st.net_icmp_echo_sent, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "  recv: "); u64_to_str(st.net_icmp_echo_recv, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "\n");
    screen_console_puts(buf);
    strcpy(buf, "  TCP connections: "); u64_to_str(st.net_tcp_connections, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "\n");
    screen_console_puts(buf);
    strcpy(buf, "  UDP rx dropped (buffer full): "); u64_to_str(st.net_udp_rx_dropped, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "\n");
    screen_console_puts(buf);
    strcpy(buf, "  IP frag reassembled: "); u64_to_str(st.net_ip_frag_reassembled, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "\n");
    screen_console_puts(buf);
    strcpy(buf, "  IP frag dropped: "); u64_to_str(st.net_ip_frag_rx_dropped, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "  evicted: "); u64_to_str(st.net_ip_frag_evicted, n_tmp); strcat(buf, n_tmp);
    strcat(buf, "\n");
    screen_console_puts(buf);

    /* Show active sockets. */
    screen_console_puts("Sockets:\n");
    int count = 0;
    for (int i = 0; i < MAX_SOCKETS; i++) {
        if (g_sockets[i].in_use) {
            char ipstr[20];
            ipstr[0] = 0; format_ip(g_sockets[i].remote_ip, ipstr);
            strcpy(buf, "  ["); u64_to_str(i, n_tmp); strcat(buf, n_tmp);
            strcat(buf, "] type="); strcat(buf, g_sockets[i].type == SOCK_TCP ? "TCP" : "UDP");
            strcat(buf, " remote="); strcat(buf, ipstr);
            strcat(buf, ":"); u64_to_str(g_sockets[i].remote_port, n_tmp); strcat(buf, n_tmp);
            strcat(buf, "\n");
            screen_console_puts(buf);
            count++;
        }
    }
    if (count == 0) screen_console_puts("  (none)\n");

    /* Show ARP cache. */
    screen_console_puts("ARP cache:\n");
    count = 0;
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        u32 ip; u8 mac[6];
        if (net_arp_get_cache(i, &ip, mac) == 0) {
            char ipstr[20], macstr[24];
            ipstr[0] = 0; format_ip(ip, ipstr);
            macstr[0] = 0; format_mac(mac, macstr);
            strcpy(buf, "  "); strcat(buf, ipstr); strcat(buf, " -> ");
            strcat(buf, macstr); strcat(buf, "\n");
            screen_console_puts(buf);
            count++;
        }
    }
    if (count == 0) screen_console_puts("  (empty)\n");

    return 0;
}

int shell_cmd_dhcp(const char *args) {
    (void)args;
    screen_console_puts("Sending DHCP discover...\n");
    int rc = net_dhcp_discover();
    if (rc == 0) {
        char buf[80]; char ipstr[20];
        ipstr[0] = 0; format_ip(g_ip, ipstr);
        strcpy(buf, "DHCP success: IP="); strcat(buf, ipstr);
        strcat(buf, "\n");
        screen_console_puts(buf);
        ipstr[0] = 0; format_ip(g_mask, ipstr);
        strcpy(buf, "  mask="); strcat(buf, ipstr);
        strcat(buf, "\n");
        screen_console_puts(buf);
        ipstr[0] = 0; format_ip(g_gateway, ipstr);
        strcpy(buf, "  gateway="); strcat(buf, ipstr);
        strcat(buf, "\n");
        screen_console_puts(buf);
        ipstr[0] = 0; format_ip(g_dns, ipstr);
        strcpy(buf, "  DNS="); strcat(buf, ipstr);
        strcat(buf, "\n");
        screen_console_puts(buf);
    } else {
        screen_console_puts("DHCP failed (timeout)\n");
        return 1;   /* fix2: scripts must be able to test the outcome */
    }
    return 0;
}

int shell_cmd_dns(const char *args) {
    if (!args[0]) {
        screen_console_puts("usage: dns <name> [aaaa|cname|mx|txt|ns|srv]\n");
        return 1;
    }
    char buf[600];
    /* WP-09: check for record-type subcommand */
    int do_aaaa = 0, do_cname = 0, do_mx = 0, do_txt = 0, do_ns = 0, do_srv = 0;
    const char *name = args;
    if (strlen(args) > 5 && args[0]=='a' && args[1]=='a' && args[2]=='a' && args[3]=='a' && args[4]==' ') {
        do_aaaa = 1; name = args + 5;
    } else if (strlen(args) > 6 && args[0]=='c' && args[1]=='n' && args[2]=='a' && args[3]=='m' && args[4]=='e' && args[5]==' ') {
        do_cname = 1; name = args + 6;
    } else if (strlen(args) > 3 && args[0]=='m' && args[1]=='x' && args[2]==' ') {
        do_mx = 1; name = args + 3;
    } else if (strlen(args) > 4 && args[0]=='t' && args[1]=='x' && args[2]=='t' && args[3]==' ') {
        do_txt = 1; name = args + 4;
    } else if (strlen(args) > 3 && args[0]=='n' && args[1]=='s' && args[2]==' ') {
        do_ns = 1; name = args + 3;
    } else if (strlen(args) > 4 && args[0]=='s' && args[1]=='r' && args[2]=='v' && args[3]==' ') {
        do_srv = 1; name = args + 4;
    }
    if (do_aaaa || do_cname || do_mx || do_txt || do_ns || do_srv) {
        strcpy(buf, "Resolving "); strcat(buf, name);
        strcat(buf, do_aaaa ? " (AAAA)" : do_cname ? " (CNAME)" :
                       do_mx ? " (MX)" : do_txt ? " (TXT)" :
                       do_ns ? " (NS)" : " (SRV)");
        strcat(buf, "...\n");
        screen_console_puts(buf);
    }

    if (do_mx) {
        u16 prefs[4];
        static char hosts[4][256];
        int n = net_dns_resolve_mx(name, prefs, (char *)hosts, 256, 4);
        if (n <= 0) { screen_console_puts("MX: no mail exchanger (or timeout)\n"); return 0; }
        for (int i = 0; i < n; i++) {
            strcpy(buf, "MX: ");
            char n2[8]; u64_to_str(prefs[i], n2); strcat(buf, n2);
            strcat(buf, " "); strcat(buf, hosts[i]);
            strcat(buf, "\n");
            screen_console_puts(buf);
        }
        return 0;
    }
    if (do_txt) {
        char txt[512];
        if (net_dns_resolve_txt(name, txt, sizeof(txt)) > 0) {
            strcpy(buf, "TXT: "); strcat(buf, txt); strcat(buf, "\n");
            screen_console_puts(buf);
        } else {
            screen_console_puts("TXT: no text record (or timeout)\n");
        }
        return 0;
    }
    if (do_ns) {
        char ns[256];
        if (net_dns_resolve_ns(name, ns, sizeof(ns)) == 0) {
            strcpy(buf, "NS: "); strcat(buf, ns); strcat(buf, "\n");
            screen_console_puts(buf);
        } else {
            screen_console_puts("NS: no name server (or timeout)\n");
        }
        return 0;
    }
    if (do_srv) {
        u16 pri, wgt, port;
        char target[256];
        if (net_dns_resolve_srv(name, &pri, &wgt, &port, target, sizeof(target)) == 0) {
            strcpy(buf, "SRV: ");
            char n2[8];
            u64_to_str(pri, n2); strcat(buf, n2); strcat(buf, " ");
            u64_to_str(wgt, n2); strcat(buf, n2); strcat(buf, " ");
            u64_to_str(port, n2); strcat(buf, n2); strcat(buf, " ");
            strcat(buf, target);
            strcat(buf, "\n");
            screen_console_puts(buf);
        } else {
            screen_console_puts("SRV: no service record (or timeout)\n");
        }
        return 0;
    }
    if (do_aaaa) {
        /* WP-09: AAAA query */
        u8 ipv6[16];
        if (net_dns_resolve_aaaa(name, ipv6) == 0) {
            strcpy(buf, "AAAA: ");
            int bi = 6;
            buf[bi] = 0;
            for (int i = 0; i < 16; i += 2) {
                u16 w = ((u16)ipv6[i] << 8) | ipv6[i+1];
                if (i > 0) buf[bi++] = ':';
                if (w == 0) { buf[bi++] = '0'; }
                else {
                    char tmp[8]; int ti = 0;
                    u16 w2 = w;
                    while (w2) { tmp[ti++] = "0123456789abcdef"[w2 & 0xF]; w2 >>= 4; }
                    while (ti > 0) buf[bi++] = tmp[--ti];
                }
            }
            buf[bi] = 0;
            strcat(buf, "\n");
            screen_console_puts(buf);
        } else {
            screen_console_puts("AAAA: no IPv6 record (or timeout)\n");
        }
        return 0;
    }
    if (do_cname) {
        /* WP-09: CNAME query */
        char cname[256];
        u32 ip;
        if (net_dns_resolve_cname(name, cname, sizeof(cname), &ip) == 0) {
            strcpy(buf, "CNAME: "); strcat(buf, cname); strcat(buf, "\n");
            screen_console_puts(buf);
            char ipstr[20];
            ipstr[0] = 0; format_ip(ip, ipstr);
            strcpy(buf, "A: "); strcat(buf, ipstr); strcat(buf, "\n");
            screen_console_puts(buf);
        } else {
            screen_console_puts("CNAME: not a CNAME or resolution failed\n");
        }
        return 0;
    }
    /* Default: A record query + show CNAME if present */
    u32 ip;
    char cname[256];
    cname[0] = 0;
    u32 cname_ip;
    if (net_dns_resolve_cname(name, cname, sizeof(cname), &cname_ip) == 0 && strlen(cname) > 0 && strcmp(cname, name) != 0) {
        strcpy(buf, "CNAME: "); strcat(buf, cname); strcat(buf, "\n");
        screen_console_puts(buf);
        char ipstr[20];
        ipstr[0] = 0; format_ip(cname_ip, ipstr);
        strcpy(buf, "A: "); strcat(buf, ipstr); strcat(buf, "\n");
        screen_console_puts(buf);
    } else if (net_dns_resolve(name, &ip) == 0) {
        char ipstr[20];
        ipstr[0] = 0; format_ip(ip, ipstr);
        strcpy(buf, "A: "); strcat(buf, ipstr); strcat(buf, "\n");
        screen_console_puts(buf);
    } else {
        screen_console_puts("DNS resolution failed (timeout)\n");
    }
    return 0;
}

/* WP-09 mainstream: dnstest — exercise every record type against the
 * configured resolver (SLIRP forwards to the real upstream DNS). */
static int shell_cmd_dnstest(const char *args) {
    (void)args;
    int fails = 0;
    screen_console_puts("DNS record-type self-test (live resolver):\n");

    /* A */
    u32 ip = 0;
    int okA = (net_dns_resolve("example.com", &ip) == 0 && ip != 0);
    if (!okA) fails++;
    {
        char b[96]; char ipstr[20]; char n2[12];
        ipstr[0] = 0; format_ip(ip, ipstr);
        strcpy(b, "  ["); strcat(b, okA ? "PASS" : "FAIL");
        strcat(b, "] A    example.com = "); strcat(b, ipstr);
        strcat(b, "\n"); screen_console_puts(b);
        (void)n2;
    }

    /* AAAA (google.com publishes IPv6) */
    u8 v6[16];
    int okAAAA = (net_dns_resolve_aaaa("google.com", v6) == 0);
    if (!okAAAA) fails++;
    {
        char b[64];
        strcpy(b, "  ["); strcat(b, okAAAA ? "PASS" : "FAIL");
        strcat(b, "] AAAA google.com");
        strcat(b, "\n"); screen_console_puts(b);
    }

    /* MX (gmail.com) */
    u16 prefs[4];
    static char mxhosts[4][256];
    int nmx = net_dns_resolve_mx("gmail.com", prefs, (char *)mxhosts, 256, 4);
    int okMX = (nmx > 0);
    if (!okMX) fails++;
    {
        char b[320];
        strcpy(b, "  ["); strcat(b, okMX ? "PASS" : "FAIL");
        strcat(b, "] MX   gmail.com");
        if (nmx > 0) {
            char n2[8];
            strcat(b, " pref=");
            u64_to_str(prefs[0], n2); strcat(b, n2);
            strcat(b, " "); strcat(b, mxhosts[0]);
        }
        strcat(b, "\n"); screen_console_puts(b);
    }

    /* TXT (google.com SPF) */
    char txt[512];
    int ntxt = net_dns_resolve_txt("google.com", txt, sizeof(txt));
    int okTXT = (ntxt > 0);
    if (!okTXT) fails++;
    {
        char b[560];
        strcpy(b, "  ["); strcat(b, okTXT ? "PASS" : "FAIL");
        strcat(b, "] TXT  google.com");
        if (ntxt > 0) { strcat(b, " \""); strcat(b, txt); strcat(b, "\""); }
        strcat(b, "\n"); screen_console_puts(b);
    }

    /* NS (google.com) */
    char ns[256];
    int okNS = (net_dns_resolve_ns("google.com", ns, sizeof(ns)) == 0);
    if (!okNS) fails++;
    {
        char b[320];
        strcpy(b, "  ["); strcat(b, okNS ? "PASS" : "FAIL");
        strcat(b, "] NS   google.com");
        if (okNS) { strcat(b, " "); strcat(b, ns); }
        strcat(b, "\n"); screen_console_puts(b);
    }

    /* SRV (_xmpp-server._tcp.jabber.org — Google publishes real SRV records) */
    u16 pri, wgt, port;
    char target[256];
    int okSRV = (net_dns_resolve_srv("_xmpp-server._tcp.jabber.org", &pri, &wgt,
                                 &port, target, sizeof(target)) == 0);
    if (!okSRV) fails++;
    {
        char b[380]; char n2[8];
        strcpy(b, "  ["); strcat(b, okSRV ? "PASS" : "FAIL");
        strcat(b, "] SRV  _xmpp-server._tcp.jabber.org");
        if (okSRV) {
            strcat(b, " port=");
            u64_to_str(port, n2); strcat(b, n2);
            strcat(b, " "); strcat(b, target);
        }
        strcat(b, "\n"); screen_console_puts(b);
    }

    if (fails == 0) screen_console_puts("dnstest: ALL PASS\n");
    else screen_console_puts("dnstest: FAILURES\n");
    return fails == 0 ? 0 : 1;
}

int shell_cmd_lspci(const char *args) {
    (void)args;
    driver_pci_list_devices();
    return 0;
}

int shell_cmd_wget(const char *args) {
    if (!args[0]) {
        screen_console_puts("usage: wget <http://host:port/path> | wget <host> [port] [path]\n");
        return 1;
    }
    /* WP-09: Check for https:// prefix → use TLS */
    int use_tls = 0;
    if (args[0]=='h' && args[1]=='t' && args[2]=='t' && args[3]=='p' &&
        args[4]=='s' && args[5]==':' && args[6]=='/' && args[7]=='/') {
        use_tls = 1;
        args += 8; /* skip "https://" */
    } else if (args[0]=='h' && args[1]=='t' && args[2]=='t' && args[3]=='p' &&
               args[4]==':' && args[5]=='/' && args[6]=='/') {
        args += 7; /* skip "http://" */
    }
    /* Parse URL: host[:port][/path]   (after http:// or https:// stripped)
     * OR:  host [port] [path]         (whitespace separated, legacy form)
     * WP-09 fix: support host:port/path in a single arg (URL form).
     */
    char host[64] = {0};
    int port = use_tls ? 443 : 80;
    char path[128] = "/";
    int i = 0, j = 0;
    /* If we just stripped http(s)://, args[i] is now the host portion of a URL.
     * Look for ':' (port) or '/' (path) or ' ' (legacy) as host terminator. */
    int url_form = (args[i] != 0);  /* if there's any content after stripping, treat as URL form */
    while (args[i] && j < 63) {
        char c = args[i];
        if (c == ':' || c == '/' || c == ' ') break;
        host[j++] = c;
        i++;
    }
    host[j] = 0;
    /* Parse optional port: ":NNN" */
    if (args[i] == ':') {
        i++;
        port = 0;
        while (args[i] && args[i] >= '0' && args[i] <= '9') {
            port = port * 10 + (args[i] - '0');
            i++;
        }
        if (port == 0) port = use_tls ? 443 : 80;
    }
    /* Parse optional path: starts with '/' */
    if (args[i] == '/') {
        j = 0;
        while (args[i] && j < 127) path[j++] = args[i++];
        path[j] = 0;
    } else if (args[i] == ' ') {
        /* Legacy form: "host port path" */
        while (args[i] == ' ') i++;
        if (args[i]) {
            port = 0;
            while (args[i] && args[i] >= '0' && args[i] <= '9') {
                port = port * 10 + (args[i] - '0');
                i++;
            }
            if (port == 0) port = use_tls ? 443 : 80;
            while (args[i] == ' ') i++;
            if (args[i]) {
                j = 0;
                while (args[i] && j < 127) path[j++] = args[i++];
                path[j] = 0;
            }
        }
    }
    (void)url_form;

    /* Resolve host (try as IP first). */
    u32 ip = parse_ip(host);
    if (ip == 0) {
        if (net_dns_resolve(host, &ip) != 0) {
            screen_console_puts("cannot resolve host\n");
            return 1;
        }
    }

    char buf[80]; char ipstr[20];
    ipstr[0] = 0; format_ip(ip, ipstr);
    strcpy(buf, "Connecting to "); strcat(buf, ipstr);
    strcat(buf, ":"); u64_to_str(port, n_tmp); strcat(buf, n_tmp);
    strcat(buf, path); strcat(buf, use_tls ? " (TLS)\n" : "\n");
    screen_console_puts(buf);

    /* WP-09: HTTPS path — use TLS */
    if (use_tls) {
        extern int net_tls_https_get(u32 ip, u16 port, const char *hostname, const char *path, void *out, int outlen);
        /* WP-09-FIX BUG-022: use a 16 KiB response buffer instead of one
         * 4 KiB page — larger HTTPS responses were silently truncated. */
        enum { WGET_TLS_BUFSZ = 16384 };
        u8 *resp = (u8 *)(uintptr_t)mem_pmm_alloc_contig(WGET_TLS_BUFSZ / PMM_PAGE_SIZE);
        if (!resp) { screen_console_puts("out of memory\n"); return 1; }
        int n = net_tls_https_get(ip, (u16)port, host, path, resp, WGET_TLS_BUFSZ);
        if (n > 0) {
            /* Find body (after \r\n\r\n) */
            int body_start = 0;
            for (int k = 0; k < n - 3; k++) {
                if (resp[k]=='\r' && resp[k+1]=='\n' && resp[k+2]=='\r' && resp[k+3]=='\n') {
                    body_start = k + 4; break;
                }
            }
            int body_len = n - body_start;
            /* Save to VFS */
            int fd = fs_vfs_open("/wget_https.html", VFS_O_WRONLY | VFS_O_CREAT | VFS_O_TRUNC);
            if (fd >= 0) {
                fs_vfs_write(fd, resp + body_start, body_len);
                fs_vfs_close(fd);
                char b[80];
                strcpy(b, "Saved "); u64_to_str(body_len, n_tmp); strcat(b, n_tmp);
                strcat(b, " bytes to /wget_https.html\n");
                screen_console_puts(b);
            } else {
                /* Print to console */
                for (int k = body_start; k < n; k++) screen_console_putc(resp[k]);
            }
        } else {
            char b[40]; strcpy(b, "TLS failed (code "); u64_to_str((u64)(-n), n_tmp); strcat(b, n_tmp); strcat(b, ")\n");
            screen_console_puts(b);
        }
        /* WP-09-FIX BUG-022: free the whole 16 KiB contiguous block. */
        for (int pg = 0; pg < WGET_TLS_BUFSZ / PMM_PAGE_SIZE; pg++)
            mem_pmm_free_frame((u64)(uintptr_t)resp + (u64)pg * PMM_PAGE_SIZE);
        return 0;
    }

    int sock = net_socket(SOCK_TCP);
    if (sock < 0) { screen_console_puts("socket failed\n"); return 1; }
    if (net_connect(sock, ip, (u16)port) < 0) {
        screen_console_puts("connect failed\n");
        net_close(sock);
        return 1;
    }
    screen_console_puts("Connected.\n");

    /* Send HTTP GET. */
    char request[256];
    strcpy(request, "GET ");
    strcat(request, path);
    strcat(request, " HTTP/1.0\r\nHost: ");
    strcat(request, host);
    strcat(request, "\r\n\r\n");
    net_send(sock, request, strlen(request));

    /* P1-3 FIX: Save response body to a VFS file instead of just printing
     * the first 500 bytes. Extract filename from the URL path. */
    /* Extract filename from path (last component after last '/') */
    char fname[64];
    const char *last = path;
    for (const char *p = path; *p; p++) { if (*p == '/') last = p + 1; }
    if (*last) {
        int k = 0;
        while (last[k] && k < 63) { fname[k] = last[k]; k++; }
        fname[k] = 0;
    } else {
        strcpy(fname, "index.html");
    }

    /* Receive response — loop until we get headers + full body.
     * WP-09-FIX BUG-002: rbuf enlarged 1024 -> 4096 — with the 8 KiB
     * rx_buf several segments can be waiting at once and a 1 KiB header
     * buffer mis-split the stream ("malformed HTTP response").
     *
     * BUG-002 FOLLOW-UP FIX (root cause of the ~7 KB wget stall):
     * the 4096-byte rbuf lived ON THE STACK of this kernel thread —
     * and kernel thread stacks are exactly 4096 bytes (one page).
     * The oversized local overflowed the stack and corrupted the
     * received bytes before the header search ever saw them, so Phase 1
     * never found \r\n\r\n and wget aborted with "malformed HTTP
     * response" after ~7 KB. Allocate the buffer from the heap instead. */
    enum { RBUF_CAP = 4096 };
    char *rbuf = (char *)kmalloc(RBUF_CAP);
    if (!rbuf) {
        screen_console_puts("wget: out of memory\n");
        net_close(sock);
        return 1;
    }
    int total_header = 0;
    int header_end = -1;  /* index of \r\n\r\n in rbuf */
    int content_length = -1;
    int body_start = 0;
    int body_received = 0;
    /* Phase 1: receive until we find \r\n\r\n (end of headers). */
    while (header_end < 0) {
        int n = net_recv(sock, rbuf + total_header, RBUF_CAP - 1 - total_header);
        if (n <= 0) { screen_console_puts("no response (timeout)\n"); kfree(rbuf); net_close(sock); return 1; }
        total_header += n;
        rbuf[total_header] = 0;
        /* Search for \r\n\r\n */
        for (int k = 0; k <= total_header - 4; k++) {
            if (rbuf[k] == '\r' && rbuf[k+1] == '\n' &&
                rbuf[k+2] == '\r' && rbuf[k+3] == '\n') {
                header_end = k;
                body_start = k + 4;
                body_received = total_header - body_start;
                break;
            }
        }
        /* BUG-002 FOLLOW-UP FIX (app layer): the buffer-full check below
         * used to fire EVEN WHEN the header end had just been found.
         * With the 8 KiB rx_buf, the first net_recv often returns a full
         * 4095 bytes (headers + ~3.9 KB of body in one call); the old
         * order (search → full-check) aborted with "malformed HTTP
         * response" right after a SUCCESSFUL match at header_end=200.
         * Only declare malformed when the buffer filled WITHOUT a match. */
        if (header_end < 0 && total_header >= RBUF_CAP - 1) {
            screen_console_puts("malformed HTTP response\n");
            kfree(rbuf);
            net_close(sock);
            return 1;
        }
    }
    /* Parse Content-Length from headers (case-insensitive). */
    for (int k = 0; k < header_end; k++) {
        if (rbuf[k] == 'C' || rbuf[k] == 'c') {
            if (((rbuf[k+1] == 'o' || rbuf[k+1] == 'O') &&
                 (strncmp(rbuf + k, "Content-Length:", 15) == 0 ||
                  strncmp(rbuf + k, "content-length:", 15) == 0))) {
                int v = k + 15;
                while (rbuf[v] == ' ' || rbuf[v] == '\t') v++;
                content_length = 0;
                while (rbuf[v] >= '0' && rbuf[v] <= '9') {
                    content_length = content_length * 10 + (rbuf[v] - '0');
                    v++;
                }
                break;
            }
        }
    }
    if (content_length < 0) content_length = body_received;  /* unknown — save what we have */

    /* Open VFS file for writing.
     * WP-09-FIX BUG-006: open with O_TRUNC (the HTTPS path already did;
     * without it re-downloading over an existing larger file kept the
     * old tail bytes). */
    char fpath[80];
    strcpy(fpath, "/");
    strcat(fpath, fname);
    int fd = fs_vfs_open(fpath, VFS_O_WRONLY | VFS_O_CREAT | VFS_O_TRUNC);
    if (fd < 0) {
        /* If VFS create fails, print to console as fallback. */
        screen_console_puts("wget: cannot create file, printing to console:\n");
        int show = body_received > 500 ? 500 : body_received;
        for (int k = 0; k < show; k++) screen_console_putc(rbuf[body_start + k]);
        screen_console_putc('\n');
        kfree(rbuf);
        net_close(sock);
        return 1;
    }

    /* Write the initial body data (already received with headers). */
    fs_vfs_write(fd, rbuf + body_start, body_received);
    int total_saved = body_received;

    /* Phase 2: loop net_recv until we have all content_length bytes. */
    while (total_saved < content_length) {
        int n = net_recv(sock, rbuf, RBUF_CAP);
        if (n <= 0) break;  /* timeout or connection closed */
        fs_vfs_write(fd, rbuf, n);
        total_saved += n;
    }
    fs_vfs_close(fd);
    kfree(rbuf);
    net_close(sock);

    /* Report. */
    screen_console_puts("Saved ");
    u64_to_str(total_saved, n_tmp); screen_console_puts(n_tmp);
    screen_console_puts(" bytes to ");
    screen_console_puts(fpath);
    screen_console_putc('\n');
    return 0;
}

/* WP-09 mainstream: connection-level loss/congestion simulation.
 * Builds a fake ESTABLISHED connection, sends 3 segments (segment 1
 * "lost"), then feeds three duplicate ACKs through the REAL packet
 * handling path (net_tcp_handle_packet). Asserts fast retransmit fires,
 * fast recovery inflates/deflates the window, and the cumulative ACK
 * drains the retransmission buffer. All packets go through the exact
 * code path a real NIC delivery would take. */
static int net_tcp_cc_sim_test(void) {
    net_tcp_conn_t *c = 0;
    for (int i = 0; i < TCP_MAX_CONNS; i++) {
        if (!g_tcp_conns[i].in_use) { c = &g_tcp_conns[i]; break; }
    }
    if (!c) return 0;
    memset(c, 0, sizeof(*c));
    c->in_use = 1;
    c->sock_fd = -1;
    c->remote_ip = 0;   /* unspecified: net_ip_send drops silently, no RSTs */
    c->local_port = 55555;
    c->remote_port = 55556;
    c->state = TCP_ESTABLISHED;
    c->mss = 536;
    c->cwnd = 1;
    c->ssthresh = 65535;
    c->driver_snd_wnd = 65535;
    c->our_seq = 1000;
    c->driver_snd_una = 1000;
    c->our_ack = 5000;
    net_tcp_cc_init(&c->cc);

    u8 data[536];
    memset(data, 'A', sizeof(data));
    /* 3 segments in flight: 1000..1535, 1536..2071, 2072..2607.
     * Segment 1 is "lost" on the wire (never reaches the peer).
     * Fill the retransmission buffer directly (as net_tcp_send would) so the
     * simulation does not depend on real NIC delivery or ARP timeouts. */
    for (int sgi = 0; sgi < 3; sgi++) {
        memcpy(c->rtx_buf + sgi * 536, data, 536);
    }
    c->rtx_len = 3 * 536;
    /* BUG-0205: rtx_sent tracks the transmitted prefix; the simulation
     * emulates three segments that net_tcp_send has already sent. */
    c->rtx_sent = 3 * 536;
    c->rtx_seq = 1000;
    c->rto = 300;                        /* no RTO interference */
    c->rto_deadline = core_timer_ticks() + 300;
    c->send_tick = core_timer_ticks();
    c->rtx_retransmitted = 0;
    c->our_seq = 1000 + 3 * 536;

    /* Build a raw ACK segment from the peer: ack = 1000 (dup).
     * Layout: src(2) dst(2) seq(4) ack(4) doff|flags(2) win(2) cksum(2) urg(2) */
    u8 seg[20];
    #define CC_SIM_BUILD_ACK(seg, ackval) do { \
        (seg)[0] = 0xD9; (seg)[1] = 0x04;                  /* src 55556 */ \
        (seg)[2] = 0xD9; (seg)[3] = 0x03;                  /* dst 55555 */ \
        (seg)[4] = 0; (seg)[5] = 0; (seg)[6] = 0; (seg)[7] = 0; /* seq */ \
        (seg)[8] = (u8)((ackval) >> 24); (seg)[9] = (u8)((ackval) >> 16); \
        (seg)[10] = (u8)((ackval) >> 8); (seg)[11] = (u8)(ackval); \
        (seg)[12] = 0x50; (seg)[13] = 0x10;                /* hdr20, ACK */ \
        (seg)[14] = 0xFF; (seg)[15] = 0xFF;                /* win */ \
        (seg)[16] = 0; (seg)[17] = 0; (seg)[18] = 0; (seg)[19] = 0; \
    } while (0)

    for (int k = 0; k < 3; k++) {
        CC_SIM_BUILD_ACK(seg, 1000);
        net_tcp_handle_packet(c->remote_ip, seg, 20);
        {
            char db[120];
            strcpy(db, "    [sim] after dup ACK: fr=");
            char nn[12];
            u64_to_str((u64)c->fr_active, nn); strcat(db, nn);
            strcat(db, " dups=");
            u64_to_str((u64)c->dup_ack_count, nn); strcat(db, nn);
            strcat(db, " rtx_len=");
            u64_to_str((u64)c->rtx_len, nn); strcat(db, nn);
            strcat(db, " rtx_re=");
            u64_to_str((u64)c->rtx_retransmitted, nn); strcat(db, nn);
            screen_console_puts(db); screen_console_puts("\n");
        }
    }
    int ok_fr = (c->fr_active == 1 && c->dup_ack_count == 3 &&
                 c->rtx_retransmitted == 1 &&
                 c->cwnd == c->ssthresh / c->mss + 3);

    /* Peer receives the retransmission → cumulative ACK advances to 2608.
     * Fast recovery ends: cwnd deflates to ssthresh, rtx buffer empties. */
    CC_SIM_BUILD_ACK(seg, 2608);
    net_tcp_handle_packet(c->remote_ip, seg, 20);
    int ok_end = (c->fr_active == 0 && c->rtx_len == 0 &&
                  c->driver_snd_una == 2608 &&
                  c->cwnd == c->ssthresh / c->mss);

    c->in_use = 0;

    char b[128];
    strcpy(b, "  fast retransmit + inflation: ");
    strcat(b, ok_fr ? "PASS" : "FAIL");
    screen_console_puts(b); screen_console_puts("\n");
    strcpy(b, "  recovery end + deflate + rtx drain: ");
    strcat(b, ok_end ? "PASS" : "FAIL");
    screen_console_puts(b); screen_console_puts("\n");
    return ok_fr && ok_end;
}

/* WP-09 mainstream: tcpcc_test — run the CUBIC (RFC 8312) self-test vectors
 * inside the kernel. Covers integer_cbrt, the beta decrease, the cubic
 * growth curve at two sample points, RTO and fast-recovery bookkeeping,
 * plus a connection-level loss/congestion simulation. */
static int shell_cmd_tcpcc_test(const char *args) {
    (void)args;
    int fails = 0;
    screen_console_puts("CUBIC (RFC 8312) kernel self-test:\n");

    struct { u32 x, want; const char *name; } crts[] = {
        { 0, 0, "cbrt(0)" }, { 8, 2, "cbrt(8)" }, { 1000, 10, "cbrt(1000)" },
        { 27000, 30, "cbrt(27000)" }, { 2147483647u, 1290, "cbrt(2^31-1)" },
    };
    for (int i = 0; i < 5; i++) {
        u32 got = integer_cbrt(crts[i].x);
        int ok = (got == crts[i].want);
        if (!ok) fails++;
        char b[96];
        strcpy(b, "  "); strcat(b, crts[i].name);
        strcat(b, ": got=");
        char n[12]; u64_to_str(got, n); strcat(b, n);
        strcat(b, ok ? "  PASS" : "  FAIL");
        screen_console_puts(b); screen_console_puts("\n");
    }

    int ok7 = (net_tcp_cc_beta(10000) == 7000 && net_tcp_cc_beta(536) == 375);
    if (!ok7) fails++;
    screen_console_puts(ok7 ? "  beta decrease: PASS\n" : "  beta decrease: FAIL\n");

    /* cubic curve: W_max=60 MSS, mss=536, K=350 ticks
     * t=1s: W = 0.4*(1+3.5)^3+60 = 96.4 -> integer 96..99 MSS */
    cubic_state_t s;
    net_tcp_cc_init(&s);
    s.w_max = 60 * 536;
    net_tcp_cc_compute_k(&s, 60 * 536, 536);
    s.epoch_start = 1;
    s.net_tcp_cwnd = 60 * 536;
    u32 w1 = net_tcp_cc_on_ack(&s, 60 * 536, 60 * 536, 101, 536, 536);
    u32 m1 = w1 / 536;
    int ok1 = (m1 >= 96 && m1 <= 99);
    if (!ok1) fails++;
    char b2[96];
    strcpy(b2, "  cubic t=1s (want 96..99 MSS): got=");
    char n2[12]; u64_to_str(m1, n2); strcat(b2, n2);
    strcat(b2, ok1 ? "  PASS" : "  FAIL");
    screen_console_puts(b2); screen_console_puts("\n");

    /* t=10s: ~1055 MSS */
    net_tcp_cc_init(&s);
    s.w_max = 60 * 536;
    net_tcp_cc_compute_k(&s, 60 * 536, 536);
    s.epoch_start = 1;
    s.net_tcp_cwnd = 60 * 536;
    u32 w10 = net_tcp_cc_on_ack(&s, 60 * 536, 60 * 536, 1001, 536, 536);
    u32 m10 = w10 / 536;
    int ok10 = (m10 >= 500 && m10 <= 1100);
    if (!ok10) fails++;
    char b3[96];
    strcpy(b3, "  cubic t=10s (want ~1055 MSS): got=");
    char n3[12]; u64_to_str(m10, n3); strcat(b3, n3);
    strcat(b3, ok10 ? "  PASS" : "  FAIL");
    screen_console_puts(b3); screen_console_puts("\n");

    net_tcp_cc_init(&s);
    u32 ss = net_tcp_cc_on_rto(&s, 20000);
    int okr = (ss == 14000 && s.w_max == 20000);
    if (!okr) fails++;
    screen_console_puts(okr ? "  rto: ssthresh=0.7*cwnd, w_max=cwnd: PASS\n"
                        : "  rto: ssthresh=0.7*cwnd, w_max=cwnd: FAIL\n");

    net_tcp_cc_init(&s);
    ss = net_tcp_cc_on_fast_recovery_enter(&s, 20000);
    int okf = (ss == 14000 && s.w_max == 20000);
    if (!okf) fails++;
    screen_console_puts(okf ? "  fast recovery enter: PASS\n"
                        : "  fast recovery enter: FAIL\n");

    if (fails == 0) screen_console_puts("tcpcc_test: ALL PASS\n");
    else screen_console_puts("tcpcc_test: FAILURES\n");
    int sim_ok = net_tcp_cc_sim_test();
    return (fails == 0 && sim_ok) ? 0 : 1;
}

/* WP-09 mainstream: net_netfilter_test — netfilter self-test. Exercises rule matching,
 * state matching, per-rule hits, default policies, REJECT classification and
 * the conntrack state machine via the public netfilter interfaces, plus one
 * REAL-path check: an OUTPUT DROP rule makes net_icmp_ping fail. */
static int shell_cmd_nf_test(const char *args) {
    (void)args;
    int fails = 0;
    u32 peer = IP4(203, 0, 113, 7);
    screen_console_puts("netfilter self-test:\n");

    /* 1) rule match + hits: INPUT DROP icmp from 203.0.113.7 */
    net_netfilter_reset();
    net_netfilter_add_rule_st(NF_CHAIN_INPUT, peer, 0xFFFFFFFF, 0, 0, 1, 0,
                          NF_ACTION_DROP, NF_STATE_ANY);
    u8 v1 = net_netfilter_check(NF_CHAIN_INPUT, peer, g_ip, 1, 0, 0, NF_STATE_NEW);
    net_netfilter_rule_t rl[32];
    net_netfilter_list_rules(rl, 32);
    int ok1 = (v1 == NF_ACTION_DROP && rl[0].hits == 1);
    if (!ok1) fails++;
    screen_console_puts(ok1 ? "  [PASS] input drop rule + hits\n"
                        : "  [FAIL] input drop rule + hits\n");

    /* 2) state match: rule allows established only; NEW must fall through */
    net_netfilter_reset();
    net_netfilter_add_rule_st(NF_CHAIN_INPUT, peer, 0xFFFFFFFF, 0, 0, 6, 80,
                          NF_ACTION_DROP, NF_STATE_NEW);
    v1 = net_netfilter_check(NF_CHAIN_INPUT, peer, g_ip, 6, 51000, 80,
                         NF_STATE_ESTABLISHED);
    u8 v2 = net_netfilter_check(NF_CHAIN_INPUT, peer, g_ip, 6, 51000, 80,
                            NF_STATE_NEW);
    int ok2 = (v1 == NF_ACTION_ACCEPT && v2 == NF_ACTION_DROP);
    if (!ok2) fails++;
    screen_console_puts(ok2 ? "  [PASS] state matching (est bypasses, new hits)\n"
                        : "  [FAIL] state matching\n");

    /* 3) REJECT classification */
    net_netfilter_reset();
    net_netfilter_add_rule_st(NF_CHAIN_INPUT, 0, 0, 0, 0, 17, 53,
                          NF_ACTION_REJECT, NF_STATE_ANY);
    v1 = net_netfilter_check(NF_CHAIN_INPUT, peer, g_ip, 17, 53000, 53,
                         NF_STATE_NEW);
    int ok3 = (v1 == NF_ACTION_REJECT);
    if (!ok3) fails++;
    screen_console_puts(ok3 ? "  [PASS] reject classification\n"
                        : "  [FAIL] reject classification\n");

    /* 4) default policy: OUTPUT DROP with no rules */
    net_netfilter_reset();
    net_netfilter_set_policy(NF_CHAIN_OUTPUT, NF_ACTION_DROP);
    v1 = net_netfilter_check(NF_CHAIN_OUTPUT, g_ip, peer, 1, 0, 0, NF_STATE_NEW);
    int ok4 = (v1 == NF_ACTION_DROP);
    net_netfilter_set_policy(NF_CHAIN_OUTPUT, NF_ACTION_ACCEPT);
    if (!ok4) fails++;
    screen_console_puts(ok4 ? "  [PASS] per-chain default policy\n"
                        : "  [FAIL] per-chain default policy\n");

    /* 5) conntrack state machine (TCP): outbound SYN = NEW,
     *    inbound SYN-ACK = ESTABLISHED, then data both ways */
    net_netfilter_ct_flush();
    u16 cs = 40000, cp = 443;
    u8 s1 = net_netfilter_ct_classify(6, g_ip, cs, peer, cp, 1, 0x02);    /* SYN out */
    u8 s2 = net_netfilter_ct_classify(6, peer, cp, g_ip, cs, 0, 0x12);    /* SYN-ACK in */
    u8 s3 = net_netfilter_ct_classify(6, g_ip, cs, peer, cp, 1, 0x10);    /* ACK out */
    int ok5 = (s1 == NF_STATE_NEW && s2 == NF_STATE_ESTABLISHED &&
               s3 == NF_STATE_ESTABLISHED);
    if (!ok5) fails++;
    screen_console_puts(ok5 ? "  [PASS] conntrack TCP handshake\n"
                        : "  [FAIL] conntrack TCP handshake\n");

    /* 6) conntrack UDP: first outbound = NEW, reply = ESTABLISHED */
    net_netfilter_ct_flush();
    s1 = net_netfilter_ct_classify(17, g_ip, 5353, peer, 53, 1, 0);
    s2 = net_netfilter_ct_classify(17, peer, 53, g_ip, 5353, 0, 0);
    int ok6 = (s1 == NF_STATE_NEW && s2 == NF_STATE_ESTABLISHED);
    if (!ok6) fails++;
    screen_console_puts(ok6 ? "  [PASS] conntrack UDP flow\n"
                        : "  [FAIL] conntrack UDP flow\n");

    /* 7) REAL path: OUTPUT DROP tcp port 80 blocks icmp? no — blocks TCP.
     *    Use OUTPUT DROP icmp and expect net_icmp_ping to fail. */
    net_netfilter_reset();
    net_netfilter_add_rule_st(NF_CHAIN_OUTPUT, 0, 0, 0, 0, 1, 0,
                          NF_ACTION_DROP, NF_STATE_ANY);
    int prc = net_icmp_ping(IP4(10, 0, 2, 2), 300);
    int ok7 = (prc != 0);   /* ping must FAIL while ICMP is dropped */
    net_netfilter_del_rule(0);
    net_netfilter_ct_flush();
    int prc2 = net_icmp_ping(IP4(10, 0, 2, 2), 300);
    int ok8 = (prc2 == 0);  /* after removing the rule ping works */
    if (!ok7) fails++;
    if (!ok8) fails++;
    screen_console_puts(ok7 ? "  [PASS] OUTPUT drop blocks ping (real path)\n"
                        : "  [FAIL] OUTPUT drop blocks ping\n");
    screen_console_puts(ok8 ? "  [PASS] rule removal restores ping\n"
                        : "  [FAIL] rule removal restores ping\n");

    net_netfilter_reset();
    if (fails == 0) screen_console_puts("nf_test: ALL PASS\n");
    else screen_console_puts("nf_test: FAILURES\n");
    return fails == 0 ? 0 : 1;
}

/* WP-09 mainstream: tcptest — verify TCP option negotiation (MSS, Window
 * Scale, SACK-Permitted, Timestamps) on a REAL connection to a mainstream
 * server, plus option wire bytes on our own SYN. */
static int shell_cmd_tcptest(const char *args) {
    (void)args;
    int fails = 0;
    /* Single-line output on purpose (see KNOWN_ISSUES scroll-edge fault).
     * Live-path option negotiation is additionally covered by the HTTPS E2E
     * run (wget https://... over TLS needs the same SYN option set). */
    /* 1) OUR SYN option block: MSS + WScale + SACK-Permitted + Timestamps */
    /* P0fix1 BUG-0005 (A13-1): net_tcp_conn_t is ~16.6KB (rx_buf[8192] +
     * rtx_buf[4096] + ooo_data...). Two of them on the stack (~33KB)
     * overflowed the 16KB boot stack the shell runs on -> deterministic
     * page-table/heap corruption (#PF after the command, audit RUN-01,
     * 100% reproducible). They are only used as option-block scratch, so
     * allocate them from the heap (static placement would also push the
     * kernel image past the 0x400000 identity window). */
    net_tcp_conn_t *tmp = (net_tcp_conn_t *)kmalloc(sizeof(net_tcp_conn_t));
    if (!tmp) { screen_console_puts("tcptest: alloc failed\n"); return 1; }
    memset(tmp, 0, sizeof(*tmp));
    tmp->mss = 1460;
    tmp->win_scale_sent = 7;
    u8 opts[32];
    int n = net_tcp_build_syn_options(tmp, opts);
    int ok_syn = (n == 24 &&
                  opts[0] == TCP_OPT_MSS && opts[1] == 4 &&
                  opts[5] == TCP_OPT_WSCALE && opts[6] == 3 &&
                  opts[10] == TCP_OPT_SACK_PERM && opts[11] == 2 &&
                  opts[14] == TCP_OPT_TS && opts[15] == 10);
    if (!ok_syn) fails++;

    /* 2) PARSER unit check: a synthetic peer SYN option block */
    net_tcp_conn_t *t2 = (net_tcp_conn_t *)kmalloc(sizeof(net_tcp_conn_t));
    if (!t2) { kfree(tmp); screen_console_puts("tcptest: alloc failed\n"); return 1; }
    memset(t2, 0, sizeof(*t2));
    t2->mss = 1460;
    u8 synack_opts[24] = {
        0x02, 0x04, 0x05, 0xb4,
        0x01, 0x03, 0x03, 0x07,
        0x01, 0x01, 0x04, 0x02,
        0x01, 0x01, 0x08, 0x0a, 0x11,0x22,0x33,0x44, 0x55,0x66,0x77,0x88
    };
    net_tcp_parse_options(t2, synack_opts, 24, 1);
    int ok_parse = (t2->mss == 1460 && t2->win_scale_recv == 7 &&
                    t2->sack_permitted == 1 && t2->ts_enabled == 1 &&
                    t2->ts_recent == 0x11223344);
    kfree(t2);
    kfree(tmp);
    if (!ok_parse) fails++;

    /* 3) BUG-0069 regression (synrcvd-recycle): 32 slots driven to
     *    SYN_RCVD with an EXPIRED handshake deadline must all be
     *    recycled by ONE net_tcp_check_rto() sweep; a fresh-deadline
     *    SYN_RCVD entry must survive the sweep; and a sweep over a
     *    table with no live connections must be a clean no-op. The
     *    check deliberately rewrites the whole connection table, so it
     *    only runs when the table is idle (no in_use slot) — with live
     *    connections present it reports skip instead of corrupting
     *    them (never a FAIL: environmental, not a regression signal).
     *    An interleaved timer-IRQ sweep cannot cause a false result:
     *    recycling expired SYN_RCVD slots is idempotent and a fresh
     *    deadline is preserved by any sweeper. */
    int ok_recycle = 1;
    int recycle_skipped = 0;
    int live_conns = 0;
    for (int i = 0; i < TCP_MAX_CONNS; i++)
        if (g_tcp_conns[i].in_use) live_conns++;
    if (live_conns != 0) {
        recycle_skipped = 1;
    } else {
        u64 now = core_timer_ticks();
        /* (a) empty-table sweep: clean no-op, nothing becomes in_use */
        net_tcp_check_rto();
        for (int i = 0; i < TCP_MAX_CONNS; i++)
            if (g_tcp_conns[i].in_use) ok_recycle = 0;
        /* (b) all 32 slots -> SYN_RCVD with an expired deadline */
        for (int i = 0; i < TCP_MAX_CONNS; i++) {
            net_tcp_conn_t *c = &g_tcp_conns[i];
            c->in_use = 1;
            c->state = TCP_SYN_RCVD;
            c->remote_ip = IP4(10, 0, 2, 99);
            c->local_port = (u16)(1000 + i);
            c->remote_port = 12345;
            c->rto_deadline = (now > 0) ? (now - 1) : 0;  /* expired */
        }
        net_tcp_check_rto();
        for (int i = 0; i < TCP_MAX_CONNS; i++)
            if (g_tcp_conns[i].in_use) ok_recycle = 0;
        /* (c) a fresh-deadline SYN_RCVD entry survives the sweep */
        g_tcp_conns[0].in_use = 1;
        g_tcp_conns[0].state = TCP_SYN_RCVD;
        g_tcp_conns[0].rto_deadline = now + 6000;   /* 60 s: not expired */
        net_tcp_check_rto();
        if (!g_tcp_conns[0].in_use ||
            g_tcp_conns[0].state != TCP_SYN_RCVD) ok_recycle = 0;
        /* leave the table as we found it: everything free */
        g_tcp_conns[0].in_use = 0;
        g_tcp_conns[0].state = TCP_CLOSED;
        if (!ok_recycle) fails++;
    }

    char b[200];
    strcpy(b, "tcptest: ");
    strcat(b, fails == 0 ? "ALL PASS" : "FAILURES");
    strcat(b, " (syn-opts=");
    strcat(b, ok_syn ? "ok" : "bad");
    strcat(b, " parser=");
    strcat(b, ok_parse ? "ok" : "bad");
    strcat(b, " synrcvd-recycle=");
    strcat(b, recycle_skipped ? "skip" : (ok_recycle ? "ok" : "bad"));
    strcat(b, "; live negotiation covered by HTTPS E2E)");
    screen_console_puts(b); screen_console_puts("\n");
    return fails == 0 ? 0 : 1;
}

/* Network shell command registration (WP-10d-fix2: shell.h include,
 * the local extern declaration predates it and did not know _ex). */
void net_register_shell_commands(void) {
    shell_register_command_ex("ifconfig", shell_cmd_ifconfig, "show network interface info", "WP-06");
    shell_register_command_ex("ip", shell_cmd_ip, "show/set IP address", "WP-06");
    shell_register_command_ex("route", shell_cmd_route, "show/add/del routing table (route add <dst> <mask> <gw>)", "WP-06");
    shell_register_command_ex("arp", shell_cmd_arp, "show ARP cache", "WP-06");
    shell_register_command_ex("firewall", shell_cmd_firewall, "show/add/del firewall rules (chains, states, policies, conntrack)", "WP-06");
    shell_register_command_ex("nf_test", shell_cmd_nf_test, "netfilter self-test (rules, conntrack, policies, real-path)", "WP-06");
    shell_register_command_ex("tcpstats", shell_cmd_tcpstats, "show TCP reliability stats (cwnd, rto, etc.)", "WP-06");
    shell_register_command_ex("tcpcc_test", shell_cmd_tcpcc_test, "CUBIC congestion control self-test vectors", "WP-06");
    shell_register_command_ex("ping", shell_cmd_ping, "send ICMP echo (ping <host>)", "WP-06");
    shell_register_command_ex("netstat", shell_cmd_netstat, "show network statistics and sockets", "WP-06");
    shell_register_command_ex("dhcp", shell_cmd_dhcp, "get IP via DHCP", "WP-06");
    shell_register_command_ex("dns", shell_cmd_dns, "resolve domain name (dns <name> [aaaa|cname|mx|txt|ns|srv])", "WP-06");
    shell_register_command_ex("dnstest", shell_cmd_dnstest, "DNS record-type self-test (A/AAAA/MX/TXT/NS/SRV live)", "WP-06");
    shell_register_command_ex("tcptest", shell_cmd_tcptest, "TCP option negotiation self-test (MSS/WScale/SACK/TS live)", "WP-06");
    shell_register_command_ex("lspci", shell_cmd_lspci, "list PCI devices", "WP-06");
    shell_register_command_ex("wget", shell_cmd_wget, "download file via HTTP (wget <host> [port] [path])", "WP-06");
}

/* Periodic timer callback for network polling. */
static void net_timer_cb(void *ctx) {
    (void)ctx;
    net_poll();
}

void net_start_timer(void) {
    core_timer_register_periodic(net_timer_cb, NULL, 10);  /* every 10ms */
}

/* WP-10-chinese_support-fix2: S3 resume replay for the legacy e1000
 * path (QEMU's default -device e1000, 8086:100E, lives here - NOT in
 * the e1000e family driver). The platform reset wiped the device's
 * register state and can clear BAR0 itself; the descriptor rings and
 * buffers live in RAM and survived. Re-program the device against the
 * EXISTING rings (no re-allocation, no re-probe) so the resumed system
 * keeps the same NIC with the same MAC. Mirrors e1000_init()'s register
 * sequence exactly. */
void net_e1000_resume(void) {
    if (!g_e1000_mmio) return;   /* no legacy e1000 was up before sleep */

    /* rewrite BAR0 (harmless if the firmware already restored it) and
     * re-enable the command register before any MMIO access */
    driver_pci_write_config(g_e1000_bus, g_e1000_dev, g_e1000_func,
                            0x10, (u32)(uintptr_t)g_e1000_mmio);
    {
        u32 cs = driver_pci_read_config(g_e1000_bus, g_e1000_dev, g_e1000_func, 0x04);
        cs = (cs & 0xFFFF0000) | 0x0107;   /* IO | MEM | BM | SERR# */
        driver_pci_write_config(g_e1000_bus, g_e1000_dev, g_e1000_func, 0x04, cs);
    }

    /* Disable interrupts (polling driver). */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_IMC), 0xFFFFFFFF);

    /* Re-assert the station address (RA[0]) - the reset cleared it. */
    u32 ra_lo = g_mac[0] | ((u32)g_mac[1] << 8) | ((u32)g_mac[2] << 16) | ((u32)g_mac[3] << 24);
    u32 ra_hi = g_mac[4] | ((u32)g_mac[5] << 8) | (1u << 31);  /* AV bit */
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RA), ra_lo);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RA + 4), ra_hi);

    /* RX ring: reset BOTH sides (device restarts at RDH=0 while the
     * driver-side rx_tail kept its pre-sleep value; stale descriptor
     * statuses would make net_poll silently drop packets). */
    memset((void *)g_rx_descs, 0, PMM_PAGE_SIZE);
    for (int i = 0; i < E1000_NUM_DESC; i++)
        g_rx_descs[i].addr = (u64)(uintptr_t)g_rx_bufs[i];
    g_rx_tail = 0;
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RCTL), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDBAL),
                 (u32)(uintptr_t)g_rx_descs);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDBAH), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDLEN),
                 (u32)(sizeof(e1000_desc_t) * E1000_NUM_DESC));
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDH), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RDT),
                 E1000_NUM_DESC - 1);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_RCTL),
                 E1000_RCTL_EN | E1000_RCTL_UPE | E1000_RCTL_MPE |
                 E1000_RCTL_BAM | E1000_RCTL_SECRC);

    /* TX ring: same replay shape. */
    memset((void *)g_tx_descs, 0, PMM_PAGE_SIZE);
    g_tx_tail = 0;
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TCTL), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDBAL),
                 (u32)(uintptr_t)g_tx_descs);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDBAH), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDLEN),
                 (u32)(sizeof(e1000_desc_t) * E1000_NUM_DESC));
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDH), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TDT), 0);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + 0x0410), 0x0060200A);
    mmio_write32((volatile void *)((u8 *)g_e1000_mmio + E1000_TCTL),
                 (1u << 1) | (1u << 3) | (0x0F << 4) | (0x3F << 12));

    /* bus master LAST (QEMU caches the PCI command state). */
    {
        u32 cs = driver_pci_read_config(g_e1000_bus, g_e1000_dev, g_e1000_func, 0x04);
        cs = (cs & 0xFFFF0000) | 0x0107;
        driver_pci_write_config(g_e1000_bus, g_e1000_dev, g_e1000_func, 0x04, cs);
    }
}
