/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
/* Open Cube OS - WP-07
 * File: drivers/block/driver_block_part.c
 * Purpose: MBR + GPT partition table parser.
 */
#include "driver_block_part.h"
#include "driver_block_blk.h"
#include "mem_heap.h"
#include "lib_string.h"
#include "screen_console.h"
#include "lib_log.h"

#pragma pack(push, 1)
typedef struct {
    u8  boot;
    u8  start_chs[3];
    u8  type;
    u8  end_chs[3];
    u32 start_lba;
    u32 sectors;
} mbr_entry_t;

typedef struct {
    u8  boot_code[446];
    mbr_entry_t parts[4];
    u16 signature;   /* 0xAA55 */
} mbr_sector_t;

typedef struct {
    char sig[8];           /* "EFI PART" */
    u32 revision;
    u32 header_size;
    u32 header_crc32;
    u32 reserved;
    u64 my_lba;
    u64 alt_lba;
    u64 first_usable;
    u64 last_usable;
    u8  driver_block_part_disk_guid[16];
    u64 driver_block_part_entry_start;
    u32 num_entries;
    u32 entry_size;
    u32 entries_crc32;
} gpt_header_t;

typedef struct {
    u8  type_guid[16];
    u8  unique_guid[16];
    u64 first_lba;
    u64 last_lba;
    u64 attributes;
    char name[72];   /* UTF-16LE, but we store as raw bytes */
} gpt_entry_t;
#pragma pack(pop)

int driver_block_part_parse_mbr(int dev_idx, driver_block_part_table_t *out) {
    if (!out) return -1;
    memset(out, 0, sizeof(*out));
    out->dev_idx = dev_idx;
    out->table_type = PART_TYPE_MBR;

    u8 buf[512];
    if (driver_block_read_sectors_raw(dev_idx, 0, 1, buf) != 0) return -1;

    mbr_sector_t *mbr = (mbr_sector_t *)buf;
    if (mbr->signature != 0xAA55) return -1;

    for (int i = 0; i < 4; i++) {
        mbr_entry_t *e = &mbr->parts[i];
        if (e->type == 0) continue;
        if (out->count >= PART_MAX_PARTITIONS) break;
        /* BUG-017 FIX: Validate partition entry before accepting it.
         * Old code accepted any partition entry from sector 0, even if
         * the "MBR" was actually a superfloppy (FAT boot sector with
         * 0x55AA signature). This caused bogus partitions with start=0
         * and sector count exceeding disk capacity.
         * Now we check: start_lba > 0 and start_lba + sectors <= capacity. */
        if (e->start_lba == 0) continue;  /* start LBA 0 = bogus */
        /* Get device capacity to validate */
        driver_block_device_t *dev = driver_block_get_device(dev_idx);
        if (dev) {
            u64 end_lba = (u64)e->start_lba + e->sectors;
            if (end_lba > dev->sectors) continue;  /* exceeds disk */
        }
        partition_t *p = &out->parts[out->count];
        p->present = 1;
        p->bootable = (e->boot & 0x80) ? 1 : 0;
        p->type = e->type;
        p->start_lba = e->start_lba;
        p->sectors = e->sectors;
        char nm[20]; char n[8];
        strcpy(nm, "MBR-"); u64_to_str(out->count, n); strcat(nm, n);
        strncpy(p->name, nm, PART_NAME_LEN - 1);
        out->count++;
    }

    /* Check for GPT protective partition (type 0xEE). */
    for (int i = 0; i < out->count; i++) {
        if (out->parts[i].type == 0xEE) {
            /* This is actually a GPT disk — reparse as GPT. */
            return driver_block_part_parse_gpt(dev_idx, out);
        }
    }
    return 0;
}

/* BUG-0309 (A6-13): IEEE CRC32 (bitwise, same polynomial as gzip) used
 * for the GPT header and partition-entry-array checksums. */
static u32 driver_block_part_crc32(const u8 *buf, u64 len) {
    u32 crc = 0xFFFFFFFFu;
    for (u64 i = 0; i < len; i++) {
        crc ^= buf[i];
        for (int k = 0; k < 8; k++)
            crc = (crc >> 1) ^ (0xEDB88320u & (u32)(-(int)(crc & 1)));
    }
    return ~crc;
}

int driver_block_part_parse_gpt(int dev_idx, driver_block_part_table_t *out) {
    if (!out) return -1;
    memset(out, 0, sizeof(*out));
    out->dev_idx = dev_idx;
    out->table_type = PART_TYPE_GPT;

    /* BUG-0309 (A6-13): the parent capacity for the per-entry range check. */
    driver_block_device_t *pdev = driver_block_get_device(dev_idx);
    u64 disk_sectors = pdev ? pdev->sectors : 0;

    u8 buf[512];
    /* Read GPT header at LBA 1. */
    if (driver_block_read_sectors_raw(dev_idx, 1, 1, buf) != 0) return -1;
    gpt_header_t *gh = (gpt_header_t *)buf;
    if (memcmp(gh->sig, "EFI PART", 8) != 0) return -1;

    /* BUG-0309 (A6-13): validate the header before trusting any field in
     * it. Header CRC covers HeaderSize bytes with the CRC field zeroed;
     * my_lba must reference this header's own LBA (1). */
    if (gh->header_size < 92 || gh->header_size > 512) return -1;
    {
        u32 stored = gh->header_crc32;
        gh->header_crc32 = 0;
        u32 calc = driver_block_part_crc32(buf, gh->header_size);
        gh->header_crc32 = stored;
        if (calc != stored) return -1;
        if (gh->my_lba != 1) return -1;
    }

    u32 num_entries = gh->num_entries;
    u32 entry_size = gh->entry_size;
    u64 entry_start = gh->driver_block_part_entry_start;
    if (num_entries > PART_MAX_PARTITIONS) num_entries = PART_MAX_PARTITIONS;
    if (entry_size < sizeof(gpt_entry_t)) entry_size = sizeof(gpt_entry_t);
    /* BUG-0113 FIX: entry_size came straight from the (on-disk) GPT
     * header with only a lower bound. A huge value (or one that
     * overflows the u32 sectors_to_read multiply) made the per-entry
     * pointer entry_buf + i*entry_size run past the 4 KiB stack buffer
     * -> out-of-bounds stack read / #PF panic. Real GPTs use 128-byte
     * entries (UEFI spec minimum); refuse absurd sizes and clamp the
     * entry count so num_entries*entry_size always fits the buffer. */
    if (entry_size > 1024) return -1;

    /* Read partition entries. They usually start at LBA 2 and may span
     * multiple sectors. Read up to 8 sectors (enough for 128 entries). */
    u8 entry_buf[512 * 8];
    u64 need = (u64)num_entries * (u64)entry_size;
    if (need > sizeof(entry_buf)) {
        u32 max_fit = (u32)((u64)sizeof(entry_buf) / (u64)entry_size);
        if (max_fit == 0) return -1;
        num_entries = max_fit;
        need = (u64)num_entries * (u64)entry_size;
    }
    u32 sectors_to_read = (u32)((need + 511) / 512);
    /* BUG-0309 (A6-13): when the FULL on-disk entry array (spec size)
     * fits the buffer, read enough sectors to verify its CRC32 even if
     * the clamped entry count reads fewer. */
    u64 spec_bytes = (u64)gh->num_entries * (u64)gh->entry_size;
    if (spec_bytes > need && spec_bytes <= sizeof(entry_buf))
        sectors_to_read = (u32)((spec_bytes + 511) / 512);
    if (sectors_to_read > 8) sectors_to_read = 8;
    if (driver_block_read_sectors_raw(dev_idx, entry_start, sectors_to_read, entry_buf) != 0) return -1;
    /* BUG-0309 (A6-13): the partition entry array carries its own CRC32.
     * The spec CRC covers num_entries*entry_size bytes; the checksum is
     * enforced whenever the whole array fits the bytes actually read.
     * A WRONG CRC means a torn array - refuse the table instead of
     * registering phantom partitions. Zero is tolerated (some tools
     * leave it 0). */
    if (gh->entries_crc32 != 0 &&
        spec_bytes <= (u64)sectors_to_read * 512 &&
        driver_block_part_crc32(entry_buf, spec_bytes) != gh->entries_crc32)
        return -1;

    for (u32 i = 0; i < num_entries; i++) {
        gpt_entry_t *e = (gpt_entry_t *)(entry_buf + (u64)i * entry_size);
        /* Check if entry is used (type GUID != all zeros). */
        int used = 0;
        for (int j = 0; j < 16; j++) {
            if (e->type_guid[j] != 0) { used = 1; break; }
        }
        if (!used) continue;
        /* BUG-0309 (A6-13): reject inverted/empty/out-of-disk entries.
         * last_lba < first_lba previously wrapped sectors into a ~2^64
         * monstrosity, and nothing cross-checked the entry against the
         * disk capacity (the MBR path already did). */
        if (e->first_lba == 0 || e->last_lba < e->first_lba) continue;
        if (disk_sectors != 0 && e->last_lba >= disk_sectors) continue;
        if (out->count >= PART_MAX_PARTITIONS) break;
        partition_t *p = &out->parts[out->count];
        p->present = 1;
        p->type = e->type_guid[0];   /* first byte is a rough type indicator */
        p->start_lba = e->first_lba;
        p->sectors = e->last_lba - e->first_lba + 1;
        memcpy(p->gpt_type_guid, e->type_guid, 16);
        /* Extract ASCII name from UTF-16LE (take low bytes, stop at null). */
        int ni = 0;
        for (int j = 0; j < 72 && ni < PART_NAME_LEN - 1; j += 2) {
            char c = e->name[j];
            if (c == 0) break;
            p->name[ni++] = c;
        }
        p->name[ni] = 0;
        if (ni == 0) {
            char nm[20]; char n[8];
            strcpy(nm, "GPT-"); u64_to_str(out->count, n); strcat(nm, n);
            strncpy(p->name, nm, PART_NAME_LEN - 1);
        }
        out->count++;
    }
    return 0;
}

int driver_block_part_parse(int dev_idx, driver_block_part_table_t *out) {
    /* Try MBR first — it will auto-detect GPT if the protective entry is found. */
    return driver_block_part_parse_mbr(dev_idx, out);
}

partition_t *driver_block_part_get_partition(driver_block_part_table_t *tbl, int index) {
    if (!tbl || index < 0 || index >= tbl->count) return NULL;
    return &tbl->parts[index];
}

/* ---- WP-10d-pre: partition block-device registration -------------
 *
 * Extracted from ota_ab_update.c (WP-10u) so the in-system abdisk /
 * install commands can register freshly written partition tables
 * without rebooting.  Behavior is identical to the original
 * ota_ab_register_partition(): child device named "<parent>pN" that
 * forwards sector I/O to the parent with a start-LBA offset.
 */
typedef struct {
    int parent_idx;
    u64 start_lba;
} driver_block_part_child_priv_t;

static int driver_block_part_child_read(driver_block_device_t *dev, u64 lba, u32 count, void *buf) {
    driver_block_part_child_priv_t *p = (driver_block_part_child_priv_t *)dev->priv;
    if (!p) return -1;
    /* BUG-0310 (A6-14): the child registered `sectors` but never enforced
     * it - I/O past the partition end went straight to the parent disk and
     * could read/write into other partitions. Overflow-safe range check. */
    if (count == 0) return 0;
    if (lba >= dev->sectors || (u64)count > dev->sectors - lba) return -1;
    return driver_block_read_sectors_raw(p->parent_idx, p->start_lba + lba, count, buf);
}

static int driver_block_part_child_write(driver_block_device_t *dev, u64 lba, u32 count, const void *buf) {
    driver_block_part_child_priv_t *p = (driver_block_part_child_priv_t *)dev->priv;
    if (!p) return -1;
    /* BUG-0310 (A6-14): same partition-bounds enforcement as the read path. */
    if (count == 0) return 0;
    if (lba >= dev->sectors || (u64)count > dev->sectors - lba) return -1;
    return driver_block_write_sectors_raw(p->parent_idx, p->start_lba + lba, count, buf);
}

static const driver_block_ops_t g_part_child_ops = {
    .read  = driver_block_part_child_read,
    .write = driver_block_part_child_write,
    .flush = NULL,               /* parent driver flush runs separately */
};

int driver_block_part_register_child(const char *parent_name, int parent_idx,
                        int driver_block_part_no, u64 start_lba, u64 sectors) {
    if (!parent_name || parent_idx < 0 || driver_block_part_no < 1 || driver_block_part_no > 99)
        return -1;
    driver_block_device_t *parent = driver_block_get_device(parent_idx);
    if (!parent || !parent->present) return -1;

    char name[BLK_DEV_NAME_LEN];
    strncpy(name, parent_name, sizeof(name) - 8);
    name[sizeof(name) - 8] = 0;
    int len = (int)strlen(name);
    name[len++] = 'p';
    char num[4];
    u64_to_str((u64)driver_block_part_no, num);
    strcpy(name + len, num);

    int existing = driver_block_find_device(name);
    if (existing >= 0) {
        /* BUG-0117 FIX: the old code returned the EXISTING child
         * untouched, so after abdisk / install laid out a NEW partition
         * table the "<parent>pN" device still reported the OLD
         * start_lba/sectors - mkfs then formatted with stale geometry
         * and overran into the neighbouring partition. Refresh the
         * geometry in place instead (same-name calls with identical
         * geometry stay idempotent). */
        driver_block_device_t *ed = driver_block_get_device(existing);
        if (!ed || !ed->present) return -1;
        driver_block_part_child_priv_t *ep =
            (driver_block_part_child_priv_t *)ed->priv;
        if (!ep) return -1;
        ep->parent_idx = parent_idx;
        ep->start_lba  = start_lba;
        ed->sectors    = sectors;
        return existing;
    }

    driver_block_part_child_priv_t *priv =
        (driver_block_part_child_priv_t *)kmalloc(sizeof(driver_block_part_child_priv_t));
    if (!priv) return -1;
    priv->parent_idx = parent_idx;
    priv->start_lba = start_lba;

    driver_block_device_t dev;
    memset(&dev, 0, sizeof(dev));
    strncpy(dev.name, name, BLK_DEV_NAME_LEN - 1);
    dev.type = parent->type;          /* partition inherits the disk class */
    dev.sectors = sectors;
    dev.sector_size = 512;
    dev.present = 1;
    dev.priv = priv;
    int idx = driver_block_register(&dev, &g_part_child_ops);
    if (idx < 0) kfree(priv);
    return idx;
}

/* ---- WP-10d-pre: MBR partition table writer ------------------------
 * Used by abdisk / install to lay out a disk from inside the OS.
 * Sector 0 = 446 bytes code area (left zero here; grub-install fills
 * it with the GRUB boot image), 4 x 16-byte entries, 0xAA55 signature.
 */
int driver_block_part_write_mbr_table(int dev_idx,
                         const u8 types[4], const u32 starts[4],
                         const u32 sectors4[4]) {
    if (dev_idx < 0 || !types || !starts || !sectors4) return -1;
    u8 buf[512];
    memset(buf, 0, sizeof(buf));
    for (int i = 0; i < 4; i++) {
        if (types[i] == 0) continue;
        u8 *e = buf + 446 + i * 16;
        e[0] = 0x00;                       /* not bootable (GRUB manages) */
        e[1] = 0xFE; e[2] = 0xFF; e[3] = 0xFF;
        e[4] = types[i];
        e[5] = 0xFE; e[6] = 0xFF; e[7] = 0xFF;
        u32 start = starts[i], size = sectors4[i];
        memcpy(e + 8, &start, 4);       /* little-endian host */
        memcpy(e + 12, &size, 4);
    }
    buf[510] = 0x55;
    buf[511] = 0xAA;
    return driver_block_write_sectors_raw(dev_idx, 0, 1, buf);
}

/* ---- WP-10d-pre: boot-time partition scan --------------------------
 * Register "<parent>pN" child devices for every partition of every
 * block device (MBR or GPT).  Without this, a single-system install
 * disk (1 partition) has no child devices after a reboot and its
 * system partition cannot be mounted; the A/B scan in ota_ab_update.c only
 * covers the A/B layout.  Idempotent via driver_block_part_register_child().
 */
void driver_block_part_scan_register_all(void) {
    int n = driver_block_num_devices();      /* snapshot: children registered
                                       below are not re-scanned */
    int registered = 0;
    for (int i = 0; i < n; i++) {
        driver_block_device_t *dev = driver_block_get_device(i);
        if (!dev || !dev->present) continue;
        driver_block_part_table_t tbl;
        if (driver_block_part_parse(i, &tbl) != 0) continue;
        for (int p = 0; p < tbl.count && p < PART_MAX_PARTITIONS; p++) {
            if (!tbl.parts[p].present) continue;
            if (driver_block_part_register_child(dev->name, i, p + 1,
                                    tbl.parts[p].start_lba,
                                    tbl.parts[p].sectors) >= 0)
                registered++;
        }
    }
    if (registered > 0) {
        char line[80]; char num[8];
        strcpy(line, "partscan: ");
        u64_to_str((u64)registered, num); strcat(line, num);
        strcat(line, " partition device(s) registered");
        lib_log_info(line);
    }
}

void driver_block_part_print(const driver_block_part_table_t *tbl) {
    if (!tbl) return;
    char line[120]; char n[24];
    const char *tn = (tbl->table_type == PART_TYPE_GPT) ? "GPT" : "MBR";
    strcpy(line, "Partition table ("); strcat(line, tn); strcat(line, "):\n");
    screen_console_puts(line);
    screen_console_puts("  #  Start          Sectors        Type  Name\n");
    for (int i = 0; i < tbl->count; i++) {
        const partition_t *p = &tbl->parts[i];
        if (!p->present) continue;
        strcpy(line, "  "); u64_to_str(i, n); strcat(line, n);
        strcat(line, "  ");
        u64_to_str(p->start_lba, n); int pad = 14 - strlen(n);
        for (int j = 0; j < pad; j++) strcat(line, " ");
        strcat(line, n); strcat(line, "  ");
        u64_to_str(p->sectors, n); pad = 14 - strlen(n);
        for (int j = 0; j < pad; j++) strcat(line, " ");
        strcat(line, n); strcat(line, "  0x");
        u64_to_hex(p->type, n, 2); strcat(line, n);
        strcat(line, "  "); strcat(line, p->name);
        strcat(line, "\n");
        screen_console_puts(line);
    }
}
