<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# dnstest

`dnstest` - DNS record-type self-test (A/AAAA/MX/TXT/NS/SRV live)

Registered in: `net/net_core.c`

Domain: [Networking](index.md#network)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
