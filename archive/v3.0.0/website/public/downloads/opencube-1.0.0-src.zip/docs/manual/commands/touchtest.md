<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# touchtest

`touchtest` - multitouch pipeline self-test (tap/scroll/pinch/swipe)

Registered in: `shell/shell_cmds_chipset.c`

Domain: [Chipset (ACPI/PCI/i2c)](index.md#shell-chipset)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
