<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# i2cset

`i2cset` - write I2C byte (i2cset &lt;bus&gt; &lt;addr&gt; &lt;reg&gt; &lt;val&gt;)

Registered in: `shell/shell_cmds_chipset.c`

Domain: [Chipset (ACPI/PCI/i2c)](index.md#shell-chipset)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
