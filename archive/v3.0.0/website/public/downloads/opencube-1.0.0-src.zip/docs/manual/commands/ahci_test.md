<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# ahci_test

`ahci_test` - WP-10a: AHCI init/ports/read-write test

Registered in: `shell/shell_cmds_disk_test.c`

Domain: [Disk/storage tests](index.md#shell-disk-test)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
