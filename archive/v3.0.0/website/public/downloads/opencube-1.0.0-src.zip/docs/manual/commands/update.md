<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# update

`update` - check + install system update (update [local &lt;pkg&gt; | --local &lt;pkg&gt; | --status])

Registered in: `kernel/main.c`

Domain: [Kernel core commands](index.md#kernel-core)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
