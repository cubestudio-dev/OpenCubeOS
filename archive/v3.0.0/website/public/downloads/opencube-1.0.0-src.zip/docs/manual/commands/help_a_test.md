<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# help_a_test

`help_a_test` - verify help -a A-Z ordering

Registered in: `shell/shell_cmds_power_test.c`

Domain: [Power management tests](index.md#shell-power-test)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
