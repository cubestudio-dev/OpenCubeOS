<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# usb_serial_test

`usb_serial_test` - USB serial TX/RX round

Registered in: `shell/shell_cmds_usb_test.c`

Domain: [USB tests](index.md#shell-usb-test)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
