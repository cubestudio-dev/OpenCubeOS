<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# rtl810x

`rtl810x` - RTL810x NIC status

Registered in: `shell/shell_cmds_nic_test.c`

Domain: [Network interface tests](index.md#shell-nic-test)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
