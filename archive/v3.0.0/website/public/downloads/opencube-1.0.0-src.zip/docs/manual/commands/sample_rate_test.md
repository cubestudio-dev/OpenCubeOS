<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# sample_rate_test

`sample_rate_test` - 44100/48000 rate configuration test

Registered in: `shell/shell_cmds_snd_test.c`

Domain: [Sound tests](index.md#shell-snd-test)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
