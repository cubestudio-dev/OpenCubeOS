<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# ldd

`ldd` - list dynamic dependencies (ldd &lt;program&gt;)

Registered in: `kernel/main.c`

Domain: [Kernel core commands](index.md#kernel-core)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
