<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# ab_partition_test

`ab_partition_test` - A/B 分区发现 + 槽位 + 标志 (WP-10u)

注册于：`shell/shell_cmds_update_test.c`

领域：[OTA 更新测试](index.md#shell-update-test)

完整命令索引：[commands](index.md) - 或在运行中的系统内使用 `help -a` / `help -w`
