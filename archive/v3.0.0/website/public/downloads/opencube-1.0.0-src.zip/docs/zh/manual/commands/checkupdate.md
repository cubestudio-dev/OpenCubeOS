<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: live help -a capture + registration call sites
     + usage strings from the handler sources. -->

# checkupdate

`checkupdate` - 通过 /etc/opencube.conf 检查更新（http/https）

注册于：`kernel/main.c`

领域：[内核核心命令](index.md#kernel-core)

完整命令索引：[commands](index.md) - 或在运行中的系统内输入 `help -a` / `help -w`
