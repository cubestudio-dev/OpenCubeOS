<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: OC_SHELL_CMD call sites + the ush SVC_CMDS /
     built-in tables + usage strings from the handler
     sources. -->

# mv

`mv` - move/rename file (mv &lt;src&gt; &lt;dst&gt;)

Home: L0 recovery shell (`oc>`) - OC_SHELL_CMD in `recovery/shell_cmds_file.c`

Domain: [Files and the editor](index.md#shell-file)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
