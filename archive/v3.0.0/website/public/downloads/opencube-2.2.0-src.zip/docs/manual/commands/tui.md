<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: OC_SHELL_CMD call sites + the ush SVC_CMDS /
     built-in tables + usage strings from the handler
     sources. -->

# tui

`tui` - full-screen TUI main menu (arrows/Tab/Enter/Esc)

Home: L0 recovery shell (`oc>`) - OC_SHELL_CMD in `tui/tui_cmd.c`

Domain: [TUI (terminal UI)](index.md#tui)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
