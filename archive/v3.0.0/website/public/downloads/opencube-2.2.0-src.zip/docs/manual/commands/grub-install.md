<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: OC_SHELL_CMD call sites + the ush SVC_CMDS /
     built-in tables + usage strings from the handler
     sources. -->

# grub-install

`grub-install` - grub-install &lt;dev&gt;

**Usage:** `grub-install &lt;device&gt;  (write the GRUB `

Home: ring-3 service surface - SVC_CMDS row in `l1apps/ush.c`, dispatched through SYS_L1SVC(110) to `services/block/`.

Domain: [ush (ring-3 shell: SVC rows + built-ins)](index.md#ush)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
