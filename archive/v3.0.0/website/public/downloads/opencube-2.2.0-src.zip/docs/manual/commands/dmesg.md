<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: OC_SHELL_CMD call sites + the ush SVC_CMDS /
     built-in tables + usage strings from the handler
     sources. -->

# dmesg

`dmesg` - show the kernel log ring (dmesg [N])

Home: L0 recovery shell (`oc>`) - OC_SHELL_CMD in `recovery/shell_cmds_log.c`

Domain: [Kernel log (klog)](index.md#shell-log)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
