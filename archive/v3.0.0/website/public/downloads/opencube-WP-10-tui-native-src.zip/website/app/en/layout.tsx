// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 cubestudio-dev <cubestudio@qq.com>

import type { Metadata } from "next";
import Chrome from "@/app/_components/Chrome";

export const metadata: Metadata = {
  title: "Open Cube OS - Open-Source x86_64 L0 Kernel",
  description:
    "Open Cube OS: an open-source x86_64 kernel (L0) that can be extended into anything. WP-AUDIT-01 completed an 18-route line-by-line audit (607 findings): all 41 P0 fixes landed (p0fix1 first 20 + p0fix2 remaining 21), and all 94 P1s are now fixed (p1fix1 items 1..31 + p1fix2 items 32..62 + p1fix3 items 63..94: A/B update targets the non-booted slot, OTA integer/stack hardening, constant-time EC scalar mult and modexp, GPT/NVMe/ATA bounds, write-back cache no longer drops data silently, umount / protection, PCI BAR validation, NIC probe/fake-send/descriptor-layout/EOR/reclaim fixes per datasheet, virtio-snd capability parsing, HDA volume actually works, Ctrl+C-cancellable sshd accept, 100 ms scheduler interactive ceiling + kill-ready tid, a real modal vi); p1fix4 fixed the HTTPS E2E mid-handshake disconnect (IP-literal reference identity per RFC 6125, verified end-to-end against a real OpenSSL peer: handshake, GET, body saved, clean close), each verified with QEMU/host/construction-level evidence; WP-10-wp08fix1 shell completion (oc>/ush line editing + 15 tools + the nano/vi editor); four USB controllers, six sound-card families, in-system A/B updates, nine NIC families and four storage drivers; SSH + TLS 1.3 / TLS 1.2 + HTTPS; The first 53 P2 items (WP-10-AUDIT_P2-fix1, BUG-0136..0188) are all fixed: memory / arch / 33 USB / 11 VFS-FAT fixes, plus a found-and-fixed latent 40-byte heap block header defect (payload alignment drift shifted ATA-DMA transfers 8 bytes, breaking the /etc mount); BIOS + UEFI dual boot, all 53 second-batch P2 items (WP-10-AUDIT_P2-fix2, BUG-0189..0241) fixed: fs 12 / net_core 13 / ld_so 4 / ssh 10 / tls 8 / shell 6, plus the four release-chain hardenings (git-describe version, HTTPS E2E two-sided close_notify assertions, INTERFACES.md 176 commands, docs/verification/ made public) and the embed-chain Makefile rules; All 53 third-batch P2 items (WP-10-AUDIT_P2-fix3, BUG-0242..0294) are fixed: shell 6 / mixed 6 / text tools 5 / docs 7 / hygiene 8 / syscall-usermode 7 / sched+sync 6 / RTC-power-timer 5 / crypto 3, plus the kernel #UD root cause surfaced by the G6 evidence run was found and fixed (sys_fork never set the child's rsp0, so the TSS kept the parent's stack top and the two kernel stacks crossed; the fork path now sets rsp0 like the exec path); all 55 fourth-batch P2 items (WP-10-AUDIT_P2-fix4, BUG-0295..0349) are fixed: crypto fail-closed 4 / tar+install+download 6 / A/B boot budget 1 / block layer 9 / ATA-AHCI-NVMe 3 / console-input-PCI locks 10 / NIC 10 / sound+shell+version 12, and the fix3 release ISO was rebuilt AFTER its tag (uname verified WP-10-AUDIT_P2-fix3); 112,589 lines of source, 138 L1 extension interfaces, 46 system calls, 192 shell commands, 41/41 P0 fix tests. WP-10-input_chipset landed the five input+chipset domains (I2C-HID touchpad gestures, PCI/PCIe MMCONFIG+BAR+MSI over xAPIC, ACPI tables+AML+S3/S4/S5+GPE, SMBus block protocol, I2C PIIX4/i801/DesignWare) with 16 new shell commands (Total 192), live-verified 28/28 on BIOS and UEFI by the chipset E2E, plus the full regression 28/28, dhtest 5/5, SSH E2E 5/5, HTTPS E2E 7/7, and the license restored to the verbatim official Apache-2.0 text. WP-10-tui-qa completed a full QA sweep over the unified desktop: the previous session's 22 pending findings re-verified through three channels - 20 confirmed and fixed, 1 false positive withdrawn, 1 documented - including a P1 LSI SCRIPTS buffer overflow, a P1 X509 root-search dangling pointer that crashed modern real certificate chains (re-verified against live chains after the fix), and a P2 serial-TUI input defect where every plain key lagged one behind after any Esc (tui-test 90->93); new assets: a 34-check deep-drive E2E of all five desktop applications x BIOS/UEFI (Files operations through the real VFS, a real nano round-trip, ring-3 ush contained, every control-panel branch, F2 live language switching) and a framebuffer screenshot gate with pixel-verified CJK glyphs, zoomed crops and vision-model readback; all gates green: 0E0W, regression 28/28, TUI E2E 37/37 x2, chinese E2E 21/21 x2, deep-drive 34/34 x2, screenshot 4/4 x2, SSH 5/5, HTTPS 7/7.Apache 2.0.",
  alternates: { canonical: "/OpenCubeOS/en/" },
};

export default function EnLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <>
      {/* set <html lang> during parse (root layout is shared and defaults
          to zh-CN) */}
      <script
        dangerouslySetInnerHTML={{
          __html: `document.documentElement.lang="en"`,
        }}
      />
      <Chrome locale="en">{children}</Chrome>
    </>
  );
}
