#!/bin/bash
# Rewrite batch: force-push out/ as gh-pages branch (root commit)
set -e
OUT=${OC_GHPAGES_OUT:-/home/z/my-project/oc-work/oc-os/website/out}
ORIGIN_URL=$(git -C "${OC_PUBLIC_DIR:-/home/z/my-project/oc-work/oc-os}" config --get remote.origin.url)
echo "ORIGIN_URL=$(echo "$ORIGIN_URL" | sed 's|x-access-token:[^@]*|x-access-token:REDACTED|')"
cd "$OUT"
echo "PWD=$(pwd)"
git init -q -b gh-pages .
# build-local.sh deletes out/ (including any previous .git), so this fresh
# init has no identity — set it explicitly or the commit is authored as
# the sandbox default (Z User <z@container>), which fails repo author checks.
git config user.name "cubestudio-dev"
git config user.email "cubestudio@qq.com"
git add -A
git commit -q -m "website build: WP-10-AUDIT_P2-fix2 (P2 batch 2: all 53 fixes BUG-0189..0241 across fs/net_core/ld_so/ssh/tls/shell + findings 1-4: git-describe version, CLOSE_WAIT close_notify + two-sided HTTPS E2E assertions, INTERFACES.md 176, docs/verification/ public rule + embed-chain make userprogs/userprogs-check), WP-10-AUDIT_P2-fix2 ISO-SRC assets (3-way sha256: iso 83d97ec3, src c76e5d9c), stats 100,230 lines / 176 commands"
git log --oneline -1
echo "--- push gh-pages (force) ---"
git push -f "$ORIGIN_URL" gh-pages 2>&1
