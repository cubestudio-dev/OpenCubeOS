kernel/arch/x86_64/arch_exceptions.o: \
 kernel/arch/x86_64/arch_exceptions.c \
 kernel/arch/x86_64/arch_exceptions.h kernel/arch/x86_64/arch_idt.h \
 /home/z/my-project/archive-repo/oc-os/kernel/types.h \
 /home/z/my-project/archive-repo/oc-os/kernel/lib/lib_string.h \
 /home/z/my-project/archive-repo/oc-os/drivers/display/screen_fb.h \
 /home/z/my-project/archive-repo/oc-os/drivers/display/screen_console.h \
 /home/z/my-project/archive-repo/oc-os/kernel/mem/mem_vmm.h \
 /home/z/my-project/archive-repo/oc-os/kernel/core/core_usermode.h \
 /home/z/my-project/archive-repo/oc-os/kernel/core/core_sched.h \
 /home/z/my-project/archive-repo/oc-os/kernel/core/core_syscall.h \
 /home/z/my-project/archive-repo/oc-os/kernel/core/core_sched.h
kernel/arch/x86_64/arch_exceptions.h:
kernel/arch/x86_64/arch_idt.h:
/home/z/my-project/archive-repo/oc-os/kernel/types.h:
/home/z/my-project/archive-repo/oc-os/kernel/lib/lib_string.h:
/home/z/my-project/archive-repo/oc-os/drivers/display/screen_fb.h:
/home/z/my-project/archive-repo/oc-os/drivers/display/screen_console.h:
/home/z/my-project/archive-repo/oc-os/kernel/mem/mem_vmm.h:
/home/z/my-project/archive-repo/oc-os/kernel/core/core_usermode.h:
/home/z/my-project/archive-repo/oc-os/kernel/core/core_sched.h:
/home/z/my-project/archive-repo/oc-os/kernel/core/core_syscall.h:
/home/z/my-project/archive-repo/oc-os/kernel/core/core_sched.h:
