# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 cubestudio-dev <cubestudio@qq.com>
# Open Cube OS — Known Issues, Design Limitations, and TODOs

# Known Issues (WP-09)

This document lists all known issues, design limitations, and TODOs in
Open Cube OS as of WP-09. Each item has: description, impact, cause,
and plan.

## 1. Previously Unfixed Bugs — ALL FIXED in P7

### 1.1 heaptest hang — FIXED (P7), re-fixed (WP-09-fix1)
- **Root cause**: `kfree` backward coalescing path returned without calling
  `heap_lock_release(irq_flags)`, leaving the heap spinlock locked. The next
  `kmalloc`/`kfree` would spin forever on `heap_lock_acquire`.
- **Fix**: Added `heap_lock_release(irq_flags)` before the `return` in the
  backward coalesce path.
- **WP-09-fix1 (re-review BUG-001, P0)**: The P7 fix only covered the
  backward-coalesce path. Two MORE early-return paths in `kfree` had the
  same lock leak: double-free detection (`magic == HEAP_MAGIC_FREE`) and
  invalid-magic detection. `memtest` (which deliberately double-frees)
  printed PASS and then permanently locked the whole shell. Both paths now
  release the lock before returning.
- **Test**: `heaptest` now completes: "Heap overhead test (100 allocs): ... PASS";
  `memtest` completes AND the shell stays interactive afterwards
  (`memtest` -> `uname -a` answers).

### 1.2 ush pipe race (echo abc | cat) — FIXED (P7)
- **Root cause**: Same as §1.1 — the stuck heap lock caused `fork` to hang
  (fork calls `kmalloc` for page table allocation), which caused the pipe
  timing to be non-deterministic. With the heap lock properly released,
  fork works correctly, and the pipe producer/consumer timing is reliable.
- **Fix**: Same as §1.1 (heap_lock_release fix).
- **Test**: `echo abc | cat` × 10 → 10/10 PASS

### 1.3 heap cross-page coalescing (P2-44) — FIXED (P7)
- **Root cause**: The P6 attempt to add cross-page coalescing failed because
  the heap lock was stuck (same bug as §1.1). With the lock fixed, the
  `g_pool_bases[]` tracking + `in_same_pool()` check now works correctly.
- **Fix**: Added `g_pool_bases[]` to track contiguous pool base addresses.
  `in_same_pool()` checks if two adjacent blocks are in the same contiguous
  pool. Backward and forward coalescing now use `same_page || same_pool`.
- **Test**: `heaptest` (100 allocs + frees with coalescing) completes PASS.

### 1.4 execve BSS handling — FIXED (P6)
- **Fix**: `sys_execve` now maps `memsz > filesz` (BSS pages) by allocating
  + zero-filling extra pages, same as `user_process_create`.

## 2. Design Limitations (With Rationale)

### 2.1 No per-process cwd
- **Description**: The kernel has a single global cwd (`g_cwd` in shell.c).
  All user processes share the same cwd.
- **Impact**: Multiple ush sessions would share the same cwd.
- **Rationale**: Per-process cwd requires a `cwd` field in `user_proc_t`
  and modifying `vfs_resolve` to use the per-process cwd. Planned for WP-09.
- **Workaround**: Use absolute paths in scripts.

### 2.2 VFS is in-memory only (ramfs)
- **Description**: The root filesystem is an in-memory ramfs.
- **Impact**: Files created in ramfs are lost on reboot.
- **Rationale**: The kernel boots from ISO (read-only). A ramfs root allows
  the shell to create temporary files without a disk.

### 2.3 No virtual terminal / TTY layer
- **Description**: No TTY abstraction. `sys_read(0, ...)` reads from the
  keyboard queue directly.
- **Impact**: No job control with Ctrl+Z, no line editing in pipe stdin.
- **Rationale**: A full TTY layer is a significant feature. The current
  direct keyboard→console model is simpler.

### 2.4 No SMP (single-core only)
- **Description**: The kernel uses a single CPU core.
- **Impact**: Only one CPU core is used on multi-core systems.
- **Rationale**: SMP adds significant complexity (per-CPU stacks, IPI, TLB
  shootdown, lock ordering).

### 2.5 No paging to disk (no swap)
- **Description**: Physical memory is allocated from PMM. No swap mechanism.
- **Impact**: If physical memory is exhausted, allocations fail.
- **Rationale**: Swap requires a backing store, paging daemon, and complex
  page-replacement algorithms. Not needed for 256 MiB QEMU.

### 2.6 Network stack is minimal
- **Description**: e1000 + TCP/IP supports DHCP, DNS, ping (ICMP), wget (HTTP
  + HTTPS via TLS 1.2), TCP server (kernel sshd/net_accept), route/arp/
  firewall/tcpstats. No UDP, no TCP keepalive, no window scaling.
- **Impact**: UDP-based services unavailable.
- **Rationale**: Client-focused TCP stack covers wget/HTTPS/DNS/DHCP/SSH.

## 2A. WP-09 Known Issues / Accepted Behaviors (all verified 2026-09-30)

### 2A.1 TLS: kernel does not send close_notify on shutdown — accepted
- **Description**: `tls_close()` issues a plain TCP FIN without a TLS
  close_notify alert. The test server reports
  `unwrap (close_notify): [SSL: UNEXPECTED_EOF_WHILE_READING]`.
- **Impact**: Server-side logs show a benign EOF error; data integrity is
  unaffected (every record is MAC-verified).
- **Plan**: Send close_notify in a future WP-10+ batch.

### 2A.2 TLS: server Finished not cryptographically verified — RESOLVED (re-verified 2026-10-09, WP-10-AUDIT_P2-fix3)
- **Current behavior**: the server's Finished message IS cryptographically
  verified in both supported versions. TLS 1.3: the client derives the
  finished_key from the handshake secret via HKDF-Expand-Label, recomputes
  the HMAC over the transcript (ClientHello..ServerHello) and fails the
  handshake on verify_data mismatch (net/net_tls.c, "server Finished
  verify_data mismatch"). TLS 1.2 fallback: the client recomputes the
  12-byte PRF verify_data over Hash(handshake_messages) and aborts the
  handshake (-6) on mismatch (net/net_tls.c, server CCS + Finished block).
- **History (WP-09 client, 2026-09-30)**: the original TLS 1.2-only client
  read the server's encrypted Finished record without decrypt/verifying
  its verify_data (server-to-client application records were already
  decrypted and MAC-verified). The mainstreamed TLS 1.3/1.2 client
  (WP-09 mainstreaming, 2026-10) removed this gap; the WP-09-era
  rationale ("avoids AES-CBC decrypt for handshake records") no longer
  applies.

### 2A.3 tls.c header comment stale — doc-only
- **Description**: The file header says "Server-side encrypted records ...
  accepted but NOT decrypted", but `tls_recv()` does decrypt + MAC-verify
  application data and alerts.
- **Impact**: Documentation confusion only; behavior is correct.
- **Plan**: Fix the comment in the next code-touching batch.

### 2A.4 TLS/SSH trust model — current state (updated WP-10-AUDIT_P2-fix3, 2026-10-09)
- **TLS (current)**: the client parses and structurally bounds-checks the
  server chain (P0fix2 BUG-0024/0025), checks the validity window via the
  CMOS RTC, and anchors chains against the embedded root store. A hostname
  mismatch for a dNSName reference identity is FATAL (active-impersonation
  signal); an IP-literal target carries no reference identity (RFC 6125)
  and skips the name check; an un-anchored chain (self-signed / private-CA
  servers) prints `[tls] warning: server chain not anchored` and CONTINUES.
  On top of the chain anchor, the TLS 1.3 CertificateVerify signature and
  the server Finished (both versions — see §2A.2) are cryptographically
  verified.
- **SSH (current)**: the server host key signature over the exchange hash
  H is verified BEFORE any key is used (RFC 4253 S8;
  net_ssh_verify_host_signature), anchored by TOFU against
  /etc/ssh_known_hosts ("<ip:port> <fp>" per line; a changed host key
  refuses the connection) plus a per-installation host key (WP-AUDIT-01-p1fix2:
  the embedded universal RSA private key was removed; sshd fails closed
  without a per-installation key; clients persist the first-seen host key).
  Publickey userauth is IMPLEMENTED (RFC 4252): the client signs with the
  per-installation /etc/ssh_client_key (rsa-sha2-256; falls back to
  password when the key is absent) and sshd accepts publickey only for
  keys listed in its /etc/ssh_authorized_keys (publickey refused entirely
  when the file is missing or empty). Still deferred: keepalive, algorithm
  negotiation whitelist.
- **Remaining impact**: an un-anchored TLS chain is accepted with a visible
  warning; SSH is TOFU (first connection is unauthenticated by design).
  MITM is still possible for an attacker present at FIRST contact.

### 2A.5 paramiko test-server direct-mode probe error — test-harness only
- **Description**: `paramiko_sshd.py` probes the channel with an immediate
  `recv()`; the kernel sends nothing before exec, so the probe logs
  `channel error: Socket is closed`.
- **Impact**: None on the kernel; exec data flows via
  `check_channel_exec_request` (verified).

### 2A.6 SSH performance — QEMU DH modexp ~26-30 s
- **Description**: 2048-bit modexp in QEMU TCG takes 26-30 s per operation
  (2 ops per KEX). On real hardware this is orders of magnitude faster.
- **Impact**: Slow SSH connect under emulation only.

### 2A.7 crashlog tick display — cosmetic
- **Description**: Boot-time self-test exceptions show `@tick=0`; earlier
  records noted `@tick=1`. Tick granularity at boot differs.
- **Impact**: Display only; the 3 intentional exceptions (#DE/#UD/#PF)
  themselves are expected and unchanged.

### 2A.8 HTTPS E2E: mid-handshake disconnect after ServerHello —
     FOUND + FIXED (WP-AUDIT-01-p1fix3 verification, 2026-10-07)
- **Symptom**: `wget https://10.0.2.2:8443/` against the reference
  https_test_server.py (TLS 1.2, DHE-RSA-AES128-SHA256, self-signed
  RSA-2048 cert with NO SAN) disconnected ~0.02 s after the ServerHello
  with `TLS failed (code 1)`; the server logged
  `ssl.SSLEOFError: UNEXPECTED_EOF_WHILE_READING` inside its own
  handshake. The earlier attribution ("RSA CertificateVerify modexp cost
  + anchor policy") did not match the timing: the disconnect happened
  long BEFORE any modexp ran.
- **Probes**: TLS_DBG probes on the Certificate receive/parse path showed
  `cert rec: payload=799 ctype=22 mtype=11`, `cert mlen=795`,
  `cert parsed: ncerts=1 used=789 blen=795`, then failure with NO
  `[tls] warning` and NO ServerKeyExchange probe — the failure sat
  inside `crypto_x509_verify_chain`.
- **Root cause**: `wget` passes the URL host verbatim, so the TLS layer
  received the IP literal `10.0.2.2` as the hostname. The WP-09
  mainstream TLS batch (555fe1f) had made `crypto_x509_verify_chain(...,
  c->hostname) != X509_OK -> -4` unconditional; the p1fix3 hotfix
  (43ce437) restored warn-and-continue for un-anchored chains but only
  skipped the name check when the hostname was EMPTY — and a URL host is
  never empty. The SAN-less test cert therefore failed the dNSName match
  and the handshake died with X509_E_HOSTNAME (-7 -> -4) before the
  ServerKeyExchange. Introduced 2026-10-01 (555fe1f), NOT by p1fix3; the
  p1fix3 hotfix fixed the policy but not the caller-side IP-literal case.
- **Fix (this round)**: `net_tls_host_is_ip_literal()` in net/net_tls.c —
  IPv4 dotted-quad / IPv6 literals are stored as an EMPTY hostname
  (RFC 6125: no reference identity), so both the TLS 1.2 and TLS 1.3
  chain checks skip the dNSName comparison; the TLS 1.3 chain policy now
  matches the TLS 1.2 policy (fatal only on dNSName mismatch with a real
  reference identity; un-anchored chains warn and continue).
- **Verified E2E (post-fix)**: full handshake vs the reference server —
  `[tls] warning: server chain not anchored (code 8) - continuing`,
  ServerKeyExchange processed, server side
  `TLS handshake OK: TLSv1.2 cipher=('DHE-RSA-AES128-SHA256', ...)`,
  HTTP request received (`GET / HTTP/1.1 Host: 10.0.2.2`), 108-byte
  response sent, `Saved 24 bytes to /wget_https.html`, clean
  close_notify (alert 01 00) received on the guest. Handshake-to-response
  ~9.4 s (two 1024-bit modexps, see §2A.9).

### 2A.9 TLS DHE handshake cost in QEMU — performance, not a bug
- **Description**: the TLS 1.2 DHE path performs TWO 1024-bit modexps
  (Yc = g^x mod p and Z = Ys^x mod p) per handshake; under QEMU TCG that
  is ~8-9 s of the ~9.4 s handshake-to-response measured in §2A.8
  (1024-bit ≈ 4.0 s per op, 2048-bit ≈ 13.5 s per op on this host).
- **Impact**: slow HTTPS/OTA connect under emulation only; correctness
  is unaffected (every value verified by the MAC / Finished exchange).
- **Plan**: windowed (2^4/2^5) modular exponentiation is future
  optimization work; no protocol change is needed.

### 2A.10 host_bn_ec_test -O2 segfault — test-tooling mistake, not code
- **Symptom**: the host-side bn/EC unit test binary built with plain -O2
  segfaulted (exit 139) BEFORE printing the first test line, while the
  ASAN build of the same sources passed 7/7 — looked like an
  -O2-only code bug in the kernel bignum/EC code.
- **Root cause**: the ad-hoc build line had linked
  `kernel/lib/lib_string.c` (plus tests/host_pmm_stub.c) into the host
  binary. lib_string.c DEFINES glibc's own symbol names
  (memset/memcpy/memmove/memcmp/strlen/strcmp/strncmp/strcpy/strncpy/
  strcat/strchr/strcasecmp); in a freestanding kernel that is correct,
  but linked into a glibc host binary these strong definitions interpose
  libc's own startup-critical symbols and the process dies before main.
  ASAN interceptors mask the interposition, so only the plain -O2 build
  crashed. Reproduced (exit 139) with lib_string.c linked; clean
  (exit 0, ALL PASS) without it — on both the p1fix3 base (a75d280) and
  the current head. No kernel code was involved.
- **Fix**: tests/host_bn_ec_test.c header now documents the canonical
  build line (no lib_string.c) and the interposition warning; the stale
  `-Ikernel kernel/bn.c` path was corrected to the restructured layout.

## 3. TODOs (By Work Package)

### WP-09 (Done — shipped)

Shipped in WP-09: crypto core (AES-128/SHA-256/HMAC/DH modexp/random),
SSH client + server (group14-sha256, aes128-cbc, hmac-sha2-256,
rsa-sha2-256, password auth, session exec), TLS 1.2 client
(DHE-RSA-AES128-CBC-SHA256), HTTPS wget, route/arp/firewall/tcpstats/dns
commands, mprotect syscall test, p3_test user program.

Carried over from the old WP-09 TODO list (NOT done, deferred):
- Per-process cwd
- TTY layer with line editing
- UDP support
- Swap/paging to disk
- SMP support
- Full ext4 write support
- FAT32 LFN write support
- Signal masking (sigprocmask)
- Process groups / sessions
- Async I/O (aio)
- Kernel module loading
- User management (multi-user)
- Permission model (uid/gid)

### WP-10+ (Next)
- TLS: send close_notify on shutdown (§2A.1) — DONE (WP-10-AUDIT_P2-fix2:
  close_notify now sent in ESTABLISHED or CLOSE_WAIT; see §7)
- TLS: verify server Finished (§2A.2) — DONE (mainstreaming; see §2A.2)
- SSH: keepalive, algorithm negotiation whitelist (§2A.4 — publickey
  auth itself is DONE, see §2A.4)
- Code comment refresh: tls.c header (§2A.3)

### Future (Post WP-10)
- Network: FTP client, SFTP
- Graphics: GUI toolkit, window manager
- Audio: sound card driver
- USB: host controller driver
- Multi-core: SMP scheduler
- Virtualization: KVM-like hypervisor

## 4. Known Issues Recorded During the WP-09 Fix Rounds

### 4.1 FAT32 mount point occasionally disappears — **FIXED (WP-AUDIT-01-p0fix1, BUG-0002 / A12-002)**
- **Observed once** during the WP-09 re-review (1 in 4 runs): right after
  `mkfs.fat32 hda` -> `fatmount hda /mnt` -> `ls`/`mounts`/`fatstat`/`sync`,
  a subsequent `write /mnt/big.txt AAAA` failed with `open failed` and
  `ls /mnt` reported `no such path: /mnt`. The same sequence passed in 3
  re-runs. Root cause not located (suspected mount-table/heap race).
  We chose NOT to blind-patch; the issue is recorded here for the next
  investigation round.
- **ROOT CAUSE (WP-AUDIT-01, A12-002)**: `fs_vfs_rmdir`/`fs_vfs_unlink`
  did not refuse mount points, and `fs_ramfs_rmdir` treated a mounted
  FAT32 root (a child of a ramfs directory) as a ramfs node — freeing the
  live FAT32 context through `fs_ramfs_inode_t::data` and detaching the
  mount root while the mount table entry stayed in use. Whether the node
  still had cached children (i.e. whether any file had been listed first)
  decided pass/fail — hence the "1 in 4 runs" non-determinism.
- **Fix (WP-AUDIT-01-p0fix1)**: fs_vfs_rmdir/unlink now reject mount-point
  targets; fs_vfs_umount refuses while nested mounts exist;
  fs_ramfs_rmdir additionally verifies `child->fs_type == ramfs`.
- **Test**: `mount fat32 hda /mnt` -> `rmdir /mnt` -> "rmdir: failed";
  `ls /` still lists `mnt`; `umount /mnt` works; kernel stays alive.

## 5. WP-AUDIT-01-p0fix1 — P0 batch 1 (BUG-0001..BUG-0020) — ALL FIXED

Fixed per the WP-AUDIT-01 audit report (docs/audit/report.md §10.1,
first 20 P0 findings in report order). Each fix: patched code, 0-error
0-warning build, QEMU reproduction (FAIL before / PASS after), and the
WP-09..wp08fix1 regression suite re-run (18/18 userprog set, dhtest 5/5,
cryptotest 3/3, SSH both directions, checkupdate live OTA).

| BUG | Location | Fix |
|---|---|---|
| BUG-0001 | fs/fs_vfs.c mount message | bounds-checked msg[80] construction (was unbounded strcpy chain) |
| BUG-0002 | fs/fs_vfs.c + fs/fs_ramfs.c | rmdir/unlink refuse mount points; umount refuses with nested mounts; ramfs rmdir verifies node ownership (BUG-019 root cause) |
| BUG-0003 | fs/fs_ext4.c mount | reject zero blocks/inodes-per-group + oversized log_block_size (was #DE halt) |
| BUG-0004 | fs/fs_fat32.c | BPB validation (512B sectors, reserved>=1, num_fats>=1, clusters>0) + cluster bounds in read/write paths |
| BUG-0005 | net/net_core.c tcptest | 2×16.6KB connection structs moved off the 16KB boot stack to the heap (audit RUN-01 100% crash) |
| BUG-0006 | kernel/core/core_sched.c | kthread stacks 1 page -> 4 contiguous pages (TX path + IRQ net_poll need ~6-11KB) |
| BUG-0007..0013 | net/net_ssh.c client | packet length capped to the 4096B receive page; banner loop bounded; name-list overflow-safe bounds; negative ks_len/f_len rejected; exchange-hash input bounds-checked; encrypted receive checked before reading |
| BUG-0014..0020 | net/net_sshd.c server | same receive-page cap; negative e_len rejected; name-list bounds; hash-input size pre-check; four-buffer overflow guarded; USERAUTH negative lengths rejected; CHANNEL_OPEN_FAILURE buffer sized to the actual reply (43B) |

Known audit P0s NOT in batch 1 (BUG-0021..BUG-0041) were fixed in
WP-AUDIT-01-p0fix2 (see section 5B below).

## 5B. WP-AUDIT-01-p0fix2 — P0 batch 2 (BUG-0021..BUG-0041) — ALL FIXED

All 21 remaining audit P0s (report.md order) were fixed, compiled
0 errors / 0 warnings (-Wall -Wextra -Werror), and verified: hostile-peer
reproductions (FAIL on the p0fix1 baseline / PASS on the fixed kernel) and
a full regression pass.  Evidence for each fix:

| BUG | Location | Fix |
|---|---|---|
| BUG-0021 | net/net_tls.c https_get | request sized 2048 + total-length check before any write (was req[1024] with unchecked concatenation of a legally 1663-byte OTA redirect path; baseline repro: kernel #GP with rip=0x6161616161616161 after a 302 to a 1300-byte https path) |
| BUG-0022 | net/net_tls.c TLS1.3 record | length check is exactly buf_cap (was buf_cap+256; ASAN heap-buffer-overflow WRITE 16896 into 16640 on baseline) |
| BUG-0023 | net/net_tls.c TLS1.2 record | RFC 5246 max (2^14+2048=18432) as the record buffer bound; all TLS1.2 record buffers sized TLS12_REC_MAX; check is exactly cap (was cap+2080; ASAN WRITE 18720 into 16640) |
| BUG-0024 | net/net_tls.c Certificate | mlen checked against record payload AND body (was payload-only; ASAN global-buffer-overflow past body[12288]) |
| BUG-0025 | net/net_tls.c ServerKeyExchange | mlen was NEVER checked (up to 16MB OOB read + OOB write); now checked against payload and body |
| BUG-0026 | net/net_tls.c DHE SKE | sbuf tail 320 -> 776 (ServerDHParams legally 774B) + copy bounds check (ASAN global-buffer-overflow WRITE 774 into 384 on baseline) |
| BUG-0027 | net/net_tls.c CertVerify | sig_len bounds-checked against the message; DER decode extracted to tls13_decode_ecdsa_sig() with every length/offset checked (rl=255 wrote r-223.. on baseline); host boundary matrix 9/9 |
| BUG-0028 | shell/shell.c glob | no-slash and after-slash pattern copies bounds-checked (token can reach 287B after env/alias expansion vs pat[256]) |
| BUG-0029 | shell/shell_cmds_disk.c fsck | report buffer 80 -> 256 (8 fixed strings + numbers = 154B overflowed unconditionally on every fsck run) |
| BUG-0030 | shell/shell_cmds_file.c mv | 1MiB cap removed; copy is streamed (32KiB window); byte count verified against source size; source unlinked ONLY after a complete copy (baseline repro: 2MiB file arrived as 524288B on FAT32 and the source was gone) |
| BUG-0031 | kernel/core/core_syscall.c sys_poll | nfds > 4096 rejected (nfds*sizeof() wrapped mod 2^64 and passed access_ok, then wrote user VAs unchecked -> ring-0 #PF -> HALT) |
| BUG-0032 | kernel/core/core_usermode.c exit | number buffer 8 -> 24 (u64_to_str emits up to 21 for a user-controlled exit code) |
| BUG-0033 | kernel/core/core_syscall.c sys_execve | argv/envp are captured BEFORE the CR3 switch (old code read user VAs through the kernel CR3 identity window while access_ok validated the NEW as — argv silently lost); the new user stack is written through the new AS page tables (software walk); stack pages zeroed |
| BUG-0034 | kernel/core/core_syscall.c sys_ps | ktab[64] (3584B stack array) -> kmalloc sized to the caller's cap (kthread stacks are small; p0fix1 already grew them to 4 pages, this removes the large-array stack cost itself) |
| BUG-0035 | kernel/crypto/crypto_x509.c | DER length accumulated unsigned with an int-range guard (was signed int, 0x84 FFFFFFFF wrapped to -1 and defeated the range check); ECDSA r/s lengths also reject <= 0 (rlen<=0 bypassed the > hlen check and memcpy'd (size_t)(-1)) |
| BUG-0036 | kernel/lib/lib_config.c write | replace/append paths bounds-checked (were unchecked; a file with hundreds of duplicate keys overflowed the 4096B heap block); duplicate matching keys are collapsed (first one rewritten) |
| BUG-0037 | kernel/ota/ota_update.c autoupdate thread | line2 160 -> 272 ("Changes: " + 255B server-supplied changes + NUL = 265 overflowed by 105B on every auto-check with a long changes field) |
| BUG-0038 | kernel/ota/ota_update.c checkupdate plain | request 256 -> 2048 with a pre-computed length check (path alone can legally be 1663B) |
| BUG-0039 | kernel/ota/ota_ab.c map_package_path | any ".." path component is rejected outright (was passed through and popped by fs_vfs_normalize -> arbitrary VFS write from a hostile update package) |
| BUG-0040 | drivers/block/driver_block_nvme.c | namespaces formatted with a non-512B LBA size are refused with a clear error (block/cache layers are hardwired to 512B; every read was a 3584B heap overflow on 4Kn).  Full 4Kn support is future work |
| BUG-0041 | kernel/arch/x86_64/arch_exceptions.c | nested-#PF guard: a fault while already handling one halts immediately via serial only (was unbounded re-entry, ~0x230B per level, until a triple fault).  tcptest itself verified alive on both the p0fix1 baseline (root cause fixed there) and this build |

Reproduction/verification summary for this batch:
- QEMU end-to-end (hostile peers, p0fix1 baseline FAIL -> fixed PASS):
  BUG-0021 (#GP 0x6161616161616161 kernel HALT -> clean error, kernel alive),
  BUG-0022/0023/0024 (evil TLS server cases: silent overflow accepted ->
  record rejected, kernel alive), BUG-0030 (2MiB mv lost 3/4 of the file and
  deleted the source -> complete 2097152B copy, fsck used=4097 clusters),
  BUG-0038 (long-path checkupdate: same clean behaviour, overflow removed by
  construction), BUG-0041 (tcptest ALL PASS, kernel alive, both builds).
- Host ASAN suite (tests/host_tls_p0_test.c, kernel net_tls.c included
  directly): baseline aborts (heap/global-buffer-overflow per BUG-0022..0026
  + the BUG-0027 demo) vs fixed 16/16 PASS, ASAN silent.
- Code-level proofs: BUG-0028/0029/0031/0032/0033/0034/0035/0036/0037/0039/0040
  (bounds/overflow math is deterministic in the diffs above; for BUG-0031/0032
  no shipped user program issues those exact hostile syscalls, and BUG-0039's
  end-to-end needs an A/B boot chain that could not be completed inside the
  sandbox session).
- Regression on the final WP-AUDIT-01-p0fix2 ISO: boot self-tests all OK;
  user programs hello/exec_test/fork_test/pipe_test/mmap_test/mprotect_test/
  select_test/signal_test/p3_test/badapp(intercepted)/reloc_test PASS;
  heaptest, l1test, crashlog, ps OK; dhtest 5/5; cryptotest 3/3;
  help 3 modes (default A-Z / -w / -a), Total: 172 command registrations
  (unchanged vs the p0fix1 delivery; zero registration changes in this diff);
  DHCP + ping + DNS + real-network checkupdate (TLS 1.3 to GitHub, full JSON
  fetched); NVMe 512B mkfs/mount/write/read OK (BUG-0040 must not regress
  512B); FAT32 mkfs/mount/fsck/write/read/mv OK; SSH evil-client a08
  rejected cleanly; SeaBIOS + OVMF boot verified.

New findings recorded during this batch (NOT part of the 21, tracked for a
future round):
- fsck reports "invalid device" for NVMe device names (works for hda);
  cosmetic, P2-grade.
- BUG-0038's config-set reproduction path is not reachable as documented:
  `config set` values are capped at 255 bytes, so a >255-char URL is
  truncated at the config layer before update_url_parse ever sees it;
  the redirect-based trigger (used above) is the real attack surface.

### 4.2 umount keeps the (empty) mount-point directory — BY DESIGN (BUG-032)
- POSIX `umount` does not remove the mount-point directory either. The
  empty directory left behind (e.g. `/a1`) is the mount point the user
  created, and it is preserved so the volume can be re-mounted without
  re-creating the directory.

### 4.3 SSH/TLS client trust model — superseded (BUG-034)
- The WP-09-era decision "SSH accepts any host key; TLS accepts any
  certificate" no longer holds. See §2A.4 (updated WP-AUDIT-01-p1fix3):
  TLS anchors chains against the embedded root store with fatal hostname
  mismatch for dNSName references and warn-and-continue for un-anchored
  chains; SSH uses a TOFU known_hosts anchor with a per-installation
  host key. The remaining gap (TOFU first contact, un-anchored-chain
  acceptance with warning) is tracked in §2A.4.

### 4.4 ush `df` Size column — PARTIAL (BUG-026)
- The user-space shell cannot read the kernel mount table from ring 3.
  It reports real observed data (files found + summed sizes from
  sys_stat). Directory entries legitimately report size 0, so the
  aggregated "Size" can be 0 on an empty-ish root. The kernel shell's
  `df` shows the full mount table.

## 5. WP-09-fix5 additions (2026-10-02)

### 5.1 FAT32 create of non-8.3 names was impossible — FIXED (WP-09-fix5)
- `fat32_create_entry` ran `fat32_encode_short_name()` BEFORE the LFN
  check, so names that do not fit 8.3 (extension longer than 3 chars,
  e.g. `opencube.conf`, or any lowercase name) were rejected with -1
  before the LFN alias path could run. Reading such files (created by
  mtools/other OSes) worked; creating them in-system did not. The fix
  builds the 8.3 alias directly in the LFN path (`XXXXXX~1`). Verified:
  `config_test` 7/7 (includes delete + recreate of `/etc/opencube.conf`)
  and `touch /etc/longname.txt`.
- Remaining limitation (documented, not fixed here): the generated `~1`
  alias does not de-duplicate against existing aliases; two long names
  with the same first six characters in one directory collide on FAT
  (real FAT drivers add a numeric suffix, that machinery is not ported).

### 5.2 Public-internet TLS endpoints reject the kernel TLS client —
     RESOLVED (superseded by the mainstreamed TLS client; re-verified
     2026-10-09, WP-10-AUDIT_P2-fix3)
- **Current behavior**: the kernel TLS client offers TLS 1.3 (RFC 8446:
  X25519 key share, AES-128/256-GCM + ChaCha20-Poly1305, full HKDF key
  schedule) preferred, with a TLS 1.2 ECDHE_RSA fallback (AES-GCM /
  ChaCha20-Poly1305; legacy DHE-CBC 0x0067 retained for old servers) and
  X.509 chain + SAN dNSName hostname verification against embedded public
  CA roots (handshake fails closed on verification errors). Public
  HTTPS endpoints are verified working end-to-end:
  cubestudio-dev.github.io, google.com, cloudflare.com (README WP-09
  section).
- **History (WP-09-fix5 scope, 2026-10-02)**: the fix5-era client offered
  TLS 1.2 with `DHE-RSA-AES128-SHA256` (1024-bit DH) only, so modern
  public stacks answered the ClientHello with an alert and `checkupdate`
  worked only against servers configured for that cipher
  (tools/update_server.py). DNS + TCP to the default URL succeeded and
  the alert was answered cleanly (no crash, explicit `connect failed`
  message). The mainstreaming batch replaced this client; the limitation
  no longer applies.

## 6. WP-09 mainstreaming additions (2026-10)

### 6.1 Display-layer scroll-edge page fault (pre-existing, exposed by long sessions)
- **Symptom**: kernel #PF (#14, error_code=2, write) at `cr2=0xFD1CF480`,
  rip inside `oc_renderer_default_draw_glyph`, when a command's output
  happens to land on the screen rows near y=592 in a session that has
  scrolled to the bottom. The framebuffer is 800x600x32 (1,920,000 bytes,
  0xFD000000..0xFD1D4C00); the faulting address sits inside the framebuffer
  extent but in an unmapped 4 KiB page (0xFD1CF000).
- **Analysis**: the boot identity-map covers the framebuffer with 2 MiB
  pages, but somewhere between boot and the crashing context the effective
  mapping of that page is lost; the renderer itself bounds-checks
  (xpix/ypix vs width/height) and only reaches row 592 legitimately.
  Root cause is in the AS/page-table layer, not the renderer.
- **Impact**: rare — only hits when output lands on those rows; every
  scripted test that triggers it retried with slightly different output
  geometry passes.
- **Status**: open; workaround for scripted tests is keeping per-command
  output short (tcptest prints a single line). Fix belongs to WP-10+
  (vmm/fb mapping audit).

# Known Issues (rule-9-selfhost batch, 2026-10-03)

## KI-SH-01: nic_rw_test intermittently FAILs on rtl8139 (~1 in 5 runs)
- **Location**: kernel/nic_test_cmds.c (nic_rw_test command) + kernel/nic_rtl8139.c RX path.
- **Symptom**: `[nic_rw_test] nic_send => FAIL (length mismatch)` roughly once in five
  sessions; rtl8139_test itself (link up + TX ARP + RX ARP through the real poll loop)
  passes every run. e1000 sessions unaffected.
- **Repro**: `OC_NETDEV=rtl8139 qemu... nic_rw_test` repeatedly.
- **Status**: OPEN — pre-existing (also present before this batch; the batch did not
  touch any NIC code). Suspected RX ring race between the test's send/recv round-trip
  and the poll cadence. Tracked here per WORKFLOW section 5 item 12; fix is a separate
  batch (rule 3: no drive-by fixes).

## KI-SH-02: abdisk/install write the BIOS boot path only
- **Location**: kernel/disk_setup.c (grub_install_device).
- **Symptom**: UEFI machines cannot boot from an abdisk/install disk without the
  installer ISO (the written boot.img/core.img are GRUB i386-pc BIOS images).
- **Repro**: OC_BOOT_DISK=1 with OVMF instead of SeaBIOS.
- **Status**: OPEN by design for this batch — the ISO itself is BIOS+UEFI bootable and
  documents the path (TRY-IT 4b). A UEFI in-system install needs an ESP + x86_64-efi
  GRUB image; separate batch.

## KI-SH-03: OVMF (UEFI) may boot an attached IDE HDD instead of the CD
- **Location**: OVMF firmware BootOrder, not kernel code.
- **Symptom**: With `-drive if=ide` holding an installed disk, OVMF may ignore `-boot d`
  and try the HDD's GRUB (which then stalls at the menu). Using AHCI attachment
  (`-device ich9-ahci -device ide-hd`) behaves as expected.
- **Status**: OPEN (test-environment quirk, not a kernel bug); ab_partition_test 7/7
  verified under UEFI with AHCI attachment.

## 7. WP-10-AUDIT_P2-fix2 additions (2026-10-08)

- P2 batch 2 (BUG-0189..BUG-0241, items 54..106 of docs/audit/bugs_final.json) — ALL FIXED;
  evidence chains per fix in the release notes + worklog (`WP-10-AUDIT_P2-fix2` entry).
- The remaining OPEN findings are tracked in `docs/audit/bugs_final.json`:
  P2 items 107..214 (BUG-0242..BUG-0349, fix3+ scope) and the P3 items (258).
  Per WORKFLOW §5 item 12, the JSON file is the authoritative per-finding
  tracker (id / sev / loc / desc / src) for everything not yet fixed.
- Accepted behaviors in §2/§2A above are unchanged by fix2; the TLS
  close_notify behavior (§2A.1) is superseded: the client now sends its
  close_notify in ESTABLISHED **or** CLOSE_WAIT (finding #2), verified by
  the raw-byte recorder in the HTTPS E2E gate (tools/https_test_server.py
  observe mode).

## 8. WP-10-AUDIT_P2-fix2b additions (2026-10-09)

- Honest correction of the fix2 embed-chain claim: `make userprogs` on the
  fix2 tree reproduced the reported ERROR verbatim (userprog_libfoo block
  not found, Makefile:257 Error 1) — the fix2 commit's embed-chain Makefile
  rules did not hold; corrected in the fix2b worklog.
- Embed chain repaired: libfoo.c routed through a dedicated solib leg
  (tools/build_solib.py, -Wl,-soname,libfoo.so + DT_SONAME verification,
  regenerates l1/solib_data.h); the six dynamic-link programs (dyn_hello,
  so_test, dlsym_test, pie_test, reloc_test, main_dyn) build as ET_DYN/PIE
  via the pie/pie-foo modes in build_c_userprog.py with hard e_type /
  PT_INTERP gates against silent downgrade; libs/ld_so.c wired into
  USERPROG_SRCS (the ld_so case was dead code); main_dyn embedded and
  mapped in both exec tables (kernel/main.c + core_syscall.c).
- Verified: make userprogs end-to-end EXIT=0; QEMU six dyn progs PASS
  (main_dyn prints "main: foo_add(2,3)=5"); stats 101,150 lines; 176
  commands unchanged.
- History rewrite note: the 22 legacy `Z User <z@container>` commits
  (2026-10-03..10-07) were rewritten to cubestudio-dev via filter-branch;
  the WP-10-AUDIT_P2-fix2 tag now points at the rewritten chain
  (539bbb8c...), the handover tag at 45bcca98..., both on the same history
  as main (fix2b chain head e6e8da0e...).

## 9. WP-10-AUDIT_P2-fix3 additions (2026-10-10)

### 9.1 Kernel #UD after a child exits — ROOT-CAUSED AND FIXED

- Symptom (found during the G6 evidence run, BUG-0274..0280): after a
  child process exits, the kernel takes `#UD` at 0x22CF18 / 0x22D249 /
  0x22D3B8 (all inside the `g_procs[]` region), `cs=0x18` (kernel
  code64), `ss=0x0`, in the T1 tri-generation fork, T4 post-signal exit2
  and T6 collect configurations. The pre-fix baseline showed the same
  defect as a silent T2 freeze (the same stack crossing, corrupting data
  without hitting an invalid opcode).
- Root cause (proven with a QEMU monitor memory dump at the crash):
  `sys_fork` never set the forked child's `task_t.rsp0` (the WP-04
  BUG-029 TSS fix covered only the exec path in user_process_create), so
  the child kept `rsp0 = 0` from the create-time memset.
  `core_sched_switch_to` skips the TSS reload when `next->rsp0 == 0`,
  which left the TSS pointing at the PARENT's kernel-stack top while the
  child ran in ring 3. Every child interrupt pushed its frame onto the
  parent's stack, and a scheduling decision inside that handler saved the
  child's rsp/rip there (observed: child task rsp=0x643EE0 inside the
  parent's 0x63E000..0x644000 stack window). The parent's later `ret`s
  popped child data (pointer-shaped values like `&g_procs[1].fork_rsp`)
  as return addresses. NOT a G6 regression - the G6 unified-exit reaper
  (BUG-0275) made the exit -> wake -> collect chain complete for the
  first time, which is what exposed it.
- Fix: `sys_fork` sets the child task's `rsp0 = stack_base + stack_size`,
  exactly like the exec path (commit 6153593 on fix3-laneA, merged to
  main).
- Verification: g6_test full chain T1..T7 with T1/T4/T6-collect
  un-isolated, 18/18 checks OK (three consecutive runs), no EXCEPTION 6;
  71/71 full regression; SSH E2E 5/5; HTTPS E2E 7/7; 0 errors 0 warnings.

## 10. Audit fix-round (P0 residues + P1 residues + WRONG repairs) additions (2026-10-11)

This round (recreated after a tooling-environment loss; see the commit
message) closes the P0/P1 residues left by the independent fix-verification
round, repairs the four WRONG fixes, and closes the tactical P2 residuals:
ssh/tls/x509 subtraction-form bounds (BUG-0010/0011/0015/0017/0019/0224),
the chain_buf split-loop bound (BUG-0024), the DER `hdr+l` wrap
(BUG-0035), the 512-byte block-layer gate (BUG-0040/0054), the sshd
background host-key thread (NEW-01), the SYN_RCVD recycle reordering
(BUG-0069), TLS 1.3 KeyUpdate application (BUG-0081), the VFS-level
unlink open-fd gate (BUG-0061), the TCP TX cli window (BUG-0063), the
UDP length clamp (BUG-0066), ICMP RX checksum (BUG-0072), CDC-ACM 0xFF
(BUG-0055), empty-capture redirection (BUG-0083), cp-of-empty (BUG-0086),
ata_dma re-entry (BUG-0115), the live-path L1 builtin hook (BUG-0092),
ixgbe TX write-back DD (BUG-0126), the tg3-verified bcm57xx rewrite
(BUG-0128), EHCI speed decode (BUG-0175), igb RX error mask (BUG-0335),
awk off-by-one (BUG-0251), hub speed masks (BUG-0157), xHCI ISO SIA
(BUG-0148), hda spec-encoding shift (BUG-0339), ac97 BDBAR/LVI reprogram
(BUG-0340), SB16 DMA page/mode constants (BUG-0127/0128-snd), bounded IP
fragment reassembly (BUG-0210), net_bind conflict check (BUG-0217),
sys_write2 cli window (BUG-0276), DRBG irq window (BUG-0294), TLS 1.2
truncation fail-closed (BUG-0228), Lucky13 constant-time padding
(BUG-0229), the RFC 8446 DOWNGRD sentinel (BUG-0233), and the stale
crypto_core.h PRNG comment. Regression: 28/28 harness checks, tcptest
ALL PASS incl. synrcvd-recycle, fstest ALL PASS incl. the p1fix4 block,
dhtest 5/5, host KATs (a401 12 vectors, tls13_ks 13 KATs, blk512 13/13)
all PASS, 0 errors 0 warnings.

### 10.1 sshd first-run host-key generation is slow under QEMU TCG (not a hang)

- Symptom: on a fresh /etc volume (no persisted host key), the FIRST
  `sshd` invocation needs the per-installation RSA-2048 host key. Under
  QEMU TCG (no KVM) the Miller-Rabin generation takes a very long time —
  a measured lower bound was >9.5 minutes in this environment; real
  hardware completes it in well under a second.
- What was done (NEW-01): the generation no longer blocks the shell. It
  runs in the background `sshd-hkgen` kernel thread; the `sshd` command
  waits pollably and Ctrl+C cancels the WAIT (return -3, benign) while
  generation continues; a subsequent `sshd` reuses the same wait. The
  shell stays fully usable (verified: ps shows sshd-hkgen READY while
  other commands run).
- Residual behavior to know: on a TCG-slow machine the first key is not
  ready until the background thread finishes, so early `sshd` attempts
  report "generation still running" rather than serving. Persisted keys
  (etc.img with the key material) load instantly on every later boot.

## 11. WP-10-input_chipset additions (2026-10-13)

Honest notes for the five chipset domains (the full contract and the
eleven live-boot defects fixed by the gate are in
docs/EXTENSIONS_WP10-input_chipset.md §4):

### 11.1 SMBus process-call is unsupported by design

- `driver_smbus_process_call()` returns "unsupported": the i801-class
  backend exposes no atomic process-call path, and a decomposed
  word-write + word-read would CORRUPT EEPROM contents (the swap leg is
  not a store on real devices).

### 11.2 No QEMU model for the I2C-HID touchpad or the DesignWare I2C controller

- QEMU ships no I2C-HID device model, so `touchpad` reports the binding
  honestly ("no i2c-hid device bound") and the gesture pipeline is
  proven by `touchtest` + the host regression
  (tests/host_i2chid_touch_test.c) instead of a live device.
- The DesignWare controller has no QEMU model either; its register
  self-test runs when hardware is present and is skipped honestly
  otherwise (`i2ctest`: "DesignWare: not present on this platform
  (honest skip)").

### 11.3 MSI-capable devices report 0 of 6 on legacy QEMU machines

- On the default i440FX machine (no PCIe), `msitest` fires the LAPIC
  self-IPI (PASS) and reports devices without an MSI capability
  honestly ("e1000: no MSI cap or BAR0  SKIP (reported honestly)");
  MSI/MSI-X programming goes through the same code path on
  hardware/machines that expose the capability.

### 11.4 AML "undefined name" boot messages on QEMU's DSDT

- Early boot may print a handful of `AML: undefined name` lines
  (PRQ0/PRQ1/PRQ2/PRQ3/VEND/CSEL/CPEN): QEMU's DSDT references objects
  the minimal AML interpreter does not define. The namespace walk
  continues, ACPI power management works (S5 + S3 packages resolve,
  acpitest PASS); the messages are diagnostic, not failures.

### 11.5 Regression command-count baseline moved 176 -> 192

- The batch added 16 shell commands (additions only; the interface
  freeze holds); the regression command-count baseline and the two-way
  `help -a` check now expect 192.

## 12. WP-10-timer_rtc additions (2026-10-13)

### 12.1 HPET legacy route pauses the system tick

- This kernel drives the two 8259 PICs only (no IO-APIC redirections),
  so HPET timer interrupts reach the CPU only through the LEG_RT
  legacy route (timer 1 -> ISA IRQ8; timer 0 is never enabled because
  it would collide with the PIT on IRQ0).  While the legacy route is
  armed (the one-shot / periodic tests, max ~1.5 s per test), QEMU
  disconnects the PIT from IRQ0, so the 100 Hz system tick and every
  soft timer stall for the duration.  All HPET tests restore the boot
  state unconditionally; the `stats` tick counter resumes right after.

### 12.2 PM timer effective width is 24-bit on this platform

- QEMU 10.0 masks the PM timer read to `d & 0xffffff` (24-bit, the
  ACPI 1.0 / PIIX4 convention; Linux uses the same ACPI_PM_MASK).
  The FADT still says 32-bit (`pm_tmr_len = 4`).  Deltas are masked to
  24 bits by default (correct on both widths for windows < 4.67 s);
  real TMR_VAL_EXT hardware can set `pmtimer.width=32` in
  /etc/opencube.conf.  The wrap period is 4.67 s (24-bit), not the
  ~20 min a naive 32-bit reading suggests.

### 12.3 CMOS RTC century register is surfaced, not wired

- The WP-09 reader (`kernel/core/core_rtc.c`) reads CMOS index 0x48
  with a 2000+year fallback; the FADT century register (0x32 on QEMU)
  is now reported by `rtc` status but is not wired into that reader.
  Years decode as 2000+year when the 0x48 snapshot is not a plausible
  century - correct on QEMU and most real hardware through 2099.

### 12.4 TSC under TCG is a virtual clock

- CPUID 0x80000007.EDX[8] (Invariant TSC) reports 0 under QEMU TCG -
  honest, not a bug: the TSC tracks the virtual clock there and its
  measured frequency (~3.2 GHz) is not the host TSC.  Calibration and
  the TSC-driven delay are self-consistent (delay 100 ms measures
  100 ms against the PIT); on real hardware the TSC is the host TSC.

### 12.5 QEMU's HPET table block_id encodes a nonsense comparator count

- SeaBIOS/QEMU bake block_id 0x8086a201 into the HPET table whose
  comparator field (bits 15:8) decodes as 163 - nonsense.  The live
  GCAP register (3 timers) is authoritative; `hpet` prints both the
  table fields and the live caps so the discrepancy is visible.

### 12.6 Regression command-count baseline moved 192 -> 196

- The batch added 4 shell commands (rtc/hpet/pmtimer/tsc; additions
  only, interface freeze holds); the regression baseline and the
  two-way `help -a` check now expect 196.

## 13. WP-10-wireless_bluetooth additions (2026-10-13)

### 13.1 Wireless families: datasheet-level verification, no QEMU model
QEMU has no 802.11 device model (nothing to attach).  The seven family
drivers are verified at code-vs-datasheet level: byte-exact fixtures
through the production parsers/builders (in-kernel `wifi test`,
tests/host_wifi_test.c 38/38) and live enumeration paths (PCI/USB/SDIO
scans report honest not-present).  Vendor firmware blobs are NOT
shipped (third-party property); without one, `fw_load` fails honestly
and the device stays DOWN.  This is the work-package test matrix's
"datasheet 对照" row, not a hidden stub: every parser/builder/descriptor
format is real code with spec citations.

### 13.2 Bluetooth HCI-USB transport: no QEMU model
QEMU removed the whole bluetooth stack (incl. usb-bt-dongle and `-bt`)
in 7.1; the toolchain's qemu 10.0.13 rejects `-bt` and lists no bt
device.  The btusb class driver registers on the live USB stack
(interface class 0xE0/1/1) and the HCI-USB framing shares the HCI core
paths, but no dongle can be attached in QEMU - `bt usb` reports
"no dongle attached" honestly.  The UART transport IS exercised
end-to-end on real emulated 16550 hardware (COM2, IRQ3) against a
host-side H4 peer.

### 13.3 QEMU 16550 has no receive-timeout interrupt
The 16550 spec's RX timeout (needed to drain a partially-filled FIFO
below the trigger level) is not implemented by QEMU's serial device.
The H4 driver therefore uses RX trigger level 1 (IRQ per byte) and a
single-consumer ring (the IRQ handler); a poll-time direct FIFO drain
would race the IRQ consumer (classic 16550 check-then-read stale-byte
bug) and is deliberately absent.

### 13.4 Real defects found and fixed by this batch's own E2E loop
The Bluetooth E2E against the host-side peer caught and fixed: HCI
async commands completing on the wrong event type + one-field-off
event parameter offsets (opcode/status/handle/bdaddr); HCI ACL frames
and L2CAP data frames emitted as TWO H4/ACL packets each (type/header
split); an L2CAP CFG_REQ 4-byte payload buffer for 8 bytes of data
(compiler-caught); the RFCOMM UIH information-field offset read one
byte late (3+lbytes -> 2+lbytes); the C/R bit gating UIH data
delivery; the SDP attribute-list walker using a wrong element layout
and stride; non-zeroed selftest fixture buffers (iwlwifi ucode);
WL_MAX_DEVICES too small for seven families (4 -> 8); and the shell
`wp` tag field 24 bytes being one byte short for the batch name
(help -w group silently dropped into the fallback bucket).

### 13.5 SDIO bus state on QEMU
`sdhci-pci` exists in QEMU, so the SDHCI bring-up (reset/caps/clock/
probe) runs against real emulated hardware.  With no card attached the
CMD5/CMD0 probes time out and the state is honestly `empty`; the
brcmfmac-SDIO client therefore reports not-present.  Attaching an
SD-card image exercises the SD-memory leg of the probe (CMD8/ACMD41).

# Known Issues (WP-10-camera_misc, 2026-10-14)

## 14. Hardware-model honesty for the five new domains

### 14.1 UVC cameras: no camera model in QEMU — fixture-verified
QEMU ships no USB video device, so `uvc` reports `camera subsystem:
0 cameras` honestly.  The UVC 1.1 descriptor parser, the Probe/Commit
control logic and the baseline JPEG decoder run against byte-exact
spec fixtures in `uvctest` (30/30) and host-side (`host_camera_test`
30/30 at -Os); a real camera attaches through the existing USB stack
enumeration without further code.  Impact: none for correctness; the
live-stream path awaits real hardware.  Plan: none required.

### 14.2 CIR infrared: no QEMU model — ACPI-probed, honestly absent
QEMU models neither an ACPI CIR device (PNP0510/ITE8713-style) nor an
IR LED, so the CIR probe finds nothing and `ir` reports no CIR front
end.  The protocol codecs (NEC/RC-5/RC-6/SIRC) are byte-exact round
trip tested (`irtest` 14/14, `host_ir_test` 21/21).  Impact: none.
Plan: none required.

### 14.3 SIR infrared: loopback-verified on the emulated 16550
The SIR front end binds the secondary 16550 (COM2-style) with a
loopback-confirmed probe, so encode -> send -> recv runs against real
emulated UART hardware.  Impact: none.  Plan: none required.

### 14.4 Game port: no QEMU model — probed, honestly absent
QEMU models no game port at 0x200/0x201, so `gameport` reports no
adapter and `gameporttest` skips the live steps after passing the
pure-function checks.  Impact: none.  Plan: none required.

### 14.5 SCSI: LSI 53C895A verified end-to-end, QEMU async timing
`-device lsi` + `scsi-hd` runs the full stack: INQUIRY, READ CAPACITY,
a WRITE(10)/READ(10) round trip on the last sector (content saved and
restored) and LBA 0 through both the blk layer and raw SCSI
(`scsitest` 17/17, `host_scsi_test` 49/49).  Real media I/O uses the
chip's asynchronous disconnect/reselect protocol (SAVE DATA POINTER +
DISCONNECT -> WAIT for the reselect -> data phase), driven through
SIEN0.RSL + SCID.RRE soft enables with a polled reselect notice.
Two honest notes: (1) the polled execution model matches the kernel's
AHCI/NVMe precedent — a future interrupt-driven backend can reuse the
scsi_complete() callback; (2) QEMU's lsi model does not implement
target-driven SDTR/WDTR sync negotiation state save/restore, so the
driver keeps async 8-bit transfers (SXFER=0), which the model and the
real chip both accept.

### 14.6 Regression baseline note
The regression script's command-count check moved 198 -> 208 with this
batch (uvc/uvctest/parallel/paralleltest/gameport/gameporttest/ir/
irtest/scsi/scsitest registered; additions only, nothing removed).

## 15. WP-10-tui pre-fix audit notes (2026-10-15)

### 15.1 P3 findings remain unremediated (258 items)
WP-AUDIT-01 produced 607 findings: P0=41, P1=94, P2=214 (all three
tiers fixed and verified through BUG-0136..0349) and **P3=258
(BUG-0350..0607) which are NOT fixed and were NOT previously tracked
in this file**.  They stay machine-readable in
`docs/audit/bugs_final.json` (field `sev == "P3"`); the densest files
are net_core.c (10), userprogs/ush.c (9), core_syscall.c (9),
driver_usb.c (7), main.c (6), driver_block_ahci.c (6).  A P3 finding
is by definition a low-severity issue (style, robustness hardening,
minor resource waste) — none of the 258 is known to be user-visible
today, but that claim is honest only as an audit-time statement.  Any
batch that touches a file carrying P3 items is expected to fix the
touched-file P3s opportunistically and record them here.

### 15.2 Block LRU write-back cache is intentionally off the fs path
Every filesystem backend reads and writes through
`driver_block_*_sectors_raw` (fs_fat32.c, fs_exfat.c, fs_ext4.c), so
the blk-layer LRU write-back cache (driver_block_cache.c) is exercised
only by tests (g8test, block test commands).  This is deliberate:
`_raw` never touches cached copies, and the production writers that
bypass fs entirely (part table writes, disk_setup boot code, OTA A/B
installs) also write via `_raw`, so "everything raw" is the only
combination with zero stale-cache windows.  Wiring fs onto the cache
would require invalidating cached slots on every `_raw` write
(including the writers above) — tracked as a future enhancement, not
a bug.  The filesystems are not slower because of it in any measured
workload: the fs layers carry their own metadata caches (full FAT
table, VFS node cache).

### 15.3 fork copies the whole address space; 32 task slots
fork() walks the parent page tables and memcpy()s every user page
(core_usermode.c; no COW — VMM_FLAG_COW exists as a flag but has no
write-trap handler).  MAX_TASKS=32 (core_sched.h) bounds all tasks
including kernel threads; the 29 embedded user programs cannot all
run concurrently and an exhausted table fails gracefully (-1).  Both
facts are documented API semantics (EXTENSIONS_WP03.md tid range);
listed here because WP-AUDIT-01 P3 flagged the memory cost.  A COW
implementation needs PMM refcounts and a #PF write branch and is
planned as its own work package, not a drive-by fix.

### 15.4 virtio-snd volume: no ctl-element support, honest failure
The virtio-snd driver implements the PCM subset (0x0100..0x0105)
only.  Device volume would need the optional control-element
protocol (VIRTIO_SND_R_CTL_* 0x0200), and QEMU ships no virtio-snd
model, so that path cannot be developed or verified against anything.
driver_snd_virtio_ops_set_volume() now returns -1 (device absent or
volume unsupported) instead of the previous fake success; the
framework refuses to book the value and the `volume` command reports
the failure.  SB16 (mixer registers, read-back verified) and UAC1
(Feature Unit SET_CUR) drivers do drive real hardware volume.

### 15.5 TLS handshake: one unreproduced intermittent failure (2026-10-15)
During the WP-10-tui session-2 HTTPS E2E loop, one boot failed with
`TLS failed (code 1)` right after the server's ServerKeyExchange
record (the server then logged its own UNEXPECTED_EOF, i.e. the
kernel hung up first).  The same boot with TLS_DBG=1 completes the
whole handshake, and five further TLS_DBG=0 runs pass end to end
(7/7 each).  net_tls.c is comment-only changed since the camera_misc
release where the gate last passed, and wget over plain HTTP on the
same build/IP works, so the receive path and e1000/slirp are fine.
Recorded as an unreproduced, timing-sensitive observation instead of
a regression; if it reproduces, the suspect area is the poll-loop
handoff between net_poll() record reads and the handshake state
machine (single-CPU TCG timing).

### 15.6 S3 suspend: wake needs the platform wake source; QEMU procedure (2026-10-17)
**fix3 status: the suspend entry points are HIDDEN per user decision**
(`suspend` and `suspend_test` shell commands removed, the S3 entry in
the EN/CN TUI power pages removed).  The kernel-side implementation
stays intact: `core_power_suspend()`, its L1 wrapper and the fix2
resume chain are still compiled in, so the feature can be re-exposed
in a later batch without rework.  `sleep <sec>` is NOT suspend - it is
the BUG-0346 delay command and remains available.

`suspend` performs a real ACPI S3 (FACS waking vector + the fix2
real-mode trampoline).  Like every S3 machine, the box STAYS asleep
until a wake event arrives - on QEMU that is the monitor command
`system_wakeup` (sendkey/power-button also work), on real hardware the
power button.  This is the platform contract, not a hang: the screen
freezes at "Entering S3 (suspend to RAM)..." until the wake event.
Verified end to end on QEMU 10.0.13 TCG and QEMU 8.1.5 TCG
(suspend -> system_wakeup -> "Resumed from S3." -> the network answers
ping again).  fix2 root cause for the record: the pre-fix2 trampoline
was 32-bit flat code, but SeaBIOS delivers the waking vector through
farcall16big in 16-bit big real mode, so every resume crashed inside
the trampoline before the kernel ever ran again; the trampoline is
16/32/64-bit three-stage now and re-arms PIT (without wiping the
soft-timer table), PCI command registers, the legacy e1000 register
file and the UART RX path after resume.  Block-device class drivers
(AHCI/NVMe/virtio-blk) get their PCI command registers restored but no
per-device register replay yet - a disk that was mid-transfer at
suspend time needs a remount; recorded here instead of being silently
unsupported.

### 15.7 QEMU virtual RTC keeps host time after a guest write (2026-10-18)
**fix4 finding.** The `tui-time` "Set clock" page performs a real
MC146818 write sequence (RegB SET guard, BCD conversion, 24-hour
mode kept, and a readback INSIDE the SET window which proves the
CMOS registers took the values). On real hardware the clock then
counts from the new value. Under QEMU (10.0.13 TCG, default -rtc
mode) the virtual device re-derives the time registers from host
time once SET clears, so a `rtc` command afterwards still shows
host time. This is an emulator limitation, not a driver one; the
driver path is verified by the in-window readback. Workaround for
simulations: `qemu-system-x86_64 -rtc base=<ISO time>`.

### 15.8 TUI form status line can be overwritten by a later repaint (2026-10-18)
After submitting the time-set form the confirmation status message
("CMOS registers written...") can be blanked by a subsequent full
window refresh on some key sequences. The write itself is verified
(RegB honors the 24h bit after a write, see 15.7); only the
transient status toast is affected. Follow-up candidate for the
next batch: route the post-submit toast through the panel stack.

### 15.9 Byte tearing when blasting multi-byte input into the emulated UART (2026-10-18)
Automated E2E tooling that writes several bytes in one os.write to
the COM1 pipe can observe dropped bytes and nibble-swapped data
(0x35 arriving as 0x53) under TCG, because the guest drains the
16550 FIFO slower than the host writes. Real keyboards never send
bytes that way and real UARTs throttle at the baud rate, so this
is an emulation artifact, not a kernel bug. The E2E harness sends
byte-at-a-time with small delays (qsession.send_slow) to match
real input pacing. Relevant only to test automation.

### 15.10 Wireless: no in-kernel RX feeder (2026-10-19, WP-10-tui-qa)
The 802.11 core's RX state machine (wl_rx_frame -> beacon cache /
auth/assoc chain / LLC-SNAP decap ring) is complete and host-tested
(tests/host_wifi_test.c, 38/38), but no family driver currently has
an RX interrupt path that calls wl_rx_frame() - the ops table
(wl_family_ops_t) never grew an rx slot, and QEMU has no 802.11
model to exercise one against. wl_connect() therefore stays honestly
in WL_STATE_AUTHENTICATING (it never claims ASSOCIATED without a real
Authentication Response). Writing four families' hardware RX rings
with no radio to validate against would be speculation, so the gap is
recorded here instead of papered over: the kernel-side twin (L1
wl_rx_frame consumers) and the host test suite are the real coverage
today; family RX ISRs are L1-territory work for real hardware.
Related (same audit): wifi scan reports "0 networks (no beacons -
no radio present)" - honest, not a defect.

### 15.11 Classic TUI pages still English under zh (2026-10-19, WP-10-tui-qa)
shell.lang == zh now drives the desktop chrome, the five desktop apps
and (new this batch) the three full classic apps - System Info,
Wireless and Hardware - through the revived Chinese twins
(tui_hw_app()/tui_net_app()/tui_sysinfo_app()). Remaining
English-only surfaces under zh: the per-page direct entries of the
control-panel Hardware menu (`tui-hw PCI` style access has no twin),
and the Time (`tui-time`) / System Settings (`tui-sys`) / Extension
lab (`tui-ext`) classic pages (~200 strings). These are honest
coverage gaps recorded for the next language batch, not silent
failures.

### 15.12 E2E long-session key loss in the QEMU 16550 model (2026-10-21, WP-10-tui-native)
The full-journey E2E suites (tools/wp10_native_e2e.py) boot once and
drive 36 checks through a single serial console session. After the
serial TUI backend's ~590 B/s polled TX flood has been running for a
while, the QEMU 16550 model starts dropping host->guest key bytes
(verified by a temporary in-kernel DBG tracing keycodes and RX bytes
- the DBG code was removed afterwards): exactly 5 of 36 checks fail
in that window, identically on BIOS and UEFI boots (31/36 both) -
Files delete-cancel readback, Editor ascii cat readback, Editor CJK
cat readback, ush cat CJK, and the zh terminal banner check. All
five pass when re-run in isolated fresh-QEMU sessions
(tools/wp10_native_manual.py, 6/6 PASS including the full editor
round-trip), so the kernel key path, TUI input queue and all five
applications are functionally intact - this is a host emulation
limit of one very long session, not a kernel defect. Key-level
transcripts plus the isolated re-run appendix are archived as
evidence/e2e-bios-transcript.log and evidence/e2e-uefi-transcript.log
in the WP-10-tui-native delivery. Related to 15.9 (same 16550 model,
opposite direction: 15.9 is guest RX losing burst host writes; this
one is host->guest key loss under sustained guest TX flood).

### 15.13 #DF panic path: no core dump / crashlog entry (2026-10-21, WP-11-crash_recovery)
The double-fault (#DF) panic path prints the banner, the KERNEL STACK
OVERFLOW attribution and the task name, and applies the policy (HALT
or REBOOT) entirely at exception-dispatcher depth - which is
empirically 100% reliable (3/3 stable QEMU runs + E2E S12). It does
NOT attempt core_dump_save / crashlog_record / the register dump /
the traceback. Reason, found during three bring-up rounds: by the
time a #DF fires, the faulting task's stack is destroyed (guard page
below, return addresses overwritten) and the exception frame itself
can carry garbage (observed rsp=0xFFFFFFFFFFFFF040, garbage int/err
slots); every deeper continuation (a fresh IST1 stack window, the
crashlog RTC chain, the dump's VFS/heap writes, even the -Os serial
printer) re-faulted in that context and cascaded into nested-panic
halts with half-printed banners. The accepted shape therefore uses
only the primitives proven at that depth (ser_puts since WP-02,
lib_string assembly). Impact: a stack-overflow crash still
intercepts, attributes (task name), and stops the machine cleanly -
but leaves no /var/crash/core.dump and no crashlog entry for that
one source. Every other panic source (manual panic, #UD, #PF,
assert, watchdog) saves + persists the dump and records + flushes
the log (E2E S5/S6/S7/S8/S9/S10/S11).
