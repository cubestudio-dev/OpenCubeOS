<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: OC_SHELL_CMD call sites + the ush SVC_CMDS /
     built-in tables + usage strings from the handler
     sources. -->

# install

`install` - ring-3 half of the v2.2.0 `install` command

**Usage:** `install &lt;device&gt;  (install the running `

Domain: [Other](index.md#other)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
