<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- GENERATED page (tools/gen_api_docs.py --pages). Data
     sources: OC_SHELL_CMD call sites + the ush SVC_CMDS /
     built-in tables + usage strings from the handler
     sources. -->

# history

`history` - show command history

Home: ush built-in - streq dispatch in `src/L1/ush/main.c` (runs entirely in ring 3).

Domain: [ush (ring-3 shell: SVC rows + built-ins)](index.md#ush)

Full command index: [commands](index.md) - or `help -a` /
`help -w` inside a running system.
