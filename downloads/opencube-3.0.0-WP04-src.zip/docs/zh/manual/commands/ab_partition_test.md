<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- 由 tools/gen_api_docs.py --pages-zh 生成。数据源与英文页一致：
     OC_SHELL_CMD 注册点 + ush 的 SVC_CMDS/内建表 +
     处理函数源码中的 usage 字符串。命令帮助文本保留系统
     原文（英文）。 -->

# ab_partition_test

`ab_partition_test` - ring-3 half of the v2.2.0 `ab_partition_test` command

领域：[其他](index.md#other)

完整命令索引：[commands](index.md) —— 或在运行中的系统内输入 `help -a` / `help -w`。
