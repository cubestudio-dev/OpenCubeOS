<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- Copyright 2026 cubestudio-dev <cubestudio@qq.com> -->

# WP-10-AUDIT P0/P1/P2 acceptance — per-item code evidence (349 items)

Generated from `git show` of each item's mapped fix commit. `BEFORE` = the
removed/context lines of the fix hunk (the buggy state), `AFTER` = the added/context
lines (the fixed state). Truncated at 1200 bytes per hunk; see the commit for the
full diff. Items whose fix is documentation-only carry the doc-commit stat line.

## BUG-0001 (P0, p0fix1) — commit 0ce616a
- Location: fs_vfs.c:329-336
- Issue: 栈缓冲区溢出
- BEFORE hunk:
```
     fs_vfs_invoke_hook(VFS_HOOK_MOUNT, norm);
 
     {
         char msg[80];
-        strcpy(msg, "vfs: mounted ");
-        strcpy(msg + strlen(msg), fs_type);
-        strcpy(msg + strlen(msg), " at ");
-        strcpy(msg + strlen(msg), norm);
-        strcpy(msg + strlen(msg), "\n");
         screen_console_puts(msg);
     }
     return 0;
```
- AFTER hunk:
```
     fs_vfs_invoke_hook(VFS_HOOK_MOUNT, norm);
 
     {
+        /* P0fix1 BUG-0001 (A12-001): the mount message used to be built
+         * with unbounded strcpy() into msg[80] while "vfs: mounted " +
+         * fs_type(<=15) + " at " + norm(<=255) + "\n" can reach ~289
+         * bytes -> stack overflow. Build the message with explicit
+         * bounds and truncate the (display-only) path instead. */
         char msg[80];
+        int flen = (int)strlen(fs_type);
+        int nlen = (int)strlen(norm);
+        if (flen > 15) flen = 15;
+        int max_norm = (int)sizeof(msg) - 1 - 13 - flen - 4 - 1;
+        if (max_norm < 0) max_norm = 0;
+        if (nlen > max_norm) nlen = max_norm;
+        int mp = 0;
+        memcpy(msg + mp, "vfs: mounted ", 13); mp += 13;
+        memcpy(msg + mp, fs_type, flen); mp += flen;
+        memcpy(msg + mp, " at ", 4); mp += 4;
+        memcpy(msg + mp, norm, nlen); mp += nlen;
+        msg[mp++] = '\n';
+        msg[mp] = 0;
         screen_console_puts(msg);
     }
     return 0;
```

## BUG-0002 (P0, p0fix1) — commit 0ce616a
- Location: fs_ramfs.c:177-192
- Issue: （配合 fs_vfs.c:799-819、fs_vfs.c:303-324）  rmdir/umount 跨文件系统误释放挂载根 —— BUG-019 根因
- BEFORE hunk:
```
     if (!child) return -2;
     if (child->type != VFS_TYPE_DIR) return -3;
     if (child->first_child) return -4;  /* not empty */
     fs_vfs_detach_child(child);
     fs_ramfs_inode_t *ri = (fs_ramfs_inode_t *)child->private;
     if (ri) {
```
- AFTER hunk:
```
     if (!child) return -2;
     if (child->type != VFS_TYPE_DIR) return -3;
     if (child->first_child) return -4;  /* not empty */
+    /* P0fix1 BUG-0002 (A12-002): a mount point hanging under a ramfs
+     * directory is NOT a ramfs node -- its ->private belongs to the
+     * mounted filesystem (e.g. a fs_fat32_inode_t whose first member is
+     * a live context pointer). Treating it as fs_ramfs_inode_t here
+     * kfree()s a live context and detaches the mounted root while the
+     * mount table entry stays in use -> KNOWN_ISSUES BUG-019 "mount
+     * point occasionally disappears" + later UAF. */
+    if (child->fs_type != &g_ramfs_fs_type) return -5;  /* not ours */
     fs_vfs_detach_child(child);
     fs_ramfs_inode_t *ri = (fs_ramfs_inode_t *)child->private;
     if (ri) {
```

## BUG-0003 (P0, p0fix1) — commit 0ce616a
- Location: fs_ext4.c:703、fs_ext4.c:279
- Issue: mount 时除零 panic
- Manual HEAD verification: fs_ext4.c:773-774 s_blocks_per_group==0 拒绝挂载（grep 实证）
- BEFORE hunk:
```
         kfree(ctx);
         return NULL;
     }
     ctx->block_size = (u32)1024 << sb.s_log_block_size;
     ctx->inodes_count = sb.s_inodes_count;
     ctx->blocks_count = sb.s_blocks_count_lo;
```
- AFTER hunk:
```
         kfree(ctx);
         return NULL;
     }
+    /* P0fix1 BUG-0003 (A12-003): blocks_per_group / inodes_per_group come
+     * straight off the disk and are used as divisors below (and at the
+     * inode lookup). A crafted/corrupted volume with a zero value caused
+     * a #DE divide error that halted the kernel during `mount`. */
+    if (sb.s_blocks_per_group == 0 || sb.s_inodes_per_group == 0) {
+        screen_console_puts("ext4: invalid superblock (zero group size)\n");
+        kfree(ctx);
+        return NULL;
+    }
+    if (sb.s_log_block_size > 6) {
+        screen_console_puts("ext4: invalid block size\n");
+        kfree(ctx);
+        return NULL;
+    }
     ctx->block_size = (u32)1024 << sb.s_log_block_size;
     ctx->inodes_count = sb.s_inodes_count;
     ctx->blocks_count = sb.s_blocks_count_lo;
```

## BUG-0004 (P0, p0fix1) — commit 0ce616a
- Location: fs_fat32.c:189-194
- Issue: 、262-267、211-224、1295-1296、1268-1273   簇号/保留扇区/扇区大小无校验 → 越出卷边界写盘 / 覆写引导扇区
- BEFORE hunk:
```
 }
 
 /* Read a whole cluster into buf (must be bytes_per_cluster bytes). */
 static int fs_fat32_read_cluster(fs_fat32_ctx_t *ctx, u32 cluster, u8 *buf) {
-    if (cluster < 2) return -1;
     u64 lba = (u64)ctx->data_start_lba + (u64)(cluster - 2) * (u64)ctx->sectors_per_cluster;
     return driver_block_read_sectors_raw(ctx->dev_idx, lba,
                                 (u32)ctx->sectors_per_cluster, buf);
```
- AFTER hunk:
```
 }
 
 /* Read a whole cluster into buf (must be bytes_per_cluster bytes). */
+/* P0fix1 BUG-0004 (A12-004): cluster numbers come off disk (FAT chains,
+ * directory entries). Anything >= total_clusters + 2 maps to an LBA outside
+ * the volume and read/write would corrupt the neighbouring area. */
+static int fs_fat32_cluster_valid(const fs_fat32_ctx_t *ctx, u32 cluster) {
+    if (cluster < 2) return 0;
+    if (cluster >= (u64)ctx->total_clusters + 2) return 0;   /* outside the volume */
+    return 1;
+}
+
 static int fs_fat32_read_cluster(fs_fat32_ctx_t *ctx, u32 cluster, u8 *buf) {
+    if (!fs_fat32_cluster_valid(ctx, cluster)) return -1;
     u64 lba = (u64)ctx->data_start_lba + (u64)(cluster - 2) * (u64)ctx->sectors_per_cluster;
     return driver_block_read_sectors_raw(ctx->dev_idx, lba,
                                 (u32)ctx->sectors_per_cluster, buf);
```

## BUG-0005 (P0, p0fix1) — commit 0ce616a
- Location: net_core.c:5020-5035
- Issue: 内核栈溢出（确定性内存破坏）
- BEFORE hunk:
```
      * Live-path option negotiation is additionally covered by the HTTPS E2E
      * run (wget https://... over TLS needs the same SYN option set). */
     /* 1) OUR SYN option block: MSS + WScale + SACK-Permitted + Timestamps */
-    net_tcp_conn_t tmp;
-    memset(&tmp, 0, sizeof(tmp));
-    tmp.mss = 1460;
-    tmp.win_scale_sent = 7;
     u8 opts[32];
-    int n = net_tcp_build_syn_options(&tmp, opts);
     int ok_syn = (n == 24 &&
                   opts[0] == TCP_OPT_MSS && opts[1] == 4 &&
                   opts[5] == TCP_OPT_WSCALE && opts[6] == 3 &&
```
- AFTER hunk:
```
      * Live-path option negotiation is additionally covered by the HTTPS E2E
      * run (wget https://... over TLS needs the same SYN option set). */
     /* 1) OUR SYN option block: MSS + WScale + SACK-Permitted + Timestamps */
+    /* P0fix1 BUG-0005 (A13-1): net_tcp_conn_t is ~16.6KB (rx_buf[8192] +
+     * rtx_buf[4096] + ooo_data...). Two of them on the stack (~33KB)
+     * overflowed the 16KB boot stack the shell runs on -> deterministic
+     * page-table/heap corruption (#PF after the command, audit RUN-01,
+     * 100% reproducible). They are only used as option-block scratch, so
+     * allocate them from the heap (static placement would also push the
+     * kernel image past the 0x400000 identity window). */
+    net_tcp_conn_t *tmp = (net_tcp_conn_t *)kmalloc(sizeof(net_tcp_conn_t));
+    if (!tmp) { screen_console_puts("tcptest: alloc failed\n"); return 1; }
+    memset(tmp, 0, sizeof(*tmp));
+    tmp->mss = 1460;
+    tmp->win_scale_sent = 7;
     u8 opts[32];
+    int n = net_tcp_build_syn_options(tmp, opts);
     int ok_syn = (n == 24 &&
                   opts[0] == TCP_OPT_MSS && opts[1] == 4 &&
                   opts[5] == TCP_OPT_WSCALE && opts[6] == 3 &&
```

## BUG-0006 (P0, p0fix1) — commit 0ce616a
- Location: net_core.c:1685
- Issue: +1232+868+1995（发送路径三层嵌套 1.5KB 栈缓冲）vs core_sched.c:257-264（kthread 栈 4KB）  4KB 内核线程栈必然溢出
- BEFORE hunk:
```
      * Live-path option negotiation is additionally covered by the HTTPS E2E
      * run (wget https://... over TLS needs the same SYN option set). */
     /* 1) OUR SYN option block: MSS + WScale + SACK-Permitted + Timestamps */
-    net_tcp_conn_t tmp;
-    memset(&tmp, 0, sizeof(tmp));
-    tmp.mss = 1460;
-    tmp.win_scale_sent = 7;
     u8 opts[32];
-    int n = net_tcp_build_syn_options(&tmp, opts);
     int ok_syn = (n == 24 &&
                   opts[0] == TCP_OPT_MSS && opts[1] == 4 &&
                   opts[5] == TCP_OPT_WSCALE && opts[6] == 3 &&
```
- AFTER hunk:
```
      * Live-path option negotiation is additionally covered by the HTTPS E2E
      * run (wget https://... over TLS needs the same SYN option set). */
     /* 1) OUR SYN option block: MSS + WScale + SACK-Permitted + Timestamps */
+    /* P0fix1 BUG-0005 (A13-1): net_tcp_conn_t is ~16.6KB (rx_buf[8192] +
+     * rtx_buf[4096] + ooo_data...). Two of them on the stack (~33KB)
+     * overflowed the 16KB boot stack the shell runs on -> deterministic
+     * page-table/heap corruption (#PF after the command, audit RUN-01,
+     * 100% reproducible). They are only used as option-block scratch, so
+     * allocate them from the heap (static placement would also push the
+     * kernel image past the 0x400000 identity window). */
+    net_tcp_conn_t *tmp = (net_tcp_conn_t *)kmalloc(sizeof(net_tcp_conn_t));
+    if (!tmp) { screen_console_puts("tcptest: alloc failed\n"); return 1; }
+    memset(tmp, 0, sizeof(*tmp));
+    tmp->mss = 1460;
+    tmp->win_scale_sent = 7;
     u8 opts[32];
+    int n = net_tcp_build_syn_options(tmp, opts);
     int ok_syn = (n == 24 &&
                   opts[0] == TCP_OPT_MSS && opts[1] == 4 &&
                   opts[5] == TCP_OPT_WSCALE && opts[6] == 3 &&
```

## BUG-0007 (P0, p0fix1) — commit 0ce616a
- Location: net/net_ssh.c:131-148
- Issue: 长度字段驱动的物理页溢出（SSH 客户端，预认证）
- BEFORE hunk:
```
     }
     int pkt_len = ((int)len_buf[0] << 24) | ((int)len_buf[1] << 16) |
                   ((int)len_buf[2] << 8) | len_buf[3];
-    if (pkt_len < 1 || pkt_len > 35000) return -1;
 
     u8 *body = (u8 *)(uintptr_t)mem_pmm_alloc_frame();
     if (!body) return -1;
```
- AFTER hunk:
```
     }
     int pkt_len = ((int)len_buf[0] << 24) | ((int)len_buf[1] << 16) |
                   ((int)len_buf[2] << 8) | len_buf[3];
+    /* P0fix1 BUG-0007 (A14-01): the body is ONE 4096B page frame; the old
+     * limit of 35000 let a hostile peer write ~31KB past it (pre-auth).
+     * Everything the client legitimately receives (KEXINIT, keys,
+     * interactive channel data) fits well below this bound. */
+    if (pkt_len < 1 || pkt_len > 3500) return -1;
 
     u8 *body = (u8 *)(uintptr_t)mem_pmm_alloc_frame();
     if (!body) return -1;
```

## BUG-0008 (P0, p0fix1) — commit 0ce616a
- Location: net/net_ssh.c:180-191
- Issue: server_banner[64] 溢出（SSH 客户端，预认证）
- BEFORE hunk:
```
 static int net_ssh_recv_version(net_ssh_ctx_t *ctx) {
     int n = 0;
     u64 start = core_timer_ticks();
-    while (n < 256) {
         int r = net_recv(ctx->net_tcp_sock, ctx->server_banner + n, 1);
         if (r > 0) {
             n++;
```
- AFTER hunk:
```
 static int net_ssh_recv_version(net_ssh_ctx_t *ctx) {
     int n = 0;
     u64 start = core_timer_ticks();
+    /* P0fix1 BUG-0008 (A14-02): the loop used to allow 256 bytes into
+     * server_banner[64] -> 192 bytes of struct overwrite with no CRLF
+     * needed (pre-auth). Stop at the buffer size and reject. */
+    while (n < (int)sizeof(ctx->server_banner) - 1) {
         int r = net_recv(ctx->net_tcp_sock, ctx->server_banner + n, 1);
         if (r > 0) {
             n++;
```

## BUG-0009 (P0, p0fix1) — commit 0ce616a
- Location: net/net_ssh.c:283-292
- Issue: （配合 202-212）  KEXINIT name-list 长度整数溢出 → OOB 读循环（SSH 客户端，预认证）
- BEFORE hunk:
```
             int L = ((int)payload[q] << 24) | ((int)payload[q+1] << 16) |
                     ((int)payload[q+2] << 8) | payload[q+3];
             q += 4;
-            if (L < 0 || q + L > payload_len) { lens[li] = 0; lists[li] = ""; continue; }
             lists[li] = (const char *)(payload + q);
             lens[li] = L;
             q += L;
```
- AFTER hunk:
```
             int L = ((int)payload[q] << 24) | ((int)payload[q+1] << 16) |
                     ((int)payload[q+2] << 8) | payload[q+3];
             q += 4;
+            /* P0fix1 BUG-0009 (A14-03): `q + L` overflows for L near 2^31,
+             * so the bound check passed and name_has() walked gigabytes of
+             * address space. Subtract instead of add (no overflow). */
+            if (L < 0 || L > payload_len - q) { lens[li] = 0; lists[li] = ""; continue; }
             lists[li] = (const char *)(payload + q);
             lens[li] = L;
             q += L;
```

## BUG-0010 (P0, p0fix1) — commit 0ce616a
- Location: net/net_ssh.c:338-345
- Issue: curve25519 路径 KEX_ECDH_REPLY 的 ks_len 负值 → 巨型 memcpy（SSH 客户端，预认证）
- BEFORE hunk:
```
     int ks_len = (payload[off] << 24) | (payload[off+1] << 16) |
                  (payload[off+2] << 8) | payload[off+3];
     off += 4;
-    if (off + ks_len > payload_len) return -3;
     if (ks_len <= (int)sizeof(ctx->server_host_key)) {
         memcpy(ctx->server_host_key, payload + off, ks_len);
         ctx->server_host_key_len = ks_len;
```
- AFTER hunk:
```
     int ks_len = (payload[off] << 24) | (payload[off+1] << 16) |
                  (payload[off+2] << 8) | payload[off+3];
     off += 4;
+    /* P0fix1 BUG-0010 (A14-04): a negative ks_len passed both checks and
+     * reached memcpy with a huge size_t length. */
+    if (ks_len < 0 || off + ks_len > payload_len) return -3;
     if (ks_len <= (int)sizeof(ctx->server_host_key)) {
         memcpy(ctx->server_host_key, payload + off, ks_len);
         ctx->server_host_key_len = ks_len;
```

## BUG-0011 (P0, p0fix1) — commit 0ce616a
- Location: net/net_ssh.c:428-464
- Issue: group14 路径 KEXDH_REPLY 的 ks_len/f_len 负值 → 野指针巨型 memcpy（SSH 客户端，预认证）
- BEFORE hunk:
```
     if (off + 4 > payload_len) return -3;
     int ks_len = (payload[off] << 24) | (payload[off+1] << 16) | (payload[off+2] << 8) | payload[off+3];
     off += 4;
-    if (off + ks_len > payload_len) return -3;
     /* WP-09 fix: save K_S (server host key blob) for exchange hash H.
      * Without K_S in the hash, all derived keys are wrong. */
     if (ks_len <= (int)sizeof(ctx->server_host_key)) {
```
- AFTER hunk:
```
     if (off + 4 > payload_len) return -3;
     int ks_len = (payload[off] << 24) | (payload[off+1] << 16) | (payload[off+2] << 8) | payload[off+3];
     off += 4;
+    /* P0fix1 BUG-0011 (A14-05): reject negative lengths before they are
+     * used as (negated) memcpy sizes / buffer offsets. */
+    if (ks_len < 0 || off + ks_len > payload_len) return -3;
     /* WP-09 fix: save K_S (server host key blob) for exchange hash H.
      * Without K_S in the hash, all derived keys are wrong. */
     if (ks_len <= (int)sizeof(ctx->server_host_key)) {
```

## BUG-0012 (P0, p0fix1) — commit 0ce616a
- Location: net/net_ssh.c:576-628
- Issue: 交换哈希 H 输入溢出 4096B 物理页（SSH 客户端，预认证）
- BEFORE hunk:
```
 
 /* Compute exchange hash H = SHA-256(V_C || V_S || I_C || I_S || K_S || e || f || K).
  * V_C/V_S/I_C/I_S/K_S are length-prefixed strings, e/f/K are mpints
- * (e/f as 32-byte strings for curve25519 per RFC 8731). */
-static void net_ssh_compute_hash(net_ssh_ctx_t *ctx, u8 hash[32]) {
     /* Build hash input: strings (length-prefixed) + mpints */
     /* Use a page frame (4KB) since this can be large */
     u8 *buf = (u8 *)(uintptr_t)mem_pmm_alloc_frame();
-    if (!buf) return;
     int p = 0;
     /* V_C: client version banner (without \r\n) */
     int vlen = (int)strlen(ctx->client_banner);
     buf[p++] = (u8)(vlen >> 24); buf[p++] = (u8)(vlen >> 16);
     buf[p++] = (u8)(vlen >> 8); buf[p++] = (u8)(vlen & 0xFF);
     for (int i = 0; ctx->client_banner[i]; i++) buf[p++] = ctx->client_banner[i];
     /* V_S: server version banner */
     vlen = (int)strlen(ctx->server_banner);
     buf[p++] = (u8)(vlen >> 24); buf[p++] = (u8)(vlen >> 16);
     buf[p++] = (u8)(vlen >> 8); buf[p++] = (u8)(vlen & 0xFF);
     for (int i = 0; ctx->server_banner[i]; i++) buf[p++] = ctx->server_banner[i];
     /* I_C: client KEXINIT payload (msg_type + payload, excluding padding_length + padding)
```
- AFTER hunk:
```
 
 /* Compute exchange hash H = SHA-256(V_C || V_S || I_C || I_S || K_S || e || f || K).
  * V_C/V_S/I_C/I_S/K_S are length-prefixed strings, e/f/K are mpints
+ * (e/f as 32-byte strings for curve25519 per RFC 8731).
+ * P0fix1 BUG-0012 (A14-06): every append is now bounds-checked against the
+ * 4096B page; the old code blindly concatenated (V_C+V_S+I_C+I_S alone can
+ * reach ~5.2KB) and wrote past the page. Returns 0 or -1 on overflow. */
+static int net_ssh_compute_hash(net_ssh_ctx_t *ctx, u8 hash[32]) {
     /* Build hash input: strings (length-prefixed) + mpints */
     /* Use a page frame (4KB) since this can be large */
     u8 *buf = (u8 *)(uintptr_t)mem_pmm_alloc_frame();
+    if (!buf) return -1;
+    const int cap = 4096;
     int p = 0;
+    /* helper: room for `need` more bytes? */
+#define OC_HASH_ROOM(need) ((cap - p) >= (need))
     /* V_C: client version banner (without \r\n) */
     int vlen = (int)strlen(ctx->client_banner);
+    if (!OC_HASH_ROOM(4 + vlen)) goto overflow;
     buf[p++] = (u8)(vlen >> 24); buf[p++] = (u8)(vlen >> 16);
     buf[p++] = (u8)(vlen >> 8); buf[p++] = (u8)(vlen & 0xFF);
     for (int i = 0; ctx->client_banner[i]; i++) buf[p++] = ctx->c
```

## BUG-0013 (P0, p0fix1) — commit 0ce616a
- Location: net/net_ssh.c:1179-1235
- Issue: 加密收包 rest_buf/dec_rest 溢出（SSH 客户端，NEWKEYS 后）
- BEFORE hunk:
```
     }
     int packet_length = ((int)dec_first[0] << 24) | ((int)dec_first[1] << 16) |
                         ((int)dec_first[2] << 8) | dec_first[3];
-    if (packet_length < 1 || packet_length > 35000) {
         net_ssh_debug("[ssh] invalid packet_length in encrypted packet");
         return -1;
     }
```
- AFTER hunk:
```
     }
     int packet_length = ((int)dec_first[0] << 24) | ((int)dec_first[1] << 16) |
                         ((int)dec_first[2] << 8) | dec_first[3];
+    /* P0fix1 BUG-0013 (A14-07): the old limit of 35000 exceeds every buffer
+     * used below (rest_buf/dec_rest/body/mac_input are all 16384B). Cap the
+     * packet at what the receive page can hold (matching the plaintext
+     * path) and validate before any byte is received. */
+    if (packet_length < 1 || packet_length > 3500) {
         net_ssh_debug("[ssh] invalid packet_length in encrypted packet");
         return -1;
     }
```

## BUG-0014 (P0, p0fix1) — commit 0ce616a
- Location: net/net_sshd.c:170-196
- Issue: 未认证收包 35000 字节读入 4096B 页（sshd，监听端口，预认证）
- BEFORE hunk:
```
     }
     int pkt_len = ((int)len_buf[0] << 24) | ((int)len_buf[1] << 16) |
                   ((int)len_buf[2] << 8) | len_buf[3];
-    if (pkt_len < 1 || pkt_len > 35000) {
         char b[64]; strcpy(b, "recv_unenc: bad pkt_len=");
         char n2[10]; u64_to_str((u64)pkt_len, n2); strcat(b, n2);
         net_sshd_log(b);
```
- AFTER hunk:
```
     }
     int pkt_len = ((int)len_buf[0] << 24) | ((int)len_buf[1] << 16) |
                   ((int)len_buf[2] << 8) | len_buf[3];
+    /* P0fix1 BUG-0014 (A14-08): the body is ONE 4096B page frame; the old
+     * limit of 35000 let ANY pre-auth network client write ~31KB past it. */
+    if (pkt_len < 1 || pkt_len > 3500) {
         char b[64]; strcpy(b, "recv_unenc: bad pkt_len=");
         char n2[10]; u64_to_str((u64)pkt_len, n2); strcat(b, n2);
         net_sshd_log(b);
```

## BUG-0015 (P0, p0fix1) — commit 0ce616a
- Location: net/net_sshd.c:1099-1111
- Issue: KEXDH_INIT e_len 负值 → 野指针巨型 memcpy（sshd，预认证）
- BEFORE hunk:
```
         if (e_len != 32) return -7;
         memcpy(ctx->client_pub + SSHD_DH_BYTES - 32, payload + 4, 32);
     } else {
         const u8 *ed = payload + 4;
         int el = e_len;
         if (el > 0 && ed[0] == 0) { ed++; el--; }
         if (el > SSHD_DH_BYTES) { ed += (el - SSHD_DH_BYTES); el = SSHD_DH_BYTES; }
         memcpy(ctx->client_pub + (SSHD_DH_BYTES - el), ed, el);
```
- AFTER hunk:
```
         if (e_len != 32) return -7;
         memcpy(ctx->client_pub + SSHD_DH_BYTES - 32, payload + 4, 32);
     } else {
+        /* P0fix1 BUG-0015 (A14-09): a negative e_len skipped both clamps
+         * and made `SSHD_DH_BYTES - el` a wild offset with a huge memcpy
+         * length. Also bound `el` by the actual payload size. */
         const u8 *ed = payload + 4;
         int el = e_len;
+        if (el < 0) return -7;
+        if (4 + el > plen) return -7;   /* declared e extends past payload */
         if (el > 0 && ed[0] == 0) { ed++; el--; }
         if (el > SSHD_DH_BYTES) { ed += (el - SSHD_DH_BYTES); el = SSHD_DH_BYTES; }
         memcpy(ctx->client_pub + (SSHD_DH_BYTES - el), ed, el);
```

## BUG-0016 (P0, p0fix1) — commit 0ce616a
- Location: net/net_sshd.c:643-654
- Issue: KEXINIT name-list q+L 溢出 → 野地址读（sshd，预认证）
- BEFORE hunk:
```
             if (q + 4 > plen) break;
             int L = (int)net_sshd_read_u32(payload + q);
             q += 4;
-            if (L < 0 || q + L > plen) break;
             ptrs[li] = payload + q;
             lens[li] = L;
             q += L;
```
- AFTER hunk:
```
             if (q + 4 > plen) break;
             int L = (int)net_sshd_read_u32(payload + q);
             q += 4;
+            /* P0fix1 BUG-0016 (A14-10): `q + L` overflowed for L near 2^31
+             * and left a negative q -> wild-address reads on the next
+             * iteration and in name_has(). Subtract instead of add. */
+            if (L < 0 || L > plen - q) break;
             ptrs[li] = payload + q;
             lens[li] = L;
             q += L;
```

## BUG-0017 (P0, p0fix1) — commit 0ce616a
- Location: net/net_sshd.c:484-518
- Issue: 交换哈希 H 输入溢出 4096B 页（sshd，预认证）
- BEFORE hunk:
```
 
 /* ---------- exchange hash ---------- */
 
-static void net_sshd_compute_hash(net_sshd_ctx_t *ctx, u8 hash[32]) {
     u8 *buf = (u8 *)(uintptr_t)mem_pmm_alloc_frame();
-    if (!buf) return;
     int p = 0;
     /* client = V_C (cookie in I_C etc); we are V_S */
     net_sshd_write_cstr(buf, &p, ctx->client_banner);
```
- AFTER hunk:
```
 
 /* ---------- exchange hash ---------- */
 
+/* P0fix1 BUG-0017 (A14-11): compute the exact worst-case input size BEFORE
+ * writing. client_kexinit_len can be ~4096 on its own (pre-auth), and the
+ * old code concatenated everything into one 4096B page with no checks
+ * (banner + kexinits + K_S + mpints ~5.5KB -> ~1.4KB past the page).
+ * Returns 0, or -1 when the input does not fit (caller aborts the session). */
+static int net_sshd_compute_hash(net_sshd_ctx_t *ctx, u8 hash[32]) {
+    const int cap = 4096;
+    int need = 0;
+    need += 4 + (int)strlen(ctx->client_banner);
+    need += 4 + (int)strlen(ctx->server_banner);
+    need += 4 + ctx->client_kexinit_len;
+    need += 4 + ctx->server_kexinit_len;
+    need += 4 + 276;                       /* K_S block (<= 400B, max 276 used) */
+    if (ctx->kex_curve25519)
+        need += (4 + 32) + (4 + 32) + (4 + 1 + SSHD_DH_BYTES);
+    else
+        need += 3 * (4 + 1 + SSHD_DH_BYTES);
+    if (need > cap) return -1;
+
     u8 *buf = (u8 *)(uintptr_t)mem_pmm_alloc_frame();
+    if (!buf) return -1;
     int p = 0;
     /* client = V_C (cookie in I_C etc); we are V_S */
     net_sshd_write_cstr(buf, &p, ctx->client_banner);
```

## BUG-0018 (P0, p0fix1) — commit 0ce616a
- Location: net/net_sshd.c:310-373
- Issue: 加密收包 rest_buf/dec_rest/body/mac_input 四重溢出（sshd，KEX 后、认证前）
- BEFORE hunk:
```
         char n2[12]; u64_to_str((u64)packet_length, n2); strcat(b, n2);
         net_sshd_log(b);
     }
-    if (packet_length < 1 || packet_length > 35000) {
         char b[64]; strcpy(b, "recv: bad packet_length=");
         char n[10]; u64_to_str((u64)packet_length, n); strcat(b, n);
         net_sshd_log(b);
```
- AFTER hunk:
```
         char n2[12]; u64_to_str((u64)packet_length, n2); strcat(b, n2);
         net_sshd_log(b);
     }
+    if (packet_length < 1 || packet_length > 3500) {
         char b[64]; strcpy(b, "recv: bad packet_length=");
         char n[10]; u64_to_str((u64)packet_length, n); strcat(b, n);
         net_sshd_log(b);
```

## BUG-0019 (P0, p0fix1) — commit 0ce616a
- Location: net/net_sshd.c:838-841
- Issue: 与 965-969   USERAUTH 负长度 → 巨型 memcpy（sshd，凭证校验之前）
- BEFORE hunk:
```
     int off = 0;
     if (off + 4 > plen) return -1;
     int ulen = (int)net_sshd_read_u32(payload + off); off += 4;
-    if (off + ulen > plen) return -1;
     memcpy(ctx->auth_user, payload + off, ulen < 31 ? ulen : 31);
     ctx->auth_user[ulen < 31 ? ulen : 31] = 0;
     off += ulen;
```
- AFTER hunk:
```
     int off = 0;
     if (off + 4 > plen) return -1;
     int ulen = (int)net_sshd_read_u32(payload + off); off += 4;
+    /* P0fix1 BUG-0019 (A14-13): a negative ulen passed `off + ulen > plen`
+     * and reached memcpy with a huge size_t length -- pre-password, so any
+     * unauthenticated client could crash the sshd. */
+    if (ulen < 0 || off + ulen > plen) return -1;
     memcpy(ctx->auth_user, payload + off, ulen < 31 ? ulen : 31);
     ctx->auth_user[ulen < 31 ? ulen : 31] = 0;
     off += ulen;
```

## BUG-0020 (P0, p0fix1) — commit 0ce616a
- Location: net/net_sshd.c:1178-1185
- Issue: CHANNEL_OPEN_FAILURE 的 fail[16] 栈溢出（sshd，认证后；默认凭证 oc/oc）
- BEFORE hunk:
```
                 ctx->channel_open = 1;
                 net_sshd_log("session channel open (CONFIRMATION sent)");
             } else {
-                u8 fail[16];
                 int fp = 0;
                 u32 rc4 = 3;  /* ADMIN_PROHIBITED */
                 fail[fp++] = (u8)(rc4 >> 24); fail[fp++] = (u8)(rc4 >> 16);
```
- AFTER hunk:
```
                 ctx->channel_open = 1;
                 net_sshd_log("session channel open (CONFIRMATION sent)");
             } else {
+                /* P0fix1 BUG-0020 (A14-14): the failure reply is 4 (reason)
+                 * + 4+31 (message string) + 4 (lang tag) = 43 bytes, but the
+                 * buffer was u8 fail[16] -> 27-byte stack overflow that
+                 * clobbered the serve_connection frame. Size it for the
+                 * actual reply. */
+                u8 fail[64];
                 int fp = 0;
                 u32 rc4 = 3;  /* ADMIN_PROHIBITED */
                 fail[fp++] = (u8)(rc4 >> 24); fail[fp++] = (u8)(rc4 >> 16);
```

## BUG-0021 (P0, p0fix2) — commit 9a06017
- Location: net/net_tls.c:1352-1362
- Issue: https_get req[1024] 栈溢出（OTA 路径，远端内容驱动，4KB kthread 栈上）
- BEFORE hunk:
```
                   void *out_buf, int out_len) {
     if (net_tls_connect(ip, port, hostname) != 0) return -1;
     net_tls_ctx_t *c = net_tls_get_ctx();
-    char req[1024];
     int rl = 0;
     memcpy(req + rl, "GET ", 4); rl += 4;
-    memcpy(req + rl, path, strlen(path)); rl += (int)strlen(path);
     memcpy(req + rl, " HTTP/1.1\r\nHost: ", 17); rl += 17;
-    memcpy(req + rl, hostname, strlen(hostname)); rl += (int)strlen(hostname);
     memcpy(req + rl, "\r\nConnection: close\r\n\r\n", 25); rl += 25;
     if (net_tls_send(c, req, rl) < 0) {
         net_tls_close(c);
```
- AFTER hunk:
```
                   void *out_buf, int out_len) {
     if (net_tls_connect(ip, port, hostname) != 0) return -1;
     net_tls_ctx_t *c = net_tls_get_ctx();
+    /* P0fix2 BUG-0021 (A14-15): the request was built by unchecked
+     * concatenation into req[1024] while the OTA layer legally passes a
+     * 1663-byte CDN redirect path — path(1300)+host(100) alone overflowed
+     * by ~420 bytes.  Sized for the legal maximum (4+1663+17+127+25+1 =
+     * 1837) and the total length is now checked before any write. */
+    char req[2048];
+    int plen = (int)strlen(path);
+    int hlen = (int)strlen(hostname);
+    if (4 + plen + 17 + hlen + 25 + 1 > (int)sizeof(req)) {
+        net_tls_close(c);
+        return -1;
+    }
     int rl = 0;
     memcpy(req + rl, "GET ", 4); rl += 4;
+    memcpy(req + rl, path, plen); rl += plen;
     memcpy(req + rl, " HTTP/1.1\r\nHost: ", 17); rl += 17;
+    memcpy(req + rl, hostname, hlen); rl += hlen;
     memcpy(req + rl, "\r\nConnection: close\r\n\r\n", 25); rl += 25;
     if (net_tls_send(c, req, rl) < 0) {
         net_tls_close(c);
```

## BUG-0022 (P0, p0fix2) — commit 9a06017
- Location: net/net_tls.c:152-158
- Issue: TLS1.3 记录长度检查比缓冲大 256 → 溢出（预认证，握手期明文记录即可）
- BEFORE hunk:
```
     if (net_tcp_read_exact(c->net_tcp_sock, hdr, 5) < 0) return -1;
     int type = hdr[0];
     int len = ((int)hdr[3] << 8) | hdr[4];
-    if (len < 0 || len > buf_cap + 256) return -1;
     if (net_tcp_read_exact(c->net_tcp_sock, buf, len) < 0) return -1;
 
     if ((!c->hs_keys_active && !c->app_keys_active) || type != CT_APPDATA) {
```
- AFTER hunk:
```
     if (net_tcp_read_exact(c->net_tcp_sock, hdr, 5) < 0) return -1;
     int type = hdr[0];
     int len = ((int)hdr[3] << 8) | hdr[4];
+    /* P0fix2 BUG-0022 (A14-16): the old check allowed buf_cap+256, reading
+     * up to 256 bytes past the caller's buffer (g_hsrec is a 16640-byte
+     * heap block).  RFC 8446 max record = 2^14+256 = 16640 = buf_cap. */
+    if (len < 0 || len > buf_cap) return -1;
     if (net_tcp_read_exact(c->net_tcp_sock, buf, len) < 0) return -1;
 
     if ((!c->hs_keys_active && !c->app_keys_active) || type != CT_APPDATA) {
```

## BUG-0023 (P0, p0fix2) — commit 9a06017
- Location: net/net_tls.c:783-823
- Issue: TLS1.2 记录长度检查 cap+2080 → 最高 2080 字节溢出；合法最大 CBC 记录也溢出（预认证）
- BEFORE hunk:
```
     if (net_tcp_read_exact(c->net_tcp_sock, hdr, 5) < 0) return -1;
     int type = hdr[0];
     int len = ((int)hdr[3] << 8) | hdr[4];
-    if (len < 0 || len > cap + 2080) return -1;
     if (net_tcp_read_exact(c->net_tcp_sock, buf, len) < 0) return -1;
     /* ChangeCipherSpec is ALWAYS a plaintext record, including the
      * server's one that arrives after we already switched to encrypted
```
- AFTER hunk:
```
     if (net_tcp_read_exact(c->net_tcp_sock, hdr, 5) < 0) return -1;
     int type = hdr[0];
     int len = ((int)hdr[3] << 8) | hdr[4];
+    /* P0fix2 BUG-0023 (A14-17): the old check allowed cap+2080 while every
+     * buffer on this path (rec/plain/mbuf) was 16640/17000 bytes; a hostile
+     * 18720-byte record — and even a legitimately full 18432-byte CBC
+     * record — overflowed them.  All callers now pass TLS12_REC_MAX-sized
+     * buffers and this check is exactly the buffer capacity. */
+    if (len < 0 || len > cap) return -1;
     if (net_tcp_read_exact(c->net_tcp_sock, buf, len) < 0) return -1;
     /* ChangeCipherSpec is ALWAYS a plaintext record, including the
      * server's one that arrives after we already switched to encrypted
```

## BUG-0024 (P0, p0fix2) — commit 7fa48a1
- Location: net/net_tls.c:939-942
- Issue: TLS1.2 Certificate 消息 mlen 拷入 body[12288] 溢出（证书校验之前，无需有效证书）
- BEFORE hunk:
```
         memcpy(c->server_random, body + p, 32); p += 32;
         if (p >= blen) return -1;
         int sid_len = body[p++];
-        if (p + sid_len + 4 > blen) return -1;   /* sid + cipher(2) + compression(1) */
         p += sid_len;
         c->cipher = ((int)body[p] << 8) | body[p + 1]; p += 2;
         p += 1;
-        if (p + 2 > blen) return -1;
-        int ext_total = ((int)body[p] << 8) | body[p + 1]; p += 2;
-        if (p + ext_total > blen) return -1;   /* ext block must fit in the message */
-        int end = p + ext_total;
         while (p + 4 <= end) {
             int etype = ((int)body[p] << 8) | body[p + 1];
             int elen = ((int)body[p + 2] << 8) | body[p + 3];
```
- AFTER hunk:
```
         memcpy(c->server_random, body + p, 32); p += 32;
         if (p >= blen) return -1;
         int sid_len = body[p++];
+        /* sid + cipher(2) + compression(1) = 3 bytes after sid_len; the old
+         * BUG-0079 check added 4 and rejected every extension-less
+         * ServerHello (58 bytes) with an off-by-one. */
+        if (p + sid_len + 3 > blen) return -1;
         p += sid_len;
         c->cipher = ((int)body[p] << 8) | body[p + 1]; p += 2;
         p += 1;
+        /* RFC 5246 7.4.1.2: the extensions block is OPTIONAL in TLS 1.2 —
+         * a ServerHello without one ends right after the compression byte.
+         * The old code unconditionally read ext_total and refused valid
+         * extension-less ServerHellos. */
+        if (p + 2 <= blen) {
+            int ext_total = ((int)body[p] << 8) | body[p + 1]; p += 2;
+            if (p + ext_total > blen) return -1;   /* ext block must fit in the message */
+            int end = p + ext_total;
         while (p + 4 <= end) {
             int etype = ((int)body[p] << 8) | body[p + 1];
             int elen = ((int)body[p + 2] << 8) | body[p + 3];
```

## BUG-0025 (P0, p0fix2) — commit 9a06017
- Location: net/net_tls.c:971-974
- Issue: TLS1.2 ServerKeyExchange 的 mlen 完全未检查（需有效证书链）
- BEFORE hunk:
```
 
     /* ServerKeyExchange (may be absent for fixed-DH; we require ECDHE) */
     {
-        static u8 rec[16640];
         int payload = net_tls12_recv_record(c, &ctype, rec, (int)sizeof(rec));
         if (payload < 4 || ctype != CT_HANDSHAKE) return -1;
         int mlen = ((int)rec[1] << 16) | ((int)rec[2] << 8) | rec[3];
         memcpy(body, rec + 4, mlen);
         blen = mlen;
         hs_log_push(c, rec, mlen + 4);
```
- AFTER hunk:
```
 
     /* ServerKeyExchange (may be absent for fixed-DH; we require ECDHE) */
     {
         int payload = net_tls12_recv_record(c, &ctype, rec, (int)sizeof(rec));
         if (payload < 4 || ctype != CT_HANDSHAKE) return -1;
         int mlen = ((int)rec[1] << 16) | ((int)rec[2] << 8) | rec[3];
+        /* P0fix2 BUG-0025 (A14-19): the ServerKeyExchange message length
+         * was NEVER checked against either the record payload or body —
+         * mlen up to 16 MB meant a massive OOB read from rec and an OOB
+         * write into body. */
+        if (mlen < 0 || mlen + 4 > payload || mlen > (int)sizeof(body)) return -1;
         memcpy(body, rec + 4, mlen);
         blen = mlen;
         hs_log_push(c, rec, mlen + 4);
```

## BUG-0026 (P0, p0fix2) — commit 9a06017
- Location: net/net_tls.c:984-1008
- Issue: TLS1.2 DHE ServerKeyExchange 的 sbuf[384] 溢出（需有效证书）
- BEFORE hunk:
```
             return -1;
         }
         int p = 0;
-        static u8 sbuf[64 + 320];   /* static: kernel stacks are small */
         memcpy(sbuf, c->client_random, 32);
         memcpy(sbuf + 32, c->server_random, 32);
         if (c->cipher == CS_TLS12_DHE_RSA_AES128_CBC_SHA256) {
```
- AFTER hunk:
```
             return -1;
         }
         int p = 0;
+        /* P0fix2 BUG-0026 (A14-20): ServerDHParams carries three 2-byte-
+         * length integers, each up to 256 bytes on the wire = 774 bytes
+         * total; the old 320-byte tail overflowed by 454 bytes.  776
+         * covers the legal maximum and the copy below is bounds-checked. */
+        static u8 sbuf[64 + 776];   /* static: kernel stacks are small */
         memcpy(sbuf, c->client_random, 32);
         memcpy(sbuf + 32, c->server_random, 32);
         if (c->cipher == CS_TLS12_DHE_RSA_AES128_CBC_SHA256) {
```

## BUG-0027 (P0, p0fix2) — commit 9a06017
- Location: net/net_tls.c:656-671
- Issue: TLS1.3 CertificateVerify ECDSA 签名 DER r/s 长度未检查 → 栈下溢写（需有效 ECDSA 证书链）
- BEFORE hunk:
```
         } else if (alg == 0x0403) {   /* ecdsa_secp256r1_sha256 */
             const crypto_x509_cert_t *leaf = &c->certs[0];
             u8 r[32], s[32];
-            /* decode DER ECDSA sig */
-            const u8 *q = sig;
-            if (q[0] != 0x30) return -5;
-            int tot = q[1];
-            (void)tot;
-            int p2 = 2;
-            if (q[p2++] != 0x02) return -5;
-            int rl = q[p2++];
-            memcpy(r + (32 - rl), q + p2, rl);
-            p2 += rl;
-            if (q[p2++] != 0x02) return -5;
-            int sl = q[p2++];
-            memcpy(s + (32 - sl), q + p2, sl);
             if (ecdsa_verify(EC_P256, leaf->ec_pub, leaf->ec_pub_len,
                              mhash, 32, r, 32, s, 32) != 1)
                 return -5;
```
- AFTER hunk:
```
         } else if (alg == 0x0403) {   /* ecdsa_secp256r1_sha256 */
             const crypto_x509_cert_t *leaf = &c->certs[0];
             u8 r[32], s[32];
+            /* P0fix2 BUG-0027 (A14-21): the DER decode (with all the length
+             * bounds checks it was missing) now lives in the extracted
+             * tls13_decode_ecdsa_sig() so the host test suite exercises
+             * the identical kernel code. */
+            if (tls13_decode_ecdsa_sig(sig, sig_len, r, s) != 0)
+                return -5;
             if (ecdsa_verify(EC_P256, leaf->ec_pub, leaf->ec_pub_len,
                              mhash, 32, r, 32, s, 32) != 1)
                 return -5;
```

## BUG-0028 (P0, p0fix2) — commit 9a06017
- Location: shell.c:875-885
- Issue: 字符串缓冲（栈溢出）
- BEFORE hunk:
```
     if (last_slash < 0) {
         /* No directory - use cwd. */
         strcpy(dirpath, shell_get_cwd());
         strcpy(pat, tok->text);
     } else {
         if (last_slash >= VFS_PATH_LEN - 1) return -1;
```
- AFTER hunk:
```
     if (last_slash < 0) {
         /* No directory - use cwd. */
         strcpy(dirpath, shell_get_cwd());
+        /* P0fix2 BUG-0028 (A15-1): env/alias expansion can grow a single
+         * token to 287 bytes while pat holds VFS_PATH_LEN (256) — the old
+         * unchecked strcpy smashed up to 31 stack bytes here. */
+        if (tlen >= (int)sizeof(pat)) return -1;
         strcpy(pat, tok->text);
     } else {
         if (last_slash >= VFS_PATH_LEN - 1) return -1;
```

## BUG-0029 (P0, p0fix2) — commit 9a06017
- Location: shell_cmds_disk.c:380-394
- Issue: （二次使用 434-439）  字符串缓冲（无条件栈溢出）
- BEFORE hunk:
```
         return 1;
     }
 
-    char buf[80]; char num[20];
     /* WP-09-FIX BUG-021: report the device the user actually asked
      * about, not a hardcoded "hda". */
     screen_console_puts("fsck: FAT32 filesystem on ");
```
- AFTER hunk:
```
         return 1;
     }
 
+    /* P0fix2 BUG-0029 (A15-2): the fsck FAT32 report accumulates 8 fixed
+     * strings plus numbers (154+ bytes on a typical volume) into what used
+     * to be an 80-byte buffer — an unconditional 74-byte stack overflow on
+     * every run; the second use below needs up to 98 bytes.  256 covers
+     * both with margin. */
+    char buf[256]; char num[20];
     /* WP-09-FIX BUG-021: report the device the user actually asked
      * about, not a hardcoded "hda". */
     screen_console_puts("fsck: FAT32 filesystem on ");
```

## BUG-0030 (P0, p0fix2) — commit 9a06017
- Location: shell_cmds_file.c:344-346
- Issue: + 379-382   数据丢失
- BEFORE hunk:
```
         screen_console_puts("mv: cannot open source\n");
         return 1;
     }
-    /* Get source size. */
     fs_vfs_stat_t ss;
-    if (fs_vfs_stat(rsrc, &ss) < 0) ss.size = 65536;
-    u64 total = ss.size;
-    if (total > 1024 * 1024) total = 1024 * 1024;  /* 1 MiB cap */
-
-    char *buf = (char *)kmalloc(total > 0 ? total : 1);
     if (!buf) {
         screen_console_puts("mv: out of memory\n");
         fs_vfs_close(fd);
         return 1;
     }
-    int total_read = 0;
-    int n;
-    while (total_read < (int)total &&
-           (n = fs_vfs_read(fd, buf + total_read, (int)total - total_read)) > 0) {
-        total_read += n;
-    }
-    fs_vfs_close(fd);
-
-    /* Write to dst. */
     int wfd = fs_vfs_open(rdst, VFS_O_WRONLY | VFS_O_CREAT);
     if (wfd < 0) {
         screen_console_puts("mv: cannot create destination\n");
         kfree(buf);
         return 1;
     }
-    int written = 0;
-    while (written < total_read) {
-        int w = fs_vfs_write(wfd, buf + written, total_read - written);
-        if (w <= 0) break;
-        written += w;
     }
     fs_vfs_close(wfd);
     kfree(buf);
 
     /* Unlink source. */
     if (fs_vfs_unlink(rsrc) < 0) {
```
- AFTER hunk:
```
         screen_console_puts("mv: cannot open source\n");
         return 1;
     }
+    /* Get source size (used only for the post-copy completeness check). */
     fs_vfs_stat_t ss;
+    int had_size = (fs_vfs_stat(rsrc, &ss) == 0);
+
+    /* P0fix2 BUG-0030 (A15-3): the old fallback capped the copy at 1 MiB
+     * and then unlinked the source unconditionally — any file larger than
+     * the cap was silently truncated and its data lost.  Copy in a fixed
+     * window until EOF instead, verify the byte count against the source
+     * size, and remove the source only after a complete copy. */
+    char *buf = (char *)kmalloc(32768);
     if (!buf) {
         screen_console_puts("mv: out of memory\n");
         fs_vfs_close(fd);
         return 1;
     }
     int wfd = fs_vfs_open(rdst, VFS_O_WRONLY | VFS_O_CREAT);
     if (wfd < 0) {
         screen_console_puts("mv: cannot create destination\n");
         kfree(buf);
+        fs_vfs_close(fd);
         return 1;
     }
+    u64 total_read = 0;
+    int copy_ok = 1;
+    for (;;) {
+        int n = fs_vfs_read(fd, buf, 32768);
+        if (n < 0) { copy_ok = 0; break; }
+        if (n == 0) break;   /* EOF */
+        int off 
```

## BUG-0031 (P0, p0fix2) — commit 9a06017
- Location: core_syscall.c:957-991
- Issue: sys_poll 的 `nfds * sizeof(pollfd_t)` 整数回绕绕过校验 → 内核对未映射用户地址写 → ring-0 #PF → 内核 HALT（用户态可触发 panic）
- BEFORE hunk:
```
 
 static u64 sys_poll(u64 fds_ptr, u64 nfds, u64 timeout_ms, u64 a4) {
     (void)a4;
     /* P3-9 FIX: verify pollfd array is mapped (was only range-check). */
     if (!access_ok_read(fds_ptr, nfds * sizeof(pollfd_t))) return (u64)-1;
     user_proc_t *proc = user_process_current();
```
- AFTER hunk:
```
 
 static u64 sys_poll(u64 fds_ptr, u64 nfds, u64 timeout_ms, u64 a4) {
     (void)a4;
+    /* P0fix2 BUG-0031 (A2-1): nfds is user-controlled and the old
+     * `nfds * sizeof(pollfd_t)` silently wrapped mod 2^64 (nfds = 2^61
+     * multiplies to 0), so the access_ok check passed with len 0 and the
+     * loop then wrote pfds[i].revents far beyond the validated range —
+     * the first unmapped page made it a ring-0 #PF and a kernel HALT.
+     * Cap nfds: fd indices are checked against PROC_MAX_FDS below, so any
+     * larger poll can never be meaningful. */
+    if (nfds > 4096) return (u64)-1;
     /* P3-9 FIX: verify pollfd array is mapped (was only range-check). */
     if (!access_ok_read(fds_ptr, nfds * sizeof(pollfd_t))) return (u64)-1;
     user_proc_t *proc = user_process_current();
```

## BUG-0032 (P0, p0fix2) — commit 9a06017
- Location: core_usermode.c:221-226
- Issue: SYS_EXIT(0) 用 `char n[8]` 接收无界 u64_to_str(用户可控 code) → 内核栈缓冲区溢出最多 13 字节
- BEFORE hunk:
```
     for (int i = 0; i < MAX_USER_PROCS; i++) {
         if (g_procs[i].alive && g_procs[i].tid == tid) {
             g_procs[i].alive = 0;
-            char n[8]; u64_to_str((u64)g_procs[i].pid, n);
             screen_console_puts("[user] process ");
             screen_console_puts(n);
             screen_console_puts(" exited (code=");
```
- AFTER hunk:
```
     for (int i = 0; i < MAX_USER_PROCS; i++) {
         if (g_procs[i].alive && g_procs[i].tid == tid) {
             g_procs[i].alive = 0;
+            /* P0fix2 BUG-0032 (A2-2): n was char[8] while u64_to_str can
+             * emit up to 20 digits + NUL for a user-controlled exit code —
+             * an up-to-13-byte overflow of this kernel stack frame.  24
+             * covers any u64. */
+            char n[24]; u64_to_str((u64)g_procs[i].pid, n);
             screen_console_puts("[user] process ");
             screen_console_puts(n);
             screen_console_puts(" exited (code=");
```

## BUG-0033 (P0, p0fix2) — commit 9a06017
- Location: core_syscall.c:1089-1231
- Issue: sys_execve 在 CR3 已切到内核 AS、旧 AS 已销毁之后构造 argv/envp 与用户栈内容 → 所有用户 VA 读写走 0-4GiB 恒等映射窗口：argv 读到垃圾/丢失，栈写入落在物理 ~0x3FFFxxxx（≥1GiB 机器=破坏活物理帧；512MiB QEMU=静默丢失，
- BEFORE hunk:
```
     user_proc_t *proc = user_process_current();
     if (!proc) return (u64)-1;
 
     extern mem_vmm_as_t mem_vmm_kernel_as(void);
     mem_vmm_as_t old_as = proc->as;
     __asm__ volatile("mov %0, %%cr3" :: "r"(mem_vmm_kernel_as()) : "memory");
     if (old_as) mem_vmm_destroy_address_space(old_as);
     proc->as = create_user_address_space();
-    if (proc->as == 0) return (u64)-1;
 
     typedef struct __attribute__((packed)) {
         u8 ident[16]; u16 type; u16 machine; u32 version; u64 entry; u64 phoff;
```
- AFTER hunk:
```
     user_proc_t *proc = user_process_current();
     if (!proc) return (u64)-1;
 
+    /* P0fix2 BUG-0033 (A2-3) step 1: read argv/envp NOW, before the CR3
+     * switch and before the old address space is destroyed.  Here CR3 is
+     * still the caller's user address space and proc->as is the same one
+     * access_ok_* validates, so both the checks and the dereferences see
+     * the same, correct memory. */
+    typedef struct { u8 data[32][256]; int len[32]; int count; } exec_args_buf_t;
+    exec_args_buf_t *ab = (exec_args_buf_t *)kmalloc(sizeof(exec_args_buf_t));
+    exec_args_buf_t *eb = (exec_args_buf_t *)kmalloc(sizeof(exec_args_buf_t));
+    if (!ab || !eb) {
+        if (ab) kfree(ab);
+        if (eb) kfree(eb);
+        return (u64)-1;
+    }
+    memset(ab, 0, sizeof(*ab));
+    memset(eb, 0, sizeof(*eb));
+    if (argv != 0) {
+        for (int a = 0; a < 32; a++) {
+            u64 entry_ptr = argv + (u64)a * sizeof(u64);
+            if (!access_ok_read(entry_ptr, sizeof(u64))) break;
+            u64 str_ptr = *(u64 *)(uintptr_t)entry_ptr;
+            if (str_ptr == 0) break;
+            if (!access_ok_str(str_ptr)) break;
+            const char *sp = (c
```

## BUG-0034 (P0, p0fix2) — commit 9a06017
- Location: core_syscall.c:1787-1802
- Issue: sys_ps 栈上 `ktab[64]`=3584B，而内核线程栈只有 1 页 4096B（core_sched.c:264），入口已耗 ~3990B，余量 ~100B；0x80 为 trap 门(0xEE) IF=1，嵌套定时器中断(≥184B)必越页 → 相邻物理帧损坏（间歇性）
- BEFORE hunk:
```
         cap > sizeof(core_sched_task_info_t) * 64) return (u64)-1;
     int max = (int)(cap / sizeof(core_sched_task_info_t));
     {
-        core_sched_task_info_t ktab[64];
         int n = core_sched_task_info_get(ktab, max);
-        if (n < 0) return (u64)-1;
         if (copy_to_user(buf, ktab, (u64)n * sizeof(core_sched_task_info_t)) < 0) {
             return (u64)-1;
         }
         return (u64)n;
     }
 }
```
- AFTER hunk:
```
         cap > sizeof(core_sched_task_info_t) * 64) return (u64)-1;
     int max = (int)(cap / sizeof(core_sched_task_info_t));
     {
+        /* P0fix2 BUG-0034 (A2-4): ktab was a fixed 3584-byte stack array on
+         * a small kernel thread stack (entry frame plus a nested timer IRQ
+         * on top left almost no headroom on a 1-page stack).  Size it for
+         * the caller's cap and take it from the heap instead. */
+        core_sched_task_info_t *ktab =
+            (core_sched_task_info_t *)kmalloc(sizeof(core_sched_task_info_t) * (u64)max);
+        if (!ktab) return (u64)-1;
         int n = core_sched_task_info_get(ktab, max);
+        if (n < 0) { kfree(ktab); return (u64)-1; }
         if (copy_to_user(buf, ktab, (u64)n * sizeof(core_sched_task_info_t)) < 0) {
+            kfree(ktab);
             return (u64)-1;
         }
+        kfree(ktab);
         return (u64)n;
     }
 }
```

## BUG-0035 (P0, p0fix2) — commit 9a06017
- Location: crypto_x509.c:44-53
- Issue: + crypto_x509.c:456-467   整数溢出 → 负长度 memcpy → 内核内存破坏（远程可触发）
- BEFORE hunk:
```
     if (l & 0x80) {
         int n = l & 0x7F;
         if (n == 0 || n > 4 || d->len < 2 + n) return -1;
-        l = 0;
-        for (int i = 0; i < n; i++) l = (l << 8) | d->p[2 + i];
         hdr = 2 + n;
     }
-    if (d->len < hdr + l) return -1;
     *body = d->p + hdr;
     *body_len = l;
     d->p += hdr + l;
```
- AFTER hunk:
```
     if (l & 0x80) {
         int n = l & 0x7F;
         if (n == 0 || n > 4 || d->len < 2 + n) return -1;
+        u32 ul = 0;
+        for (int i = 0; i < n; i++) ul = (ul << 8) | d->p[2 + i];
+        /* P0fix2 BUG-0035 (A4-01): the old signed-int accumulation wrapped
+         * on lengths like 0x84 FF FF FF FF (l became -1), so the range
+         * check below read `d->len < hdr - 1` and let a negative body
+         * length through to a (size_t)(-1) memcpy inside verify_cert_sig.
+         * Accumulate unsigned and reject anything beyond int range. */
+        if (ul > 0x7FFFFFFFu) return -1;
+        l = (int)ul;
         hdr = 2 + n;
     }
+    if (l < 0 || d->len < hdr + l) return -1;
     *body = d->p + hdr;
     *body_len = l;
     d->p += hdr + l;
```

## BUG-0036 (P0, p0fix2) — commit 9a06017
- Location: kernel/lib/lib_config.c:285
- Issue: ,303-318   内存管理/堆溢出
- BEFORE hunk:
```
         char k[OC_CONFIG_KEY_MAX], v[OC_CONFIG_VAL_MAX];
         if (parse_line(line, k, sizeof(k), v, sizeof(v)) &&
             strcmp(k, key) == 0) {
-            /* replace this line with key=value */
-            for (int c = 0; c < kl; c++) out[olen++] = key[c];
-            out[olen++] = '=';
-            for (int c = 0; c < vl; c++) out[olen++] = canon[c];
-            out[olen++] = '\n';
-            replaced = 1;
         } else {
             for (int c = 0; line[c]; c++)
                 if (olen < OC_CONFIG_FILE_MAX - 2) out[olen++] = line[c];
```
- AFTER hunk:
```
         char k[OC_CONFIG_KEY_MAX], v[OC_CONFIG_VAL_MAX];
         if (parse_line(line, k, sizeof(k), v, sizeof(v)) &&
             strcmp(k, key) == 0) {
+            /* replace this line with key=value.
+             * P0fix2 BUG-0036 (A5-01): the replace and append paths wrote
+             * key/canon with NO bounds check on out[kmalloc(4096)] — a file
+             * with hundreds of duplicate keys (or one nearly full with
+             * comments) overflowed the heap block by hundreds of bytes.
+             * Only the first matching line is rewritten (duplicate keys are
+             * dropped, which also bounds the output by the input size),
+             * and every write is bounds-checked. */
+            if (!replaced) {
+                if (olen + kl + vl + 2 > OC_CONFIG_FILE_MAX - 1) {
+                    kfree(out);
+                    kfree(buf);
+                    return OC_CONFIG_E_TOOLONG;
+                }
+                for (int c = 0; c < kl; c++) out[olen++] = key[c];
+                out[olen++] = '=';
+                for (int c = 0; c < vl; c++) out[olen++] = canon[c];
+                out[olen++] = '\n';
+                replaced = 1;
+            }
```

## BUG-0037 (P0, p0fix2) — commit 9a06017
- Location: kernel/ota/ota_update.c:692
- Issue: ,707-709   字符串缓冲/栈溢出（网络触发）
- BEFORE hunk:
```
 
     /* Give DHCP/ARP a moment to settle, then run the real check. */
     ota_update_info_t info;
-    char line2[160];
     int rc = ota_update_check(&info);
     if (rc == OC_UPDATE_OK) {
         au_print("Current version is up to date.");
```
- AFTER hunk:
```
 
     /* Give DHCP/ARP a moment to settle, then run the real check. */
     ota_update_info_t info;
+    /* P0fix2 BUG-0037 (A5-02): line2 was 160 bytes while "Changes: "(9) +
+     * info.changes (up to 255) + NUL = 265 — the server-supplied changes
+     * text smashed 105 bytes of this kernel-thread stack (auto_check runs
+     * on boot).  272 covers the largest field with margin. */
+    char line2[272];
     int rc = ota_update_check(&info);
     if (rc == OC_UPDATE_OK) {
         au_print("Current version is up to date.");
```

## BUG-0038 (P0, p0fix2) — commit 9a06017
- Location: kernel/ota/ota_update.c:272-278
- Issue: 字符串缓冲/栈溢出（URL 路径）
- BEFORE hunk:
```
             return OC_UPDATE_E_CONNECT;
         }
 
-        char request[256];
         strcpy(request, "GET ");
         strcat(request, u.path);
         strcat(request, " HTTP/1.0\r\nHost: ");
```
- AFTER hunk:
```
             return OC_UPDATE_E_CONNECT;
         }
 
+        char request[2048];   /* P0fix2 BUG-0038 (A5-03): was 256, while
+                               * u.path alone can legally carry a 1663-byte
+                               * CDN redirect path (see ota_update.h); the
+                               * old strcat chain overflowed by up to ~1.4KB */
+        {
+            int need = 4 + (int)strlen(u.path) + 17 + (int)strlen(u.host) + 38 + 1;
+            if (need > (int)sizeof(request)) {
+                net_close(sock);
+                return OC_UPDATE_E_BUFSIZE;
+            }
+        }
         strcpy(request, "GET ");
         strcat(request, u.path);
         strcat(request, " HTTP/1.0\r\nHost: ");
```

## BUG-0039 (P0, p0fix2) — commit 9a06017
- Location: kernel/ota/ota_ab.c:790-794
- Issue: ,880-886   路径遍历/任意文件写
- BEFORE hunk:
```
         return 0;
     }
     if (path[0] == '/') return 1;                 /* absolute: skip */
     if (strlen(path) + 2 > (u64)outcap) return OC_UPDATE_E_BUFSIZE;
     strcpy(out, "/");
     strcat(out, path);
```
- AFTER hunk:
```
         return 0;
     }
     if (path[0] == '/') return 1;                 /* absolute: skip */
+    /* P0fix2 BUG-0039 (A5-04): ".." components passed through untouched and
+     * fs_vfs_normalize pops them at string level, so a tar entry named
+     * a/../../../etc/opencube.conf escaped the slot mount point and wrote
+     * anywhere in the VFS (update --local needs no external validation).
+     * Reject any path containing a ".." component outright. */
+    for (const char *p = path; *p; p++) {
+        if (p[0] == '.' && p[1] == '.' &&
+            (p[2] == '/' || p[2] == '\0') &&
+            (p == path || p[-1] == '/')) {
+            return OC_UPDATE_E_BUFSIZE;
+        }
+    }
     if (strlen(path) + 2 > (u64)outcap) return OC_UPDATE_E_BUFSIZE;
     strcpy(out, "/");
     strcat(out, path);
```

## BUG-0040 (P0, p0fix2) — commit 9a06017
- Location: driver_block_blk.c:96-109
- Issue: + driver_block_nvme.c:519-524, 634-646   块层/缓存层硬编码 512B 扇区 vs NVMe 注册非 512 sector_size → 4K 扇区盘上每次缓存读越界写内存
- BEFORE hunk:
```
         u64 nsze = *(u64 *)(id_ns + 0);          /* Namespace Size (blocks) */
         u8  flbas = id_ns[26];                   /* Formatted LBA Size */
         u8  lbads = id_ns[128 + 4 * (flbas & 0x0F) + 2];   /* LBAF[flbas].LBADS */
-        /* P2-23: bound lbads to prevent insane sector sizes. */
-        if (lbads > 16) lbads = 9;  /* fallback to 512 if corrupt */
-        u32 sector_size = (lbads > 0) ? (1u << lbads) : 512u;
         g_nvme.sector_size = sector_size;
         g_nvme.sectors     = nsze;
         driver_block_nvme_log_dec("nvme: NSZE=", nsze, " blocks\n");
```
- AFTER hunk:
```
         u64 nsze = *(u64 *)(id_ns + 0);          /* Namespace Size (blocks) */
         u8  flbas = id_ns[26];                   /* Formatted LBA Size */
         u8  lbads = id_ns[128 + 4 * (flbas & 0x0F) + 2];   /* LBAF[flbas].LBADS */
+        /* P0fix2 BUG-0040 (A6-1): the block and cache layers are hardwired
+         * to 512-byte sectors (BLK_SECTOR_SIZE / cache slot data[512]).
+         * Registering a device whose formatted LBA size is not 512B made
+         * every driver_block_read_sectors() copy sector_size bytes into
+         * 512-byte caller buffers — 3584 bytes of heap overflow per read
+         * on a 4Kn drive.  Until the block layer is made sector-size-aware,
+         * refuse the namespace with a clear error instead of corrupting
+         * memory.  (Old code fell back to 512 only for lbads > 16.) */
+        if (lbads != 9) {
+            u32 reported = (lbads > 0 && lbads <= 16) ? (1u << lbads) : 0;
+            driver_block_nvme_log("nvme: unsupported formatted LBA size (only 512B supported; got ");
+            if (reported) {
+                char nb[16];
+                u64_to_str(reported, nb);
+                driver_block_nvme_log(nb);
+        
```

## BUG-0041 (P0, p0fix2) — commit 9a06017
- Location: net_core.c:5020/5034 + vmm
- Issue: 实测复现：tcptest 命令完成后触发连环 #PF（cr2=0xFD1CF480 为 fb 区未映射页，即 KNOWN_ISSUES §6.1 地址），异常处理器自身递归 #PF（rsp 每次 -0x230）直至三重故障，QEMU 退出。100% 复现。
- BEFORE hunk:
```
 }
 
 void arch_exc_dispatch(arch_irq_frame_t *f) {
     /* P4 fix: crash log/dump. Old code only printed the exception to the
      * serial console and framebuffer, then halted. If you missed the
      * message (e.g. console scrolled), the diagnostic was lost.
```
- AFTER hunk:
```
 }
 
 void arch_exc_dispatch(arch_irq_frame_t *f) {
+    /* P0fix2 BUG-0041 (RUN-01): guard against recursive fault handling.
+     * The fault-printing path itself can #PF (the KNOWN_ISSUES 6.1
+     * framebuffer rolling-edge page), and the old handler re-entered
+     * itself with no bound: each entry pushed ~0x230 bytes until the
+     * stack ran out and the CPU raised a triple fault (tcptest 100%
+     * crash chain in the audit).  An in-handler counter stops the
+     * recursion: on a NESTED #PF (a fault while already handling one)
+     * we report once via SERIAL ONLY (no framebuffer, no crash-log
+     * write) and halt immediately.  Faults that the VMM legitimately
+     * handles (stack/heap growth) decrement the counter on resume. */
+    static int exc_in_pf = 0;
+    int is_pf = (f->int_no == 14);
+    if (is_pf && exc_in_pf) {
+        ser_puts("\r\n*** NESTED #PF INSIDE EXCEPTION HANDLER - HALTING ***\r\n");
+        for (;;) {
+            __asm__ volatile("cli; hlt");
+        }
+    }
+    if (is_pf) exc_in_pf++;
+
     /* P4 fix: crash log/dump. Old code only printed the exception to the
      * serial console and framebuffer, then halted. If you missed the
 
```

## BUG-0042 (P1, p1fix1) — commit 1abc0c4
- Location: kernel/arch/x86_64/arch_context_switch.S:75-115
- Issue: （全仓缺失）  ⑥并发/资源管理
- BEFORE hunk:
```
 %define OFF_SS    224
 %define OFF_CR3   248
 
 section .text
 align 16
 arch_context_switch:
```
- AFTER hunk:
```
 %define OFF_SS    224
 %define OFF_CR3   248
 
+; BUG-0042 FIX: per-task FPU/SSE state.
+; OFF_FPU       = offsetof(task_t, fpu_state)   (fxsave area, 512B, 16-aligned)
+; OFF_FPU_SAVED = offsetof(task_t, fpu_saved)   (int flag: image valid?)
+; These two offsets are pinned by _Static_assert in core_sched.c.
+%define OFF_FPU        288
+%define OFF_FPU_SAVED  800
+
 section .text
 align 16
 arch_context_switch:
```

## BUG-0043 (P1, p1fix1) — commit 1abc0c4
- Location: kernel/mem/mem_pmm.c:193-202
- Issue: （及 229-247）  ⑥并发/中断安全
- BEFORE hunk:
```
     }
 }
 
 u64 mem_pmm_alloc_frame(void) {
-    /* P1-1 FIX: guard against g_total_pages == 0 (div by zero). */
-    if (g_total_pages == 0) return 0;
-    /* Scan from g_last_scan for a free page. */
-    for (u64 i = 0; i < g_total_pages; i++) {
-        u64 idx = (g_last_scan + i) % g_total_pages;
-        if (!bitmap_test(idx)) {
-            bitmap_set(idx);
-            g_used_pages++;
-            g_free_pages--;
-            g_last_scan = idx + 1;
-            g_total_allocs++;  /* P4: counter */
-            return idx << PMM_PAGE_SHIFT;
         }
-    }
 
-    /* Out of memory. Call emergency callbacks. */
-    for (int i = 0; i < PMM_MAX_EMERGENCY_CBS; i++) {
-        if (g_emergency_cbs[i]) {
-            g_emergency_cbs[i]();
-            /* Retry after emergency free. */
-            for (u64 j = 0; j < g_total_pages; j++) {
-                if (!bitmap_test(j)) {
-                    bitmap_set(j);
-                    g_used_pages++;
-                    g_free_pages--;
-                    g_last_scan = j + 1;
-                    g_total_allocs++;  /* P4: counter */
-                    return j << PMM_PAGE_SHIFT;
                 }
             }
         }
- 
```
- AFTER hunk:
```
     }
 }
 
+/* BUG-0043 FIX: single-CPU atomicity helpers for the PMM bitmap.
+ * pmm_irq_save() returns the previous RFLAGS with IF cleared;
+ * pmm_irq_restore() re-enables interrupts only if they were enabled
+ * before, so calls nested inside IRQ context are safe. */
+static inline u64 pmm_irq_save(void) {
+    u64 flags;
+    __asm__ volatile("pushfq; pop %0; cli" : "=r"(flags) :: "memory");
+    return flags;
+}
+static inline void pmm_irq_restore(u64 flags) {
+    if (flags & 0x200) __asm__ volatile("sti" ::: "memory");
+}
+
 u64 mem_pmm_alloc_frame(void) {
+    /* BUG-0043 FIX: the bitmap test-then-set below must be atomic with
+     * respect to IRQ-context allocators (the mem_heap soft-timer
+     * callback grows pools via kmalloc -> mem_pmm_alloc_contig from the
+     * timer IRQ). A torn window could hand the same physical frame to
+     * both the preempted thread and the IRQ. Save IF, disable
+     * interrupts for the whole critical section, restore the previous
+     * state on exit (nested IRQ-context callers see IF already clear,
+     * so the restore is a no-op for them). */
+    u64 flags = pmm_irq_save();
+    u64 result = 0;
+
+    do {
+        /* P1-1 FIX
```

## BUG-0044 (P1, p1fix1) — commit 1abc0c4
- Location: kernel/mem/mem_vmm.c:404-448
- Issue: ③⑤⑩（缺页处理语义错误）
- BEFORE hunk:
```
 /* Check if a virtual address is near the faulting stack pointer (stack growth).
  * P0-10 FIX: takes the faulting RSP (from the exception frame) instead of
  * reading the current RSP, which during a #PF points at the kernel exception
- * stack, not the user/kernel stack that actually faulted. */
 static int in_stack_region(u64 vaddr, u64 faulting_rsp) {
     /* Allow growth within 64 KiB below the faulting RSP. */
-    return vaddr < faulting_rsp && vaddr >= (faulting_rsp - 0x10000);
 }
 
 int mem_vmm_handle_page_fault(u64 vaddr, u64 error_code, u64 rip, u64 faulting_rsp) {
-    (void)error_code;
     g_fault_stats.total_faults++;
 
     /* Try L1 fault handlers first. */
     for (int i = 0; i < g_fault_handler_count; i++) {
```
- AFTER hunk:
```
 /* Check if a virtual address is near the faulting stack pointer (stack growth).
  * P0-10 FIX: takes the faulting RSP (from the exception frame) instead of
  * reading the current RSP, which during a #PF points at the kernel exception
+ * stack, not the user/kernel stack that actually faulted.
+ * BUG-0044 (b) FIX: automatic growth is also bounded - the region never
+ * extends below VMM_USER_STACK_TOP - VMM_STACK_LIMIT_BYTES, so a runaway
+ * program cannot demand unbounded physical pages by walking RSP down. */
+#define VMM_USER_STACK_TOP      0x40000000ULL   /* matches core_usermode.h */
+#define VMM_STACK_LIMIT_BYTES   (8ULL * 1024ULL * 1024ULL)  /* 8 MiB cap */
 static int in_stack_region(u64 vaddr, u64 faulting_rsp) {
     /* Allow growth within 64 KiB below the faulting RSP. */
+    if (vaddr >= faulting_rsp || vaddr < (faulting_rsp - 0x10000)) return 0;
+    /* BUG-0044 (b): hard floor - below this the stack never grows. */
+    if (vaddr < VMM_USER_STACK_TOP - VMM_STACK_LIMIT_BYTES) return 0;
+    return 1;
 }
 
 int mem_vmm_handle_page_fault(u64 vaddr, u64 error_code, u64 rip, u64 faulting_rsp) {
+    /* BUG-0044 (A1-3) FIX: respect the CPU's own fault classification
+ 
```

## BUG-0045 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_xhci.c:300-312
- Issue: , 1084-1097
- BEFORE hunk:
```
  * ================================================================== */
 
 static int driver_usb_xhci_next_event(driver_usb_xhci_state_t *x, xtrb_t *out) {
-    xtrb_t *t = &x->ev[x->ev_deq];
-    u32 ctrl = t[0][3];
-    if (!(ctrl & x->ev_cycle)) return 0;   /* no (new) event */
-    out[0][0] = t[0][0]; out[0][1] = t[0][1];
-    out[0][2] = t[0][2]; out[0][3] = ctrl;
-    x->ev_deq++;
-    if (x->ev_deq == XHCI_RING_N - 1) {    /* step over the LINK TRB */
-        x->ev_deq = 0;
-        x->ev_cycle ^= 1;
     }
-    return 1;
 }
 
 /* publish the dequeue pointer so the controller frees consumed events */
```
- AFTER hunk:
```
  * ================================================================== */
 
 static int driver_usb_xhci_next_event(driver_usb_xhci_state_t *x, xtrb_t *out) {
+    for (;;) {
+        xtrb_t *t = &x->ev[x->ev_deq];
+        u32 ctrl = t[0][3];
+
+        /* BUG-0045 FIX: the last slot of the event ring holds a LINK TRB
+         * (now actually written at init — see the event ring setup),
+         * matching the command/transfer rings. Real controllers never
+         * park an event on it; QEMU, which wraps the ring without
+         * honouring the LINK, can. Handle both: a LINK is stepped over
+         * (wrap to slot 0, flip the cycle); anything else is consumed
+         * when its cycle bit matches. The old code never wrote the LINK
+         * and skipped slot 63 unconditionally, losing one event out of
+         * every 64 and desyncing from QEMU's wrap point. */
+        if (((ctrl >> TRB_TYPE_SH) & 0x3fu) == TRB_LINK) {
+            x->ev_deq = 0;
+            x->ev_cycle ^= 1;
+            continue;
+        }
+        if (!(ctrl & x->ev_cycle)) return 0;   /* no (new) event */
+
+        out[0][0] = t[0][0]; out[0][1] = t[0][1];
+        out[0][2] = t[0][2]; out[0][3] 
```

## BUG-0046 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_xhci.c:965-976
- Issue: vs 564-575
- BEFORE hunk:
```
  * ================================================================== */
 
 static int driver_usb_xhci_next_event(driver_usb_xhci_state_t *x, xtrb_t *out) {
-    xtrb_t *t = &x->ev[x->ev_deq];
-    u32 ctrl = t[0][3];
-    if (!(ctrl & x->ev_cycle)) return 0;   /* no (new) event */
-    out[0][0] = t[0][0]; out[0][1] = t[0][1];
-    out[0][2] = t[0][2]; out[0][3] = ctrl;
-    x->ev_deq++;
-    if (x->ev_deq == XHCI_RING_N - 1) {    /* step over the LINK TRB */
-        x->ev_deq = 0;
-        x->ev_cycle ^= 1;
     }
-    return 1;
 }
 
 /* publish the dequeue pointer so the controller frees consumed events */
```
- AFTER hunk:
```
  * ================================================================== */
 
 static int driver_usb_xhci_next_event(driver_usb_xhci_state_t *x, xtrb_t *out) {
+    for (;;) {
+        xtrb_t *t = &x->ev[x->ev_deq];
+        u32 ctrl = t[0][3];
+
+        /* BUG-0045 FIX: the last slot of the event ring holds a LINK TRB
+         * (now actually written at init — see the event ring setup),
+         * matching the command/transfer rings. Real controllers never
+         * park an event on it; QEMU, which wraps the ring without
+         * honouring the LINK, can. Handle both: a LINK is stepped over
+         * (wrap to slot 0, flip the cycle); anything else is consumed
+         * when its cycle bit matches. The old code never wrote the LINK
+         * and skipped slot 63 unconditionally, losing one event out of
+         * every 64 and desyncing from QEMU's wrap point. */
+        if (((ctrl >> TRB_TYPE_SH) & 0x3fu) == TRB_LINK) {
+            x->ev_deq = 0;
+            x->ev_cycle ^= 1;
+            continue;
+        }
+        if (!(ctrl & x->ev_cycle)) return 0;   /* no (new) event */
+
+        out[0][0] = t[0][0]; out[0][1] = t[0][1];
+        out[0][2] = t[0][2]; out[0][3] 
```

## BUG-0047 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_xhci.c:415-419
- Issue: , 651, 682
- BEFORE hunk:
```
  * ================================================================== */
 
 static int driver_usb_xhci_next_event(driver_usb_xhci_state_t *x, xtrb_t *out) {
-    xtrb_t *t = &x->ev[x->ev_deq];
-    u32 ctrl = t[0][3];
-    if (!(ctrl & x->ev_cycle)) return 0;   /* no (new) event */
-    out[0][0] = t[0][0]; out[0][1] = t[0][1];
-    out[0][2] = t[0][2]; out[0][3] = ctrl;
-    x->ev_deq++;
-    if (x->ev_deq == XHCI_RING_N - 1) {    /* step over the LINK TRB */
-        x->ev_deq = 0;
-        x->ev_cycle ^= 1;
     }
-    return 1;
 }
 
 /* publish the dequeue pointer so the controller frees consumed events */
```
- AFTER hunk:
```
  * ================================================================== */
 
 static int driver_usb_xhci_next_event(driver_usb_xhci_state_t *x, xtrb_t *out) {
+    for (;;) {
+        xtrb_t *t = &x->ev[x->ev_deq];
+        u32 ctrl = t[0][3];
+
+        /* BUG-0045 FIX: the last slot of the event ring holds a LINK TRB
+         * (now actually written at init — see the event ring setup),
+         * matching the command/transfer rings. Real controllers never
+         * park an event on it; QEMU, which wraps the ring without
+         * honouring the LINK, can. Handle both: a LINK is stepped over
+         * (wrap to slot 0, flip the cycle); anything else is consumed
+         * when its cycle bit matches. The old code never wrote the LINK
+         * and skipped slot 63 unconditionally, losing one event out of
+         * every 64 and desyncing from QEMU's wrap point. */
+        if (((ctrl >> TRB_TYPE_SH) & 0x3fu) == TRB_LINK) {
+            x->ev_deq = 0;
+            x->ev_cycle ^= 1;
+            continue;
+        }
+        if (!(ctrl & x->ev_cycle)) return 0;   /* no (new) event */
+
+        out[0][0] = t[0][0]; out[0][1] = t[0][1];
+        out[0][2] = t[0][2]; out[0][3] 
```

## BUG-0048 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb.c
- Issue: :468-471
- BEFORE hunk:
```
         d->present = 0;
         return 0;
     }
-    if (buf[7] >= 8 && buf[7] <= 64) d->mps0 = buf[7];
-    else if (buf[7] == 9 && speed == USB_SPEED_SS)
         d->mps0 = 512;   /* SuperSpeed encodes the fixed 512-byte EP0
                             as "9" in bMaxPacketSize0 */
 
     /* SET_ADDRESS */
     u8 new_addr = driver_usb_free_address();
```
- AFTER hunk:
```
         d->present = 0;
         return 0;
     }
+    /* BUG-0048 FIX: check the SuperSpeed encoding FIRST. bMaxPacketSize0
+     * == 9 is legal ONLY for SuperSpeed devices and means 512 bytes
+     * (xHCI spec / USB 3.1 9.6.6); the old order matched "9" inside the
+     * 8..64 branch, set mps0=9 (an illegal Max Packet Size for EP0) and
+     * left the SS branch unreachable forever, so SS enumeration failed
+     * in the XHCI backend when it programmed EP0 with MPS 9. */
+    if (speed == USB_SPEED_SS && buf[7] == 9)
         d->mps0 = 512;   /* SuperSpeed encodes the fixed 512-byte EP0
                             as "9" in bMaxPacketSize0 */
+    else if (buf[7] >= 8 && buf[7] <= 64) d->mps0 = buf[7];
 
     /* SET_ADDRESS */
     u8 new_addr = driver_usb_free_address();
```

## BUG-0049 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_ehci.c
- Issue: :637-639
- Manual HEAD verification: driver_usb_ehci.c:731 EHCI_CONFIGFLAG=1（grep 实证）
- BEFORE hunk:
```
         if (!(driver_usb_ehci_rd(e, EHCI_USBCMD) & EHCI_CMD_HCRESET)) break;
         for (volatile int t = 0; t < 1000; t++) { }
     }
-    /* clear CONFIGFLAG so ports route to this controller (no
-     * companion controllers exist in this stack) */
-    driver_usb_ehci_wr(e, EHCI_CONFIGFLAG, 0);
 
     /* allocate descriptors */
     u64 qpage = mem_pmm_alloc_frame();
```
- AFTER hunk:
```
         if (!(driver_usb_ehci_rd(e, EHCI_USBCMD) & EHCI_CMD_HCRESET)) break;
         for (volatile int t = 0; t < 1000; t++) { }
     }
+    /* BUG-0049 FIX: CONFIGFLAG(CF) semantics per the EHCI spec (2.3.9):
+     * CF=1 means "ports routed to THIS EHCI controller"; CF=0 hands the
+     * ports to the companion UHCI/OHCI controllers. The old code wrote
+     * 0 with a comment that had the meaning inverted — on any chipset
+     * with companions (or a spec-compliant real chip) that unhooks the
+     * EHCI from its own ports and leaves PSE/ASE scheduling undefined.
+     * Set CF=1 to take ownership of the ports. */
+
+    /* Set CF=1 (see BUG-0049 above). */
+    driver_usb_ehci_wr(e, EHCI_CONFIGFLAG, 1);
 
     /* allocate descriptors */
     u64 qpage = mem_pmm_alloc_frame();
```

## BUG-0050 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_ohci.c:676-704
- Issue: , 452-506
- BEFORE hunk:
```
             memcpy(o->bulk_buf + done_bytes,
                       (const void *)((uintptr_t)buf + done_bytes),
                       chunk);
         tds[i].word0 = TD_CC_NOTACC | dp | (tog ? TD_T1 : TD_T0) |
-                       (chunk - 1) | (i + 1 < ntd ? TD_R : 0);
         tds[i].cur = (u32)(o->bulk_buf_phys + done_bytes);
         tds[i].next = (i + 1 < ntd)
             ? (u32)(o->bulk_td_phys + (u64)(i + 1) * sizeof(driver_usb_ohci_td_t))
```
- AFTER hunk:
```
             memcpy(o->bulk_buf + done_bytes,
                       (const void *)((uintptr_t)buf + done_bytes),
                       chunk);
+        /* BUG-0051 FIX: TD_R (buffer rounding) marks a TD whose transfer
+         * may legally complete with less data than buffered - that is a
+         * property of IN endpoints receiving a short packet, most
+         * importantly on the FINAL TD. The old condition attached TD_R
+         * to every TD EXCEPT the last one, so a bulk-IN short packet
+         * ended the queue with DataUnderrun (treated as EIO) and the
+         * partially-received data was discarded. Follow the control
+         * path above: round on all IN TDs. */
         tds[i].word0 = TD_CC_NOTACC | dp | (tog ? TD_T1 : TD_T0) |
+                       (chunk - 1) | (dp == TD_DP_IN ? TD_R : 0);
         tds[i].cur = (u32)(o->bulk_buf_phys + done_bytes);
         tds[i].next = (i + 1 < ntd)
             ? (u32)(o->bulk_td_phys + (u64)(i + 1) * sizeof(driver_usb_ohci_td_t))
```

## BUG-0051 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_ohci.c:407-413
- Issue: , 430-449
- BEFORE hunk:
```
             memcpy(o->bulk_buf + done_bytes,
                       (const void *)((uintptr_t)buf + done_bytes),
                       chunk);
         tds[i].word0 = TD_CC_NOTACC | dp | (tog ? TD_T1 : TD_T0) |
-                       (chunk - 1) | (i + 1 < ntd ? TD_R : 0);
         tds[i].cur = (u32)(o->bulk_buf_phys + done_bytes);
         tds[i].next = (i + 1 < ntd)
             ? (u32)(o->bulk_td_phys + (u64)(i + 1) * sizeof(driver_usb_ohci_td_t))
```
- AFTER hunk:
```
             memcpy(o->bulk_buf + done_bytes,
                       (const void *)((uintptr_t)buf + done_bytes),
                       chunk);
+        /* BUG-0051 FIX: TD_R (buffer rounding) marks a TD whose transfer
+         * may legally complete with less data than buffered - that is a
+         * property of IN endpoints receiving a short packet, most
+         * importantly on the FINAL TD. The old condition attached TD_R
+         * to every TD EXCEPT the last one, so a bulk-IN short packet
+         * ended the queue with DataUnderrun (treated as EIO) and the
+         * partially-received data was discarded. Follow the control
+         * path above: round on all IN TDs. */
         tds[i].word0 = TD_CC_NOTACC | dp | (tog ? TD_T1 : TD_T0) |
+                       (chunk - 1) | (dp == TD_DP_IN ? TD_R : 0);
         tds[i].cur = (u32)(o->bulk_buf_phys + done_bytes);
         tds[i].next = (i + 1 < ntd)
             ? (u32)(o->bulk_td_phys + (u64)(i + 1) * sizeof(driver_usb_ohci_td_t))
```

## BUG-0052 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_ohci.c
- Issue: :728-731
- BEFORE hunk:
```
             memcpy(o->bulk_buf + done_bytes,
                       (const void *)((uintptr_t)buf + done_bytes),
                       chunk);
         tds[i].word0 = TD_CC_NOTACC | dp | (tog ? TD_T1 : TD_T0) |
-                       (chunk - 1) | (i + 1 < ntd ? TD_R : 0);
         tds[i].cur = (u32)(o->bulk_buf_phys + done_bytes);
         tds[i].next = (i + 1 < ntd)
             ? (u32)(o->bulk_td_phys + (u64)(i + 1) * sizeof(driver_usb_ohci_td_t))
```
- AFTER hunk:
```
             memcpy(o->bulk_buf + done_bytes,
                       (const void *)((uintptr_t)buf + done_bytes),
                       chunk);
+        /* BUG-0051 FIX: TD_R (buffer rounding) marks a TD whose transfer
+         * may legally complete with less data than buffered - that is a
+         * property of IN endpoints receiving a short packet, most
+         * importantly on the FINAL TD. The old condition attached TD_R
+         * to every TD EXCEPT the last one, so a bulk-IN short packet
+         * ended the queue with DataUnderrun (treated as EIO) and the
+         * partially-received data was discarded. Follow the control
+         * path above: round on all IN TDs. */
         tds[i].word0 = TD_CC_NOTACC | dp | (tog ? TD_T1 : TD_T0) |
+                       (chunk - 1) | (dp == TD_DP_IN ? TD_R : 0);
         tds[i].cur = (u32)(o->bulk_buf_phys + done_bytes);
         tds[i].next = (i + 1 < ntd)
             ? (u32)(o->bulk_td_phys + (u64)(i + 1) * sizeof(driver_usb_ohci_td_t))
```

## BUG-0053 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_msc.c:131-150
- Issue: , 178-200
- BEFORE hunk:
```
               ((u32)csw[3] << 24);
     u32 rtag = (u32)csw[4] | ((u32)csw[5] << 8) | ((u32)csw[6] << 16) |
                ((u32)csw[7] << 24);
     u8 status = csw[12];
     m->busy = 0;
     if (sig != MSC_CSW_SIG || rtag != tag) {
         screen_console_puts("msc: CSW bad signature or tag\n");
         return -1;
     }
     if (status != 0) {
         /* command failed: fetch sense to clear the condition.  busy
          * is already cleared here; the sense BOT manages its own busy
```
- AFTER hunk:
```
               ((u32)csw[3] << 24);
     u32 rtag = (u32)csw[4] | ((u32)csw[5] << 8) | ((u32)csw[6] << 16) |
                ((u32)csw[7] << 24);
+    u32 res = (u32)csw[8] | ((u32)csw[9] << 8) | ((u32)csw[10] << 16) |
+              ((u32)csw[11] << 24);
     u8 status = csw[12];
     m->busy = 0;
     if (sig != MSC_CSW_SIG || rtag != tag) {
         screen_console_puts("msc: CSW bad signature or tag\n");
         return -1;
     }
+    /* BUG-0053 FIX: validate dCBWDataResidue. The data phase used to
+     * treat a short IN packet as a clean early exit, and the CSW
+     * residue field was never read - so a device (or an attacker) that
+     * delivered less data than the command asked for still reported
+     * CSW status PASS and the caller happily used a partially-filled
+     * buffer (silent data corruption on reads). Now: on a short IN
+     * transfer the missing bytes must equal the CSW residue, and any
+     * shortfall on a read is an error, never a success. */
+    if (data_len) {
+        u32 expected = data_len - done;   /* OUT: done == data_len -> 0 */
+        if (res != expected || done < data_len) {
+            char l[96]; char n[12]; char n2[12];
+          
```

## BUG-0054 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_msc.c:243-249
- Issue: , 375-380
- BEFORE hunk:
```
               ((u32)csw[3] << 24);
     u32 rtag = (u32)csw[4] | ((u32)csw[5] << 8) | ((u32)csw[6] << 16) |
                ((u32)csw[7] << 24);
     u8 status = csw[12];
     m->busy = 0;
     if (sig != MSC_CSW_SIG || rtag != tag) {
         screen_console_puts("msc: CSW bad signature or tag\n");
         return -1;
     }
     if (status != 0) {
         /* command failed: fetch sense to clear the condition.  busy
          * is already cleared here; the sense BOT manages its own busy
```
- AFTER hunk:
```
               ((u32)csw[3] << 24);
     u32 rtag = (u32)csw[4] | ((u32)csw[5] << 8) | ((u32)csw[6] << 16) |
                ((u32)csw[7] << 24);
+    u32 res = (u32)csw[8] | ((u32)csw[9] << 8) | ((u32)csw[10] << 16) |
+              ((u32)csw[11] << 24);
     u8 status = csw[12];
     m->busy = 0;
     if (sig != MSC_CSW_SIG || rtag != tag) {
         screen_console_puts("msc: CSW bad signature or tag\n");
         return -1;
     }
+    /* BUG-0053 FIX: validate dCBWDataResidue. The data phase used to
+     * treat a short IN packet as a clean early exit, and the CSW
+     * residue field was never read - so a device (or an attacker) that
+     * delivered less data than the command asked for still reported
+     * CSW status PASS and the caller happily used a partially-filled
+     * buffer (silent data corruption on reads). Now: on a short IN
+     * transfer the missing bytes must equal the CSW residue, and any
+     * shortfall on a read is an error, never a success. */
+    if (data_len) {
+        u32 expected = data_len - done;   /* OUT: done == data_len -> 0 */
+        if (res != expected || done < data_len) {
+            char l[96]; char n[12]; char n2[12];
+          
```

## BUG-0055 (P1, p1fix1) — commit 1abc0c4
- Location: driver_usb_serial.c:167-169
- Issue: , 135-138
- BEFORE hunk:
```
     return -1;
 }
 
 static int driver_usb_serial_cdc_probe(driver_usb_dev_t *dev) {
-    /* CDC-ACM: control iface class 2 subclass 2 (protocol usually 1
-     * for AT commands; accept any) + data iface class 0x0a */
-    driver_usb_interface_t *ctrl =
-        driver_usb_find_if(dev, USB_CLASS_CDC, 0x02, 0xff, 0);
-    if (!ctrl) ctrl = driver_usb_find_if(dev, USB_CLASS_CDC, 0x02, 0x02, 0);
     if (!ctrl) return -1;
     if (!driver_usb_find_if(dev, USB_CLASS_CDC_DATA, 0, 0, 0)) return -1;
     return ser_claim(dev, SER_T_CDC);
```
- AFTER hunk:
```
     return -1;
 }
 
+/* BUG-0055 FIX: locate the CDC-ACM control interface without pinning
+ * bInterfaceProtocol. driver_usb_find_if matches exactly, and the old
+ * probe asked for protocol 0xff first (a value real devices essentially
+ * never report) and 0x02 second - so the overwhelmingly common
+ * bInterfaceProtocol=0x00 devices were never claimed at all. Try the
+ * documented values in order: 0x02 (AT commands, v.25ter), 0x01
+ * (AT commands), 0x00 (no specific protocol). */
+static driver_usb_interface_t *driver_usb_serial_find_cdc_ctrl(
+        driver_usb_dev_t *dev) {
+    static const u8 protos[] = { 0x02, 0x01, 0x00 };
+    for (int i = 0; i < 3; i++) {
+        driver_usb_interface_t *ifp =
+            driver_usb_find_if(dev, USB_CLASS_CDC, 0x02, protos[i], 0);
+        if (ifp) return ifp;
+    }
+    return NULL;
+}
+
 static int driver_usb_serial_cdc_probe(driver_usb_dev_t *dev) {
+    /* CDC-ACM: control iface class 2 subclass 2 (any protocol) +
+     * data iface class 0x0a */
+    driver_usb_interface_t *ctrl = driver_usb_serial_find_cdc_ctrl(dev);
     if (!ctrl) return -1;
     if (!driver_usb_find_if(dev, USB_CLASS_CDC_DATA, 0, 0, 0)) return -1;
     ret
```

## BUG-0056 (P1, p1fix1) — commit 1abc0c4
- Location: fs_fat32.c:696-708
- Issue: rmdir 对含 `.`/`..` 的标准目录永远失败
- BEFORE hunk:
```
 /* Free every cluster in the chain starting at `start_cluster`. */
 static int fs_fat32_free_cluster_chain(fs_fat32_ctx_t *ctx, u32 start_cluster) {
     u32 cluster = start_cluster;
-    while (cluster >= 2 && cluster < FAT_EOC) {
         u32 next = fs_fat32_next_cluster(ctx, cluster);
         if (fs_fat32_set_fat_entry(ctx, cluster, 0x00000000u) < 0) return -1;
         cluster = next;
```
- AFTER hunk:
```
 /* Free every cluster in the chain starting at `start_cluster`. */
 static int fs_fat32_free_cluster_chain(fs_fat32_ctx_t *ctx, u32 start_cluster) {
     u32 cluster = start_cluster;
+    u32 oc_hops = 0;   /* BUG-0058: bound the walk (corrupt chain = cycle) */
+    while (cluster >= 2 && cluster < FAT_EOC && oc_hops++ < ctx->total_clusters + 2u) {
         u32 next = fs_fat32_next_cluster(ctx, cluster);
         if (fs_fat32_set_fat_entry(ctx, cluster, 0x00000000u) < 0) return -1;
         cluster = next;
```

## BUG-0057 (P1, p1fix1) — commit 1abc0c4
- Location: fs_fat32.c:1321
- Issue: 、1367-1381   g_last_ctx 在 umount 后悬挂 → df 触发 UAF
- BEFORE hunk:
```
 /* Free every cluster in the chain starting at `start_cluster`. */
 static int fs_fat32_free_cluster_chain(fs_fat32_ctx_t *ctx, u32 start_cluster) {
     u32 cluster = start_cluster;
-    while (cluster >= 2 && cluster < FAT_EOC) {
         u32 next = fs_fat32_next_cluster(ctx, cluster);
         if (fs_fat32_set_fat_entry(ctx, cluster, 0x00000000u) < 0) return -1;
         cluster = next;
```
- AFTER hunk:
```
 /* Free every cluster in the chain starting at `start_cluster`. */
 static int fs_fat32_free_cluster_chain(fs_fat32_ctx_t *ctx, u32 start_cluster) {
     u32 cluster = start_cluster;
+    u32 oc_hops = 0;   /* BUG-0058: bound the walk (corrupt chain = cycle) */
+    while (cluster >= 2 && cluster < FAT_EOC && oc_hops++ < ctx->total_clusters + 2u) {
         u32 next = fs_fat32_next_cluster(ctx, cluster);
         if (fs_fat32_set_fat_entry(ctx, cluster, 0x00000000u) < 0) return -1;
         cluster = next;
```

## BUG-0058 (P1, p1fix1) — commit 1abc0c4
- Location: fs_fat32.c:251-259、389、443、696；fs_exfat.c:229-236
- Issue: 、319、576-580、801、406   FAT/exFAT 簇链遍历无环检测 → 内核死循环（挂死）
- BEFORE hunk:
```
 /* Free every cluster in the chain starting at `start_cluster`. */
 static int fs_fat32_free_cluster_chain(fs_fat32_ctx_t *ctx, u32 start_cluster) {
     u32 cluster = start_cluster;
-    while (cluster >= 2 && cluster < FAT_EOC) {
         u32 next = fs_fat32_next_cluster(ctx, cluster);
         if (fs_fat32_set_fat_entry(ctx, cluster, 0x00000000u) < 0) return -1;
         cluster = next;
```
- AFTER hunk:
```
 /* Free every cluster in the chain starting at `start_cluster`. */
 static int fs_fat32_free_cluster_chain(fs_fat32_ctx_t *ctx, u32 start_cluster) {
     u32 cluster = start_cluster;
+    u32 oc_hops = 0;   /* BUG-0058: bound the walk (corrupt chain = cycle) */
+    while (cluster >= 2 && cluster < FAT_EOC && oc_hops++ < ctx->total_clusters + 2u) {
         u32 next = fs_fat32_next_cluster(ctx, cluster);
         if (fs_fat32_set_fat_entry(ctx, cluster, 0x00000000u) < 0) return -1;
         cluster = next;
```

## BUG-0059 (P1, p1fix1) — commit 1abc0c4
- Location: fs_exfat.c:213-236
- Issue: （设计面）  exFAT 分配位图（0x81）从不读写 → 位图与 FAT 不一致
- BEFORE hunk:
```
     return rc;
 }
 
 static u32 fs_exfat_alloc_cluster(fs_exfat_ctx_t *ctx) {
     u32 start = ctx->last_alloc ? ctx->last_alloc + 1 : 2;
     if (start < 2 || start >= ctx->cluster_count + 2) start = 2;
```
- AFTER hunk:
```
     return rc;
 }
 
+static u64 fs_exfat_cluster_sector(fs_exfat_ctx_t *ctx, u32 cluster);
+
+/* BUG-0059: allocation bitmap maintenance. The exFAT spec keeps the
+ * free/used state of every cluster in the allocation bitmap (the FAT
+ * only records chains); skipping it means the on-disk bitmap drifts
+ * out of sync with what the driver actually allocated, so any other
+ * implementation (or fsck) reads the volume wrong. */
+static inline int fs_exfat_bitmap_get(const fs_exfat_ctx_t *ctx, u32 cluster) {
+    if (!ctx->bitmap_cache || cluster < 2 || cluster >= ctx->cluster_count + 2)
+        return -1;
+    u64 bit = (u64)(cluster - 2);
+    return (ctx->bitmap_cache[bit >> 3] >> (bit & 7)) & 1;
+}
+static void fs_exfat_bitmap_set(fs_exfat_ctx_t *ctx, u32 cluster, int val) {
+    if (!ctx->bitmap_cache || cluster < 2 || cluster >= ctx->cluster_count + 2)
+        return;
+    u64 bit = (u64)(cluster - 2);
+    u8 mask = (u8)(1u << (bit & 7));
+    if (val) ctx->bitmap_cache[bit >> 3] |= mask;
+    else     ctx->bitmap_cache[bit >> 3] &= (u8)~mask;
+}
+static int fs_exfat_bitmap_writeback(fs_exfat_ctx_t *ctx) {
+    if (!ctx->bitmap_cache) return 0;
+    u32 spc = ctx->sectors_pe
```

## BUG-0060 (P1, p1fix1) — commit 1abc0c4
- Location: fs_ext4.c:317
- Issue: 、348-349   extent 条目起始偏移错误（root +16 字节、child +8 字节，正确均为 +12）→ extent 卷读错数据
- Manual HEAD verification: fs_ext4.c:374,392 hdr+12（grep 实证）
- BEFORE hunk:
```
     u16 n_entries = hdr->eh_entries;
     if (n_entries > max_entries) n_entries = max_entries;
     if (hdr->eh_depth == 0) {
-        const fs_ext4_extent_t *ext = (const fs_ext4_extent_t *)(i_block + 4);
         for (u16 i = 0; i < n_entries; i++) {
             if (logical >= ext[i].ee_block &&
                 logical < ext[i].ee_block + ext[i].ee_len) {
```
- AFTER hunk:
```
     u16 n_entries = hdr->eh_entries;
     if (n_entries > max_entries) n_entries = max_entries;
     if (hdr->eh_depth == 0) {
+        /* BUG-0060 FIX: extent entries start at i_block + 12 bytes (the
+         * extent header is 12 bytes: magic/entries/max/depth/generation).
+         * The old pointer arithmetic used i_block + 4 where i_block is a
+         * u32 pointer, i.e. +16 bytes - every extent lookup on the root
+         * node read the wrong entry. */
+        const fs_ext4_extent_t *ext =
+            (const fs_ext4_extent_t *)((const u8 *)i_block + 12);
         for (u16 i = 0; i < n_entries; i++) {
             if (logical >= ext[i].ee_block &&
                 logical < ext[i].ee_block + ext[i].ee_len) {
```

## BUG-0061 (P1, p1fix1) — commit 1abc0c4
- Location: fs_ramfs.c:224-243；fs_fat32.c:812-907
- Issue: unlink 后仍打开的 fd 继续写：ramfs UAF 写 / FAT32 复活已释放簇链（可破坏他文件）
- BEFORE hunk:
```
      * mount table entry stays in use -> KNOWN_ISSUES BUG-019 "mount
      * point occasionally disappears" + later UAF. */
     if (child->fs_type != &g_ramfs_fs_type) return -5;  /* not ours */
     fs_vfs_detach_child(child);
     fs_ramfs_inode_t *ri = (fs_ramfs_inode_t *)child->private;
     if (ri) {
```
- AFTER hunk:
```
      * mount table entry stays in use -> KNOWN_ISSUES BUG-019 "mount
      * point occasionally disappears" + later UAF. */
     if (child->fs_type != &g_ramfs_fs_type) return -5;  /* not ours */
+    /* BUG-0061 FIX: refuse to free the inode while an fd still points at
+     * this node - a writer through the still-open fd would hit freed
+     * memory (UAF) after we kfree() here. */
+    if (child->open_count > 0) return -4;   /* EBUSY: fd still open */
     fs_vfs_detach_child(child);
     fs_ramfs_inode_t *ri = (fs_ramfs_inode_t *)child->private;
     if (ri) {
```

## BUG-0062 (P1, p1fix1) — commit 1abc0c4
- Location: fs_ext4.c:253-273
- Issue: 、276-297、444-472   crafted 卷多处越界读（栈/堆）
- BEFORE hunk:
```
     }
     u64 desc_sector = desc_byte_offset / 512;
     u32 off_in_sec = (u32)(desc_byte_offset % 512);
     int rc = driver_block_ata_read_sectors(ctx->drive, desc_sector, 1, buf);
     if (rc != 1) return -1;
     memcpy(gd, buf + off_in_sec, desc_size);
```
- AFTER hunk:
```
     }
     u64 desc_sector = desc_byte_offset / 512;
     u32 off_in_sec = (u32)(desc_byte_offset % 512);
+    /* BUG-0062 FIX: a crafted sector/cluster geometry can push the
+     * descriptor across the sector boundary; the unbounded memcpy then
+     * read past the 512-byte stack buffer. Also reject groups that are
+     * obviously out of range before doing any I/O. */
+    if (off_in_sec + desc_size > 512) return -1;
     int rc = driver_block_ata_read_sectors(ctx->drive, desc_sector, 1, buf);
     if (rc != 1) return -1;
     memcpy(gd, buf + off_in_sec, desc_size);
```

## BUG-0063 (P1, p1fix1) — commit 1abc0c4
- Location: net_core.c:3540-3578
- Issue: + 2212-2224 vs 2362-2395   IRQ 与线程对 TCP rtx/rx 状态的无锁竞态
- BEFORE hunk:
```
 
     /* Debug: print PCI info. */
     {
         char buf[80]; char n[20];
         u32 shell_cmd_reg = driver_pci_read_config(bus, dev, func, 0x04);
         strcat(buf, " dev="); u64_to_str(dev, n); strcat(buf, n);
         strcat(buf, " func="); u64_to_str(func, n); strcat(buf, n);
         strcat(buf, " cmd=0x"); u64_to_hex(shell_cmd_reg, n, 4); strcat(buf, n);
```
- AFTER hunk:
```
 
     /* Debug: print PCI info. */
     {
+        /* BUG-0064 FIX: buf was an uninitialised 80-byte stack array and
+         * the debug block started with strcat() - the string length came
+         * from whatever garbage was on the stack, so the write could run
+         * past the end of the buffer. Start with buf[0]=0. */
         char buf[80]; char n[20];
         u32 shell_cmd_reg = driver_pci_read_config(bus, dev, func, 0x04);
+        buf[0] = 0;
         strcat(buf, " dev="); u64_to_str(dev, n); strcat(buf, n);
         strcat(buf, " func="); u64_to_str(func, n); strcat(buf, n);
         strcat(buf, " cmd=0x"); u64_to_hex(shell_cmd_reg, n, 4); strcat(buf, n);
```

## BUG-0064 (P1, p1fix1) — commit 1abc0c4
- Location: net_core.c:566-573
- Issue: 与 645-657   e1000_init 对未初始化栈缓冲调用 strcat
- BEFORE hunk:
```
 
     /* Debug: print PCI info. */
     {
         char buf[80]; char n[20];
         u32 shell_cmd_reg = driver_pci_read_config(bus, dev, func, 0x04);
         strcat(buf, " dev="); u64_to_str(dev, n); strcat(buf, n);
         strcat(buf, " func="); u64_to_str(func, n); strcat(buf, n);
         strcat(buf, " cmd=0x"); u64_to_hex(shell_cmd_reg, n, 4); strcat(buf, n);
```
- AFTER hunk:
```
 
     /* Debug: print PCI info. */
     {
+        /* BUG-0064 FIX: buf was an uninitialised 80-byte stack array and
+         * the debug block started with strcat() - the string length came
+         * from whatever garbage was on the stack, so the write could run
+         * past the end of the buffer. Start with buf[0]=0. */
         char buf[80]; char n[20];
         u32 shell_cmd_reg = driver_pci_read_config(bus, dev, func, 0x04);
+        buf[0] = 0;
         strcat(buf, " dev="); u64_to_str(dev, n); strcat(buf, n);
         strcat(buf, " func="); u64_to_str(func, n); strcat(buf, n);
         strcat(buf, " cmd=0x"); u64_to_hex(shell_cmd_reg, n, 4); strcat(buf, n);
```

## BUG-0065 (P1, p1fix1) — commit 1abc0c4
- Location: ld_so.c:371-379
- Issue: , 419-426, 493-500, 508-514, 549-560, 590-597, 616-623   .dynamic 遍历无界（d_tag 循环仅靠 DT_NULL 终止）
- Manual HEAD verification: libs/ld_so.c:248 LDSO_DYN_MAX=64 两处循环有界（grep 实证）
- BEFORE hunk:
```
         unsigned long so_rela = 0, so_relasz = 0;
         unsigned long so_jmprel = 0, so_pltrelsz = 0;
         int i;
-        for (i = 0; ; i++) {
             if (dyn[i].tag == DT_NULL) break;
             if (dyn[i].tag == DT_SYMTAB) so_symtab = base + dyn[i].val;
             else if (dyn[i].tag == DT_STRTAB) so_strtab = base + dyn[i].val;
```
- AFTER hunk:
```
         unsigned long so_rela = 0, so_relasz = 0;
         unsigned long so_jmprel = 0, so_pltrelsz = 0;
         int i;
+        /* BUG-0065 FIX: the walk used to rely solely on hitting DT_NULL.
+         * A crafted .dynamic without a terminator makes i run away
+         * reading kernel memory. Bound every walk to 64 entries
+         * (far more than any real shared object needs). */
+        for (i = 0; i < 64; i++) {
             if (dyn[i].tag == DT_NULL) break;
             if (dyn[i].tag == DT_SYMTAB) so_symtab = base + dyn[i].val;
             else if (dyn[i].tag == DT_STRTAB) so_strtab = base + dyn[i].val;
```

## BUG-0066 (P1, p1fix1) — commit 1abc0c4
- Location: net_core.c:1520
- Issue: , 1695-1712, 2823-2843, 3077-3199   IP/UDP 长度字段未与实际帧长核对 → 远程可触发 OOB 读
- BEFORE hunk:
```
     int hdr_len = (iph->ver_ihl & 0x0F) * 4;
     if (hdr_len < 20 || len < hdr_len) return;
 
     const void *payload = (const u8 *)data + hdr_len;
     int payload_len = ntohs(iph->total_len) - hdr_len;
     u32 src_ip = ntohl(iph->src_ip);
```
- AFTER hunk:
```
     int hdr_len = (iph->ver_ihl & 0x0F) * 4;
     if (hdr_len < 20 || len < hdr_len) return;
 
+    /* BUG-0066 FIX: cross-check the IP header length field against the
+     * actual frame length before trusting payload_len. A crafted
+     * total_len larger than the frame made every transport parser read
+     * past the end of the receive buffer (remote OOB read). */
+    {
+        u16 claimed = ntohs(iph->total_len);
+        if (claimed < (u16)hdr_len || claimed > len) return;
+    }
+    /* BUG-0072 FIX: verify the IP header checksum and drop corrupt
+     * datagrams. The RX path previously accepted everything unchecked. */
+    if (internet_checksum(iph, hdr_len, 0) != 0) {
+        g_stats.net_rx_bad_checksum++;
+        return;
+    }
+
     const void *payload = (const u8 *)data + hdr_len;
     int payload_len = ntohs(iph->total_len) - hdr_len;
     u32 src_ip = ntohl(iph->src_ip);
```

## BUG-0067 (P1, p1fix1) — commit 1abc0c4
- Location: net_core.c:2359
- Issue: , 2425, 2481, 2487, 2495   TCP 序号比较无回绕保护（before/after 宏缺失）
- BEFORE hunk:
```
             /* WP-09: Handle ACK for sent data */
             if (flags & TCP_ACK) {
                 /* Update driver_snd_una (slide window) */
-                if (ack > c->driver_snd_una) {
                     /* WP-09: New data ACKed — slide retransmission buffer */
                     u32 acked_bytes = ack - c->driver_snd_una;
                     if (c->rtx_len > 0 && acked_bytes <= (u32)c->rtx_len) {
```
- AFTER hunk:
```
             /* WP-09: Handle ACK for sent data */
             if (flags & TCP_ACK) {
                 /* Update driver_snd_una (slide window) */
+                if (SEQ_GT(ack, c->driver_snd_una)) {   /* BUG-0067 */
                     /* WP-09: New data ACKed — slide retransmission buffer */
                     u32 acked_bytes = ack - c->driver_snd_una;
                     if (c->rtx_len > 0 && acked_bytes <= (u32)c->rtx_len) {
```

## BUG-0068 (P1, p1fix1) — commit 1abc0c4
- Location: net_core.c:2334-2338
- Issue: RST 零验证盲注
- BEFORE hunk:
```
     }
 
     if (flags & TCP_RST) {
-        c->state = TCP_CLOSED;
-        c->in_use = 0;
         return;
     }
 
```
- AFTER hunk:
```
     }
 
     if (flags & TCP_RST) {
+        /* BUG-0068 FIX: a RST used to be accepted from anyone regardless
+         * of its sequence number (blind-reset injection). RFC 793 3.4:
+         * in SYN-RECEIVED only a RST with SEG.SEQ == SND.UNA is legal;
+         * in established states the RST sequence must fall inside the
+         * receive window. We check the same window inequality before
+         * tearing the connection down. */
+        u32 rcv_next = c->our_ack;
+        u32 rcv_wnd  = 8192;   /* receive window as advertised */
+        int in_window = SEQ_LE(rcv_next, seq) && SEQ_LT(seq, rcv_next + rcv_wnd);
+        if (c->state == TCP_SYN_RCVD)
+            in_window = (seq == rcv_next);
+        if (in_window) {
+            c->state = TCP_CLOSED;
+            c->in_use = 0;
+        }
         return;
     }
 
```

## BUG-0069 (P1, p1fix1) — commit 1abc0c4
- Location: net_core.c:2299-2327
- Issue: + 2143-2149   SYN_RCVD 永不超时 → 32 个 SYN 永久打满连接表（远程 DoS）；服务端 SYN 选项不解析
- BEFORE hunk:
```
 
     /* Debug: print PCI info. */
     {
         char buf[80]; char n[20];
         u32 shell_cmd_reg = driver_pci_read_config(bus, dev, func, 0x04);
         strcat(buf, " dev="); u64_to_str(dev, n); strcat(buf, n);
         strcat(buf, " func="); u64_to_str(func, n); strcat(buf, n);
         strcat(buf, " cmd=0x"); u64_to_hex(shell_cmd_reg, n, 4); strcat(buf, n);
```
- AFTER hunk:
```
 
     /* Debug: print PCI info. */
     {
+        /* BUG-0064 FIX: buf was an uninitialised 80-byte stack array and
+         * the debug block started with strcat() - the string length came
+         * from whatever garbage was on the stack, so the write could run
+         * past the end of the buffer. Start with buf[0]=0. */
         char buf[80]; char n[20];
         u32 shell_cmd_reg = driver_pci_read_config(bus, dev, func, 0x04);
+        buf[0] = 0;
         strcat(buf, " dev="); u64_to_str(dev, n); strcat(buf, n);
         strcat(buf, " func="); u64_to_str(func, n); strcat(buf, n);
         strcat(buf, " cmd=0x"); u64_to_hex(shell_cmd_reg, n, 4); strcat(buf, n);
```

## BUG-0070 (P1, p1fix1) — commit 1abc0c4
- Location: net_core.c:1669-1678
- Issue: + 3204/3239/3319/3369/3394/3416/3439 + 2881   net_udp_bind 无去重、无解绑，DNS 每次解析重复绑定，返回值全部被忽略
- BEFORE hunk:
```
 }
 
 int net_udp_bind(u16 port, net_udp_handler_fn handler) {
     for (int i = 0; i < UDP_MAX_HANDLERS; i++) {
         if (g_udp_handlers[i].handler == NULL) {
             g_udp_handlers[i].port = port;
```
- AFTER hunk:
```
 }
 
 int net_udp_bind(u16 port, net_udp_handler_fn handler) {
+    /* BUG-0070 FIX: reject a duplicate bind first (the DNS client used
+     * to silently pile up one binding per lookup until the table was
+     * exhausted); the caller has no way to know a second handler for
+     * the same port can never be delivered. */
+    for (int i = 0; i < UDP_MAX_HANDLERS; i++) {
+        if (g_udp_handlers[i].handler != NULL && g_udp_handlers[i].port == port)
+            return -1;
+    }
     for (int i = 0; i < UDP_MAX_HANDLERS; i++) {
         if (g_udp_handlers[i].handler == NULL) {
             g_udp_handlers[i].port = port;
```

## BUG-0071 (P1, p1fix1) — commit 1abc0c4
- Location: net_core.c:2084
- Issue: + 2049-2057   窗口缩放错配：通告 scale=7 但窗口值不缩放 → 对端以为有 1MB 缓冲（实际 8KB）
- BEFORE hunk:
```
     c->rto_deadline = 0;
     c->dup_ack_count = 0;
     c->mss = 1460;         /* default MSS (Ethernet MTU - 40) */
-    c->win_scale_sent = 7; /* window scale: 2^7 = 128 → 8192*128 = 1MB */
     c->win_scale_recv = 0;
     c->ts_recent = 0;
     c->ts_echo = 0;
```
- AFTER hunk:
```
     c->rto_deadline = 0;
     c->dup_ack_count = 0;
     c->mss = 1460;         /* default MSS (Ethernet MTU - 40) */
+    c->win_scale_sent = 0;   /* BUG-0071: do not advertise a scale we never apply */ /* window scale: 2^7 = 128 → 8192*128 = 1MB */
     c->win_scale_recv = 0;
     c->ts_recent = 0;
     c->ts_echo = 0;
```

## BUG-0072 (P1, p1fix1) — commit 7fa48a1
- Location: net_core.c:2271-2606
- Issue: （全 RX 路径）  IP/TCP/UDP/ICMP 接收校验和一概不验证
- BEFORE hunk:
```
     return (u16)(~sum);
 }
 
 /* ============================================================
  * Network configuration state
  * ============================================================ */
```
- AFTER hunk:
```
     return (u16)(~sum);
 }
 
+/* RFC 1071-style raw accumulator WITHOUT the final complement. Use this
+ * (checksum_fold included) when a checksum must span several buffers
+ * (pseudo-header + segment), because internet_checksum() complements on
+ * every call and two chained calls complement twice - the verification
+ * then fails for EVERY valid packet. That was the BUG-0072 regression
+ * found while re-running the SSH/HTTPS end-to-end suites on p1fix3:
+ * every inbound TCP segment was dropped as "bad checksum", so sshd,
+ * the kernel ssh client and the TLS server all starved. */
+static u32 checksum_raw_add(const void *data, int len, u32 sum) {
+    const u16 *p = (const u16 *)data;
+    while (len > 1) {
+        sum += *p++;
+        len -= 2;
+    }
+    if (len == 1) {
+        sum += *(const u8 *)p;
+    }
+    return sum;   /* caller folds with checksum_fold() */
+}
+
+static u16 checksum_fold(u32 sum) {
+    while (sum >> 16) {
+        sum = (sum & 0xFFFF) + (sum >> 16);
+    }
+    return (u16)sum;
+}
+
 /* ============================================================
  * Network configuration state
  * ============================================================ *
```

## BUG-0073 (P1, p1fix2) — commit 906f151
- Location: net/net_ssh.c:484-571
- Issue: （配合 net_ssh.h:21-23,31）  SSH 客户端主机密钥验证是"仅签名、无锚点"的 TOFU → 无 MITM 防护
- BEFORE hunk:
```
 #include "lib_string.h"
 #include "mem_pmm.h"
 #include "core_timer.h"
 
 /* SSH message types (RFC 4254 §4) */
 #define SSH_MSG_KEXINIT         20
```
- AFTER hunk:
```
 #include "lib_string.h"
 #include "mem_pmm.h"
 #include "core_timer.h"
+#include "fs_vfs.h"
 
 /* SSH message types (RFC 4254 §4) */
 #define SSH_MSG_KEXINIT         20
```

## BUG-0074 (P1, p1fix2) — commit 906f151
- Location: net/net_ssh.c:320
- Issue: ,389 / net_sshd.c:587-587,685,743 / net_tls.c:247-251,875,896   A4-02（xorshift32 PRNG）在协议层的完整影响面
- BEFORE hunk:
```
 #include "lib_string.h"
 #include "mem_pmm.h"
 #include "core_timer.h"
 
 /* SSH message types (RFC 4254 §4) */
 #define SSH_MSG_KEXINIT         20
```
- AFTER hunk:
```
 #include "lib_string.h"
 #include "mem_pmm.h"
 #include "core_timer.h"
+#include "fs_vfs.h"
 
 /* SSH message types (RFC 4254 §4) */
 #define SSH_MSG_KEXINIT         20
```

## BUG-0075 (P1, p1fix2) — commit ad4ca78
- Location: net/net_sshd_rsa_key.h:7-43
- Issue: + net_sshd.c:854-950 + net_ssh.c:870-957   内嵌"万能"RSA 私钥同时充当 sshd 主机密钥、sshd 授权用户密钥、SSH 客户端身份密钥
- BEFORE hunk:
```
 #include "lib_string.h"
 #include "core_timer.h"
 
-/* bring-up debugging (0 = quiet, production; 1 = verbose during bring-up) */
-#define TLS_DBG 1
 #if TLS_DBG
 #include "screen_console.h"
 #define TLS_DBG_P(msg) screen_console_puts("[tls-dbg] " msg "\n")
```
- AFTER hunk:
```
 #include "lib_string.h"
 #include "core_timer.h"
 
+/* bring-up debugging (0 = quiet, production; 1 = verbose during bring-up.
+ * To re-enable: set to 1 and rebuild the kernel; all probes are compiled out
+ * at 0, so there is zero runtime cost on the release image. */
+#define TLS_DBG 0
 #if TLS_DBG
 #include "screen_console.h"
 #define TLS_DBG_P(msg) screen_console_puts("[tls-dbg] " msg "\n")
```

## BUG-0076 (P1, p1fix2) — commit 906f151
- Location: net/net_tls.c:133-136
- Issue: + 1124   AES-256-GCM / ChaCha20-Poly1305 套件密钥长度硬编码 16 字节 → 选中即失败
- BEFORE hunk:
```
     net_tls13_ks_derive_secret(secret, label, thash, thash_len, out);
 }
 
-static void net_tls13_traffic_keys(const u8 *secret, u8 *key, u8 *iv) {
-    net_tls13_expand_label(secret, 32, "key", NULL, 0, key, 16);
     net_tls13_expand_label(secret, 32, "iv", NULL, 0, iv, 12);
 }
 
```
- AFTER hunk:
```
     net_tls13_ks_derive_secret(secret, label, thash, thash_len, out);
 }
 
+/* BUG-0076 FIX (A14-25): the key length must follow the negotiated
+ * cipher suite, not a hardcoded 16. TLS_AES_128_GCM_SHA256 uses a
+ * 16-byte key, but TLS_AES_256_GCM_SHA384 and
+ * TLS_CHACHA20_POLY1305_SHA256 both use 32-byte keys (RFC 8446
+ * appendix B.4). The old code always expanded 16 bytes, so the
+ * moment either 32-byte suite was selected the AEAD was keyed with a
+ * truncated key and every handshake after EncryptedExtensions
+ * failed the decrypt ("selecting the suite = guaranteed failure").
+ * The wkey/rkey buffers are already 32 bytes (net_tls.h). */
+static int net_tls13_key_len(int cipher) {
+    if (cipher == CS_TLS13_AES256GCM_SHA384 ||
+        cipher == CS_TLS13_CHACHA20POLY1305_SHA256) return 32;
+    return 16;
+}
+
+static void net_tls13_traffic_keys(const u8 *secret, u8 *key, u8 *iv, int key_len) {
+    net_tls13_expand_label(secret, 32, "key", NULL, 0, key, key_len);
     net_tls13_expand_label(secret, 32, "iv", NULL, 0, iv, 12);
 }
 
```

## BUG-0077 (P1, p1fix2) — commit 906f151
- Location: net/net_tls.c:587-588
- Issue: TLS1.3 CertificateEntry 扩展只跳长度不跳数据 → 带 SCT 的常见证书链解析错位
- BEFORE hunk:
```
         int thl = transcript_hash(c, th);
         net_tls13_derive_secret(c->hs_secret, "c hs traffic", th, thl, c->c_hs);
         net_tls13_derive_secret(c->hs_secret, "s hs traffic", th, thl, c->s_hs);
-        net_tls13_traffic_keys(c->c_hs, c->wkey, c->wiv);
-        net_tls13_traffic_keys(c->s_hs, c->rkey, c->riv);
         c->wseq = c->rseq = 0;
         c->hs_keys_active = 1;
         TLS_DBG_P("handshake keys derived");
```
- AFTER hunk:
```
         int thl = transcript_hash(c, th);
         net_tls13_derive_secret(c->hs_secret, "c hs traffic", th, thl, c->c_hs);
         net_tls13_derive_secret(c->hs_secret, "s hs traffic", th, thl, c->s_hs);
+        net_tls13_traffic_keys(c->c_hs, c->wkey, c->wiv, net_tls13_key_len(c->cipher));
+        net_tls13_traffic_keys(c->s_hs, c->rkey, c->riv, net_tls13_key_len(c->cipher));
         c->wseq = c->rseq = 0;
         c->hs_keys_active = 1;
         TLS_DBG_P("handshake keys derived");
```

## BUG-0078 (P1, p1fix2) — commit 906f151
- Location: net/net_tls.c:106-116
- Issue: + 420-424   transcript/hs_log 9216 字节静默截断 → 大证书链 Finished 必败
- BEFORE hunk:
```
 }
 
 static void transcript_push(net_tls_ctx_t *c, const void *data, int len) {
-    if (c->transcript_len + len > (int)sizeof(c->transcript)) return;
     memcpy(c->transcript + c->transcript_len, data, len);
     c->transcript_len += len;
 }
 
 static void hs_log_push(net_tls_ctx_t *c, const void *data, int len) {
-    if (c->hs_log_len + len > (int)sizeof(c->hs_log)) return;
     memcpy(c->hs_log + c->hs_log_len, data, len);
     c->hs_log_len += len;
 }
```
- AFTER hunk:
```
 }
 
 static void transcript_push(net_tls_ctx_t *c, const void *data, int len) {
+    /* BUG-0078 FIX (A14-27): overflow is no longer silent. Flag it and
+     * report it; the handshake checks the flag before Finished. */
+    if (len < 0 || c->transcript_len + len > (int)sizeof(c->transcript)) {
+        c->transcript_overflow = 1;
+        return;
+    }
     memcpy(c->transcript + c->transcript_len, data, len);
     c->transcript_len += len;
 }
 
 static void hs_log_push(net_tls_ctx_t *c, const void *data, int len) {
+    if (len < 0 || c->hs_log_len + len > (int)sizeof(c->hs_log)) {
+        c->hs_log_overflow = 1;
+        return;
+    }
     memcpy(c->hs_log + c->hs_log_len, data, len);
     c->hs_log_len += len;
 }
```

## BUG-0079 (P1, p1fix2) — commit 7fa48a1
- Location: net/net_tls.c:476-507
- Issue: ServerHello 解析无边界（sid_len/ext_total 不设限）→ OOB 读至 #PF
- BEFORE hunk:
```
         memcpy(c->server_random, body + p, 32); p += 32;
         if (p >= blen) return -1;
         int sid_len = body[p++];
-        if (p + sid_len + 4 > blen) return -1;   /* sid + cipher(2) + compression(1) */
         p += sid_len;
         c->cipher = ((int)body[p] << 8) | body[p + 1]; p += 2;
         p += 1;
-        if (p + 2 > blen) return -1;
-        int ext_total = ((int)body[p] << 8) | body[p + 1]; p += 2;
-        if (p + ext_total > blen) return -1;   /* ext block must fit in the message */
-        int end = p + ext_total;
         while (p + 4 <= end) {
             int etype = ((int)body[p] << 8) | body[p + 1];
             int elen = ((int)body[p + 2] << 8) | body[p + 3];
```
- AFTER hunk:
```
         memcpy(c->server_random, body + p, 32); p += 32;
         if (p >= blen) return -1;
         int sid_len = body[p++];
+        /* sid + cipher(2) + compression(1) = 3 bytes after sid_len; the old
+         * BUG-0079 check added 4 and rejected every extension-less
+         * ServerHello (58 bytes) with an off-by-one. */
+        if (p + sid_len + 3 > blen) return -1;
         p += sid_len;
         c->cipher = ((int)body[p] << 8) | body[p + 1]; p += 2;
         p += 1;
+        /* RFC 5246 7.4.1.2: the extensions block is OPTIONAL in TLS 1.2 —
+         * a ServerHello without one ends right after the compression byte.
+         * The old code unconditionally read ext_total and refused valid
+         * extension-less ServerHellos. */
+        if (p + 2 <= blen) {
+            int ext_total = ((int)body[p] << 8) | body[p + 1]; p += 2;
+            if (p + ext_total > blen) return -1;   /* ext block must fit in the message */
+            int end = p + ext_total;
         while (p + 4 <= end) {
             int etype = ((int)body[p] << 8) | body[p + 1];
             int elen = ((int)body[p + 2] << 8) | body[p + 3];
```

## BUG-0080 (P1, p1fix2) — commit 906f151
- Location: net/net_tls.c:382-407
- Issue: 0 长度记录导致握手无限循环（远程挂死）
- Manual HEAD verification: net/net_tls.c:662-694 stalls 计数器（grep 实证）
- BEFORE hunk:
```
 #include "core_timer.h"
 
 /* bring-up debugging (0 = quiet, production; 1 = verbose during bring-up) */
-#define TLS_DBG 0
 #if TLS_DBG
 #include "screen_console.h"
 #define TLS_DBG_P(msg) screen_console_puts("[tls-dbg] " msg "\n")
```
- AFTER hunk:
```
 #include "core_timer.h"
 
 /* bring-up debugging (0 = quiet, production; 1 = verbose during bring-up) */
+#define TLS_DBG 1
 #if TLS_DBG
 #include "screen_console.h"
 #define TLS_DBG_P(msg) screen_console_puts("[tls-dbg] " msg "\n")
```

## BUG-0081 (P1, p1fix2) — commit 906f151
- Location: net/net_tls.c:1314-1318
- Issue: net_tls_recv 对 KEY_UPDATE/NEW_SESSION_TICKET 无界递归 → 远程栈耗尽
- Manual HEAD verification: net/net_tls.c:1850-1882 KEY_UPDATE 处理（grep 实证）
- BEFORE hunk:
```
 #include "core_timer.h"
 
 /* bring-up debugging (0 = quiet, production; 1 = verbose during bring-up) */
-#define TLS_DBG 0
 #if TLS_DBG
 #include "screen_console.h"
 #define TLS_DBG_P(msg) screen_console_puts("[tls-dbg] " msg "\n")
```
- AFTER hunk:
```
 #include "core_timer.h"
 
 /* bring-up debugging (0 = quiet, production; 1 = verbose during bring-up) */
+#define TLS_DBG 1
 #if TLS_DBG
 #include "screen_console.h"
 #define TLS_DBG_P(msg) screen_console_puts("[tls-dbg] " msg "\n")
```

## BUG-0082 (P1, p1fix2) — commit 906f151
- Location: net/net_tls.c:583
- Issue: ,592,957,963   A4-01（X509 DER 负长度 P0）从本路四个入口全部可达（影响面确认）
- BEFORE hunk:
```
         int thl = transcript_hash(c, th);
         net_tls13_derive_secret(c->hs_secret, "c hs traffic", th, thl, c->c_hs);
         net_tls13_derive_secret(c->hs_secret, "s hs traffic", th, thl, c->s_hs);
-        net_tls13_traffic_keys(c->c_hs, c->wkey, c->wiv);
-        net_tls13_traffic_keys(c->s_hs, c->rkey, c->riv);
         c->wseq = c->rseq = 0;
         c->hs_keys_active = 1;
         TLS_DBG_P("handshake keys derived");
```
- AFTER hunk:
```
         int thl = transcript_hash(c, th);
         net_tls13_derive_secret(c->hs_secret, "c hs traffic", th, thl, c->c_hs);
         net_tls13_derive_secret(c->hs_secret, "s hs traffic", th, thl, c->s_hs);
+        net_tls13_traffic_keys(c->c_hs, c->wkey, c->wiv, net_tls13_key_len(c->cipher));
+        net_tls13_traffic_keys(c->s_hs, c->rkey, c->riv, net_tls13_key_len(c->cipher));
         c->wseq = c->rseq = 0;
         c->hs_keys_active = 1;
         TLS_DBG_P("handshake keys derived");
```

## BUG-0083 (P1, p1fix2) — commit 906f151
- Location: shell.c:1125-1129
- Issue: + 1361-1391   嵌套 capture 逻辑错误（可远程触发，含数据污染）
- BEFORE hunk:
```
 /* Execute a single command word + args string. Returns 1 if found, 0 if not. */
 static int shell_run_simple(const char *cmd, const char *args) {
     shell_cmd_fn fn = shell_lookup(cmd);
-    if (!fn) return 0;
     fn(args);
     return 1;
 }
```
- AFTER hunk:
```
 /* Execute a single command word + args string. Returns 1 if found, 0 if not. */
 static int shell_run_simple(const char *cmd, const char *args) {
     shell_cmd_fn fn = shell_lookup(cmd);
+    if (!fn) {
+        /* BUG-0092 FIX (A16-5): give L1-registered builtins (see
+         * l1_wp8cd.c shell_register_builtin) a real dispatch path:
+         * without this, names registered through the documented L1 API
+         * were stored in an orphaned table and "not found" at oc>. */
+        extern int l1_wp8cd_builtin_exec(const char *cmd, const char *args);
+        if (l1_wp8cd_builtin_exec(cmd, args)) return 1;
+        return 0;
+    }
     fn(args);
     return 1;
 }
```

## BUG-0084 (P1, p1fix2) — commit 906f151
- Location: shell.c:892
- Issue: 别名/自覆盖（相对目录通配符全坏）
- BEFORE hunk:
```
         memcpy(dirpath, tok->text, (usize)last_slash + 1);
         dirpath[last_slash + 1] = 0;
         /* If the path was like "/foo/x.c" with a wildcard, dirpath is the
-         * parent dir (with trailing slash). Normalize it. */
-        if (shell_resolve_path(dirpath, dirpath, VFS_PATH_LEN) < 0) return -1;
         /* P0fix2 BUG-0028 (A15-1): the same bound applies to the pattern
          * after the last slash. */
         if (tlen - last_slash - 1 >= (int)sizeof(pat)) return -1;
```
- AFTER hunk:
```
         memcpy(dirpath, tok->text, (usize)last_slash + 1);
         dirpath[last_slash + 1] = 0;
         /* If the path was like "/foo/x.c" with a wildcard, dirpath is the
+         * parent dir (with trailing slash). Normalize it.
+         * BUG-0084 FIX (A15-5): the old code called
+         *   shell_resolve_path(dirpath, dirpath, ...)
+         * with the SAME buffer as input and output. For RELATIVE
+         * patterns such as "src" SLASH "*dot-c" the resolver first does
+         * strcpy(out, g_cwd) - destroying the very input it is about
+         * to read on the next line - so every relative wildcard
+         * expanded to garbage (ls/mv/cp/cd with a "dir STAR" pattern
+         * all broke). Resolve through a scratch copy instead. */
+        {
+            char dir_in[VFS_PATH_LEN];
+            strcpy(dir_in, dirpath);
+            if (shell_resolve_path(dir_in, dirpath, VFS_PATH_LEN) < 0) return -1;
+        }
         /* P0fix2 BUG-0028 (A15-1): the same bound applies to the pattern
          * after the last slash. */
         if (tlen - last_slash - 1 >= (int)sizeof(pat)) return -1;
```

## BUG-0085 (P1, p1fix2) — commit 906f151
- Location: shell_cmds_file.c:860
- Issue: , 918 + 863-865   edit 命令三重缺陷（数据丢失）
- BEFORE hunk:
```
                         ":d<num> delete line, :w save, :q quit, :wq, :q!)\n");
         return 1;
     }
     enum { CAP = 8192 };
     char *vbuf = (char *)kmalloc(CAP);
     if (!vbuf) { screen_console_puts("edit: out of memory\n"); return 1; }
     int vlen = 0;
 
-    int rfd = fs_vfs_open(args, VFS_O_RDONLY);
     if (rfd >= 0) {
         int n;
         while (vlen < CAP - 1 &&
                (n = fs_vfs_read(rfd, vbuf + vlen, CAP - 1 - vlen)) > 0)
             vlen += n;
         fs_vfs_close(rfd);
     }
     vbuf[vlen] = 0;
 
     screen_console_puts("-- ");
-    screen_console_puts(args);
     screen_console_puts(" -- ");
     {
         char nb[16];
```
- AFTER hunk:
```
                         ":d<num> delete line, :w save, :q quit, :wq, :q!)\n");
         return 1;
     }
+    /* BUG-0085 FIX (A15-6) part 1: fs_vfs_open needs ABSOLUTE paths, but
+     * edit used the raw argument for BOTH the load and the save, so a
+     * relative path failed to load (empty buffer) and then - because the
+     * O_CREAT|O_TRUNC save went through the same raw path - either saved
+     * an empty file over the WRONG location or silently worked on a
+     * different file than the user was looking at. Resolve once and use
+     * the resolved path everywhere. */
+    const char *rpath = shell_resolve_path_static(args);
+    if (!rpath) {
+        screen_console_puts("edit: bad path\n");
+        return 1;
+    }
     enum { CAP = 8192 };
     char *vbuf = (char *)kmalloc(CAP);
     if (!vbuf) { screen_console_puts("edit: out of memory\n"); return 1; }
     int vlen = 0;
+    int truncated_load = 0;   /* BUG-0085 part 2 */
 
+    int rfd = fs_vfs_open(rpath, VFS_O_RDONLY);
     if (rfd >= 0) {
         int n;
         while (vlen < CAP - 1 &&
                (n = fs_vfs_read(rfd, vbuf + vlen, CAP - 1 - vlen)) > 0)
             vlen += n;
+        /* BUG-0085 FIX (
```

## BUG-0086 (P1, p1fix2) — commit 906f151
- Location: shell_cmds_file.c:425-427
- Issue: , 436-439   cp 静默截断
- BEFORE hunk:
```
                 /* Stat each entry to get size for files. */
                 fs_vfs_stat_t es;
                 u64 sz = 0;
-                /* Build child path. */
                 char child[VFS_PATH_LEN];
                 int pl = (int)strlen(resolved);
                 strcpy(child, resolved);
-                if (pl > 0 && child[pl - 1] != '/') {
                     child[pl++] = '/';
                     child[pl] = 0;
                 }
```
- AFTER hunk:
```
                 /* Stat each entry to get size for files. */
                 fs_vfs_stat_t es;
                 u64 sz = 0;
+                /* Build child path.
+                 * BUG-0087 FIX (A15-8): resolved + '/' + e.name was
+                 * strcpy'd into a fixed buffer with NO bound check - a
+                 * long cwd (or a deep listing path) plus a long entry
+                 * name overflowed the stack frame. Bound the join and
+                 * skip entries that cannot fit. */
                 char child[VFS_PATH_LEN];
                 int pl = (int)strlen(resolved);
+                int need_slash = (pl > 0 && resolved[pl - 1] != '/');
+                int el = (int)strlen(e.name);
+                if (pl + need_slash + el + 1 > (int)sizeof(child)) {
+                    print_dirent(e.name, e.type, 0);
+                    continue;
+                }
                 strcpy(child, resolved);
+                if (need_slash) {
                     child[pl++] = '/';
                     child[pl] = 0;
                 }
```

## BUG-0087 (P1, p1fix2) — commit 906f151
- Location: shell_cmds_file.c:132-139
- Issue: （ls）、482-489（tree_walk）、602-609（du_walk）  无界子路径拼接（条件性栈溢出）
- BEFORE hunk:
```
                 /* Stat each entry to get size for files. */
                 fs_vfs_stat_t es;
                 u64 sz = 0;
-                /* Build child path. */
                 char child[VFS_PATH_LEN];
                 int pl = (int)strlen(resolved);
                 strcpy(child, resolved);
-                if (pl > 0 && child[pl - 1] != '/') {
                     child[pl++] = '/';
                     child[pl] = 0;
                 }
```
- AFTER hunk:
```
                 /* Stat each entry to get size for files. */
                 fs_vfs_stat_t es;
                 u64 sz = 0;
+                /* Build child path.
+                 * BUG-0087 FIX (A15-8): resolved + '/' + e.name was
+                 * strcpy'd into a fixed buffer with NO bound check - a
+                 * long cwd (or a deep listing path) plus a long entry
+                 * name overflowed the stack frame. Bound the join and
+                 * skip entries that cannot fit. */
                 char child[VFS_PATH_LEN];
                 int pl = (int)strlen(resolved);
+                int need_slash = (pl > 0 && resolved[pl - 1] != '/');
+                int el = (int)strlen(e.name);
+                if (pl + need_slash + el + 1 > (int)sizeof(child)) {
+                    print_dirent(e.name, e.type, 0);
+                    continue;
+                }
                 strcpy(child, resolved);
+                if (need_slash) {
                     child[pl++] = '/';
                     child[pl] = 0;
                 }
```

## BUG-0088 (P1, p1fix2) — commit 906f151
- Location: userprogs/ush.c:803-812
- Issue: `unalias` 无参数时 NULL 指针解引用
- BEFORE hunk:
```
         return 1;
     }
     if (streq(argv[0], "unalias")) {
         /* Simple: just overwrite with empty */
         for (int i = 0; i < g_alias_count; i++) {
             if (streq(g_alias[i].name, argv[1])) {
```
- AFTER hunk:
```
         return 1;
     }
     if (streq(argv[0], "unalias")) {
+        /* BUG-0088 FIX (A16-1): with no argument argv[1] is NULL and
+         * streq dereferenced it, crashing ush. Require a name. */
+        if (!argv[1]) {
+            puts_("usage: unalias name\n");
+            return 1;
+        }
         /* Simple: just overwrite with empty */
         for (int i = 0; i < g_alias_count; i++) {
             if (streq(g_alias[i].name, argv[1])) {
```

## BUG-0089 (P1, p1fix2) — commit 906f151
- Location: userprogs/ush.c:466
- Issue: 、1158、1189   写目标文件缺 O_TRUNC：nano/vi 保存、cp、mv 在覆盖较短内容时残留旧尾字节（数据损坏）
- BEFORE hunk:
```
 }
 
 static int unano_save(const char *file) {
-    int fd = sys_open(file, 6);   /* WRONLY|CREAT */
     if (fd < 0) return -1;
     for (int i = 0; i < unano_nlines; i++) {
         sys_write(fd, unano_lines[i], strlen_(unano_lines[i]));
```
- AFTER hunk:
```
 }
 
 static int unano_save(const char *file) {
+    /* BUG-0089 FIX (A16-2): save with O_TRUNC - without it, saving a
+     * SHORTER document over a longer existing file left the old tail
+     * bytes behind (corrupted file). */
+    int fd = sys_open(file, 22);   /* WRONLY|CREAT|TRUNC */
     if (fd < 0) return -1;
     for (int i = 0; i < unano_nlines; i++) {
         sys_write(fd, unano_lines[i], strlen_(unano_lines[i]));
```

## BUG-0090 (P1, p1fix2) — commit 906f151
- Location: userprogs/ush.c:2014-2058
- Issue: 重定向路径 fd 泄漏 + 双重 close + stdin 永久改绑
- BEFORE hunk:
```
     /* WP-08cd: Redirect — save/restore fd 0/1 instead of fork.
      * This avoids fork-related issues (child can't make syscalls
      * properly in some cases). We dup the original fd, redirect,
-     * run the builtin, then restore. */
     if (redir_out || redir_in) {
-        int saved_out __attribute__((unused)) = -1;
         if (redir_out) {
             /* P2-15 FIX: pass O_TRUNC (0x10) when not appending so that
              * `echo new > existing` truncates the existing content instead
```
- AFTER hunk:
```
     /* WP-08cd: Redirect — save/restore fd 0/1 instead of fork.
      * This avoids fork-related issues (child can't make syscalls
      * properly in some cases). We dup the original fd, redirect,
+     * run the builtin, then restore.
+     *
+     * BUG-0090 FIX (A16-3): this path had three fd-lifecycle bugs:
+     *   1. the redirect fd was never closed after dup2 (fd leak),
+     *   2. after a builtin, fd 1 was closed to "restore" the console —
+     *      but fd 1 was merely OVERWRITTEN by dup2, and closing it left
+     *      the slot empty forever (the next dup2 of the next command
+     *      then reused slot 1 for the FILE), and stdin was NEVER
+     *      restored: after `cmd < file` every later command read from
+     *      the already-closed file (stdin permanently re-bound),
+     *   3. the exec-child path closed fd 1 in the PARENT after wait()
+     *      — a double close in disguise.
+     * With the kernel-side fd refcounting (BUG-0098) the correct
+     * sequence is: dup() the originals, dup2 the redirect fd over
+     * 0/1, close the redirect fd (refcount now makes this safe), run,
+     * then dup2 the saved originals back and close them. */
     if (
```

## BUG-0091 (P1, p1fix2) — commit 906f151
- Location: l1/l1_ext.h:111-128
- Issue: + l1/l1_ext.c:80-84 + drivers/display/screen_console.c:91-93   console hook 的"抑制字符"契约未实现
- BEFORE hunk:
```
 typedef int (*screen_console_hook_fn)(void* ctx, u8 ch);
 void l1_ext_set_console_hook(screen_console_hook_fn hook, void* ctx);
 
-/* Called by the L0 console for every character (do not call from L1). */
-void l1_ext_console_hook(u8 ch);
 
 /* ------------------------------------------------------------------ *
  * 5. SYSTEM CONFIGURATION (WP-09-fix5)
```
- AFTER hunk:
```
 typedef int (*screen_console_hook_fn)(void* ctx, u8 ch);
 void l1_ext_set_console_hook(screen_console_hook_fn hook, void* ctx);
 
+/* Called by the L0 console for every character (do not call from L1).
+ * BUG-0091 FIX (A16-4): returns the hook's verdict (0 = nothing
+ * handled, L0 draws; non-zero = hook handled/suppressed the char),
+ * matching the documented contract above. */
+int l1_ext_console_hook(u8 ch);
 
 /* ------------------------------------------------------------------ *
  * 5. SYSTEM CONFIGURATION (WP-09-fix5)
```

## BUG-0092 (P1, p1fix2) — commit 906f151
- Location: l1/l1_wp8cd.c:39-81
- Issue: 、84-106 + l1/l1_wp8cd.h:26-46   WP-08cd"注册"类 L1 接口虚设：文档承诺 oc> 集成 / 可 exec，实为孤立静态表
- BEFORE hunk:
```
     return 0;
 }
 
-/* Interface 52: shell_register_builtin — P1-6 FIX
- * Registers a builtin command in the kernel shell command table.
- * The fn pointer IS stored and IS called when the command is typed
- * at the oc> prompt. This is a real registration, not a stub. */
 int shell_register_builtin(const char *name, shell_builtin_fn fn, const char *help) {
     if (!name || !fn) return -1;
     if (g_builtin_count >= 32) return -2;
```
- AFTER hunk:
```
     return 0;
 }
 
+/* Interface 52: shell_register_builtin — BUG-0092 FIX (A16-5)
+ *
+ * This used to be an ORPHANED TABLE: the fn was stored, the self-test
+ * called the stored pointer directly, and nothing else ever looked at
+ * the table - so a builtin registered through the documented L1 API
+ * was NOT actually available at the oc> prompt (the doc promised
+ * integration; the code delivered a private array).
+ *
+ * Now the kernel shell dispatch (shell_run_simple) consults this
+ * table through l1_wp8cd_builtin_exec() whenever no built-in command
+ * matches, so a name registered here IS executable at oc>. */
 int shell_register_builtin(const char *name, shell_builtin_fn fn, const char *help) {
     if (!name || !fn) return -1;
     if (g_builtin_count >= 32) return -2;
```

## BUG-0093 (P1, p1fix2) — commit 906f151
- Location: docs/
- Issue: ** CONFIG.md 全文把配置键写成 `ota_update_url`，代码实际解析 `update_url`。
- BEFORE hunk:
```
 | File missing while reading (`lib_config_read`) | error `OC_CONFIG_E_NOFILE` (checkupdate prints `config file missing or unreadable`) |
 | Key missing / empty value | built-in default is used (`lib_config_read_default`) |
 | `auto_check` invalid value (not yes/no) | treated as `no` (safe default), warning logged; `config set` **rejects** the value outright |
-| `ota_update_url` invalid prefix | accepted by `config set`, rejected at check time (`invalid URL prefix (must be http:// or https://)`) |
 | Non-ASCII value in `config set` | rejected |
 
 ## 4. Editing from inside the system
```
- AFTER hunk:
```
 | File missing while reading (`lib_config_read`) | error `OC_CONFIG_E_NOFILE` (checkupdate prints `config file missing or unreadable`) |
 | Key missing / empty value | built-in default is used (`lib_config_read_default`) |
 | `auto_check` invalid value (not yes/no) | treated as `no` (safe default), warning logged; `config set` **rejects** the value outright |
+| `update_url` invalid prefix | accepted by `config set`, rejected at check time (`invalid URL prefix (must be http:// or https://)`) |
 | Non-ASCII value in `config set` | rejected |
 
 ## 4. Editing from inside the system
```

## BUG-0094 (P1, p1fix2) — commit 906f151
- Location: docs/
- Issue: ** TRY-IT.md OTA 演练第 4 节 `config set ota_update_url ...` 静默无效。
- BEFORE hunk:
```
 | File missing while reading (`lib_config_read`) | error `OC_CONFIG_E_NOFILE` (checkupdate prints `config file missing or unreadable`) |
 | Key missing / empty value | built-in default is used (`lib_config_read_default`) |
 | `auto_check` invalid value (not yes/no) | treated as `no` (safe default), warning logged; `config set` **rejects** the value outright |
-| `ota_update_url` invalid prefix | accepted by `config set`, rejected at check time (`invalid URL prefix (must be http:// or https://)`) |
 | Non-ASCII value in `config set` | rejected |
 
 ## 4. Editing from inside the system
```
- AFTER hunk:
```
 | File missing while reading (`lib_config_read`) | error `OC_CONFIG_E_NOFILE` (checkupdate prints `config file missing or unreadable`) |
 | Key missing / empty value | built-in default is used (`lib_config_read_default`) |
 | `auto_check` invalid value (not yes/no) | treated as `no` (safe default), warning logged; `config set` **rejects** the value outright |
+| `update_url` invalid prefix | accepted by `config set`, rejected at check time (`invalid URL prefix (must be http:// or https://)`) |
 | Non-ASCII value in `config set` | rejected |
 
 ## 4. Editing from inside the system
```

## BUG-0095 (P1, p1fix2) — commit 906f151
- Location: docs/
- Issue: ** UPDATE-HOWTO.md 让用户运行不存在的 `tools/ota_update_server.py`（实际 `tools/update_server.py`）。
- BEFORE hunk:
```
 One command serves everything (manifest, optional v2 manifest, package):
 
 ```sh
-python3 tools/ota_update_server.py --mode http --port 8008 \
   --json '{ "version": "WP-10d", "time": "2026-10-20",
             "changes": "new release",
             "changes_v2_url": "http://10.0.2.2:8008/update-v2.json",
```
- AFTER hunk:
```
 One command serves everything (manifest, optional v2 manifest, package):
 
 ```sh
+python3 tools/update_server.py --mode http --port 8008 \
   --json '{ "version": "WP-10d", "time": "2026-10-20",
             "changes": "new release",
             "changes_v2_url": "http://10.0.2.2:8008/update-v2.json",
```

## BUG-0096 (P1, p1fix2) — commit 906f151
- Location: 线上站点 ↔ GitHub Release
- Issue: "三处 SHA256 字节级一致"声明已失效
- BEFORE hunk:
```
 <!-- SPDX-License-Identifier: Apache-2.0 -->
 <!-- Copyright 2026 cubestudio-dev <cubestudio@qq.com> -->
 
-# Open Cube OS - WP-AUDIT-01-p1fix1
 
 **官网**: https://cubestudio-dev.github.io/OpenCubeOS
 **GitHub**: https://github.com/cubestudio-dev/OpenCubeOS
```
- AFTER hunk:
```
 <!-- SPDX-License-Identifier: Apache-2.0 -->
 <!-- Copyright 2026 cubestudio-dev <cubestudio@qq.com> -->
 
+# Open Cube OS - WP-AUDIT-01-p1fix2
 
 **官网**: https://cubestudio-dev.github.io/OpenCubeOS
 **GitHub**: https://github.com/cubestudio-dev/OpenCubeOS
```

## BUG-0097 (P1, p1fix2) — commit 68abf48
- Location: update.json 全部副本
- Issue: 三代 manifest 并存，仓库非权威源，重建即回滚
- BEFORE hunk:
```
 {
-  "version": "WP-10d",
-  "time": "2026-10-04",
-  "changes": "USB host stack: UHCI/OHCI/EHCI/XHCI device-level, HID/MSC/serial/audio, hub + hot-plug; 159 cmds, 122 L1 ifaces",
   "changes_v2_url": "https://cubestudio-dev.github.io/OpenCubeOS/update-v2.json",
-  "package_url": "https://github.com/cubestudio-dev/OpenCubeOS/releases/download/wp10d/opencube-wp10d-update.tar.gz",
-  "package_sha256": "ccc17c9a68cfe7b66b78bd9302d32d52d17a73e58dd971adf9483296d3915db6",
-  "package_size": 515027
-}
```
- AFTER hunk:
```
 {
+  "version": "WP-AUDIT-01-p0fix2",
+  "time": "2026-10-05",
+  "changes": "audit p0fix2: 21 P0 fixes (TLS bounds, shell mv data-loss, sys_poll panic, execve CR3, X509, OTA traversal, 4Kn), 172 cmds",
   "changes_v2_url": "https://cubestudio-dev.github.io/OpenCubeOS/update-v2.json",
+  "package_url": "https://cubestudio-dev.github.io/OpenCubeOS/downloads/opencube-wp-audit-01-p0fix2-update.tar.gz",
+  "package_sha256": "a2e5656e5e830996b55c07bc1be67501c3933c2c399113f924c211aec19569f3",
+  "package_size": 534727
+}
```

## BUG-0098 (P1, p1fix2) — commit 906f151
- Location: core_syscall.c:580-612
- Issue: /347-356/1437-1465   VFS fd(kind 1) 无引用计数：dup/dup2/fork 共享 fs_vfs_fd，任一方 close 即全局释放 → 幸存 fd 悬空（写静默失败或串写他文件）；ush.c:2084-2088 的 dup2+close 触发外置命令 `> fi
- BEFORE hunk:
```
         } else if (child->fds[i].kind == 3) {
             sys_pipe_t *p = pipe_get(child->fds[i].pipe_id);
             if (p) p->writer_count++;
         }
     }
 
```
- AFTER hunk:
```
         } else if (child->fds[i].kind == 3) {
             sys_pipe_t *p = pipe_get(child->fds[i].pipe_id);
             if (p) p->writer_count++;
+        } else if (child->fds[i].kind == 1) {
+            /* BUG-0098 FIX (A2-5): the child shares the parent's VFS
+             * open-file slot. Add a reference so a later close by EITHER
+             * side only drops its own reference instead of destroying
+             * the slot (which left the survivor with a dangling fd whose
+             * reads failed and writes were silently lost). */
+            fs_vfs_fd_addref(child->fds[i].fs_vfs_fd);
         }
     }
 
```

## BUG-0099 (P1, p1fix2) — commit 906f151
- Location: core_syscall.c:388
- Issue: /414; core_usermode.c:1048   陈旧 tid：子任务 EXITED 后调度器随时回收并复用槽位，wait4/kill/user_process_kill 再对旧 tid 调 core_kthread_destroy/core_sched_task_exited → 误杀无关
- BEFORE hunk:
```
         } else if (child->fds[i].kind == 3) {
             sys_pipe_t *p = pipe_get(child->fds[i].pipe_id);
             if (p) p->writer_count++;
         }
     }
 
```
- AFTER hunk:
```
         } else if (child->fds[i].kind == 3) {
             sys_pipe_t *p = pipe_get(child->fds[i].pipe_id);
             if (p) p->writer_count++;
+        } else if (child->fds[i].kind == 1) {
+            /* BUG-0098 FIX (A2-5): the child shares the parent's VFS
+             * open-file slot. Add a reference so a later close by EITHER
+             * side only drops its own reference instead of destroying
+             * the slot (which left the survivor with a dangling fd whose
+             * reads failed and writes were silently lost). */
+            fs_vfs_fd_addref(child->fds[i].fs_vfs_fd);
         }
     }
 
```

## BUG-0100 (P1, p1fix2) — commit 906f151
- Location: core_syscall.c:467-474
- Issue: /519-543/933-951   pipe/select 丢失唤醒竞态：数据检查与入队+block 之间可被定时器抢占，写者 wake 时读者未入队 → 读者永眠（数据已就绪）
- BEFORE hunk:
```
         } else if (child->fds[i].kind == 3) {
             sys_pipe_t *p = pipe_get(child->fds[i].pipe_id);
             if (p) p->writer_count++;
         }
     }
 
```
- AFTER hunk:
```
         } else if (child->fds[i].kind == 3) {
             sys_pipe_t *p = pipe_get(child->fds[i].pipe_id);
             if (p) p->writer_count++;
+        } else if (child->fds[i].kind == 1) {
+            /* BUG-0098 FIX (A2-5): the child shares the parent's VFS
+             * open-file slot. Add a reference so a later close by EITHER
+             * side only drops its own reference instead of destroying
+             * the slot (which left the survivor with a dangling fd whose
+             * reads failed and writes were silently lost). */
+            fs_vfs_fd_addref(child->fds[i].fs_vfs_fd);
         }
     }
 
```

## BUG-0101 (P1, p1fix2) — commit 906f151
- Location: core_syscall.c:897-953
- Issue: sys_select timeout_ms==0 语义颠倒（POSIX=立即返回，实现=永久阻塞）；未打开的 fd（stdin 0）既不 ready 也不入等待队列
- BEFORE hunk:
```
         } else if (child->fds[i].kind == 3) {
             sys_pipe_t *p = pipe_get(child->fds[i].pipe_id);
             if (p) p->writer_count++;
         }
     }
 
```
- AFTER hunk:
```
         } else if (child->fds[i].kind == 3) {
             sys_pipe_t *p = pipe_get(child->fds[i].pipe_id);
             if (p) p->writer_count++;
+        } else if (child->fds[i].kind == 1) {
+            /* BUG-0098 FIX (A2-5): the child shares the parent's VFS
+             * open-file slot. Add a reference so a later close by EITHER
+             * side only drops its own reference instead of destroying
+             * the slot (which left the survivor with a dangling fd whose
+             * reads failed and writes were silently lost). */
+            fs_vfs_fd_addref(child->fds[i].fs_vfs_fd);
         }
     }
 
```

## BUG-0102 (P1, p1fix2) — commit 906f151
- Location: core_sched.c:623-639
- Issue: 调度器逻辑 — yield 自弹出后任务孤儿化
- BEFORE hunk:
```
                "task_t.fpu_state offset must match OFF_FPU in arch_context_switch.S");
 _Static_assert(__builtin_offsetof(task_t, fpu_saved) == 800,
                "task_t.fpu_saved offset must match OFF_FPU_SAVED in arch_context_switch.S");
 
 void core_sched_init(void) {
     /* BUG-0042 FIX: enable the FPU/SSE environment and make it
```
- AFTER hunk:
```
                "task_t.fpu_state offset must match OFF_FPU in arch_context_switch.S");
 _Static_assert(__builtin_offsetof(task_t, fpu_saved) == 800,
                "task_t.fpu_saved offset must match OFF_FPU_SAVED in arch_context_switch.S");
+/* BUG-0103 FIX (A3-02): the switch-in path now RESTORES RFLAGS from
+ * task_t.rflags; pin its offset the same way so a future struct change
+ * cannot silently desync the assembly. */
+_Static_assert(__builtin_offsetof(task_t, rflags) == 208,
+               "task_t.rflags offset must match OFF_RFLAGS in arch_context_switch.S");
 
 void core_sched_init(void) {
     /* BUG-0042 FIX: enable the FPU/SSE environment and make it
```

## BUG-0103 (P1, p1fix2) — commit 906f151
- Location: arch_context_switch.S:127-156
- Issue: （经 core_sched.c:486、core_timer.c:180 触发）  上下文切换不恢复 RFLAGS — IF=0 泄漏
- BEFORE hunk:
```
     mov rbp, [rsi + OFF_RBP]
     mov rdx, [rsi + OFF_RDX]
     mov rcx, [rsi + OFF_RCX]
     mov rbx, [rsi + OFF_RBX]
     mov rax, [rsi + OFF_RAX]
 
```
- AFTER hunk:
```
     mov rbp, [rsi + OFF_RBP]
     mov rdx, [rsi + OFF_RDX]
     mov rcx, [rsi + OFF_RCX]
+
+    ; BUG-0103 FIX (A3-02): restore the incoming task's RFLAGS.
+    ; The switch-out path above saves RFLAGS, but the switch-in path
+    ; never restored it, so the incoming task ran with whatever IF state
+    ; the switch point happened to have:
+    ;   - a task switched out inside a cli critical section and later
+    ;     resumed from an IF=1 yield could come back with IF=1 while it
+    ;     still believes it holds the lock (interrupts enabled under a
+    ;     spinlock/critical section), and
+    ;   - a task switched out inside an IRQ handler (IF=0) resumed from
+    ;     a task that yielded with IF=1 would run its IRQ epilogue with
+    ;     interrupts ENABLED (nested IRQ on a handler stack).
+    ; Load the saved RFLAGS here via a push/popfq pair. rax is scratch
+    ; at this point; the task's real rax is loaded right after. The
+    ; popfq sits after the new RSP/RIP-push setup, so the interrupt
+    ; window it opens is the normal pre-ret window on the new task's
+    ; own stack.
+    mov rax, [rsi + OFF_RFLAGS]
+    push rax
+    popfq
+
     mov rbx, [rsi + OFF_RBX]
 
```

## BUG-0104 (P1, p1fix3) — commit 3bd374e
- Location: core_sync.c:82-92
- Issue: sem_wait 等待表满回退路径自死锁
- BEFORE hunk:
```
              * Instead, release the lock, spin briefly, and retry. */
             spin_unlock(&sem->lock);
             for (volatile int spin = 0; spin < 1000; spin++);
-            spin_lock(&sem->lock);
             continue;  /* re-check count */
         }
         /* Mark ourselves BLOCKED before releasing the lock so sem_post
```
- AFTER hunk:
```
              * Instead, release the lock, spin briefly, and retry. */
             spin_unlock(&sem->lock);
             for (volatile int spin = 0; spin < 1000; spin++);
+            /* BUG-0104 FIX: the fallback used to re-take the spinlock
+             * HERE and then `continue` into the loop head which takes
+             * the same spinlock again. A non-recursive spinlock does
+             * not permit that: the second spin_lock spun forever on a
+             * lock WE hold — a self-deadlock on the table-full path.
+             * Leave the lock free; the loop head re-locks it. */
             continue;  /* re-check count */
         }
         /* Mark ourselves BLOCKED before releasing the lock so sem_post
```

## BUG-0105 (P1, p1fix3) — commit 3bd374e
- Location: core_sync.c:202-233
- Issue: cond_wait 等待表满时未注册即阻塞 → 永久睡眠
- BEFORE hunk:
```
 }
 
 void cond_wait(cond_t *c, mutex_t *m) {
-    spin_lock(&c->lock);
-    c->waiters++;
-    /* P0-5 FIX: register our TID AND set BLOCKED state while holding the
-     * lock, so cond_signal can wake us without a lost-wakeup race. */
     tid_t my_tid = core_kthread_current_tid();
-    for (int i = 0; i < COND_MAX_WAITERS; i++) {
-        if (c->waiter_tids[i] == 0 || c->waiter_tids[i] == (tid_t)-1) {
-            c->waiter_tids[i] = my_tid;
-            break;
         }
     }
     task_t *me = core_kthread_current();
     if (me) me->state = TASK_BLOCKED;
```
- AFTER hunk:
```
 }
 
 void cond_wait(cond_t *c, mutex_t *m) {
     tid_t my_tid = core_kthread_current_tid();
+    spin_lock(&c->lock);
+    int registered = 0;
+    for (;;) {
+        c->waiters++;
+        /* P0-5 FIX: register our TID AND set BLOCKED state while holding the
+         * lock, so cond_signal can wake us without a lost-wakeup race. */
+        for (int i = 0; i < COND_MAX_WAITERS; i++) {
+            if (c->waiter_tids[i] == 0 || c->waiter_tids[i] == (tid_t)-1) {
+                c->waiter_tids[i] = my_tid;
+                registered = 1;
+                break;
+            }
         }
+        if (registered) break;
+        /* BUG-0105 FIX: the waiter table is FULL. The old code just fell
+         * through: it marked us TASK_BLOCKED WITHOUT being registered,
+         * so cond_signal could never find our tid — permanent sleep.
+         * Retract the waiter count, drop c->lock AND the caller's mutex
+         * (so a signaler can make progress), spin briefly and retry the
+         * registration — the same fail-open pattern sem_wait uses since
+         * its BUG-046 fix (with the BUG-0104 self-deadlock avoided by
+         * letting the loop head re-take the lock). */
+
```

## BUG-0106 (P1, p1fix3) — commit 3bd374e
- Location: crypto_core.c:433-442
- Issue: 非密码学 PRNG 用于全部 TLS/SSH 密钥材料
- BEFORE hunk:
```
         crypto_bn_sub(b, mod, len);
     }
 
-    /* Square-and-multiply: scan exp from MSB */
     for (int i = 0; i < len; i++) {
         for (int bit = 7; bit >= 0; bit--) {
-            /* r = r^2 mod mod */
             memset(product, 0, 2 * len);
-            /* Schoolbook multiply: r * r → 2*len-byte product */
             for (int j = len - 1; j >= 0; j--) {
                 for (int k = len - 1; k >= 0; k--) {
                     int prod_idx = j + k + 1;
```
- AFTER hunk:
```
         crypto_bn_sub(b, mod, len);
     }
 
+    u8 *mul_r = (u8 *)(uintptr_t)mem_pmm_alloc_frame();  /* len bytes (BUG-0108) */
+    if (!mul_r) {
+        mem_pmm_free_frame((u64)(uintptr_t)r);
+        mem_pmm_free_frame((u64)(uintptr_t)b);
+        mem_pmm_free_frame((u64)(uintptr_t)product);
+        mem_pmm_free_frame((u64)(uintptr_t)prod2);
+        return;
+    }
+
+    /* Square-and-MULTIPLY-ALWAYS (BUG-0108 FIX, A4-04): the old loop
+     * multiplied only when the exponent bit was set, so the per-bit
+     * timing of a 1024/2048-bit modexp directly leaked the (private)
+     * exponent. Now the multiply runs on EVERY bit and its result is
+     * merged through a constant-time masked select, so the executed
+     * instruction sequence is identical for every key. */
     for (int i = 0; i < len; i++) {
         for (int bit = 7; bit >= 0; bit--) {
+            u8 m = (u8)(0u - ((exp[i] >> bit) & 1));   /* 0x00 / 0xFF */
+
+            /* r = r^2 mod mod (always) */
             memset(product, 0, 2 * len);
+            /* Schoolbook multiply: r * r -> 2*len-byte product */
             for (int j = len - 1; j >= 0; j--) {
                 for (int k = len - 1; k >= 0;
```

## BUG-0107 (P1, p1fix3) — commit 3bd374e
- Location: crypto_x509.c:456-467
- Issue: ECDSA r/s 左侧未清零，使用未初始化栈数据验证
- BEFORE hunk:
```
         if (crypto_der_read_tag_len(&inner, &tag, &body, &blen) != 0 || tag != 0x02)
             return X509_E_BADSIG;
         u8 r[EC_MAX_SCALAR];
         int rlen = blen;
         while (rlen > 1 && body[0] == 0) { body++; rlen--; }
         /* P0fix2 BUG-0035 (A4-01): rlen could arrive negative (from the
```
- AFTER hunk:
```
         if (crypto_der_read_tag_len(&inner, &tag, &body, &blen) != 0 || tag != 0x02)
             return X509_E_BADSIG;
         u8 r[EC_MAX_SCALAR];
+        /* BUG-0107 FIX (A4-03): r was left UNINITIALISED. Only the right
+         * hlen-rlen bytes were filled by the memcpy below; ecdsa_verify()
+         * consumes the full hlen-byte big-endian scalar, so the leading
+         * bytes were stack garbage whenever the DER INTEGER was shorter
+         * than the hash size (common: leading zero stripped). Verify
+         * used random data -> non-deterministic results. Zero first. */
+        memset(r, 0, sizeof(r));
         int rlen = blen;
         while (rlen > 1 && body[0] == 0) { body++; rlen--; }
         /* P0fix2 BUG-0035 (A4-01): rlen could arrive negative (from the
```

## BUG-0108 (P1, p1fix3) — commit 3bd374e
- Location: crypto_ec_nist.c:270-309
- Issue: + 468-483（另 crypto_core.c:618-656）  私钥标量乘/模幂非常量时间（时间侧信道）
- BEFORE hunk:
```
     fe_mul(c, Z3, Z3, H);
 }
 
-/* Scalar multiplication with 4-bit windows (public-data path).
- * Windows are aligned from the first set bit: each window covers up to 4
- * bits starting at the current position. */
 static void crypto_pt_scalar_mult(const crypto_ec_curve_t *c,
                            u64 *RX, u64 *RY, u64 *RZ,
                            const u8 *k_be, int k_len,
                            const u64 *PX, const u64 *PY, const u64 *PZ) {
-    u64 tx[15][EC_LIMBS], ty[15][EC_LIMBS], tz[15][EC_LIMBS];
-    crypto_pt_copy(c, tx[0], ty[0], tz[0], PX, PY, PZ);
-    for (int i = 1; i < 15; i++) {
-        /* tx[i] = (i+1)*P: odd index (i+1 even) via doubling of ((i+1)/2)P,
-         * even index (i+1 odd) via addition of P to (i)P. */
-        if (i & 1)
-            crypto_pt_double(c, tx[i], ty[i], tz[i],
-                      tx[(i + 1) / 2 - 1], ty[(i + 1) / 2 - 1], tz[(i + 1) / 2 - 1]);
-        else
-            crypto_pt_add(c, tx[i], ty[i], tz[i],
-                   tx[i - 1], ty[i - 1], tz[i - 1], PX, PY, PZ);
-    }
-
     int total = k_len * 8;
     crypto_pt_set_inf(c, RX, RY, RZ);
-    int i = 0;
-    while (i < total && !((k_be[i / 8] >> (7 - (i % 
```
- AFTER hunk:
```
     fe_mul(c, Z3, Z3, H);
 }
 
+/* Scalar multiplication - CONSTANT TIME (BUG-0108 FIX, A4-04).
+ *
+ * The old implementation used a 4-bit window with three secret-dependent
+ * control-flow paths:
+ *   - a loop that skipped the leading zero bits of the scalar (leaked the
+ *     position of the top set bit of the private key / ECDSA nonce),
+ *   - `if (w) add` (leaked which windows were zero),
+ *   - data-dependent table indexing tx[w-1] (branch/cache side channel).
+ *
+ * The replacement is a fixed bit-wise double-and-add-ALWAYS ladder over
+ * exactly k_len*8 iterations: every iteration performs one doubling and
+ * one addition unconditionally, and the addition result is merged with a
+ * masked constant-time select (all limbs, no branches). The instruction
+ * and memory-access sequence is identical for every scalar value.
+ *
+ * Known residual: crypto_pt_add() keeps an early-out branch when one of
+ * its inputs is the point at infinity. During the first iterations R is
+ * the identity, so the number of leading zero bits of the scalar (at
+ * most 7 per leading zero byte, bounded by the fixed length) still
+ * influences which branch is taken there. Removing that requ
```

## BUG-0109 (P1, p1fix3) — commit 3bd374e
- Location: kernel/ota/ota_ab.c:1059-1063
- Issue: + kernel/ota/ota_update.c:559-563   整数安全/栈溢出
- BEFORE hunk:
```
     *pkg_path = path;
 
     char msg[80];
-    char num[12];
     strcpy(msg, "update: downloading... (");
     u64_to_str(pkg->package_size / 1024, num);
     strcat(msg, num);
```
- AFTER hunk:
```
     *pkg_path = path;
 
     char msg[80];
+    /* BUG-0109 FIX: the display buffer was char num[12]. package_size is
+     * parsed from the (network-supplied) manifest as a full u64, so a
+     * huge value printed up to 20 decimal digits into 12 bytes -> stack
+     * overflow inside the update path. u64 needs at most 20 digits + NUL
+     * = 21 bytes; 24 gives headroom. */
+    char num[24];
     strcpy(msg, "update: downloading... (");
     u64_to_str(pkg->package_size / 1024, num);
     strcat(msg, num);
```

## BUG-0110 (P1, p1fix3) — commit 3bd374e
- Location: kernel/ota/ota_ab.c:1108
- Issue: ,1165,1117,1174   逻辑：更新目标槽硬编码 B
- BEFORE hunk:
```
     *pkg_path = path;
 
     char msg[80];
-    char num[12];
     strcpy(msg, "update: downloading... (");
     u64_to_str(pkg->package_size / 1024, num);
     strcat(msg, num);
```
- AFTER hunk:
```
     *pkg_path = path;
 
     char msg[80];
+    /* BUG-0109 FIX: the display buffer was char num[12]. package_size is
+     * parsed from the (network-supplied) manifest as a full u64, so a
+     * huge value printed up to 20 decimal digits into 12 bytes -> stack
+     * overflow inside the update path. u64 needs at most 20 digits + NUL
+     * = 21 bytes; 24 gives headroom. */
+    char num[24];
     strcpy(msg, "update: downloading... (");
     u64_to_str(pkg->package_size / 1024, num);
     strcat(msg, num);
```

## BUG-0111 (P1, p1fix3) — commit 3bd374e
- Location: kernel/ota/ota_update.c:487-499
- Issue: ,691-693（配合 core_sched.c:257-264）  资源管理：4 KiB 线程栈装不下 OTA 检查调用链
- BEFORE hunk:
```
             if (*q < '0' || *q > '9') return -2;
             u64 v = 0;
             while (*q >= '0' && *q <= '9') {
-                v = v * 10u + (u64)(*q - '0');
                 q++;
             }
             *out = v;
```
- AFTER hunk:
```
             if (*q < '0' || *q > '9') return -2;
             u64 v = 0;
             while (*q >= '0' && *q <= '9') {
+                /* BUG-0109 FIX: detect the u64 wrap instead of silently
+                 * accepting a malicious manifest number that overflows
+                 * (e.g. a huge package_size would wrap to a tiny value
+                 * and defeat the download-size sanity check). */
+                u64 digit = (u64)(*q - '0');
+                if (v > ((u64)-1 - digit) / 10u) return -2;
+                v = v * 10u + digit;
                 q++;
             }
             *out = v;
```

## BUG-0112 (P1, p1fix3) — commit 3bd374e
- Location: kernel/lib/lib_string.c:74-79
- Issue: 内存管理：strncpy 语义破坏（n+1 越界写）
- BEFORE hunk:
```
     return dst;
 }
 
 char* strncpy(char* dst, const char* src, usize n) {
     char* d = dst;
-    while (n && (*d++ = *src++)) --n;
     while (n--) *d++ = 0;
     return dst;
 }
```
- AFTER hunk:
```
     return dst;
 }
 
+/* BUG-0112 FIX: the old loop `while (n && (*d++ = *src++)) --n;`
+ * consumed one extra byte of the budget when the source ran out: the
+ * terminating NUL was stored by the copy loop itself and the padding
+ * loop then ran with an un-decremented count, writing n+1 bytes total
+ * (one past the contract). Callers that sized their buffer as exactly
+ * `n` saw a one-byte stack/heap overwrite. This version stores the
+ * terminator via the padding loop only and writes EXACTLY n bytes,
+ * matching ISO C strncpy semantics. */
 char* strncpy(char* dst, const char* src, usize n) {
     char* d = dst;
+    while (n && *src) { *d++ = *src++; n--; }
     while (n--) *d++ = 0;
     return dst;
 }
```

## BUG-0113 (P1, p1fix3) — commit 3bd374e
- Location: driver_block_part.c:120-134
- Issue: GPT entry_size 无上界 → 栈越界读 / #PF panic
- BEFORE hunk:
```
     u64 entry_start = gh->driver_block_part_entry_start;
     if (num_entries > PART_MAX_PARTITIONS) num_entries = PART_MAX_PARTITIONS;
     if (entry_size < sizeof(gpt_entry_t)) entry_size = sizeof(gpt_entry_t);
 
     /* Read partition entries. They usually start at LBA 2 and may span
      * multiple sectors. Read up to 8 sectors (enough for 128 entries). */
     u8 entry_buf[512 * 8];
-    u32 sectors_to_read = (num_entries * entry_size + 511) / 512;
     if (sectors_to_read > 8) sectors_to_read = 8;
     if (driver_block_read_sectors_raw(dev_idx, entry_start, sectors_to_read, entry_buf) != 0) return -1;
 
```
- AFTER hunk:
```
     u64 entry_start = gh->driver_block_part_entry_start;
     if (num_entries > PART_MAX_PARTITIONS) num_entries = PART_MAX_PARTITIONS;
     if (entry_size < sizeof(gpt_entry_t)) entry_size = sizeof(gpt_entry_t);
+    /* BUG-0113 FIX: entry_size came straight from the (on-disk) GPT
+     * header with only a lower bound. A huge value (or one that
+     * overflows the u32 sectors_to_read multiply) made the per-entry
+     * pointer entry_buf + i*entry_size run past the 4 KiB stack buffer
+     * -> out-of-bounds stack read / #PF panic. Real GPTs use 128-byte
+     * entries (UEFI spec minimum); refuse absurd sizes and clamp the
+     * entry count so num_entries*entry_size always fits the buffer. */
+    if (entry_size > 1024) return -1;
 
     /* Read partition entries. They usually start at LBA 2 and may span
      * multiple sectors. Read up to 8 sectors (enough for 128 entries). */
     u8 entry_buf[512 * 8];
+    u64 need = (u64)num_entries * (u64)entry_size;
+    if (need > sizeof(entry_buf)) {
+        u32 max_fit = (u32)((u64)sizeof(entry_buf) / (u64)entry_size);
+        if (max_fit == 0) return -1;
+        num_entries = max_fit;
+        need = (u64)num_entries * (u64)e
```

## BUG-0114 (P1, p1fix3) — commit dd0882f
- Location: driver_block_nvme.c:533-534
- Issue: vs 337/351   I/O 队列按 MQES 缩小创建但回绕固定 %64 → SQE 越界写 + 门铃值非法
- BEFORE hunk:
```
     u64 mmio_base;
     u32 dstrd;          /* doorbell stride: 4 << dstrd bytes per doorbell */
     u16 mqes;           /* max queue entries (size = mqes+1) */
 
     /* Admin queue (qid=0). */
     driver_block_nvme_sqe_t *asq;
```
- AFTER hunk:
```
     u64 mmio_base;
     u32 dstrd;          /* doorbell stride: 4 << dstrd bytes per doorbell */
     u16 mqes;           /* max queue entries (size = mqes+1) */
+    u32 admin_qsize;    /* BUG-0317: admin queue depth, clamped to MQES+1 */
 
     /* Admin queue (qid=0). */
     driver_block_nvme_sqe_t *asq;
```

## BUG-0115 (P1, p1fix3) — commit 3bd374e
- Location: driver_block_ata_dma.c:369
- Issue: （对照 ahci.c:567 的正确写法）  init_ctrl 无控制器表上界检查 → 重复/L1 扩展调用时 g_ctrls[2] 越界写
- BEFORE hunk:
```
 /* WP-10a: bring up one IDE controller's BMDMA registers and its drives.
  * Returns 0 on success, -1 when the controller has no BMDMA BAR. */
 static int driver_block_ata_dma_init_ctrl(u8 bus, u8 dev, u8 func) {
     driver_pci_enable_device(bus, dev, func);
     u32 bar4 = driver_pci_read_bar(bus, dev, func, 4);
     if (bar4 == 0) {
```
- AFTER hunk:
```
 /* WP-10a: bring up one IDE controller's BMDMA registers and its drives.
  * Returns 0 on success, -1 when the controller has no BMDMA BAR. */
 static int driver_block_ata_dma_init_ctrl(u8 bus, u8 dev, u8 func) {
+    /* BUG-0115 FIX: g_ctrls[BMDMA_MAX_CTRLS] was indexed with
+     * g_ctrl_count++ and no bound check. A second init pass (dev
+     * re-enumeration or an L1 extension calling the init hook again)
+     * pushed g_ctrl_count past 2 and wrote out of the controller table.
+     * Same guard the AHCI driver has had since its BUG-free rewrite
+     * (ahci.c:567). */
+    if (g_ctrl_count >= (int)(sizeof(g_ctrls) / sizeof(g_ctrls[0]))) {
+        dlog_bdf("ata_dma: controller table full, ignoring IDE ctrl at ",
+                 bus, dev, func, "\n");
+        return -1;
+    }
     driver_pci_enable_device(bus, dev, func);
     u32 bar4 = driver_pci_read_bar(bus, dev, func, 4);
     if (bar4 == 0) {
```

## BUG-0116 (P1, p1fix3) — commit 3bd374e
- Location: driver_block_cache.c:47-54
- Issue: + driver_block_blk.c:112-118   淘汰脏页回写失败被忽略 + 写路径恒返回 0 → 设备错误时静默丢数据
- BEFORE hunk:
```
     return -1;
 }
 
 static int pick_victim(void) {
     /* Find empty slot first. */
     for (int i = 0; i < BLK_CACHE_SLOTS; i++) {
         if (g_cache[i].dev_idx == -1) return i;
     }
-    /* LRU: pick the slot with the smallest last_used. */
-    int victim = 0;
-    u64 oldest = g_cache[0].last_used;
-    for (int i = 1; i < BLK_CACHE_SLOTS; i++) {
-        if (g_cache[i].last_used < oldest) {
-            oldest = g_cache[i].last_used;
-            victim = i;
         }
     }
-    /* Write back if dirty. */
-    if (g_cache[victim].dirty) {
-        driver_block_write_sectors_raw(g_cache[victim].dev_idx, g_cache[victim].lba, 1, g_cache[victim].data);
-        g_cache_stats.writebacks++;
-    }
-    g_cache_stats.evicts++;
-    return victim;
 }
 
 int driver_block_cache_read(int dev_idx, u64 lba, void *buf) {
```
- AFTER hunk:
```
     return -1;
 }
 
+/* BUG-0116 FIX: pick a victim slot. The old code picked the LRU slot,
+ * fired one write-back for a dirty page and IGNORED the return value -
+ * a device error silently dropped the data (the slot got reused). Now
+ * victims are tried in LRU order: a clean slot is taken immediately, a
+ * dirty slot is only released when its write-back SUCCEEDS. If every
+ * dirty slot fails to write back the function returns -1 and the
+ * callers fall back to write-through instead of losing data. */
 static int pick_victim(void) {
     /* Find empty slot first. */
     for (int i = 0; i < BLK_CACHE_SLOTS; i++) {
         if (g_cache[i].dev_idx == -1) return i;
     }
+    u8 tried[BLK_CACHE_SLOTS];
+    memset(tried, 0, sizeof(tried));
+    for (;;) {
+        int vi = -1;
+        u64 oldest = ~0ull;
+        for (int i = 0; i < BLK_CACHE_SLOTS; i++) {
+            if (tried[i]) continue;
+            if (g_cache[i].last_used < oldest) {
+                oldest = g_cache[i].last_used;
+                vi = i;
+            }
         }
+        if (vi < 0) return -1;   /* every candidate failed its write-back */
+        if (!g_cache[vi].dirty) return vi;
+        if (dri
```

## BUG-0117 (P1, p1fix3) — commit 3bd374e
- Location: driver_block_part.c:223-224
- Issue: + driver_block_disk_setup.c:376/513   register_child 名字冲突返回旧几何子设备 → abdisk/install 二次布局沿用过期 start/sectors → mkfs 按旧尺寸跨分区格式化
- BEFORE hunk:
```
     strcpy(name + len, num);
 
     int existing = driver_block_find_device(name);
-    if (existing >= 0) return existing;
 
     driver_block_part_child_priv_t *priv =
         (driver_block_part_child_priv_t *)kmalloc(sizeof(driver_block_part_child_priv_t));
```
- AFTER hunk:
```
     strcpy(name + len, num);
 
     int existing = driver_block_find_device(name);
+    if (existing >= 0) {
+        /* BUG-0117 FIX: the old code returned the EXISTING child
+         * untouched, so after abdisk / install laid out a NEW partition
+         * table the "<parent>pN" device still reported the OLD
+         * start_lba/sectors - mkfs then formatted with stale geometry
+         * and overran into the neighbouring partition. Refresh the
+         * geometry in place instead (same-name calls with identical
+         * geometry stay idempotent). */
+        driver_block_device_t *ed = driver_block_get_device(existing);
+        if (!ed || !ed->present) return -1;
+        driver_block_part_child_priv_t *ep =
+            (driver_block_part_child_priv_t *)ed->priv;
+        if (!ep) return -1;
+        ep->parent_idx = parent_idx;
+        ep->start_lba  = start_lba;
+        ed->sectors    = sectors;
+        return existing;
+    }
 
     driver_block_part_child_priv_t *priv =
         (driver_block_part_child_priv_t *)kmalloc(sizeof(driver_block_part_child_priv_t));
```

## BUG-0118 (P1, p1fix3) — commit 3bd374e
- Location: screen_console.c:48-51
- Issue: 整数安全（除零 panic）
- BEFORE hunk:
```
     u32 cw  = screen_active_renderer->cell_w;
     u32 chh = screen_active_renderer->cell_h;
     const screen_fb_info_t* fb = screen_fb_get_info();
-
-    for (u32 cy = 0; cy + 1 < g_console.rows; ++cy) {
         u8* dst = fb->addr + (u64)(cy * chh) * fb->pitch;
         u8* src = fb->addr + (u64)((cy + 1) * chh) * fb->pitch;
         memcpy(dst, src, (usize)fb->pitch * chh);
     }
     /* Clear the last cell-row to bg. */
-    screen_fb_fill_rect(0, (g_console.rows - 1) * chh,
                     g_console.cols * cw, chh, g_console.bg_pixel);
 }
 
```
- AFTER hunk:
```
     u32 cw  = screen_active_renderer->cell_w;
     u32 chh = screen_active_renderer->cell_h;
     const screen_fb_info_t* fb = screen_fb_get_info();
+    /* BUG-0119 FIX: the scroll used the stale g_console.rows even when
+     * the active renderer's cell size or the framebuffer geometry made
+     * rows*chh run past the real fb surface - the last memcpy row (and
+     * the clear of the "last row") then wrote outside the framebuffer.
+     * Clamp the working rows/clear-height to the actual surface. */
+    if (cw == 0 || chh == 0) return;   /* degenerate renderer: nothing sane to scroll */
+    u32 rows = g_console.rows;
+    if (fb == NULL || fb->addr == NULL) return;
+    if ((u64)rows * chh > (u64)fb->height) rows = (u32)((u64)fb->height / chh);
+    if (rows == 0) return;
+
+    for (u32 cy = 0; cy + 1 < rows; ++cy) {
         u8* dst = fb->addr + (u64)(cy * chh) * fb->pitch;
         u8* src = fb->addr + (u64)((cy + 1) * chh) * fb->pitch;
         memcpy(dst, src, (usize)fb->pitch * chh);
     }
     /* Clear the last cell-row to bg. */
+    screen_fb_fill_rect(0, (rows - 1) * chh,
                     g_console.cols * cw, chh, g_console.bg_pixel);
 }
 
```

## BUG-0119 (P1, p1fix3) — commit 3bd374e
- Location: screen_console.c:25-42
- Issue: （+ screen_font.c:34-39）  指针安全（滚动 memcpy 越界 #PF）
- BEFORE hunk:
```
     u32 cw  = screen_active_renderer->cell_w;
     u32 chh = screen_active_renderer->cell_h;
     const screen_fb_info_t* fb = screen_fb_get_info();
-
-    for (u32 cy = 0; cy + 1 < g_console.rows; ++cy) {
         u8* dst = fb->addr + (u64)(cy * chh) * fb->pitch;
         u8* src = fb->addr + (u64)((cy + 1) * chh) * fb->pitch;
         memcpy(dst, src, (usize)fb->pitch * chh);
     }
     /* Clear the last cell-row to bg. */
-    screen_fb_fill_rect(0, (g_console.rows - 1) * chh,
                     g_console.cols * cw, chh, g_console.bg_pixel);
 }
 
```
- AFTER hunk:
```
     u32 cw  = screen_active_renderer->cell_w;
     u32 chh = screen_active_renderer->cell_h;
     const screen_fb_info_t* fb = screen_fb_get_info();
+    /* BUG-0119 FIX: the scroll used the stale g_console.rows even when
+     * the active renderer's cell size or the framebuffer geometry made
+     * rows*chh run past the real fb surface - the last memcpy row (and
+     * the clear of the "last row") then wrote outside the framebuffer.
+     * Clamp the working rows/clear-height to the actual surface. */
+    if (cw == 0 || chh == 0) return;   /* degenerate renderer: nothing sane to scroll */
+    u32 rows = g_console.rows;
+    if (fb == NULL || fb->addr == NULL) return;
+    if ((u64)rows * chh > (u64)fb->height) rows = (u32)((u64)fb->height / chh);
+    if (rows == 0) return;
+
+    for (u32 cy = 0; cy + 1 < rows; ++cy) {
         u8* dst = fb->addr + (u64)(cy * chh) * fb->pitch;
         u8* src = fb->addr + (u64)((cy + 1) * chh) * fb->pitch;
         memcpy(dst, src, (usize)fb->pitch * chh);
     }
     /* Clear the last cell-row to bg. */
+    screen_fb_fill_rect(0, (rows - 1) * chh,
                     g_console.cols * cw, chh, g_console.bg_pixel);
 }
 
```

## BUG-0120 (P1, p1fix3) — commit 3bd374e
- Location: screen_fb.c:62-64
- Issue: （fill_rect）、74-76（blit）  整数安全（裁剪溢出绕过 → 越界写）
- BEFORE hunk:
```
 }
 
 void screen_fb_fill_rect(u32 x, u32 y, u32 w, u32 h, u32 pixel) {
-    /* Clip to framebuffer. */
     if (x >= g_fb.width || y >= g_fb.height) return;
-    if (x + w > g_fb.width)  w = g_fb.width  - x;
-    if (y + h > g_fb.height) h = g_fb.height - y;
 
     for (u32 j = 0; j < h; ++j) {
         u8*  row = g_fb.addr + (u64)(y + j) * g_fb.pitch;
```
- AFTER hunk:
```
 }
 
 void screen_fb_fill_rect(u32 x, u32 y, u32 w, u32 h, u32 pixel) {
+    /* Clip to framebuffer.
+     * BUG-0120 FIX: the old clipping compared x + w > width in u32, so a
+     * huge w (x + w wrapping past 2^32) bypassed the clip and the fill
+     * loop wrote far outside the framebuffer. x < width is already
+     * established here, so compare against width - x (no overflow). */
     if (x >= g_fb.width || y >= g_fb.height) return;
+    if (w > g_fb.width  - x) w = g_fb.width  - x;
+    if (h > g_fb.height - y) h = g_fb.height - y;
 
     for (u32 j = 0; j < h; ++j) {
         u8*  row = g_fb.addr + (u64)(y + j) * g_fb.pitch;
```

## BUG-0121 (P1, p1fix3) — commit 3bd374e
- Location: driver_pci.c:104-124
- Issue: 逻辑/整数（64 位 BAR 截断 + bar_index 无校验）
- BEFORE hunk:
```
 }
 
 u32 driver_pci_read_bar(u8 bus, u8 dev, u8 func, int bar_index) {
     u8 offset = 0x10 + (u8)(bar_index * 4);
     u32 bar = driver_pci_read_config(bus, dev, func, offset);
     if (bar & 1) {
```
- AFTER hunk:
```
 }
 
 u32 driver_pci_read_bar(u8 bus, u8 dev, u8 func, int bar_index) {
+    /* BUG-0121 FIX: bar_index used to be trusted. A negative index (or
+     * anything above BAR5) wrapped the u8 offset arithmetic and read an
+     * unrelated config register, handing callers a bogus "BAR". */
+    if (bar_index < 0 || bar_index > 5) return 0;
     u8 offset = 0x10 + (u8)(bar_index * 4);
     u32 bar = driver_pci_read_config(bus, dev, func, offset);
     if (bar & 1) {
```

## BUG-0122 (P1, p1fix3) — commit 3bd374e
- Location: driver_nic_rtl8169.c:167-172
- Issue: 探测逻辑死代码：rtl8168/rtl8125/rtl810x 三个家族永远无法初始化
- BEFORE hunk:
```
     d->bus = bus; d->dev = dev; d->func = func;
 
     /* Find the PIO BAR (BAR0 is MMIO on most boards, the PIO window is
-     * usually BAR2; walk the first three). */
     u16 io = 0;
     for (int b = 0; b < 3 && !io; b++) {
-        u32 bar = driver_pci_read_bar(bus, dev, func, b);
-        if ((bar & 0x1) && (bar & 0xFFFC)) io = (u16)(bar & 0xFFFC);
     }
     if (!io) return -1;
     d->io = io;
```
- AFTER hunk:
```
     d->bus = bus; d->dev = dev; d->func = func;
 
     /* Find the PIO BAR (BAR0 is MMIO on most boards, the PIO window is
+     * usually BAR2; walk the first three).
+     * BUG-0122 FIX (A8-1): driver_pci_read_bar() MASKS the result (I/O
+     * BARs return bar & ~3, MMIO bar & ~0xF), so bit 0 is ALWAYS clear
+     * in the returned value and the old `(bar & 0x1)` test never fired:
+     * all three RTL8169-family inits failed on every machine. Read the
+     * RAW config dword (like driver_nic_rtl8139.c does) to test the
+     * I/O-space indicator bit. */
     u16 io = 0;
     for (int b = 0; b < 3 && !io; b++) {
+        u32 raw = driver_pci_read_config(bus, dev, func, 0x10 + (u8)(b * 4));
+        if ((raw & 0x1) && (raw & 0xFFFC)) io = (u16)(raw & 0xFFFC);
     }
     if (!io) return -1;
     d->io = io;
```

## BUG-0123 (P1, p1fix3) — commit 3bd374e
- Location: driver_nic_other.c:97-99
- Issue: , 199-203   同类死代码：3c59x 与 nForce 家族永远无法初始化
- BEFORE hunk:
```
     memset(d, 0, sizeof(*d));
     d->bus = bus; d->dev = dev; d->func = func;
 
-    u32 bar0 = driver_pci_read_bar(bus, dev, func, 0);
     if (!bar0 || !(bar0 & 0x1)) return -1;   /* needs the PIO window */
     d->io = (u16)(bar0 & 0xFFFC);
     other_pci_enable(bus, dev, func);
```
- AFTER hunk:
```
     memset(d, 0, sizeof(*d));
     d->bus = bus; d->dev = dev; d->func = func;
 
+    /* BUG-0123 FIX (A8-2): read the RAW config dword to detect the I/O
+     * BAR - driver_pci_read_bar() masks the result so bit 0 is always
+     * clear and the old test never fired (dead init on all hardware). */
+    u32 bar0 = driver_pci_read_config(bus, dev, func, 0x10);
     if (!bar0 || !(bar0 & 0x1)) return -1;   /* needs the PIO window */
     d->io = (u16)(bar0 & 0xFFFC);
     other_pci_enable(bus, dev, func);
```

## BUG-0124 (P1, p1fix3) — commit 3bd374e
- Location: driver_nic_other.c:292-305
- Issue: , 390-431（另见 213-226, 117-130）  "假发送"存根：send 返回成功但不发送任何字节；AR81xx/Yukon 以全零 MAC 注册
- BEFORE hunk:
```
     (void)ndev; (void)buf;
     mmio_legacy_dev_t *d = (mmio_legacy_dev_t *)ndev->priv;
     if (!d || !d->up || len <= 0) return -1;
-    d->tx_packets++;
-    return len;
 }
 
 static int mmio_ops_recv(driver_nic_device_t *ndev, void *buf, int maxlen) {
```
- AFTER hunk:
```
     (void)ndev; (void)buf;
     mmio_legacy_dev_t *d = (mmio_legacy_dev_t *)ndev->priv;
     if (!d || !d->up || len <= 0) return -1;
+    /* BUG-0124 FIX (A8-3): the old stub counted the packet and returned
+     * len while never sending a byte - net.c believed every send
+     * succeeded and DHCP/TCP silently starved. Report failure honestly
+     * until the AR81xx/Yukon DMA datapath is really implemented. */
+    return -1;
 }
 
 static int mmio_ops_recv(driver_nic_device_t *ndev, void *buf, int maxlen) {
```

## BUG-0125 (P1, p1fix3) — commit 3bd374e
- Location: driver_nic_rtl8139.c:272-278
- Issue: , 293-301   发送路径三缺陷叠加：失效等待死代码 + 多余的 TSD=0 写 + 超时仍推进槽位（KI-SH-01 首要嫌疑，见 §4）
- BEFORE hunk:
```
     if (!d->up || len <= 0 || len > 1790) return -1;   /* datasheet max TX frame */
 
     int slot = d->tx_cur;
-    /* Wait for an idle slot: after completion the chip sets TOK|OWN;
-     * a slot whose TSD has neither bit is free.  Clear any stale state
-     * before handing the buffer to the chip. */
     for (int t = 0; t < 1000000; t++) {
         u32 tsd = inl_p(d->io + R8139_TSD0 + slot * 4);
-        if (!((tsd & R8139_TSD_TOK) && (tsd & R8139_TSD_OWN)) &&
-            !(tsd & R8139_TSD_TOK)) break;
-        outl_p(d->io + R8139_TSD0 + slot * 4, 0);
-        break;
     }
     memcpy(d->tx_bufs[slot], buf, len);
 
     outl_p(d->io + R8139_TSAD0 + slot * 4,
            (u32)(uintptr_t)d->tx_bufs[slot]);
     /* Writing the size (with bit13 CLEAR) triggers the send; the chip
-     * sets TOK when the frame is out. */
     outl_p(d->io + R8139_TSD0 + slot * 4,
            ((u32)len & R8139_TSD_SIZE));
     /* TP_POLL kick: harmless on hardware, required by some models. */
```
- AFTER hunk:
```
     if (!d->up || len <= 0 || len > 1790) return -1;   /* datasheet max TX frame */
 
     int slot = d->tx_cur;
+    /* BUG-0125 FIX (A8-4): the old wait was dead logic - the condition
+     * `!((TOK&&OWN)) && !(TOK)` simplifies to `!(TOK)` and BOTH branches
+     * broke on the first iteration, and it also wrote TSD=0 (a zero-size
+     * send trigger) on the way out. That extra write fired the chip with
+     * size 0 against the stale buffer, and the unconditional slot bump
+     * let the next sends overwrite buffers the chip still owned.
+     *
+     * Correct hand-over: a slot is reusable when the chip set TOK (last
+     * frame completed) or when it has never been armed (TOK and SIZE are
+     * both 0). Poll for that; on timeout FAIL without arming anything
+     * and without advancing the ring. */
+    int ready = 0;
     for (int t = 0; t < 1000000; t++) {
         u32 tsd = inl_p(d->io + R8139_TSD0 + slot * 4);
+        if (tsd & R8139_TSD_TOK) { ready = 1; break; }
+        if (!(tsd & R8139_TSD_SIZE) && !(tsd & R8139_TSD_TOK)) { ready = 1; break; }
+    }
+    if (!ready) {
+        /* chip still owns this slot: do NOT overwrite the buffer, do NOT
+         * bum
```

## BUG-0126 (P1, p1fix3) — commit 3bd374e
- Location: driver_nic_ixgbe.c:286-287
- Issue: , 305-315   依据 82598/82599 datasheet（及 Linux ixgbe 布局）：TX 命令位写错字、RX 写回字段偏移全错 → 真硬件上 TX 读越界 / RX 永不工作
- BEFORE hunk:
```
     int slot = d->tx_tail;
     memcpy(d->tx_bufs[slot], buf, len);
     d->tx_descs[slot].addr = (u64)(uintptr_t)d->tx_bufs[slot];
-    d->tx_descs[slot].len = (u16)len;
-    d->tx_descs[slot].vlan = 0;
-    d->tx_descs[slot].cmd_status =
-        IXGBE_TXD_EOP | IXGBE_TXD_IFCS | IXGBE_TXD_RS | IXGBE_TXD_DEXT;
     __asm__ volatile("sfence" ::: "memory");
     d->tx_tail = (d->tx_tail + 1) % IXGBE_NUM_DESC;
     ix_wreg(d, IXGBE_TXQ_BASE(0) + IXGBE_Q_DT, (u32)d->tx_tail);
 
     for (int t = 0; t < 1000000; t++) {
-        if (d->tx_descs[slot].cmd_status & IXGBE_TXD_RS) break;
     }
     d->tx_packets++;
     return len;
```
- AFTER hunk:
```
     int slot = d->tx_tail;
     memcpy(d->tx_bufs[slot], buf, len);
     d->tx_descs[slot].addr = (u64)(uintptr_t)d->tx_bufs[slot];
+    /* BUG-0126 FIX (A8-5): flags + length belong in cmd_type_len (offset
+     * 8); olinfo_status carries PAYLEN (bits 31:14) = the frame length
+     * for a non-LSO frame. The old code wrote the flag bits into
+     * PAYLEN's field, telling the chip to DMA ~232 KB from a 4 KB
+     * buffer (out-of-bounds read + garbage frames). */
+    d->tx_descs[slot].cmd_type_len = (u32)len | IXGBE_TXD_EOP | IXGBE_TXD_IFCS |
+                                     IXGBE_TXD_RS | IXGBE_TXD_DEXT;
+    d->tx_descs[slot].olinfo_status = ((u32)len << 14);
     __asm__ volatile("sfence" ::: "memory");
     d->tx_tail = (d->tx_tail + 1) % IXGBE_NUM_DESC;
     ix_wreg(d, IXGBE_TXQ_BASE(0) + IXGBE_Q_DT, (u32)d->tx_tail);
 
     for (int t = 0; t < 1000000; t++) {
+        /* TX write-back: DD lands in bit 0 of the offset-8 dword. */
+        if (d->tx_descs[slot].cmd_type_len & IXGBE_TXD_STAT_DD) break;
     }
     d->tx_packets++;
     return len;
```

## BUG-0127 (P1, p1fix3) — commit 3bd374e
- Location: driver_nic_rtl8169.c:331-332
- Issue: （对比 146 行 RX 有 EOR）  TX 描述符环从不设置 EOR → 真硬件上第 32 帧后发送机跑出环外永久停摆
- BEFORE hunk:
```
     d->tx_descs[slot].buf_lo = (u32)(uintptr_t)d->tx_bufs[slot];
     d->tx_descs[slot].buf_hi = 0;
     __asm__ volatile("sfence" ::: "memory");
     d->tx_descs[slot].opts1 = R8169_D_OWN | R8169_D_FS | R8169_D_LS |
                               (u32)len;
 
     /* Kick the engine (TP_POLL bit 6 = send normal-priority queue). */
```
- AFTER hunk:
```
     d->tx_descs[slot].buf_lo = (u32)(uintptr_t)d->tx_bufs[slot];
     d->tx_descs[slot].buf_hi = 0;
     __asm__ volatile("sfence" ::: "memory");
+    /* BUG-0127 FIX (A8-6): the C+ mode TX ring has NO TDLEN-style length
+     * register - wrap-around is signalled ONLY by the EOR bit on the
+     * last descriptor (the RX ring already does this, see line ~146).
+     * Without it the transmitter walked past desc 31 into the zero page
+     * and parked there forever after the 32nd frame. */
     d->tx_descs[slot].opts1 = R8169_D_OWN | R8169_D_FS | R8169_D_LS |
+                              ((slot == R8169_TX_DESCS - 1) ? R8169_D_EOR : 0u) |
                               (u32)len;
 
     /* Kick the engine (TP_POLL bit 6 = send normal-priority queue). */
```

## BUG-0128 (P1, p1fix3) — commit 3bd374e
- Location: driver_nic_bcm57xx.c:259-266
- Issue: , 277-286   TX 无任何完成回收检查（环回绕即覆盖在途描述符）+ RX 缓冲从未提交给硬件
- BEFORE hunk:
```
     if (!d->up || len <= 0 || len > BCM_BUF_SIZE) return -1;
 
     int slot = d->tx_tail;
     memcpy(d->tx_bufs[slot], buf, len);
     d->tx_descs[slot].addr = (u32)(uintptr_t)d->tx_bufs[slot];
     d->tx_descs[slot].len_flags = (u32)len | 0x80000000u;   /* EOF */
```
- AFTER hunk:
```
     if (!d->up || len <= 0 || len > BCM_BUF_SIZE) return -1;
 
     int slot = d->tx_tail;
+    /* BUG-0128 FIX (A8-7a): refuse to overwrite a descriptor the chip
+     * may still own. Track the consumer index (chip's send progress);
+     * when the ring is nearly full, poll the TX consumer index mailbox
+     * (0x3208, tg3 MAILBOX_SND_CONIDX_0) for progress and fail the send
+     * with -1 if the outstanding descriptors do not drain in time. */
+    for (int t = 0; t < 1000000; t++) {
+        int inflight = (d->tx_tail - d->tx_clean + BCM_TX_DESCS) % BCM_TX_DESCS;
+        if (inflight < BCM_TX_DESCS - 1) break;
+        d->tx_clean = (int)driver_nic_bcm57xx_reg(d, BCM_TX_CONIDX0) % BCM_TX_DESCS;
+        if (t == 999999) return -1;   /* ring still full: honest failure */
+    }
     memcpy(d->tx_bufs[slot], buf, len);
     d->tx_descs[slot].addr = (u32)(uintptr_t)d->tx_bufs[slot];
     d->tx_descs[slot].len_flags = (u32)len | 0x80000000u;   /* EOF */
```

## BUG-0129 (P1, p1fix3) — commit 3bd374e
- Location: driver_snd_virtio.c
- Issue: :230-241
- BEFORE hunk:
```
         u8 cap_vndr = (u8)(hdr & 0xff);
         u8 cap_next = (u8)((hdr >> 8) & 0xff);
         u8 cap_len  = (u8)((hdr >> 16) & 0xff);
-        if (cap_vndr == VPCI_CAP_VENDOR && cap_len >= 20) {
-            /* cfg_type is at cap_ptr+3, bar at +4, offset +8, length +16 */
             u32 type_off = driver_pci_read_config(bus, dev, func,
                                            (u8)((cap_ptr + 4) & 0xfc));
             u32 lo = driver_pci_read_config(bus, dev, func,
                                      (u8)((cap_ptr + 8) & 0xfc));
             u32 len_lo = driver_pci_read_config(bus, dev, func,
                                          (u8)((cap_ptr + 16) & 0xfc));
-            u8 cfg_type = (u8)((type_off >> 0) & 0xff);
-            u8 bar = (u8)((type_off >> 8) & 0xff);
             u32 bar_val = driver_pci_read_bar(bus, dev, func, bar & 7);
             u64 base = (u64)(bar_val & ~0xfu) + lo;
             (void)len_lo;
```
- AFTER hunk:
```
         u8 cap_vndr = (u8)(hdr & 0xff);
         u8 cap_next = (u8)((hdr >> 8) & 0xff);
         u8 cap_len  = (u8)((hdr >> 16) & 0xff);
+        if (cap_vndr == VPCI_CAP_VENDOR && cap_len >= 16) {
+            /* BUG-0129 FIX (A9-03): two independent parsing bugs made
+             * virtio-snd probe IMPOSSIBLE (QEMU has no such device, so
+             * it survived every test run):
+             *   1) Virtio PCI capability layout: +0 vndr, +1 next,
+             *      +2 len, +3 cfg_type, +4 bar, +5 id, +8 offset_lo,
+             *      +12 offset_hi, +16 notify_off_multiplier.
+             *      driver_pci_read_config reads an ALIGNED dword, and
+             *      caps are 4-byte aligned: dword@cap+0 carries
+             *      cfg_type in bits 31:24, dword@cap+4 carries bar in
+             *      bits 7:0. The old code took cfg_type from dword@+4
+             *      byte 0 (= the BAR field) and bar from its bits 15:8
+             *      (= the id field) - every capability type was
+             *      misidentified.
+             *   2) The length filter was >= 20, but common/isr/device
+             *      caps are 16 bytes (only notify is 20), so those
+         
```

## BUG-0130 (P1, p1fix3) — commit 3bd374e
- Location: driver_snd_hda.c:279-283
- Issue: 、690-701
- BEFORE hunk:
```
             /* ack the response IRQ so the controller keeps going */
             driver_snd_hda_w8(d, HDA_RIRBSTS, HDA_RBSTS_IRQ);
             int unsolicited = (ex & (1u << 4)) ? 1 : 0;
-            if (!unsolicited && (u8)(ex & 0xf) == d->codec_cad)
                 return resp;
             continue;   /* ignore unsolicited / foreign responses */
         }
```
- AFTER hunk:
```
             /* ack the response IRQ so the controller keeps going */
             driver_snd_hda_w8(d, HDA_RIRBSTS, HDA_RBSTS_IRQ);
             int unsolicited = (ex & (1u << 4)) ? 1 : 0;
+            /* BUG-0131 FIX (A9-05): the filter compared the response's
+             * cad against d->codec_cad, which stays 0 during codec
+             * ENUMERATION (it is only assigned after scan_codec
+             * succeeds). A codec that lives at cad != 0 had every
+             * solicited response dropped as "foreign" -> every verb
+             * timed out -> "codec enumeration failed". The target cad
+             * is encoded in the verb itself (bits 31:28), so compare
+             * against that - no state needed, correct at any cad. */
+            if (!unsolicited && (u8)(ex & 0xf) == (u8)((verb >> 28) & 0xf))
                 return resp;
             continue;   /* ignore unsolicited / foreign responses */
         }
```

## BUG-0131 (P1, p1fix3) — commit 3bd374e
- Location: driver_snd_hda.c:225-271
- Issue: （243 行）、296-363（359 行）
- BEFORE hunk:
```
             /* ack the response IRQ so the controller keeps going */
             driver_snd_hda_w8(d, HDA_RIRBSTS, HDA_RBSTS_IRQ);
             int unsolicited = (ex & (1u << 4)) ? 1 : 0;
-            if (!unsolicited && (u8)(ex & 0xf) == d->codec_cad)
                 return resp;
             continue;   /* ignore unsolicited / foreign responses */
         }
```
- AFTER hunk:
```
             /* ack the response IRQ so the controller keeps going */
             driver_snd_hda_w8(d, HDA_RIRBSTS, HDA_RBSTS_IRQ);
             int unsolicited = (ex & (1u << 4)) ? 1 : 0;
+            /* BUG-0131 FIX (A9-05): the filter compared the response's
+             * cad against d->codec_cad, which stays 0 during codec
+             * ENUMERATION (it is only assigned after scan_codec
+             * succeeds). A codec that lives at cad != 0 had every
+             * solicited response dropped as "foreign" -> every verb
+             * timed out -> "codec enumeration failed". The target cad
+             * is encoded in the verb itself (bits 31:28), so compare
+             * against that - no state needed, correct at any cad. */
+            if (!unsolicited && (u8)(ex & 0xf) == (u8)((verb >> 28) & 0xf))
                 return resp;
             continue;   /* ignore unsolicited / foreign responses */
         }
```

## BUG-0132 (P1, p1fix3) — commit 3bd374e
- Location: net_sshd.c
- Issue: 实测：sshd 启动后阻塞监听，Ctrl+C 无法中断，shell 完全失去响应（^C 字节未被消费），只能重启虚拟机。
- BEFORE hunk:
```
 #include "net_core.h"
 #include "net_ssh.h"
 #include "shell.h"
 /* BUG-0075 FIX (A14-24): the embedded universal host key header
  * (net_sshd_rsa_key.h) was DELETED - see the comment at the
  * net_sshd_hostkey_ensure() call in net_sshd_main(). The private
```
- AFTER hunk:
```
 #include "net_core.h"
 #include "net_ssh.h"
 #include "shell.h"
+#include "driver_input_keyboard.h"   /* BUG-0132 FIX: ^C cancels blocking accept */
 /* BUG-0075 FIX (A14-24): the embedded universal host key header
  * (net_sshd_rsa_key.h) was DELETED - see the comment at the
  * net_sshd_hostkey_ensure() call in net_sshd_main(). The private
```

## BUG-0133 (P1, p1fix3) — commit 3bd374e
- Location: fs_vfs.c/shell umount
- Issue: 实测：umount / 无任何防护（不检查根/忙），执行后 mount 表为空，ramfs 全部数据（含 /etc 配置）丢失，所有文件操作失败，无恢复路径只能重启。
- BEFORE hunk:
```
     if (!mount_point) return -1;
     char norm[VFS_PATH_LEN];
     if (fs_vfs_normalize(mount_point, norm, sizeof(norm)) < 0) return -1;
     /* P0fix1 BUG-0002 (A12-002, trigger surface 2): umounting "/" (the
      * root ramfs) used to release the whole tree INCLUDING nested mount
      * roots (their ->private is another fs's inode/context), leaving
```
- AFTER hunk:
```
     if (!mount_point) return -1;
     char norm[VFS_PATH_LEN];
     if (fs_vfs_normalize(mount_point, norm, sizeof(norm)) < 0) return -1;
+    /* BUG-0133 FIX: the root of the VFS namespace (the root ramfs) is the
+     * backbone every other path resolves through. Unmounting it used to
+     * succeed, blank the mount table, drop every ramfs file (including
+     * /etc) and leave the system with no recovery path but a reboot.
+     * Refuse explicitly. */
+    if (strcmp(norm, "/") == 0) {
+        screen_console_puts("vfs: cannot unmount the root filesystem\n");
+        return -4;
+    }
     /* P0fix1 BUG-0002 (A12-002, trigger surface 2): umounting "/" (the
      * root ramfs) used to release the whole tree INCLUDING nested mount
      * roots (their ->private is another fs's inode/context), leaving
```

## BUG-0134 (P1, p1fix3) — commit 3bd374e
- Location: core_sched/shell
- Issue: 实测：连续 run loop × 8 后系统响应从 0.1s 恶化到 30s+（ps 超时），loop 进程为死循环且无便捷 kill 途径（run 输出 pid 与 kill 需要的 tid 对应关系不明确），无并发限制。
- BEFORE hunk:
```
     int background = (shell_cmd_len > 0 && args[shell_cmd_len-1] == '&');
     pid_t pid = user_process_create(elf, size, args);
     if (pid >= 0) {
-        char buf[40]; char n[20];
         strcpy(buf, "started pid="); u64_to_str((u64)pid, n); strcpy(buf+strlen(buf), n);
         strcpy(buf+strlen(buf), "\n"); screen_console_puts(buf);
         /* WP-08cd: For user-space shell (ush), set a flag so the kernel
          * shell's main loop skips readline while ush is running.
```
- AFTER hunk:
```
     int background = (shell_cmd_len > 0 && args[shell_cmd_len-1] == '&');
     pid_t pid = user_process_create(elf, size, args);
     if (pid >= 0) {
+        char buf[96]; char n[20];
         strcpy(buf, "started pid="); u64_to_str((u64)pid, n); strcpy(buf+strlen(buf), n);
+        /* BUG-0134 FIX: print the kill-ready tid next to the pid. `run`
+         * used to print only the pid while `kill` consumes a tid — the
+         * audit noted the two numbers were not obviously related. */
+        extern int user_process_get_tid(pid_t pid);
+        int tid = user_process_get_tid(pid);
+        if (tid >= 0) {
+            strcpy(buf+strlen(buf), " tid=");
+            u64_to_str((u64)tid, n);
+            strcpy(buf+strlen(buf), n);
+            strcpy(buf+strlen(buf), " (kill ");
+            u64_to_str((u64)tid, n);
+            strcpy(buf+strlen(buf), n);
+            strcpy(buf+strlen(buf), " stops it)");
+        }
         strcpy(buf+strlen(buf), "\n"); screen_console_puts(buf);
         /* WP-08cd: For user-space shell (ush), set a flag so the kernel
          * shell's main loop skips readline while ush is running.
```

## BUG-0135 (P1, p1fix3) — commit 3bd374e
- Location: shell/editor.c
- Issue: 实测：vi 命令打开的是与 nano 完全相同的界面（同一实现），不存在 vi 双模式；发送 ithree-fox 与 :wq 全被当作文本插入。宣称的 vi 编辑器功能不实。
- BEFORE hunk:
```
         /* Everything else: ignore. */
     }
 }
```
- AFTER hunk:
```
         /* Everything else: ignore. */
     }
 }
+
+/* ================================================================== *
+ * BUG-0135 FIX: a real two-mode vi.
+ *
+ * The audit run showed `vi` was registered as a plain alias of the nano
+ * engine ("same engine as nano"), so "ithree-fox" and ":wq" were both
+ * taken as literal text — the claimed vi editor did not exist. Below is
+ * a real modal vi built on the same line-buffer session state:
+ *
+ *   NORMAL (entry mode)
+ *     h j k l / arrows   move (j/k clamp the column like vi)
+ *     0 / $              line start / end
+ *     G / g g            last line / first line
+ *     x                  delete the char under the cursor
+ *     d d                delete the current line
+ *     i a A I o O        enter INSERT (before/at/after, line ops)
+ *     :                  ex command line (w, q, wq, q!)
+ *
+ *   INSERT
+ *     printable chars    insert at the cursor
+ *     BKSP / DEL         delete before / at the cursor (BKSP merges lines)
+ *     Enter              split the line at the cursor
+ *     arrows / Home/End  move
+ *     ESC                back to NORMAL
+ *
+ * The console has no ANSI escapes, so any stru
```

## BUG-0136 (P2, p2fix1) — commit 97128bc
- Location: kernel/mem/mem_vmm.c:282-377
- Issue: ②⑦（destroy 的"USER=用户私帧"脆弱约定）
- BEFORE hunk:
```
  * the page tables already allocated are linked into the address space hierarchy
  * and will be freed by mem_vmm_destroy_address_space. This is not a true leak. */
 static volatile u64 *walk_pt(mem_vmm_as_t as, u64 vaddr, int create) {
     volatile u64 *pml4e = pml4_entry_ptr(as, vaddr);
     if (!(*pml4e & VMM_FLAG_PRESENT)) {
         if (!create) return NULL;
```
- AFTER hunk:
```
  * the page tables already allocated are linked into the address space hierarchy
  * and will be freed by mem_vmm_destroy_address_space. This is not a true leak. */
 static volatile u64 *walk_pt(mem_vmm_as_t as, u64 vaddr, int create) {
+    /* BUG-0136 FIX (A1-10): any PT allocated below is PRIVATE to this AS
+     * when the AS is not the kernel AS; tag the linking PDE so destroy can
+     * free tables by ownership instead of by position/shape convention. */
+    const u64 owner = (as != g_kernel_pml4) ? VMM_FLAG_PT_OWNER : 0;
+
     volatile u64 *pml4e = pml4_entry_ptr(as, vaddr);
     if (!(*pml4e & VMM_FLAG_PRESENT)) {
         if (!create) return NULL;
```

## BUG-0137 (P2, p2fix1) — commit 97128bc
- Location: kernel/arch/x86_64/arch_idt_stub.S:81-88
- Issue: ⑧栈对齐（SysV 16 字节）
- BEFORE hunk:
```
     ; The arch_irq_frame_t struct starts with r15 at its lowest address, so
     ; rdi = rsp is exactly the frame pointer we want.
     mov rdi, rsp
-    ; Align stack to 16 bytes for the call (SysV ABI requirement).
-    ; Entry to arch_isr_common: rsp = original - 56 (40 CPU + 8 error + 8 vector).
-    ; After 15 GPR pushes: rsp = original - 176 (176 % 16 = 0, aligned).
-    ; But call itself pushes 8, making it 184 % 16 = 8 (misaligned).
-    ; So sub rsp, 8 before the call to keep alignment.
-    sub rsp, 8
     call arch_isr_dispatch
-    add rsp, 8
 
-    ; Restore GPRs.
-    pop r15
     pop r14
     pop r13
     pop r12
```
- AFTER hunk:
```
     ; The arch_irq_frame_t struct starts with r15 at its lowest address, so
     ; rdi = rsp is exactly the frame pointer we want.
     mov rdi, rsp
+    ; BUG-0137 FIX (A1-4): SysV ABI requires rsp = 0 (mod 16) AT the call
+    ; instruction, so that the callee sees rsp = 8 (mod 16) on entry. In
+    ; 64-bit mode the CPU pushes 5 quadwords (SS, RSP, RFLAGS, CS, RIP =
+    ; 40 bytes) for EVERY interrupt/exception - ring3 and ring0 sources
+    ; alike; IRETQ always pops those 5, and a same-privilege frame is also
+    ; 5 quadwords (the 3-quadword frame is a 32-bit-mode concept). So the
+    ; frame below the stub base is a constant 40 + 16 (err+vector) + 120
+    ; (15 GPRs) = 176 = 11*16 bytes. What varies is the BASE alignment:
+    ; TSS rsp0 / IST tops are 16-aligned in this kernel (kmalloc payloads
+    ; are 16-aligned, static stacks are aligned(16)), but the interrupted
+    ; ring0 rsp can be 0 or 8 (mod 16) depending on the interrupt point.
+    ; The previous fixed `sub rsp, 8` was therefore inverted: on every
+    ; 16-aligned-base path the call site was ALREADY aligned and the sub
+    ; misaligned it (call at 8 mod 16 -> dispatch entry rsp = 0 mod 16,
+    ; an ABI
```

## BUG-0138 (P2, p2fix1) — commit 97128bc
- Location: kernel/arch/x86_64/arch_idt_stub.S:57-87
- Issue: ⑥⑧（DF 标志）
- BEFORE hunk:
```
 ; Common entry: save all GPRs, call dispatcher, restore, iretq.
 align 16
 arch_isr_common:
     ; Save general-purpose registers (SysV order doesn't matter here, we
     ; pass the frame pointer in rdi).
     push rax
```
- AFTER hunk:
```
 ; Common entry: save all GPRs, call dispatcher, restore, iretq.
 align 16
 arch_isr_common:
+    ; BUG-0138 FIX (A1-5): interrupt/trap gates do not clear DF. A ring3
+    ; `std` followed by any interrupt or syscall would otherwise run the
+    ; whole kernel dispatch chain with DF=1, and GCC can emit `rep movsb`
+    ; for aggregate copies even under -mno-sse -> silent memory corruption.
+    cld
     ; Save general-purpose registers (SysV order doesn't matter here, we
     ; pass the frame pointer in rdi).
     push rax
```

## BUG-0139 (P2, p2fix1) — commit 97128bc
- Location: kernel/arch/x86_64/arch_exceptions.c:226-265
- Issue: （配合 arch_idt.c:195-196）  ⑥⑦（IST 栈被挂起重用）
- BEFORE hunk:
```
     ser_puts(&buf[i+1]);
 }
 
 void arch_exc_dispatch(arch_irq_frame_t *f) {
     /* P0fix2 BUG-0041 (RUN-01): guard against recursive fault handling.
      * The fault-printing path itself can #PF (the KNOWN_ISSUES 6.1
```
- AFTER hunk:
```
     ser_puts(&buf[i+1]);
 }
 
+/* BUG-0139 FIX (A1-6): reap-and-yield continuation for kills taken on
+ * IST2-backed exceptions (#DB=1, NMI=2, #BP=3). Runs on the dedicated exit
+ * stack (arch_exc_exit.S), NEVER on IST2, so the scheduler records an
+ * address on this private stack and the global IST2 region is abandoned
+ * instead of carrying a suspended frame that the next IST2 exception would
+ * overwrite. Never returns. */
+void arch_exc_kill_and_yield(user_proc_t *proc, u64 vec) {
+    extern void arch_ist2_range(u64 *base, u64 *size);
+    u64 ist2_base = 0, ist2_size = 0, rsp = 0;
+    arch_ist2_range(&ist2_base, &ist2_size);
+    __asm__ volatile("mov %%rsp, %0" : "=r"(rsp));
+
+    ser_puts("*** IST-exit: vector=");
+    ser_dec(vec);
+    ser_puts(" exit-stack rsp=0x");
+    ser_hex(rsp);
+    if (rsp >= ist2_base && rsp < ist2_base + ist2_size) {
+        ser_puts(" [FAIL: still on IST2]\r\n");
+    } else {
+        ser_puts(" [off-IST2 OK]\r\n");
+    }
+
+    user_process_reap_resources(proc, 128 + (int)vec);
+    task_t *t = core_kthread_current();
+    if (t) t->state = TASK_EXITED;
+    core_sched_yield();
+    /* The task is EXITED; the scheduler never resume
```

## BUG-0140 (P2, p2fix1) — commit 97128bc
- Location: kernel/mem/mem_heap.c:200-204
- Issue: ③整数溢出
- BEFORE hunk:
```
 void *kmalloc(u64 size) {
     if (size == 0) return NULL;
 
     /* Round up to alignment. */
     size = (size + HEAP_ALIGN - 1) & ~(HEAP_ALIGN - 1);
 
     u64 irq_flags;
     mem_heap_lock_acquire(&irq_flags);
```
- AFTER hunk:
```
 void *kmalloc(u64 size) {
     if (size == 0) return NULL;
 
+    /* BUG-0140 FIX (A1-7): reject sizes that would wrap through the
+     * alignment rounding. size >= 2^64 - 15 used to round to 0, pass the
+     * zero check, make find_free(0) match the first free block (b->size
+     * >= 0 is always true) and hand out a 0-size block whose caller would
+     * then write the full unaligned length - heap overflow + stats drift. */
+    if (size > HEAP_MAX_ALLOC) return NULL;
+
     /* Round up to alignment. */
     size = (size + HEAP_ALIGN - 1) & ~(HEAP_ALIGN - 1);
+    if (size == 0) return NULL;  /* paranoia: re-check after rounding */
 
     u64 irq_flags;
     mem_heap_lock_acquire(&irq_flags);
```

## BUG-0141 (P2, p2fix1) — commit 97128bc
- Location: kernel/mem/mem_heap.c:75-119
- Issue: ,210-218   ②④⑤（碎片化下大分配永久失败 + 池槽泄漏）
- BEFORE hunk:
```
     return 0;
 }
 
 static void add_pool(u64 page_count) {
-    if (g_pool_count >= 16) return;
-    /* WP-07: allocate a contiguous run of pages so the heap can satisfy
-     * large allocations (shell token arrays need ~40KB contiguous).
-     * Previously each page was a separate 4KB block, which couldn't
-     * satisfy any allocation > 4KB. */
     u64 phys = mem_pmm_alloc_contig(page_count);
     if (phys == 0) {
-        /* Fallback: allocate single pages (old behavior). */
         for (u64 i = 0; i < page_count; i++) {
             u64 p = mem_pmm_alloc_frame();
             if (p == 0) break;
-            mem_heap_block_t *blk = (mem_heap_block_t*)p;
-            blk->magic = HEAP_MAGIC_FREE;
-            blk->size = PMM_PAGE_SIZE - sizeof(mem_heap_block_t);
-            blk->prev = NULL;
-            blk->next = g_free_list;
-            blk->_pad = 0;
-            if (g_free_list) g_free_list->prev = blk;
-            g_free_list = blk;
-            g_heap_size += PMM_PAGE_SIZE;
-            g_overhead += sizeof(mem_heap_block_t);
-            g_free_count++;
         }
-        g_pool_pages[g_pool_count] = page_count;
-        g_pool_bases[g_pool_count] = 0; /* single
```
- AFTER hunk:
```
     return 0;
 }
 
+static void add_pool_region(u64 base, u64 pages) {
+    /* One big contiguous free block spanning all pages (BUG-0141 FIX:
+     * shared by the contig path and the adjacent-run fallback path). */
+    mem_heap_block_t *blk = (mem_heap_block_t*)base;
+    blk->magic = HEAP_MAGIC_FREE;
+    blk->size = pages * PMM_PAGE_SIZE - sizeof(mem_heap_block_t);
+    blk->prev = NULL;
+    blk->next = g_free_list;
+    if (g_free_list) g_free_list->prev = blk;
+    g_free_list = blk;
+    g_heap_size += pages * PMM_PAGE_SIZE;
+    g_overhead += sizeof(mem_heap_block_t);
+    g_free_count++;
+    if (g_pool_count < 16) {
+        g_pool_pages[g_pool_count] = pages;
+        g_pool_bases[g_pool_count] = base;
+        g_pool_count++;
+    }
+}
+
 static void add_pool(u64 page_count) {
     u64 phys = mem_pmm_alloc_contig(page_count);
     if (phys == 0) {
+        /* Fallback: allocate single pages, but chain PHYSICALLY ADJACENT
+         * pages into one contiguous block (BUG-0141 FIX, A1-8a). The old
+         * fallback registered every page as base=0 "single-page pools"
+         * that in_same_pool() could never merge - so under fragmentation
+         * the heap could 
```

## BUG-0142 (P2, p2fix1) — commit 97128bc
- Location: kernel/arch/x86_64/arch_multiboot2.c:20-72
- Issue: （及 kernel/mem/mem_pmm.c:69-70）  ①④（畸形 mbi 越界读/除零）
- BEFORE hunk:
```
     memset(out, 0, sizeof(*out));
     if (!mbi_phys) return -1;
     const arch_multiboot2_header_t* hdr = (const arch_multiboot2_header_t*)mbi_phys;
     out->header = hdr;
     g_mb2_info = out;   /* WP-10d-pre: remember for arch_multiboot2_get_kernel_self */
 
```
- AFTER hunk:
```
     memset(out, 0, sizeof(*out));
     if (!mbi_phys) return -1;
     const arch_multiboot2_header_t* hdr = (const arch_multiboot2_header_t*)mbi_phys;
+    /* BUG-0142 FIX (A1-9a): the mbi comes from the bootloader (GRUB is only
+     * half-trusted). Validate the wrapper before dereferencing anything:
+     * total_size must at least cover the header + END tag and must stay
+     * within a sane bound (1 MiB - the mbi lives in low memory). */
+    if (hdr->total_size < 16 || hdr->total_size > 0x100000u) return -1;
     out->header = hdr;
     g_mb2_info = out;   /* WP-10d-pre: remember for arch_multiboot2_get_kernel_self */
 
```

## BUG-0143 (P2, p2fix1) — commit 97128bc
- Location: driver_usb.c
- Issue: :114-127
- BEFORE hunk:
```
     if (g_core.n_drivers >= USB_MAX_DRIVERS) return -1;
     driver_usb_driver_t *dr = &g_core.drivers[g_core.n_drivers];
     memset(dr, 0, sizeof(*dr));
-    strcpy(dr->name, name);
     dr->class_code = class_code;
     dr->probe = probe;
     dr->disconnect = disconnect;
```
- AFTER hunk:
```
     if (g_core.n_drivers >= USB_MAX_DRIVERS) return -1;
     driver_usb_driver_t *dr = &g_core.drivers[g_core.n_drivers];
     memset(dr, 0, sizeof(*dr));
+    /* BUG-0143 FIX (A10-10): name[] is a fixed 24-byte field inside the
+     * exported driver registry and the old strcpy() copied the caller's
+     * string unbounded - any name of 24+ characters overwrote class_code/
+     * probe/disconnect/used and then the next driver slot.  Copy with an
+     * explicit bound and always terminate (strncpy-style with a forced
+     * NUL); names that do not fit are truncated and reported.  The 6
+     * built-in names ("hid-kbd"/"hid-mouse"/"usb-msc"/"cdc-acm"/
+     * "ftdi-serial"/"usb-audio", 8-11 chars) are unaffected. */
+    int i = 0;
+    while (i < (int)sizeof(dr->name) - 1 && name[i]) {
+        dr->name[i] = name[i];
+        i++;
+    }
+    dr->name[i] = '\0';
+    if (name[i] != '\0') {
+        driver_usb_log("usb: driver name truncated to 23 chars: ");
+        driver_usb_log(dr->name);
+        driver_usb_log("\n");
+    }
     dr->class_code = class_code;
     dr->probe = probe;
     dr->disconnect = disconnect;
```

## BUG-0144 (P2, p2fix1) — commit 97128bc
- Location: driver_usb.c:902
- Issue: , 957, 976, 1237-1249, 1320
- BEFORE hunk:
```
     if (g_core.n_drivers >= USB_MAX_DRIVERS) return -1;
     driver_usb_driver_t *dr = &g_core.drivers[g_core.n_drivers];
     memset(dr, 0, sizeof(*dr));
-    strcpy(dr->name, name);
     dr->class_code = class_code;
     dr->probe = probe;
     dr->disconnect = disconnect;
```
- AFTER hunk:
```
     if (g_core.n_drivers >= USB_MAX_DRIVERS) return -1;
     driver_usb_driver_t *dr = &g_core.drivers[g_core.n_drivers];
     memset(dr, 0, sizeof(*dr));
+    /* BUG-0143 FIX (A10-10): name[] is a fixed 24-byte field inside the
+     * exported driver registry and the old strcpy() copied the caller's
+     * string unbounded - any name of 24+ characters overwrote class_code/
+     * probe/disconnect/used and then the next driver slot.  Copy with an
+     * explicit bound and always terminate (strncpy-style with a forced
+     * NUL); names that do not fit are truncated and reported.  The 6
+     * built-in names ("hid-kbd"/"hid-mouse"/"usb-msc"/"cdc-acm"/
+     * "ftdi-serial"/"usb-audio", 8-11 chars) are unaffected. */
+    int i = 0;
+    while (i < (int)sizeof(dr->name) - 1 && name[i]) {
+        dr->name[i] = name[i];
+        i++;
+    }
+    dr->name[i] = '\0';
+    if (name[i] != '\0') {
+        driver_usb_log("usb: driver name truncated to 23 chars: ");
+        driver_usb_log(dr->name);
+        driver_usb_log("\n");
+    }
     dr->class_code = class_code;
     dr->probe = probe;
     dr->disconnect = disconnect;
```

## BUG-0145 (P2, p2fix1) — commit 97128bc
- Location: driver_usb.c:921-929
- Issue: , 1124-1130
- BEFORE hunk:
```
     td->buffer = (u32)buf;
 }
 
 /* wait for a run of TDs to go inactive or error out */
 static int driver_usb_uhci_tds_wait(driver_usb_uhci_td_t *tds, int first, int n,
                          u32 timeout_ms) {
```
- AFTER hunk:
```
     td->buffer = (u32)buf;
 }
 
+/* BUG-0145 FIX (A10-12): one shared TD-retirement procedure for BOTH
+ * timeout paths (control/bulk tds_wait below and the interrupt wait).
+ * Intel UHCI Design Guide Rev 1.1 (1996), USBCMD/USBSTS register
+ * descriptions: the host controller prefetches schedule structures and
+ * may be mid-transaction on a TD, so software that retires a TD clears
+ * RS (USBCMD bit 0) and must wait for USBSTS.HCHalted (bit 5) before
+ * rewriting any TD status word.  Procedure: stop RS, poll HCHalted with
+ * a 10 ms cap (then proceed - degraded but bounded, never hung), clear
+ * the ACTIVE bits, restart the schedule exactly as it was.  Keeping the
+ * two call sites identical was the audit's "consistent style" demand. */
+static void driver_usb_uhci_retire(driver_usb_uhci_td_t *tds, int first, int n) {
+    u16 cmd = driver_usb_uhci_inw(g_uhci.io + UHCI_USBCMD);
+    driver_usb_uhci_outw(g_uhci.io + UHCI_USBCMD, (u16)(cmd & ~UHCI_CMD_RS));
+    u64 halt_deadline = core_timer_now_ms() + 10;
+    while (core_timer_now_ms() < halt_deadline) {
+        if (driver_usb_uhci_inw(g_uhci.io + UHCI_USBSTS) &
+            UHCI_STS_HCHALTED) break;
+        core_sched_
```

## BUG-0146 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_xhci.c:280-294
- Issue: , 328-334, 869-875
- BEFORE hunk:
```
     r->trb = trb;
     r->phys = phys;
     r->enq = 0;
     r->cycle = 1;
     r->configured = 0;
     for (int i = 0; i < XHCI_RING_N; i++)
```
- AFTER hunk:
```
     r->trb = trb;
     r->phys = phys;
     r->enq = 0;
+    r->deq = 0;
+    r->in_flight = 0;
     r->cycle = 1;
     r->configured = 0;
     for (int i = 0; i < XHCI_RING_N; i++)
```

## BUG-0147 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_xhci.c
- Issue: :701-702
- BEFORE hunk:
```
  *   events: 32 TRANSFER  33 COMMAND_COMPLETION  34 PORT_STATUS_CHANGE.
  *   Completion codes: 1 success  6 stall  13 short packet  ...
  *
- * Rings: every ring is 64 TRBs with a LINK TRB (Toggle Cycle set, and
- * its cycle bit re-written on every wrap) in the last entry.  One
- * transfer = one event (IOC on the last TRB of the chain only).
  * Device bring-up follows the spec sequence: Enable Slot ->
  * Address Device BSR=1 -> (core reads desc8 through EP0) ->
  * Address Device BSR=0 with the real MPS0 (intercepted from the
```
- AFTER hunk:
```
  *   events: 32 TRANSFER  33 COMMAND_COMPLETION  34 PORT_STATUS_CHANGE.
  *   Completion codes: 1 success  6 stall  13 short packet  ...
  *
+ * Rings: every ring is 64 TRBs with a LINK TRB (Toggle Cycle set; its
+ * cycle bit is re-written on every wrap to the PRE-wrap cycle state so
+ * the controller consumes it and toggles its own CCS - xHCI 4.9.4) in
+ * the last entry.  One transfer = one event (IOC on the last TRB of
+ * the chain only).  The producer also tracks how many TRBs are still
+ * un-retired (events not yet observed) and refuses to enqueue into a
+ * full ring (xHCI 4.9.3: never write TRBs the HC has not consumed).
  * Device bring-up follows the spec sequence: Enable Slot ->
  * Address Device BSR=1 -> (core reads desc8 through EP0) ->
  * Address Device BSR=0 with the real MPS0 (intercepted from the
```

## BUG-0148 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_xhci.c:465-467
- Issue: , 494-496, 863-864
- BEFORE hunk:
```
     u8 rootport; u32 route;
     driver_usb_xhci_topology_of(s->dev, &rootport, &route);
     u32 st = x->ctx_stride;
-    memset(s->in_ctx, 0, 1024);
     u32 *ic = (u32 *)(void *)s->in_ctx;
     ic[0] = 0;                                   /* drop flags */
     ic[1] = (1u << 0) | (1u << 1);               /* add slot + EP0 */
```
- AFTER hunk:
```
     u8 rootport; u32 route;
     driver_usb_xhci_topology_of(s->dev, &rootport, &route);
     u32 st = x->ctx_stride;
+    /* BUG-0153 FIX (A10-30): the input context now spans the control
+     * context, slot context and up to 31 endpoint contexts (2*64 + 31*64
+     * = 2112 bytes with CSZ=1) - zero the whole backing page so no stale
+     * bytes leak into high endpoint contexts (the old 1024-byte memset
+     * already truncated at CSZ=0 / epid >= 30). */
+    memset(s->in_ctx, 0, PMM_PAGE_SIZE);
     u32 *ic = (u32 *)(void *)s->in_ctx;
     ic[0] = 0;                                   /* drop flags */
     ic[1] = (1u << 0) | (1u << 1);               /* add slot + EP0 */
```

## BUG-0149 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_xhci.c:1
- Issue: 047-1050
- BEFORE hunk:
```
  *   events: 32 TRANSFER  33 COMMAND_COMPLETION  34 PORT_STATUS_CHANGE.
  *   Completion codes: 1 success  6 stall  13 short packet  ...
  *
- * Rings: every ring is 64 TRBs with a LINK TRB (Toggle Cycle set, and
- * its cycle bit re-written on every wrap) in the last entry.  One
- * transfer = one event (IOC on the last TRB of the chain only).
  * Device bring-up follows the spec sequence: Enable Slot ->
  * Address Device BSR=1 -> (core reads desc8 through EP0) ->
  * Address Device BSR=0 with the real MPS0 (intercepted from the
```
- AFTER hunk:
```
  *   events: 32 TRANSFER  33 COMMAND_COMPLETION  34 PORT_STATUS_CHANGE.
  *   Completion codes: 1 success  6 stall  13 short packet  ...
  *
+ * Rings: every ring is 64 TRBs with a LINK TRB (Toggle Cycle set; its
+ * cycle bit is re-written on every wrap to the PRE-wrap cycle state so
+ * the controller consumes it and toggles its own CCS - xHCI 4.9.4) in
+ * the last entry.  One transfer = one event (IOC on the last TRB of
+ * the chain only).  The producer also tracks how many TRBs are still
+ * un-retired (events not yet observed) and refuses to enqueue into a
+ * full ring (xHCI 4.9.3: never write TRBs the HC has not consumed).
  * Device bring-up follows the spec sequence: Enable Slot ->
  * Address Device BSR=1 -> (core reads desc8 through EP0) ->
  * Address Device BSR=0 with the real MPS0 (intercepted from the
```

## BUG-0150 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_xhci.c:1
- Issue: 001-1008
- BEFORE hunk:
```
  *   events: 32 TRANSFER  33 COMMAND_COMPLETION  34 PORT_STATUS_CHANGE.
  *   Completion codes: 1 success  6 stall  13 short packet  ...
  *
- * Rings: every ring is 64 TRBs with a LINK TRB (Toggle Cycle set, and
- * its cycle bit re-written on every wrap) in the last entry.  One
- * transfer = one event (IOC on the last TRB of the chain only).
  * Device bring-up follows the spec sequence: Enable Slot ->
  * Address Device BSR=1 -> (core reads desc8 through EP0) ->
  * Address Device BSR=0 with the real MPS0 (intercepted from the
```
- AFTER hunk:
```
  *   events: 32 TRANSFER  33 COMMAND_COMPLETION  34 PORT_STATUS_CHANGE.
  *   Completion codes: 1 success  6 stall  13 short packet  ...
  *
+ * Rings: every ring is 64 TRBs with a LINK TRB (Toggle Cycle set; its
+ * cycle bit is re-written on every wrap to the PRE-wrap cycle state so
+ * the controller consumes it and toggles its own CCS - xHCI 4.9.4) in
+ * the last entry.  One transfer = one event (IOC on the last TRB of
+ * the chain only).  The producer also tracks how many TRBs are still
+ * un-retired (events not yet observed) and refuses to enqueue into a
+ * full ring (xHCI 4.9.3: never write TRBs the HC has not consumed).
  * Device bring-up follows the spec sequence: Enable Slot ->
  * Address Device BSR=1 -> (core reads desc8 through EP0) ->
  * Address Device BSR=0 with the real MPS0 (intercepted from the
```

## BUG-0151 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_xhci.c:610-619
- Issue: , 950-963
- BEFORE hunk:
```
             u32 type = (ev[3] >> TRB_TYPE_SH) & 0x3fu;
             driver_usb_xhci_erdp_update(x);
             if (type != TRB_EV_TRANSFER) continue;
             /* Transfer Event: TL = DW2[23:0], CC = DW2[31:24],
              * Slot ID = DW3[31:24] */
             u32 cc = (ev[2] >> 24) & 0xffu;
             u64 ptr = ((u64)ev[0] | ((u64)ev[1] << 32)) & ~0xfull;
-            u32 slotid = (ev[3] >> 24) & 0xffu;
             if (ptr == trb_phys) {
                 if (cc_out) *cc_out = cc;
                 if (rem_out) *rem_out = ev[2] & 0xffffffu;
                 return 1;
             }
-            for (int i = 0; i < XHCI_MAX_SLOTS; i++) {
-                driver_usb_xhci_slot_t *s = &x->slots[i];
-                if (!s->used || (u32)s->hw_slot != slotid) continue;
-                for (int l = 0; l < 4; l++) {
-                    if (s->int_pending[l] &&
-                        s->int_trb_phys[l] == ptr) {
-                        if (cc == CC_SUCCESS || cc == CC_SHORT_PACKET)
-                            s->latch_valid[l] = 1;
-                        s->int_pending[l] = 0;
-                    }
-                }
-            }
         }
         driver_usb_xhci_er
```
- AFTER hunk:
```
             u32 type = (ev[3] >> TRB_TYPE_SH) & 0x3fu;
             driver_usb_xhci_erdp_update(x);
             if (type != TRB_EV_TRANSFER) continue;
+            /* retire the completed TRB and latch pending interrupt
+             * completions (shared bookkeeping, BUG-0146) */
+            driver_usb_xhci_transfer_event(x, &ev);
             /* Transfer Event: TL = DW2[23:0], CC = DW2[31:24],
              * Slot ID = DW3[31:24] */
             u32 cc = (ev[2] >> 24) & 0xffu;
             u64 ptr = ((u64)ev[0] | ((u64)ev[1] << 32)) & ~0xfull;
             if (ptr == trb_phys) {
                 if (cc_out) *cc_out = cc;
                 if (rem_out) *rem_out = ev[2] & 0xffffffu;
                 return 1;
             }
         }
         driver_usb_xhci_erdp_update(x);
         if (core_timer_now_ms() > deadline) return 0;
```

## BUG-0152 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_xhci.c:758
- Issue: , 862, 869-875
- BEFORE hunk:
```
     u8 dir_in = (setup->bmRequestType & 0x80) ? 1 : 0;
     u64 setup_param = 0;
     memcpy(&setup_param, setup, 8);
-    driver_usb_xhci_ring_put(r, setup_param, 8,
-                  (TRB_SETUP_STAGE << TRB_TYPE_SH) | TRB_IDT | TRB_CH);
-    u64 tr_last;
-    if (len == 0) {
-        tr_last = driver_usb_xhci_ring_put(r, 0, 0,
-                                (TRB_STATUS_STAGE << TRB_TYPE_SH) |
-                                (dir_in ? 0u : TRB_DIR_IN) | TRB_IOC);
-    } else {
-        u8 *bounce = s->ctl_buf;
-        if (!dir_in) memcpy(bounce, buf, len);
-        driver_usb_xhci_ring_put(r, (u64)(uintptr_t)bounce, len,
-                      (TRB_DATA_STAGE << TRB_TYPE_SH) |
-                      (dir_in ? TRB_DIR_IN : 0u) | TRB_CH);
-        tr_last = driver_usb_xhci_ring_put(r, 0, 0,
-                                (TRB_STATUS_STAGE << TRB_TYPE_SH) |
-                                (dir_in ? 0u : TRB_DIR_IN) | TRB_IOC);
     }
     driver_usb_xhci_doorbell(x, (u32)s->hw_slot, 1);   /* slot doorbell, EP0 */
 
     u32 cc = 0, rem = 0;
```
- AFTER hunk:
```
     u8 dir_in = (setup->bmRequestType & 0x80) ? 1 : 0;
     u64 setup_param = 0;
     memcpy(&setup_param, setup, 8);
+    /* BUG-0147 FIX (A10-24): Setup Stage TRB DW3 bits 17:16 = TRT
+     * (Transfer Type, xHCI spec 6.4.1.2.1 Table 6-9): 0 = no data
+     * stage, 2 = OUT data stage, 3 = IN data stage (cross-checked
+     * against Linux TRB_TX_TYPE: TRB_DATA_OUT=2 / TRB_DATA_IN=3; the
+     * first fix wrote the inverted 1/2 pair and 1 is Reserved - real
+     * hosts reject it).  TRT only exists from xHCI 1.0 (HCIVERSION
+     * halfword at CAPLENGTH+2, exactly like Linux's hci_version test);
+     * 0.96 hosts leave it 0.  QEMU (HCIVERSION 0x0100) sequences TRBs
+     * without validating TRT, so either encoding runs there; a real
+     * host rejects a reserved TRT or mis-sequences the transfer. */
+    u32 trt = 0;
+    if (len != 0 && (x->cap[0] >> 16) >= 0x100)
+        trt = dir_in ? (3u << 16) : (2u << 16);
+    /* BUG-0146 (A10-23): a control TD is 2-3 TRBs; refuse up front
+     * rather than overwrite TRBs the controller has not consumed yet
+     * (xHCI 4.9.3) when the EP0 ring ever fills. */
+    if (r->in_flight + 3 > XHCI_RING_N - 1) return OC_USB_ENOMEM;
+   
```

## BUG-0153 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_xhci.c:381-392
- Issue: , 749, 789
- BEFORE hunk:
```
         while (driver_usb_xhci_next_event(x, &ev)) {
             u32 type = (ev[3] >> TRB_TYPE_SH) & 0x3fu;
             driver_usb_xhci_erdp_update(x);
-            if (type != TRB_EV_CMD_DONE) continue;
-            u64 ptr = ((u64)ev[0] | ((u64)ev[1] << 32)) & ~0xfull;
-            if (ptr == cmd_phys) {
                 /* Command Completion Event: CC = DW2[31:24],
                  * Slot ID = DW3[31:24] */
-                u32 cc = (ev[2] >> 24) & 0xffu;
-                x->cmd_rc = (int)cc;
-                x->cmd_slot = (int)((ev[3] >> 24) & 0xffu);
-                return (cc == CC_SUCCESS) ? 0 : -2;
             }
-            /* completion of an older command: ignore */
         }
         driver_usb_xhci_erdp_update(x);
         if (core_timer_now_ms() > deadline) return OC_USB_ETIMEDOUT;
```
- AFTER hunk:
```
         while (driver_usb_xhci_next_event(x, &ev)) {
             u32 type = (ev[3] >> TRB_TYPE_SH) & 0x3fu;
             driver_usb_xhci_erdp_update(x);
+            if (type == TRB_EV_CMD_DONE) {
                 /* Command Completion Event: CC = DW2[31:24],
                  * Slot ID = DW3[31:24] */
+                u64 ptr = ((u64)ev[0] | ((u64)ev[1] << 32)) & ~0xfull;
+                /* BUG-0146: retire this (or an older) command so the
+                 * producer-side count tracks the HC again */
+                if (ptr >= x->cmd_phys &&
+                    ptr < x->cmd_phys + (u64)XHCI_RING_N * 16 &&
+                    x->cmd_in_flight > 0)
+                    x->cmd_in_flight--;
+                if (ptr == cmd_phys) {
+                    u32 cc = (ev[2] >> 24) & 0xffu;
+                    x->cmd_rc = (int)cc;
+                    x->cmd_slot = (int)((ev[3] >> 24) & 0xffu);
+                    return (cc == CC_SUCCESS) ? 0 : -2;
+                }
+                /* completion of an older command: retired above, ignore */
+            } else if (type == TRB_EV_TRANSFER) {
+                /* never drop transfer events seen during a command wait:
+               
```

## BUG-0154 (P2, p2fix1) — commit 97128bc
- Location: driver_usb.c:961-991
- Issue: + 906-932
- BEFORE hunk:
```
     (void)h;
     driver_usb_state_t *u = &g_uhci;
     if (!u->up || !d) return -1;
-    if (len > 14 * 64) return -1;
 
     u8 addr = d->addr;
     u8 data_pid = (setup->bmRequestType & 0x80) ? USB_PID_IN
```
- AFTER hunk:
```
     (void)h;
     driver_usb_state_t *u = &g_uhci;
     if (!u->up || !d) return -1;
+    /* BUG-0144 FIX (A10-11): the DATA-stage buffer is the one DMA target
+     * this driver does NOT own (control transfers DMA the caller's buffer
+     * directly; bulk/interrupt/ISO go through the probe-time bounce pages,
+     * which are checked at probe).  A caller buffer above the 32-bit line
+     * would be silently truncated inside td->buffer, so refuse it cleanly.
+     * In-tree callers pass kernel BSS/stack/heap addresses (always well
+     * below 4 GiB), so the valid path is unchanged. */
+    if (len && (((u64)(uintptr_t)buf >> 32) != 0)) return OC_USB_EINVAL;
+    /* BUG-0155 FIX (A10-6): the capacity guard must use the DEVICE's mps0,
+     * not a hard-coded 64: a FS device with mps0=8 was rejected for a
+     * 150-byte config descriptor even though 68 data TDs * 8 B = 544 B
+     * fit comfortably in the (now larger) TD pool. */
+    {
+        u16 mps0_guard = d->mps0 ? d->mps0 : 8;
+        if (len > (USB_CTRL_TD_COUNT - 2) * (u32)mps0_guard) return -1;
+    }
 
     u8 addr = d->addr;
     u8 data_pid = (setup->bmRequestType & 0x80) ? USB_PID_IN
```

## BUG-0155 (P2, p2fix1) — commit 97128bc
- Location: driver_usb.c:942
- Issue: ,970-983
- BEFORE hunk:
```
         }
         if (!busy) return 0;
         if (core_timer_now_ms() > deadline) {
-            /* retire the TDs by briefly stopping the schedule */
-            u16 cmd = driver_usb_uhci_inw(g_uhci.io + UHCI_USBCMD);
-            driver_usb_uhci_outw(g_uhci.io + UHCI_USBCMD, cmd & ~UHCI_CMD_RS);
-            for (int i = first; i < first + n; i++)
-                tds[i].ctrl &= ~TD_CTRL_ACTIVE;
-            driver_usb_uhci_outw(g_uhci.io + UHCI_USBCMD, cmd);
             return OC_USB_ETIMEDOUT;
         }
         core_sched_yield();
```
- AFTER hunk:
```
         }
         if (!busy) return 0;
         if (core_timer_now_ms() > deadline) {
+            /* BUG-0145 FIX (A10-12): retire through the shared procedure
+             * (stop RS, poll HCHalted, clear ACTIVE, restart RS); the old
+             * inline path cleared ACTIVE with the schedule still running -
+             * a HC/CPU race on the same volatile word with undefined
+             * real-hardware behaviour. */
+            driver_usb_uhci_retire(tds, first, n);
             return OC_USB_ETIMEDOUT;
         }
         core_sched_yield();
```

## BUG-0156 (P2, p2fix1) — commit 97128bc
- Location: driver_usb.c
- Issue: :669-734
- BEFORE hunk:
```
     if (g_core.n_drivers >= USB_MAX_DRIVERS) return -1;
     driver_usb_driver_t *dr = &g_core.drivers[g_core.n_drivers];
     memset(dr, 0, sizeof(*dr));
-    strcpy(dr->name, name);
     dr->class_code = class_code;
     dr->probe = probe;
     dr->disconnect = disconnect;
```
- AFTER hunk:
```
     if (g_core.n_drivers >= USB_MAX_DRIVERS) return -1;
     driver_usb_driver_t *dr = &g_core.drivers[g_core.n_drivers];
     memset(dr, 0, sizeof(*dr));
+    /* BUG-0143 FIX (A10-10): name[] is a fixed 24-byte field inside the
+     * exported driver registry and the old strcpy() copied the caller's
+     * string unbounded - any name of 24+ characters overwrote class_code/
+     * probe/disconnect/used and then the next driver slot.  Copy with an
+     * explicit bound and always terminate (strncpy-style with a forced
+     * NUL); names that do not fit are truncated and reported.  The 6
+     * built-in names ("hid-kbd"/"hid-mouse"/"usb-msc"/"cdc-acm"/
+     * "ftdi-serial"/"usb-audio", 8-11 chars) are unaffected. */
+    int i = 0;
+    while (i < (int)sizeof(dr->name) - 1 && name[i]) {
+        dr->name[i] = name[i];
+        i++;
+    }
+    dr->name[i] = '\0';
+    if (name[i] != '\0') {
+        driver_usb_log("usb: driver name truncated to 23 chars: ");
+        driver_usb_log(dr->name);
+        driver_usb_log("\n");
+    }
     dr->class_code = class_code;
     dr->probe = probe;
     dr->disconnect = disconnect;
```

## BUG-0157 (P2, p2fix1) — commit 97128bc
- Location: driver_usb.c
- Issue: :554-571
- BEFORE hunk:
```
     if (g_core.n_drivers >= USB_MAX_DRIVERS) return -1;
     driver_usb_driver_t *dr = &g_core.drivers[g_core.n_drivers];
     memset(dr, 0, sizeof(*dr));
-    strcpy(dr->name, name);
     dr->class_code = class_code;
     dr->probe = probe;
     dr->disconnect = disconnect;
```
- AFTER hunk:
```
     if (g_core.n_drivers >= USB_MAX_DRIVERS) return -1;
     driver_usb_driver_t *dr = &g_core.drivers[g_core.n_drivers];
     memset(dr, 0, sizeof(*dr));
+    /* BUG-0143 FIX (A10-10): name[] is a fixed 24-byte field inside the
+     * exported driver registry and the old strcpy() copied the caller's
+     * string unbounded - any name of 24+ characters overwrote class_code/
+     * probe/disconnect/used and then the next driver slot.  Copy with an
+     * explicit bound and always terminate (strncpy-style with a forced
+     * NUL); names that do not fit are truncated and reported.  The 6
+     * built-in names ("hid-kbd"/"hid-mouse"/"usb-msc"/"cdc-acm"/
+     * "ftdi-serial"/"usb-audio", 8-11 chars) are unaffected. */
+    int i = 0;
+    while (i < (int)sizeof(dr->name) - 1 && name[i]) {
+        dr->name[i] = name[i];
+        i++;
+    }
+    dr->name[i] = '\0';
+    if (name[i] != '\0') {
+        driver_usb_log("usb: driver name truncated to 23 chars: ");
+        driver_usb_log(dr->name);
+        driver_usb_log("\n");
+    }
     dr->class_code = class_code;
     dr->probe = probe;
     dr->disconnect = disconnect;
```

## BUG-0158 (P2, p2fix1) — commit 97128bc
- Location: driver_usb.c:649
- Issue: -658, :73
- BEFORE hunk:
```
         if (known) continue;
         found += driver_usb_enum_one(h, -1, (u8)p, 0);
     }
-    /* after the root level, walk any hubs that just appeared */
-    for (int pass = 0; pass < 2; pass++) {
         for (int i = 0; i < USB_MAX_DEVICES; i++) {
             driver_usb_dev_t *d = &g_core.devs[i];
             if (d->present && d->host == h &&
```
- AFTER hunk:
```
         if (known) continue;
         found += driver_usb_enum_one(h, -1, (u8)p, 0);
     }
+    /* after the root level, walk any hubs that just appeared.
+     * BUG-0158 FIX (A10-9): the old 2-pass loop only ever reached tier-2
+     * hubs, silently contradicting the documented USB_ENUM_DEPTH=4; each
+     * pass discovers the next tier, so iterate exactly USB_ENUM_DEPTH
+     * times (tier-3 and below now enumerate instead of never appearing).
+     * Cycle protection: a hub is walked exactly once - class_priv is set
+     * to the sentinel below before hub_enumerate() overwrites it with the
+     * port count, so an already-walked (or already walking) hub never
+     * re-enters this loop. */
+    for (int pass = 0; pass < USB_ENUM_DEPTH; pass++) {
         for (int i = 0; i < USB_MAX_DEVICES; i++) {
             driver_usb_dev_t *d = &g_core.devs[i];
             if (d->present && d->host == h &&
```

## BUG-0159 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ohci.c:720-722
- Issue: , 289, 308, 344, 409, 477 等
- BEFORE hunk:
```
  * Schedule:
  *   - control ED chain on HcControlHeadED (CLE), bulk chain on
  *     HcBulkHeadED (BLE), one interrupt ED in HCCA slot 0
- *   - blocking transfers: build ED+TD chain, link at list head, wait
- *     for the last TD's CC to leave 0xF, unlink
  */
 #include "driver_usb.h"
 #include "mem_pmm.h"
```
- AFTER hunk:
```
  * Schedule:
  *   - control ED chain on HcControlHeadED (CLE), bulk chain on
  *     HcBulkHeadED (BLE), one interrupt ED in HCCA slot 0
+ *   - blocking transfers: build the TD chain while the ED carries the
+ *     Skip bit (K), clear K and ring CLF/BLF to arm, then poll the WHOLE
+ *     chain (the first failed TD decides the error code; success only
+ *     when every TD left CC=0xF) and disarm with K + a frame-boundary
+ *     settle so the HC provably released the descriptors before the CPU
+ *     rebuilds them (BUG-0162 / BUG-0165)
  */
 #include "driver_usb.h"
 #include "mem_pmm.h"
```

## BUG-0160 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ehci.c:209-216
- Issue: , 617-622, 674-701
- BEFORE hunk:
```
     if (toggle_hc) token |= QTD_TOKEN_DTOGGLE;
     if (last) token &= ~QTD_TOKEN_IOC;
     td->token = token;
     u64 p = (u64)(uintptr_t)buf;
     for (int i = 0; i < 5; i++) {
         u64 a = p ? (p + (u64)i * 4096) : 0;
```
- AFTER hunk:
```
     if (toggle_hc) token |= QTD_TOKEN_DTOGGLE;
     if (last) token &= ~QTD_TOKEN_IOC;
     td->token = token;
+    /* BUG-0160 FIX (A11-2): the qTD buffer pointers are 32-bit DMA
+     * addresses (EHCI 1.0 spec 4.10.2/4.10.3 - five page pointers plus
+     * the in-page offset).  This truncation is safe by construction:
+     * every buffer handed here is one of the probe-validated descriptor
+     * frames (ctrl_buf/bulk_buf bounce pages; caller buffers are always
+     * memcpy'd in/out, never DMA'd directly), and probe_one() rejects a
+     * pool at/above 4 GiB, so the dropped bits are provably zero. */
     u64 p = (u64)(uintptr_t)buf;
     for (int i = 0; i < 5; i++) {
         u64 a = p ? (p + (u64)i * 4096) : 0;
```

## BUG-0161 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ohci.c:359
- Issue: -366, 181
- BEFORE hunk:
```
 /* ---- toggles (per address / endpoint / direction) ---- */
 
 static u8 driver_usb_ohci_tog_get(driver_usb_ohci_state_t *o, driver_usb_dev_t *d, u8 ep_addr) {
-    int idx = (d->addr & 0x0f) * 16 + (USB_EP_NUM(ep_addr) & 0x0f);
     return (o->toggles[idx] >> ((ep_addr & 0x80) ? 1 : 0)) & 1;
 }
 
 static void driver_usb_ohci_tog_set(driver_usb_ohci_state_t *o, driver_usb_dev_t *d, u8 ep_addr,
                          u8 v) {
-    int idx = (d->addr & 0x0f) * 16 + (USB_EP_NUM(ep_addr) & 0x0f);
     u8 bit = (u8)(1u << ((ep_addr & 0x80) ? 1 : 0));
     if (v) o->toggles[idx] |= bit;
     else   o->toggles[idx] &= (u8)~bit;
```
- AFTER hunk:
```
 /* ---- toggles (per address / endpoint / direction) ---- */
 
 static u8 driver_usb_ohci_tog_get(driver_usb_ohci_state_t *o, driver_usb_dev_t *d, u8 ep_addr) {
+    /* BUG-0161 FIX (A11-20): full 7-bit device address (spec 9.1.1.5) */
+    int idx = (d->addr & 0x7f) * 16 + (USB_EP_NUM(ep_addr) & 0x0f);
     return (o->toggles[idx] >> ((ep_addr & 0x80) ? 1 : 0)) & 1;
 }
 
 static void driver_usb_ohci_tog_set(driver_usb_ohci_state_t *o, driver_usb_dev_t *d, u8 ep_addr,
                          u8 v) {
+    /* BUG-0161 FIX (A11-20): full 7-bit device address */
+    int idx = (d->addr & 0x7f) * 16 + (USB_EP_NUM(ep_addr) & 0x0f);
     u8 bit = (u8)(1u << ((ep_addr & 0x80) ? 1 : 0));
     if (v) o->toggles[idx] |= bit;
     else   o->toggles[idx] &= (u8)~bit;
```

## BUG-0162 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ohci.c
- Issue: :242-251
- BEFORE hunk:
```
  * Schedule:
  *   - control ED chain on HcControlHeadED (CLE), bulk chain on
  *     HcBulkHeadED (BLE), one interrupt ED in HCCA slot 0
- *   - blocking transfers: build ED+TD chain, link at list head, wait
- *     for the last TD's CC to leave 0xF, unlink
  */
 #include "driver_usb.h"
 #include "mem_pmm.h"
```
- AFTER hunk:
```
  * Schedule:
  *   - control ED chain on HcControlHeadED (CLE), bulk chain on
  *     HcBulkHeadED (BLE), one interrupt ED in HCCA slot 0
+ *   - blocking transfers: build the TD chain while the ED carries the
+ *     Skip bit (K), clear K and ring CLF/BLF to arm, then poll the WHOLE
+ *     chain (the first failed TD decides the error code; success only
+ *     when every TD left CC=0xF) and disarm with K + a frame-boundary
+ *     settle so the HC provably released the descriptors before the CPU
+ *     rebuilds them (BUG-0162 / BUG-0165)
  */
 #include "driver_usb.h"
 #include "mem_pmm.h"
```

## BUG-0163 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ohci.c:394
- Issue: , 402, 417-418, 446
- Manual HEAD verification: driver_usb_ohci.c:125,481,497 修复注释在（grep 实证）
- BEFORE hunk:
```
     if (o->bulk_busy) return -1;
     if (len == 0) return 0;
     if (d->speed == USB_SPEED_LS) return OC_USB_EINVAL;
-    if (len > OHCI_N_BULK_TD * 64) return OC_USB_EINVAL;
 
     o->bulk_busy = 1;
     driver_usb_ohci_ed_t *ed = o->bulk_ed;
```
- AFTER hunk:
```
     if (o->bulk_busy) return -1;
     if (len == 0) return 0;
     if (d->speed == USB_SPEED_LS) return OC_USB_EINVAL;
 
     o->bulk_busy = 1;
     driver_usb_ohci_ed_t *ed = o->bulk_ed;
```

## BUG-0164 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ohci.c
- Issue: :662-675
- BEFORE hunk:
```
  * Schedule:
  *   - control ED chain on HcControlHeadED (CLE), bulk chain on
  *     HcBulkHeadED (BLE), one interrupt ED in HCCA slot 0
- *   - blocking transfers: build ED+TD chain, link at list head, wait
- *     for the last TD's CC to leave 0xF, unlink
  */
 #include "driver_usb.h"
 #include "mem_pmm.h"
```
- AFTER hunk:
```
  * Schedule:
  *   - control ED chain on HcControlHeadED (CLE), bulk chain on
  *     HcBulkHeadED (BLE), one interrupt ED in HCCA slot 0
+ *   - blocking transfers: build the TD chain while the ED carries the
+ *     Skip bit (K), clear K and ring CLF/BLF to arm, then poll the WHOLE
+ *     chain (the first failed TD decides the error code; success only
+ *     when every TD left CC=0xF) and disarm with K + a frame-boundary
+ *     settle so the HC provably released the descriptors before the CPU
+ *     rebuilds them (BUG-0162 / BUG-0165)
  */
 #include "driver_usb.h"
 #include "mem_pmm.h"
```

## BUG-0165 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ohci.c:253-263
- Issue: , 261, 420
- BEFORE hunk:
```
     u64 deadline = core_timer_now_ms() + timeout_ms;
     int rc = 0;
     for (;;) {
-        u32 w0 = tds[ntd - 1].word0;
-        u32 cc = w0 & TD_CC_MSK;
-        if (cc != TD_CC_NOTACC) {
-            if (cc == TD_CC_NOERR) rc = 0;
-            else if (cc == TD_CC_STALL) rc = OC_USB_ESTALL;
             else if (cc == TD_CC_NORESP) rc = OC_USB_ETIMEDOUT;
             else rc = OC_USB_EIO;
             break;
         }
         if (core_timer_now_ms() > deadline) {
-            /* disarm: skip the ED so the HC stops touching it */
-            ed->word0 |= ED_K;
             rc = OC_USB_ETIMEDOUT;
             break;
         }
         core_sched_yield();
     }
-    /* disarm and clear the completion flags */
     ed->word0 |= ED_K;
-    if (list == 0) driver_usb_ohci_wr(o, OHCI_CMDSTS, OHCI_CMD_CLF);
-    else driver_usb_ohci_wr(o, OHCI_CMDSTS, OHCI_CMD_BLF);
     return rc;
 }
 
```
- AFTER hunk:
```
     u64 deadline = core_timer_now_ms() + timeout_ms;
     int rc = 0;
     for (;;) {
+        /* BUG-0162 FIX (A11-21): walk the WHOLE chain on every poll.
+         * The old loop inspected only the LAST TD: on a mid-chain
+         * failure the HC halts there (the ED halts when a TD retires
+         * with an error condition), the trailing TDs stay CC=0xF
+         * forever, and the transfer burned its full timeout AND
+         * misreported ETIMEDOUT instead of the first failed TD's
+         * condition (MSC picks its recovery branch by error type).
+         * Success now requires EVERY TD retired - mirrors the EHCI
+         * wait_qtd chain walk. */
+        int failed = -1;      /* first failed TD decides the error */
+        int early_end = 0;    /* short packet: device ended the transfer */
+        int all_retired = 1;
+        for (int i = 0; i < ntd; i++) {
+            u32 cc = tds[i].word0 & TD_CC_MSK;
+            if (cc == TD_CC_NOTACC) { all_retired = 0; break; }
+            if (cc != TD_CC_NOERR) { failed = i; break; }
+            /* retired NOERROR with a non-zero CBP: the OHCI General TD
+             * leaves CurrentBufferPointer at the next untransfe
```

## BUG-0166 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ehci.c
- Issue: :318-324
- BEFORE hunk:
```
     if (toggle_hc) token |= QTD_TOKEN_DTOGGLE;
     if (last) token &= ~QTD_TOKEN_IOC;
     td->token = token;
     u64 p = (u64)(uintptr_t)buf;
     for (int i = 0; i < 5; i++) {
         u64 a = p ? (p + (u64)i * 4096) : 0;
```
- AFTER hunk:
```
     if (toggle_hc) token |= QTD_TOKEN_DTOGGLE;
     if (last) token &= ~QTD_TOKEN_IOC;
     td->token = token;
+    /* BUG-0160 FIX (A11-2): the qTD buffer pointers are 32-bit DMA
+     * addresses (EHCI 1.0 spec 4.10.2/4.10.3 - five page pointers plus
+     * the in-page offset).  This truncation is safe by construction:
+     * every buffer handed here is one of the probe-validated descriptor
+     * frames (ctrl_buf/bulk_buf bounce pages; caller buffers are always
+     * memcpy'd in/out, never DMA'd directly), and probe_one() rejects a
+     * pool at/above 4 GiB, so the dropped bits are provably zero. */
     u64 p = (u64)(uintptr_t)buf;
     for (int i = 0; i < 5; i++) {
         u64 a = p ? (p + (u64)i * 4096) : 0;
```

## BUG-0167 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_msc.c
- Issue: :182-196
- BEFORE hunk:
```
     driver_usb_endpoint_t *ep_in, *ep_out;
     u32 tag;
     u8  lun;
     int up;
     int driver_block_idx;              /* blk layer index, -1 = not registered */
     u64 sectors;
```
- AFTER hunk:
```
     driver_usb_endpoint_t *ep_in, *ep_out;
     u32 tag;
     u8  lun;
+    u8  instance;   /* BUG-0168: global MSC device ordinal for naming */
     int up;
     int driver_block_idx;              /* blk layer index, -1 = not registered */
     u64 sectors;
```

## BUG-0168 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_msc.c
- Issue: :375-376
- BEFORE hunk:
```
     driver_usb_endpoint_t *ep_in, *ep_out;
     u32 tag;
     u8  lun;
     int up;
     int driver_block_idx;              /* blk layer index, -1 = not registered */
     u64 sectors;
```
- AFTER hunk:
```
     driver_usb_endpoint_t *ep_in, *ep_out;
     u32 tag;
     u8  lun;
+    u8  instance;   /* BUG-0168: global MSC device ordinal for naming */
     int up;
     int driver_block_idx;              /* blk layer index, -1 = not registered */
     u64 sectors;
```

## BUG-0169 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ehci.c:410
- Issue: -424, 418
- BEFORE hunk:
```
     u8 pid = (ep_addr & 0x80) ? QTD_PID_IN : QTD_PID_OUT;
 
     driver_usb_ehci_qh_t *qh = e->qh_int;
-    driver_usb_ehci_qtd_t *td = e->ctrl_qtds;   /* reuse slot 0 (ctrl is idle
-                                        during interrupt use) */
     u32 epchar = ((u32)d->addr & 0x7f) |
                  (((u32)ep & 0xf) << QH_EPCHAR_EP_SH) |
                  (((d->speed == USB_SPEED_LS) ? 1 :
                    (d->speed == USB_SPEED_HS) ? 2 : 0)
                   << QH_EPCHAR_EPS_SH) |
                  QH_EPCHAR_DTC |
-                 (((u32)(len & 0x7ff)) << QH_EPCHAR_MPLEN_SH);
     qh->epchar = epchar;
     /* interrupt QH: SMASK = micro-frame 0 of every frame (1 ms) */
     qh->epcap = (1u << 30) | 0x01u;
```
- AFTER hunk:
```
     u8 pid = (ep_addr & 0x80) ? QTD_PID_IN : QTD_PID_OUT;
 
     driver_usb_ehci_qh_t *qh = e->qh_int;
+    /* BUG-0169 FIX (A11-4): refuse the borrow while a control transfer
+     * owns the shared ctrl_qtds[0]/ctrl_buf instead of relying on the
+     * core lock's external serialization alone; also keep busy_ctrl set
+     * for the whole interrupt transaction. */
+    if (e->busy_ctrl) return -1;
+    e->busy_ctrl = 1;
+    driver_usb_ehci_qtd_t *td = e->ctrl_qtds;   /* reuse slot 0 (guarded) */
+    /* MPLEN must be the ENDPOINT's max packet size, not the request
+     * length: MPS < len violates the endpoint transaction limit and
+     * MPS > len breaks short-packet semantics (EHCI spec 3.5.3). */
+    u16 ep_mps = 64;
+    {
+        driver_usb_endpoint_t *epd = driver_usb_find_ep(d, 0xff,
+                                          USB_EP_ATTR_INTERRUPT,
+                                          (ep_addr & 0x80) ? 1 : 0);
+        if (epd && USB_EP_NUM(epd->addr) == ep && epd->maxpack)
+            ep_mps = epd->maxpack;
+    }
     u32 epchar = ((u32)d->addr & 0x7f) |
                  (((u32)ep & 0xf) << QH_EPCHAR_EP_SH) |
                  (((d->speed == USB_SPEED_LS)
```

## BUG-0170 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_serial.c:261-274
- Issue: （对照 234-258）
- BEFORE hunk:
```
     return n;
 }
 
 int driver_usb_serial_write(const void *buf, int len) {
     for (int i = 0; i < SER_MAX_PORTS; i++) {
         driver_usb_serial_port_t *p = &g_port[i];
         if (!p->up || !p->dev->present) continue;
-        const u8 *src = (const u8 *)buf;
-        int sent = 0;
-        while (sent < len) {
-            u16 chunk = (u16)(len - sent);
-            if (chunk > 64) chunk = 64;
-            int rc = driver_usb_bulk_transfer(p->dev, p->ep_out->addr,
-                                       (void *)(src + sent), chunk);
-            if (rc < 0) {
-                if (rc == OC_USB_ESTALL) {
-                    driver_usb_control(p->dev, 0x02, USB_REQ_CLEAR_FEAT, 0,
-                                p->ep_out->addr, NULL, 0);
-                    driver_usb_tog_reset(p->dev, p->ep_out->addr);
-                }
-                return sent ? sent : rc;
-            }
-            sent += rc;
-        }
-        p->tx_bytes += (u64)sent;
-        return sent;
     }
     return -1;
 }
 
 int driver_usb_serial_read(void *buf, int max) {
-    for (int i = 0; i < SER_MAX_PORTS; i++) {
         driver_usb_serial_port_t *p = &g_port[i];
         if (!p->up) continue;

```
- AFTER hunk:
```
     return n;
 }
 
+/* Chunked blocking bulk-OUT to ONE port with stall recovery.
+ * Returns the number of bytes sent, or a negative error when nothing
+ * could be sent. */
+static int ser_port_write(driver_usb_serial_port_t *p, const void *buf, int len) {
+    const u8 *src = (const u8 *)buf;
+    int sent = 0;
+    while (sent < len) {
+        u16 chunk = (u16)(len - sent);
+        if (chunk > 64) chunk = 64;
+        int rc = driver_usb_bulk_transfer(p->dev, p->ep_out->addr,
+                                   (void *)(src + sent), chunk);
+        if (rc < 0) {
+            if (rc == OC_USB_ESTALL) {
+                driver_usb_control(p->dev, 0x02, USB_REQ_CLEAR_FEAT, 0,
+                            p->ep_out->addr, NULL, 0);
+                driver_usb_tog_reset(p->dev, p->ep_out->addr);
+            }
+            return sent ? sent : rc;
+        }
+        if (rc == 0) break;   /* defensive (A11-47): never spin on 0 */
+        sent += rc;
+    }
+    p->tx_bytes += (u64)sent;
+    return sent;
+}
+
+/* BUG-0170 FIX (A11-44): explicit per-port routing. The legacy
+ * handle-free write() can only ever talk to the first up port; with
+ * two ports attached the second on
```

## BUG-0171 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_serial.c
- Issue: :214-215
- BEFORE hunk:
```
  *
  * Both transports end in the same port object: bulk OUT for TX,
  * bulk IN drained into a small RX ring by driver_usb_serial_poll().
  */
 #include "driver_usb_serial.h"
 #include "driver_usb.h"
```
- AFTER hunk:
```
  *
  * Both transports end in the same port object: bulk OUT for TX,
  * bulk IN drained into a small RX ring by driver_usb_serial_poll().
+ *
+ * Multi-port surface (BUG-0170 FIX, A11-44): the legacy handle-free
+ * driver_usb_serial_write()/read() target the FIRST up port, with
+ * read() aggregating across all ports. Explicit routing to any port
+ * is available through driver_usb_serial_write_port(port, buf, len)
+ * (prototype declared in this file; header sync note in the worklog).
  */
 #include "driver_usb_serial.h"
 #include "driver_usb.h"
```

## BUG-0172 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_audio.c:149-153
- Issue: , 165-169
- BEFORE hunk:
```
     ad->stream_active = 1;
 
     while (sent < len) {
         u16 chunk = pkt;
-        if ((u32)chunk > (u32)(len - sent)) chunk = (u16)(len - sent);
-        chunk &= ~3u;
-        if (chunk < 4) chunk = 4;
 
         /* wait for the next frame boundary */
         u16 f0 = driver_usb_audio_frnum();
```
- AFTER hunk:
```
     ad->stream_active = 1;
 
     while (sent < len) {
+        u32 remain = (u32)(len - sent);
         u16 chunk = pkt;
+        if ((u32)chunk > remain) chunk = (u16)remain;
 
         /* wait for the next frame boundary */
         u16 f0 = driver_usb_audio_frnum();
```

## BUG-0173 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ehci.c
- Issue: :239-242
- BEFORE hunk:
```
     if (toggle_hc) token |= QTD_TOKEN_DTOGGLE;
     if (last) token &= ~QTD_TOKEN_IOC;
     td->token = token;
     u64 p = (u64)(uintptr_t)buf;
     for (int i = 0; i < 5; i++) {
         u64 a = p ? (p + (u64)i * 4096) : 0;
```
- AFTER hunk:
```
     if (toggle_hc) token |= QTD_TOKEN_DTOGGLE;
     if (last) token &= ~QTD_TOKEN_IOC;
     td->token = token;
+    /* BUG-0160 FIX (A11-2): the qTD buffer pointers are 32-bit DMA
+     * addresses (EHCI 1.0 spec 4.10.2/4.10.3 - five page pointers plus
+     * the in-page offset).  This truncation is safe by construction:
+     * every buffer handed here is one of the probe-validated descriptor
+     * frames (ctrl_buf/bulk_buf bounce pages; caller buffers are always
+     * memcpy'd in/out, never DMA'd directly), and probe_one() rejects a
+     * pool at/above 4 GiB, so the dropped bits are provably zero. */
     u64 p = (u64)(uintptr_t)buf;
     for (int i = 0; i < 5; i++) {
         u64 a = p ? (p + (u64)i * 4096) : 0;
```

## BUG-0174 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_audio.c:183
- Issue: -192, 202
- BEFORE hunk:
```
     return 0;
 }
 
 static int driver_usb_audio_ops_set_rate(driver_snd_device_t *sdev, u32 rate) {
     driver_usb_audio_dev_t *ad = (driver_usb_audio_dev_t *)sdev->priv;
     if (!ad || !ad->up) return -1;
-    /* UAC1 devices advertise fixed rates per alternate setting; the
-     * QEMU device runs 48 kHz.  Other rates are accepted as the
-     * logical request and honoured when the device supports them. */
     if (rate == 0) return -1;
     ad->rate = rate;
     return 0;
 }
 
```
- AFTER hunk:
```
     return 0;
 }
 
+/* map a standard PCM rate to its SND_RATE_* capability bit (0 when
+ * the rate is not one of the framework's standard rates) */
+static u32 driver_usb_audio_rate_bit(u32 rate) {
+    switch (rate) {
+    case 8000:  return SND_RATE_8000;
+    case 11025: return SND_RATE_11025;
+    case 16000: return SND_RATE_16000;
+    case 22050: return SND_RATE_22050;
+    case 32000: return SND_RATE_32000;
+    case 44100: return SND_RATE_44100;
+    case 48000: return SND_RATE_48000;
+    case 64000: return SND_RATE_64000;
+    case 88200: return SND_RATE_88200;
+    case 96000: return SND_RATE_96000;
+    default:    return 0;
+    }
+}
+
 static int driver_usb_audio_ops_set_rate(driver_snd_device_t *sdev, u32 rate) {
     driver_usb_audio_dev_t *ad = (driver_usb_audio_dev_t *)sdev->priv;
     if (!ad || !ad->up) return -1;
     if (rate == 0) return -1;
     ad->rate = rate;
+    /* BUG-0174 FIX (A11-50): actually tell the DEVICE. The old code
+     * only updated the in-memory ad->rate and left the endpoint
+     * sampling at whatever the stream alt-setting had configured - a
+     * non-48k device kept playing at its original speed (the comment
+     * claimed the 
```

## BUG-0175 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ehci.c:495-499
- Issue: , 556-559
- BEFORE hunk:
```
     u32 v = driver_usb_ehci_rd(e, EHCI_PORTSC + (u32)port * 4);
     out->connected = (v & PORTSC_CONNECT) ? 1 : 0;
     out->enabled = (v & PORTSC_PED) ? 1 : 0;
-    u32 lines = (v >> PORTSC_LINESTAT_SH) & 3;
-    if (out->connected && lines == 1)
-        out->speed = USB_SPEED_LS;   /* K-state = low speed */
-    else
-        out->speed = USB_SPEED_HS;   /* EHCI ports are high-speed */
     out->changed = (v & PORTSC_CSC) ? 1 : 0;
     if (v & PORTSC_CSC)
         /* W1C the change bit but KEEP port power and port enable: PP
```
- AFTER hunk:
```
     u32 v = driver_usb_ehci_rd(e, EHCI_PORTSC + (u32)port * 4);
     out->connected = (v & PORTSC_CONNECT) ? 1 : 0;
     out->enabled = (v & PORTSC_PED) ? 1 : 0;
+    /* BUG-0175 FIX (A11-6): read the PORTSC.PS (Port Speed, bits 13:12)
+     * field instead of LINE-STATE. LINE-STATUS only carries a reliable
+     * speed encoding at the END of reset; a steady-state read reports the
+     * current line J/K state, which misclassifies FS devices as HS. PS:
+     * 0=FS, 1=LS, 2=HS (EHCI 1.0 spec Table 2-16). */
+    {
+        u32 ps = (v >> 12) & 3;
+        if (ps == 1)      out->speed = USB_SPEED_LS;
+        else if (ps == 2) out->speed = USB_SPEED_HS;
+        else              out->speed = USB_SPEED_FS;
+    }
     out->changed = (v & PORTSC_CSC) ? 1 : 0;
     if (v & PORTSC_CSC)
         /* W1C the change bit but KEEP port power and port enable: PP
```

## BUG-0176 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ehci.c
- Issue: :642-648
- BEFORE hunk:
```
     if (toggle_hc) token |= QTD_TOKEN_DTOGGLE;
     if (last) token &= ~QTD_TOKEN_IOC;
     td->token = token;
     u64 p = (u64)(uintptr_t)buf;
     for (int i = 0; i < 5; i++) {
         u64 a = p ? (p + (u64)i * 4096) : 0;
```
- AFTER hunk:
```
     if (toggle_hc) token |= QTD_TOKEN_DTOGGLE;
     if (last) token &= ~QTD_TOKEN_IOC;
     td->token = token;
+    /* BUG-0160 FIX (A11-2): the qTD buffer pointers are 32-bit DMA
+     * addresses (EHCI 1.0 spec 4.10.2/4.10.3 - five page pointers plus
+     * the in-page offset).  This truncation is safe by construction:
+     * every buffer handed here is one of the probe-validated descriptor
+     * frames (ctrl_buf/bulk_buf bounce pages; caller buffers are always
+     * memcpy'd in/out, never DMA'd directly), and probe_one() rejects a
+     * pool at/above 4 GiB, so the dropped bits are provably zero. */
     u64 p = (u64)(uintptr_t)buf;
     for (int i = 0; i < 5; i++) {
         u64 a = p ? (p + (u64)i * 4096) : 0;
```

## BUG-0177 (P2, p2fix1) — commit 97128bc
- Location: driver_usb_ehci.c:282
- Issue: , 288, 297（对照 270 的 QH_EPCHAR_DTC）
- BEFORE hunk:
```
                   << QH_EPCHAR_MPLEN_SH) |
                  QH_EPCHAR_H;   /* ctrl QH is the async head of the
                                    reclamation list (spec 4.9.1.1) */
     qh->epchar = epchar;
     qh->epcap = (1u << 30);
 
-    /* qTD chain: SETUP (DATA0 per the spec - the toggle bit must be
-     * 0) + DATA (DATA1) + STATUS (DATA1).  The SETUP 8 bytes are
-     * copied into the page-aligned bounce buffer. */
     memcpy(e->ctrl_buf, setup, 8);
     driver_usb_ehci_qtd_fill(&tds[0], QTD_PID_SETUP, e->ctrl_buf, 8, 0, 0);
     int n = 1;
```
- AFTER hunk:
```
                   << QH_EPCHAR_MPLEN_SH) |
                  QH_EPCHAR_H;   /* ctrl QH is the async head of the
                                    reclamation list (spec 4.9.1.1) */
+    /* EPS encoding per EHCI 1.0 spec 2.3.5 (QH characteristic word,
+     * bits 13:12): 0=FS, 1=LS, 2=HS.  USB_SPEED_FS falls into the 0
+     * branch, so a full-speed device detected by port_status/port_reset
+     * (BUG-0175 fix) is addressed with FS timing here and never as HS.
+     * QEMU-testable: qemu -device usb-ehci -device usb-kbd puts a
+     * full-speed HID device directly on the EHCI root port. */
     qh->epchar = epchar;
     qh->epcap = (1u << 30);
 
+    /* qTD chain: SETUP (DATA0) + DATA (DATA1) + STATUS (DATA1).
+     * A11-8 review (BUG-0177): QH.EPChar.DTC=1 means the HC takes the data
+     * toggle from EACH qTD's T bit (EHCI 1.0 spec 4.11.2), NOT from the
+     * QH overlay; SETUP's qtd_fill(..., toggle_hc=0) leaves T=0 = DATA0,
+     * which is exactly what USB 2.0 8.5.3 mandates for every SETUP.
+     * The overlay never feeds the toggle on this chain, so the old
+     * "second SETUP sends DATA1" hazard does not exist here. */
     memcpy(e->ctrl_buf, setup, 8);
     d
```

## BUG-0178 (P2, p2fix1) — commit 97128bc
- Location: fs_vfs.c:640
- Issue: 只读 fd 检查用全等可被绕过
- BEFORE hunk:
```
     fs_vfs_node_t     *root_node;                  /* root of mounted fs */
     char            device[VFS_NAME_LEN];
     int             in_use;
 } fs_vfs_mount_t;
 
 static fs_vfs_fs_type_t  g_fs_types[VFS_MAX_FS_TYPES];
```
- AFTER hunk:
```
     fs_vfs_node_t     *root_node;                  /* root of mounted fs */
     char            device[VFS_NAME_LEN];
     int             in_use;
+    /* BUG-0184 FIX (A12-019 b): directory node that lived at the mount
+     * point before the mount shadowed it. Kept alive here and restored
+     * when the mount is removed, so mounting onto an existing directory
+     * REUSES it instead of inserting a second same-name child (readdir
+     * double-listing) and instead of leaking it. */
+    fs_vfs_node_t     *shadowed_node;
 } fs_vfs_mount_t;
 
 static fs_vfs_fs_type_t  g_fs_types[VFS_MAX_FS_TYPES];
```

## BUG-0179 (P2, p2fix1) — commit 97128bc
- Location: fs_vfs.c:462-468
- Issue: 节点缓存命中用 strcasecmp，与大小写敏感 fs 冲突
- BEFORE hunk:
```
     fs_vfs_node_t     *root_node;                  /* root of mounted fs */
     char            device[VFS_NAME_LEN];
     int             in_use;
 } fs_vfs_mount_t;
 
 static fs_vfs_fs_type_t  g_fs_types[VFS_MAX_FS_TYPES];
```
- AFTER hunk:
```
     fs_vfs_node_t     *root_node;                  /* root of mounted fs */
     char            device[VFS_NAME_LEN];
     int             in_use;
+    /* BUG-0184 FIX (A12-019 b): directory node that lived at the mount
+     * point before the mount shadowed it. Kept alive here and restored
+     * when the mount is removed, so mounting onto an existing directory
+     * REUSES it instead of inserting a second same-name child (readdir
+     * double-listing) and instead of leaking it. */
+    fs_vfs_node_t     *shadowed_node;
 } fs_vfs_mount_t;
 
 static fs_vfs_fs_type_t  g_fs_types[VFS_MAX_FS_TYPES];
```

## BUG-0180 (P2, p2fix1) — commit 97128bc
- Location: fs_ramfs.c:111-127
- Issue: 稀疏洞未清零 → 内核堆内容泄漏进文件
- BEFORE hunk:
```
         while (new_cap < need_end) new_cap *= 2;
         u8 *new_data = (u8 *)krealloc(ri->data, new_cap);
         if (!new_data) return -4;
         ri->data = new_data;
         ri->capacity = new_cap;
     }
     memcpy(ri->data + offset, buf, (usize)size);
     if (need_end > ri->size) {
```
- AFTER hunk:
```
         while (new_cap < need_end) new_cap *= 2;
         u8 *new_data = (u8 *)krealloc(ri->data, new_cap);
         if (!new_data) return -4;
+        /* BUG-0180 FIX (A12-015): krealloc does NOT zero the grown tail,
+         * and the write below only fills [offset, offset+size). The
+         * hole [old size, offset) returned recycled heap bytes, so
+         * `cat` on a seek-past-EOF-then-write file leaked other tasks'
+         * freed kernel heap contents. Zero-fill the exposed hole. */
+        if (offset > ri->size)
+            memset(new_data + ri->size, 0, (usize)(offset - ri->size));
         ri->data = new_data;
         ri->capacity = new_cap;
+    } else if (offset > ri->size) {
+        /* capacity already covers the hole: still zero it before use */
+        memset(ri->data + ri->size, 0, (usize)(offset - ri->size));
     }
     memcpy(ri->data + offset, buf, (usize)size);
     if (need_end > ri->size) {
```

## BUG-0181 (P2, p2fix1) — commit 97128bc
- Location: fs_vfs.c:897-908
- Issue: list_mounts 行缓冲极限溢出
- BEFORE hunk:
```
          * so later lookups cannot hit the stale cached node. */
         fs_vfs_node_t *dead = NULL;
         for (fs_vfs_node_t *c = parent->first_child; c; c = c->next_sibling) {
-            if (strcasecmp(c->name, base) == 0) { dead = c; break; }
         }
         if (dead) fs_vfs_detach_child(dead);
     }
```
- AFTER hunk:
```
          * so later lookups cannot hit the stale cached node. */
         fs_vfs_node_t *dead = NULL;
         for (fs_vfs_node_t *c = parent->first_child; c; c = c->next_sibling) {
+            if (fs_vfs_cache_name_match(parent, c->name, base)) { dead = c; break; }
         }
         if (dead) fs_vfs_detach_child(dead);
     }
```

## BUG-0182 (P2, p2fix1) — commit 97128bc
- Location: fs_vfs.c:768-783
- Issue: 权限位只存不查
- BEFORE hunk:
```
     fs_vfs_node_t     *root_node;                  /* root of mounted fs */
     char            device[VFS_NAME_LEN];
     int             in_use;
 } fs_vfs_mount_t;
 
 static fs_vfs_fs_type_t  g_fs_types[VFS_MAX_FS_TYPES];
```
- AFTER hunk:
```
     fs_vfs_node_t     *root_node;                  /* root of mounted fs */
     char            device[VFS_NAME_LEN];
     int             in_use;
+    /* BUG-0184 FIX (A12-019 b): directory node that lived at the mount
+     * point before the mount shadowed it. Kept alive here and restored
+     * when the mount is removed, so mounting onto an existing directory
+     * REUSES it instead of inserting a second same-name child (readdir
+     * double-listing) and instead of leaking it. */
+    fs_vfs_node_t     *shadowed_node;
 } fs_vfs_mount_t;
 
 static fs_vfs_fs_type_t  g_fs_types[VFS_MAX_FS_TYPES];
```

## BUG-0183 (P2, p2fix1) — commit 97128bc
- Location: fs_vfs.c:681
- Issue: seek 返回值 int 截断
- BEFORE hunk:
```
 int fs_vfs_read(int fd, void *buf, int size) {
     if (fd < 0 || fd >= VFS_MAX_FDS || !g_fds[fd].in_use) return -1;
     fs_vfs_file_t *f = &g_fds[fd];
-    if (!f->node || !f->node->fs_type || !f->node->fs_type->file_ops ||
         !f->node->fs_type->file_ops->read) {
         return -2;
     }
```
- AFTER hunk:
```
 int fs_vfs_read(int fd, void *buf, int size) {
     if (fd < 0 || fd >= VFS_MAX_FDS || !g_fds[fd].in_use) return -1;
     fs_vfs_file_t *f = &g_fds[fd];
+    if (!f->node) return -2;
+    /* BUG-0178 FIX (A12-013), read side: refuse reads only on an
+     * UNAMBIGUOUS write-only open (WRONLY set while RDONLY and CREAT
+     * are clear). The syscall layer passes user flags through verbatim
+     * and shipped user programs encode read intent both as 0 (POSIX
+     * O_RDONLY: sort/uniq) and as WRONLY|CREAT (6: wc/uniq open with
+     * create, then read), so a strict "RDONLY bit required" gate
+     * regressed those existing workflows. A plain VFS_O_WRONLY fd
+     * (flags == 0x2 exactly) is still refused. The WRITE side below is
+     * the side this bug is about and stays strict. */
+    if ((f->flags & VFS_O_WRONLY) != 0 &&
+        (f->flags & (VFS_O_RDONLY | VFS_O_CREAT)) == 0) return -1;
+    /* BUG-0182 FIX (A12-017): re-check the permission bits at use time
+     * (a chmod after open revokes access on the next call). */
+    if (!fs_vfs_node_grants(f->node, 0)) return -9;
+    if (!f->node->fs_type || !f->node->fs_type->file_ops ||
         !f->node->fs_type->file_ops-
```

## BUG-0184 (P2, p2fix1) — commit 97128bc
- Location: fs_vfs.c:293-297
- Issue: + 303-324   umount "/" 后 g_global_root 悬挂；挂载点遮蔽产生重复子节点
- BEFORE hunk:
```
 
     /* If mounting at "/", set global root to be this fs's root. */
     if (strcmp(norm, "/") == 0) {
-        /* Carry over any children of the placeholder global root (none,
-         * typically) and substitute. */
         root->parent = NULL;
         g_global_root = root;
     } else {
```
- AFTER hunk:
```
 
     /* If mounting at "/", set global root to be this fs's root. */
     if (strcmp(norm, "/") == 0) {
+        /* BUG-0184 FIX (A12-019 a): the placeholder root allocated by
+         * fs_vfs_init() used to be silently dropped here (leaked), and
+         * any children attached to it before the first mount were lost.
+         * Carry the children over to the real root, then release the
+         * placeholder. The umount side refuses "/" (BUG-0133), so
+         * g_global_root can never dangle and this substitution happens
+         * exactly once. */
+        if (g_global_root && g_global_root != root) {
+            fs_vfs_node_t *c = g_global_root->first_child;
+            while (c) {
+                fs_vfs_node_t *next = c->next_sibling;
+                fs_vfs_attach_child(root, c);
+                c = next;
+            }
+            g_global_root->first_child = NULL;
+            /* Placeholder nodes carry no fs private data (fs_type NULL,
+             * private NULL from fs_vfs_alloc_node), so a plain kfree is
+             * complete. */
+            kfree(g_global_root);
+        }
         root->parent = NULL;
         g_global_root = root;
     } else {
```

## BUG-0185 (P2, p2fix1) — commit 97128bc
- Location: fs_fat32.c:211-224；fs_exfat.c
- Issue: （mount 998 区）  FAT#1 镜像 / exFAT number_of_fats 从不更新
- BEFORE hunk:
```
  * Layout (LBA28 sectors, 512 bytes each):
  *   [reserved region: boot sector + (reserved_sectors-1) more]
  *   [FAT #0: fat_size_sectors sectors]
- *   [FAT #1: fat_size_sectors sectors]   (we only use FAT #0)
  *   [data region: starts at data_start_lba, cluster 2 is the first one]
  *
  * FAT32 entries are 32 bits wide; the low 28 bits are the next-cluster
  * pointer. End-of-chain markers are 0x0FFFFFF8..0x0FFFFFFF. Free clusters
  * are 0x00000000.
```
- AFTER hunk:
```
  * Layout (LBA28 sectors, 512 bytes each):
  *   [reserved region: boot sector + (reserved_sectors-1) more]
  *   [FAT #0: fat_size_sectors sectors]
+ *   [FAT #1: fat_size_sectors sectors]
  *   [data region: starts at data_start_lba, cluster 2 is the first one]
  *
+ * BUG-0185 (A12-020): the FAT copy that gets cached and updated is the
+ * ACTIVE one (BPB_ExtFlags, fs.doc 2.1.4 "FAT32 Extended BPB"); while
+ * mirroring is enabled (ext_flags bit 7 = 0) every FAT-sector write is
+ * replayed to every other copy, so FAT #1 is no longer left stale.
+ *
  * FAT32 entries are 32 bits wide; the low 28 bits are the next-cluster
  * pointer. End-of-chain markers are 0x0FFFFFF8..0x0FFFFFFF. Free clusters
  * are 0x00000000.
```

## BUG-0186 (P2, p2fix1) — commit 97128bc
- Location: fs_fat32.c:229-243
- Issue: FSINFO 结构从不读写；alloc 每次从簇 2 线性扫描
- BEFORE hunk:
```
     int rc = driver_block_write_sectors_raw(ctx->dev_idx,
                                (u64)ctx->fat_start_lba + sector_offset, 1,
                                ctx->fat_cache + sector_offset * ctx->bytes_per_sector);
-    return rc == 0 ? 0 : -3;
 }
 
 /* Allocate a free cluster from the FAT. Marks it as EOC (0x0FFFFFFF) and
  * returns the cluster number. Returns 0 on failure (no free cluster or I/O
  * error). */
```
- AFTER hunk:
```
     int rc = driver_block_write_sectors_raw(ctx->dev_idx,
                                (u64)ctx->fat_start_lba + sector_offset, 1,
                                ctx->fat_cache + sector_offset * ctx->bytes_per_sector);
+    if (rc != 0) return -3;
+    /* BUG-0185 FIX (A12-020): keep the mirror FATs in sync. The old
+     * comment said "we only use FAT #0" and never touched the mirror,
+     * so a second OS honouring the dual-FAT layout read a stale table
+     * (fsck-style tools flag it; some drivers repair from FAT #1). Per
+     * fs.doc 2.1.4 (BPB_ExtFlags), when mirroring is ENABLED all FAT
+     * copies must be updated on every change; when it is DISABLED only
+     * the active FAT is maintained (the loop below then writes nothing).
+     * num_fats is validated <= 4 at mount, so the loop is bounded. */
+    if (ctx->fat_mirror && ctx->num_fats >= 2) {
+        for (u32 f = 0; f < ctx->num_fats; f++) {
+            if (f == ctx->active_fat) continue;
+            u64 fat_base = (u64)ctx->reserved_sectors +
+                           (u64)f * ctx->fat_size_sectors;
+            (void)driver_block_write_sectors_raw(ctx->dev_idx,
+                fat_base + sector_off
```

## BUG-0187 (P2, p2fix1) — commit 97128bc
- Location: fs_fat32.c:606-622
- Issue: 、576-583   LFN 别名恒 "XXXXXX~1"：不查冲突、丢扩展名；读取不校验 checksum/序号
- BEFORE hunk:
```
  * Layout (LBA28 sectors, 512 bytes each):
  *   [reserved region: boot sector + (reserved_sectors-1) more]
  *   [FAT #0: fat_size_sectors sectors]
- *   [FAT #1: fat_size_sectors sectors]   (we only use FAT #0)
  *   [data region: starts at data_start_lba, cluster 2 is the first one]
  *
  * FAT32 entries are 32 bits wide; the low 28 bits are the next-cluster
  * pointer. End-of-chain markers are 0x0FFFFFF8..0x0FFFFFFF. Free clusters
  * are 0x00000000.
```
- AFTER hunk:
```
  * Layout (LBA28 sectors, 512 bytes each):
  *   [reserved region: boot sector + (reserved_sectors-1) more]
  *   [FAT #0: fat_size_sectors sectors]
+ *   [FAT #1: fat_size_sectors sectors]
  *   [data region: starts at data_start_lba, cluster 2 is the first one]
  *
+ * BUG-0185 (A12-020): the FAT copy that gets cached and updated is the
+ * ACTIVE one (BPB_ExtFlags, fs.doc 2.1.4 "FAT32 Extended BPB"); while
+ * mirroring is enabled (ext_flags bit 7 = 0) every FAT-sector write is
+ * replayed to every other copy, so FAT #1 is no longer left stale.
+ *
  * FAT32 entries are 32 bits wide; the low 28 bits are the next-cluster
  * pointer. End-of-chain markers are 0x0FFFFFF8..0x0FFFFFFF. Free clusters
  * are 0x00000000.
```

## BUG-0188 (P2, p2fix1) — commit 97128bc
- Location: fs_fat32.c:331-339
- Issue: mark_entry_deleted 只回溯同簇 LFN
- BEFORE hunk:
```
     return fs_fat32_write_dirent(ctx, dir_cluster, entry_offset, &e);
 }
 
 /* Mark a directory entry as deleted (first byte = 0xE5). */
 static int fs_fat32_mark_entry_deleted(fs_fat32_ctx_t *ctx, u32 dir_cluster, u32 entry_offset) {
     fs_fat32_dirent_t e;
     if (fs_fat32_read_dirent(ctx, dir_cluster, entry_offset, &e) < 0) return -1;
     e.name[0] = 0xE5;
     if (fs_fat32_write_dirent(ctx, dir_cluster, entry_offset, &e) < 0) return -1;
 
```
- AFTER hunk:
```
     return fs_fat32_write_dirent(ctx, dir_cluster, entry_offset, &e);
 }
 
+/* BUG-0188 support: find the cluster whose FAT chain points at `cluster`.
+ * O(chains) but deletion is rare. Returns 0 when none (start of chain). */
+static u32 fs_fat32_prev_cluster_of(const fs_fat32_ctx_t *ctx, u32 cluster) {
+    if (!ctx->fat_cache) return 0;
+    u64 entries = ctx->fat_cache_size / 4;
+    u64 limit = (u64)ctx->total_clusters + 2;
+    if (limit > entries) limit = entries;
+    for (u64 i = 2; i < limit; i++) {
+        u32 v;
+        memcpy(&v, ctx->fat_cache + i * 4, 4);
+        if ((v & 0x0FFFFFFFu) == cluster) return (u32)i;
+    }
+    return 0;
+}
+
+/* BUG-0188: forward declaration - mark_entry_deleted (below) validates
+ * the LFN run against the 8.3 checksum computed by this helper. */
+static u8 fs_fat32_lfn_checksum(const u8 *short_name);
+/* BUG-0187: forward declaration - find_entry (below) only trusts a
+ * collected LFN run after this validator passed it. */
+static int fs_fat32_lfn_run_valid(const u8 *lfn_buf, int lfn_count,
+                                  const u8 sfn[11]);
+
 /* Mark a directory entry as deleted (first byte = 0xE5). */
 static int fs_fat32_ma
```

## BUG-0189 (P2, p2fix2) — commit 539bbb8
- Location: fs_fat32.c:1049-1051
- Issue: read_dir_entries 4096 条（128KiB 目录项）硬上限静默截断
- BEFORE hunk:
```
 /* Update a directory entry's first_cluster and size on disk. */
 static int fs_fat32_update_dir_entry(fs_fat32_ctx_t *ctx, u32 dir_cluster, u32 entry_offset,
                                   u32 new_first_cluster, u64 new_size) {
     fs_fat32_dirent_t e;
     if (fs_fat32_read_dirent(ctx, dir_cluster, entry_offset, &e) < 0) return -1;
     e.first_cluster_hi = (u16)(new_first_cluster >> 16);
```
- AFTER hunk:
```
 /* Update a directory entry's first_cluster and size on disk. */
 static int fs_fat32_update_dir_entry(fs_fat32_ctx_t *ctx, u32 dir_cluster, u32 entry_offset,
                                   u32 new_first_cluster, u64 new_size) {
+    /* BUG-0191 FIX (A12-026): the on-disk file_size field is a u32
+     * (fs.doc 5.1, maximum 4 GiB-1). The old code cast the u64 result
+     * straight down, silently wrapping sizes >= 4 GiB while the
+     * in-memory ino->size kept the full value - disk and memory then
+     * disagreed about the file. Refuse sizes the field cannot represent
+     * (callers fail the write instead of truncating silently). */
+    if (new_size > 0xFFFFFFFFull) return -2;
     fs_fat32_dirent_t e;
     if (fs_fat32_read_dirent(ctx, dir_cluster, entry_offset, &e) < 0) return -1;
     e.first_cluster_hi = (u16)(new_first_cluster >> 16);
```

## BUG-0190 (P2, p2fix2) — commit 539bbb8
- Location: fs_fat32.c:846
- Issue: 、879   append_cluster 返回值忽略
- BEFORE hunk:
```
 /* Update a directory entry's first_cluster and size on disk. */
 static int fs_fat32_update_dir_entry(fs_fat32_ctx_t *ctx, u32 dir_cluster, u32 entry_offset,
                                   u32 new_first_cluster, u64 new_size) {
     fs_fat32_dirent_t e;
     if (fs_fat32_read_dirent(ctx, dir_cluster, entry_offset, &e) < 0) return -1;
     e.first_cluster_hi = (u16)(new_first_cluster >> 16);
```
- AFTER hunk:
```
 /* Update a directory entry's first_cluster and size on disk. */
 static int fs_fat32_update_dir_entry(fs_fat32_ctx_t *ctx, u32 dir_cluster, u32 entry_offset,
                                   u32 new_first_cluster, u64 new_size) {
+    /* BUG-0191 FIX (A12-026): the on-disk file_size field is a u32
+     * (fs.doc 5.1, maximum 4 GiB-1). The old code cast the u64 result
+     * straight down, silently wrapping sizes >= 4 GiB while the
+     * in-memory ino->size kept the full value - disk and memory then
+     * disagreed about the file. Refuse sizes the field cannot represent
+     * (callers fail the write instead of truncating silently). */
+    if (new_size > 0xFFFFFFFFull) return -2;
     fs_fat32_dirent_t e;
     if (fs_fat32_read_dirent(ctx, dir_cluster, entry_offset, &e) < 0) return -1;
     e.first_cluster_hi = (u16)(new_first_cluster >> 16);
```

## BUG-0191 (P2, p2fix2) — commit 539bbb8
- Location: fs_fat32.c:306-314
- Issue: file_size 写入 u32 截断
- BEFORE hunk:
```
 /* Update a directory entry's first_cluster and size on disk. */
 static int fs_fat32_update_dir_entry(fs_fat32_ctx_t *ctx, u32 dir_cluster, u32 entry_offset,
                                   u32 new_first_cluster, u64 new_size) {
     fs_fat32_dirent_t e;
     if (fs_fat32_read_dirent(ctx, dir_cluster, entry_offset, &e) < 0) return -1;
     e.first_cluster_hi = (u16)(new_first_cluster >> 16);
```
- AFTER hunk:
```
 /* Update a directory entry's first_cluster and size on disk. */
 static int fs_fat32_update_dir_entry(fs_fat32_ctx_t *ctx, u32 dir_cluster, u32 entry_offset,
                                   u32 new_first_cluster, u64 new_size) {
+    /* BUG-0191 FIX (A12-026): the on-disk file_size field is a u32
+     * (fs.doc 5.1, maximum 4 GiB-1). The old code cast the u64 result
+     * straight down, silently wrapping sizes >= 4 GiB while the
+     * in-memory ino->size kept the full value - disk and memory then
+     * disagreed about the file. Refuse sizes the field cannot represent
+     * (callers fail the write instead of truncating silently). */
+    if (new_size > 0xFFFFFFFFull) return -2;
     fs_fat32_dirent_t e;
     if (fs_fat32_read_dirent(ctx, dir_cluster, entry_offset, &e) < 0) return -1;
     e.first_cluster_hi = (u16)(new_first_cluster >> 16);
```

## BUG-0192 (P2, p2fix2) — commit 539bbb8
- Location: fs_exfat.c:503-508
- Issue: O_TRUNC 未实现
- BEFORE hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
- * through driver_block_ata_read_sectors/driver_block_ata_write_sectors (drive 0..3, LBA 0-based).
  *
- * The `device` string passed to mount is parsed into a drive number 0..3
- * (e.g. "ata0" -> 0, "ata3" -> 3, "0".."3" also accepted). exFAT is
- * mounted on the whole disk starting at LBA 0 (no partition offset).
  */
 #include "fs_exfat.h"
 #include "types.h"
```
- AFTER hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
+ * through the generic blk layer (driver_block_read_sectors_raw /
+ * driver_block_write_sectors_raw) so exFAT can live on ANY registered
+ * block device - whole disks ("hda", "sda", "vda", "nvme0", ...) as well
+ * as partition sub-devices created by driver_block_part.c ("hdap1",
+ * "sdap2", ...).
  *
+ * BUG-0197 FIX (A12-032): the `device` string passed to mount is resolved
+ * through driver_block_find_device() (with legacy "ata0".."ata3" aliases
+ * mapped onto the corresponding "hd?" block device). All LBAs used below
+ * are VOLUME-relative, exactly as the exFAT spec defines fat_offset /
+ * cluster_heap_offset; the partition mapping is the blk layer's job, so
+ * the BPB PartitionOffset field is deliberately not added to I/O
+ * addresses (it is boot-chain information, not a mapping input).
  */
 #include "fs_exfat.h"
 #include "types.h"
```

## BUG-0193 (P2, p2fix2) — commit 539bbb8
- Location: fs_exfat.c:581-588
- Issue: 扩链计数起点错：current_bytes 初始化为 1 簇
- BEFORE hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
- * through driver_block_ata_read_sectors/driver_block_ata_write_sectors (drive 0..3, LBA 0-based).
  *
- * The `device` string passed to mount is parsed into a drive number 0..3
- * (e.g. "ata0" -> 0, "ata3" -> 3, "0".."3" also accepted). exFAT is
- * mounted on the whole disk starting at LBA 0 (no partition offset).
  */
 #include "fs_exfat.h"
 #include "types.h"
```
- AFTER hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
+ * through the generic blk layer (driver_block_read_sectors_raw /
+ * driver_block_write_sectors_raw) so exFAT can live on ANY registered
+ * block device - whole disks ("hda", "sda", "vda", "nvme0", ...) as well
+ * as partition sub-devices created by driver_block_part.c ("hdap1",
+ * "sdap2", ...).
  *
+ * BUG-0197 FIX (A12-032): the `device` string passed to mount is resolved
+ * through driver_block_find_device() (with legacy "ata0".."ata3" aliases
+ * mapped onto the corresponding "hd?" block device). All LBAs used below
+ * are VOLUME-relative, exactly as the exFAT spec defines fat_offset /
+ * cluster_heap_offset; the partition mapping is the blk layer's job, so
+ * the BPB PartitionOffset field is deliberately not added to I/O
+ * addresses (it is boot-chain information, not a mapping input).
  */
 #include "fs_exfat.h"
 #include "types.h"
```

## BUG-0194 (P2, p2fix2) — commit 539bbb8
- Location: fs_exfat.c:573-589
- Issue: 扩展出的新簇不清零 → 洞读出陈旧磁盘数据
- BEFORE hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
- * through driver_block_ata_read_sectors/driver_block_ata_write_sectors (drive 0..3, LBA 0-based).
  *
- * The `device` string passed to mount is parsed into a drive number 0..3
- * (e.g. "ata0" -> 0, "ata3" -> 3, "0".."3" also accepted). exFAT is
- * mounted on the whole disk starting at LBA 0 (no partition offset).
  */
 #include "fs_exfat.h"
 #include "types.h"
```
- AFTER hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
+ * through the generic blk layer (driver_block_read_sectors_raw /
+ * driver_block_write_sectors_raw) so exFAT can live on ANY registered
+ * block device - whole disks ("hda", "sda", "vda", "nvme0", ...) as well
+ * as partition sub-devices created by driver_block_part.c ("hdap1",
+ * "sdap2", ...).
  *
+ * BUG-0197 FIX (A12-032): the `device` string passed to mount is resolved
+ * through driver_block_find_device() (with legacy "ata0".."ata3" aliases
+ * mapped onto the corresponding "hd?" block device). All LBAs used below
+ * are VOLUME-relative, exactly as the exFAT spec defines fat_offset /
+ * cluster_heap_offset; the partition mapping is the blk layer's job, so
+ * the BPB PartitionOffset field is deliberately not added to I/O
+ * addresses (it is boot-chain information, not a mapping input).
  */
 #include "fs_exfat.h"
 #include "types.h"
```

## BUG-0195 (P2, p2fix2) — commit 539bbb8
- Location: fs_exfat.c:694-707
- Issue: create() 构建 VFS 节点但不挂树 → 每次 O_CREAT 泄漏
- BEFORE hunk:
```
     if (ino->entry_cluster == 0) return -4;  /* root or no parent entry */
     fs_exfat_ctx_t *ctx = ino->ctx;
 
     /* Allocate the first cluster if the file is empty. */
     if (ino->first_cluster < 2) {
         u32 fc = fs_exfat_alloc_cluster(ctx);
-        if (fc == 0) return -5;
         ino->first_cluster = fc;
     }
 
     u64 new_end = offset + (u64)size;
     u64 cur_size = node->size;
     if (new_end > cur_size) {
-        /* Extend the cluster chain to cover new_end. */
         u32 last = ino->first_cluster;
-        while (1) {
             u32 next = fs_exfat_fat_get(ctx, last);
-            if (next == EXFAT_EOC || next < 2) break;
             last = next;
         }
-        u64 current_bytes = ctx->cluster_size;
-        while (current_bytes < new_end) {
             u32 nc = fs_exfat_alloc_cluster(ctx);
-            if (nc == 0) break;
-            fs_exfat_fat_set(ctx, last, nc);
             last = nc;
-            current_bytes += ctx->cluster_size;
         }
     }
 
-    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
-    if (!cbuf) return -6;
-
     /* Walk the chain to the cluster containing `offset`. */
     u32 cluster = ino->first_cluster;
     u6
```
- AFTER hunk:
```
     if (ino->entry_cluster == 0) return -4;  /* root or no parent entry */
     fs_exfat_ctx_t *ctx = ino->ctx;
 
+    /* The scratch cluster buffer doubles as the zero-fill buffer for
+     * every newly-allocated cluster below. */
+    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
+    if (!cbuf) return -6;
+
     /* Allocate the first cluster if the file is empty. */
     if (ino->first_cluster < 2) {
         u32 fc = fs_exfat_alloc_cluster(ctx);
+        if (fc == 0) { kfree(cbuf); return -5; }
         ino->first_cluster = fc;
+        /* BUG-0194 FIX (A12-029): the first cluster of a formerly-empty
+         * file is fresh disk space - zero it so unwritten bytes (and
+         * later holes) read as 0, matching FAT32/ramfs hole semantics. */
+        memset(cbuf, 0, ctx->cluster_size);
+        if (fs_exfat_write_sectors(ctx, fs_exfat_cluster_sector(ctx, fc),
+                                ctx->sectors_per_cluster, cbuf) != 0) {
+            kfree(cbuf);
+            return -6;
+        }
     }
 
     u64 new_end = offset + (u64)size;
     u64 cur_size = node->size;
+    u64 chain_bytes = 0;   /* chain capacity after the extend below */
     if (new_end > cur_size) {
+  
```

## BUG-0196 (P2, p2fix2) — commit 539bbb8
- Location: fs_exfat.c:1021-1030；fs_ext4.c:719-728
- Issue: unmount 只释放根节点，缓存子节点泄漏
- BEFORE hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
- * through driver_block_ata_read_sectors/driver_block_ata_write_sectors (drive 0..3, LBA 0-based).
  *
- * The `device` string passed to mount is parsed into a drive number 0..3
- * (e.g. "ata0" -> 0, "ata3" -> 3, "0".."3" also accepted). exFAT is
- * mounted on the whole disk starting at LBA 0 (no partition offset).
  */
 #include "fs_exfat.h"
 #include "types.h"
```
- AFTER hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
+ * through the generic blk layer (driver_block_read_sectors_raw /
+ * driver_block_write_sectors_raw) so exFAT can live on ANY registered
+ * block device - whole disks ("hda", "sda", "vda", "nvme0", ...) as well
+ * as partition sub-devices created by driver_block_part.c ("hdap1",
+ * "sdap2", ...).
  *
+ * BUG-0197 FIX (A12-032): the `device` string passed to mount is resolved
+ * through driver_block_find_device() (with legacy "ata0".."ata3" aliases
+ * mapped onto the corresponding "hd?" block device). All LBAs used below
+ * are VOLUME-relative, exactly as the exFAT spec defines fat_offset /
+ * cluster_heap_offset; the partition mapping is the blk layer's job, so
+ * the BPB PartitionOffset field is deliberately not added to I/O
+ * addresses (it is boot-chain information, not a mapping input).
  */
 #include "fs_exfat.h"
 #include "types.h"
```

## BUG-0197 (P2, p2fix2) — commit 539bbb8
- Location: fs_exfat.c:995-998；fs_ext4.c:26-27
- Issue: exFAT 忽略 partition_offset；exFAT/ext4 只支持整盘 LBA0
- BEFORE hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
- * through driver_block_ata_read_sectors/driver_block_ata_write_sectors (drive 0..3, LBA 0-based).
  *
- * The `device` string passed to mount is parsed into a drive number 0..3
- * (e.g. "ata0" -> 0, "ata3" -> 3, "0".."3" also accepted). exFAT is
- * mounted on the whole disk starting at LBA 0 (no partition offset).
  */
 #include "fs_exfat.h"
 #include "types.h"
```
- AFTER hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
+ * through the generic blk layer (driver_block_read_sectors_raw /
+ * driver_block_write_sectors_raw) so exFAT can live on ANY registered
+ * block device - whole disks ("hda", "sda", "vda", "nvme0", ...) as well
+ * as partition sub-devices created by driver_block_part.c ("hdap1",
+ * "sdap2", ...).
  *
+ * BUG-0197 FIX (A12-032): the `device` string passed to mount is resolved
+ * through driver_block_find_device() (with legacy "ata0".."ata3" aliases
+ * mapped onto the corresponding "hd?" block device). All LBAs used below
+ * are VOLUME-relative, exactly as the exFAT spec defines fat_offset /
+ * cluster_heap_offset; the partition mapping is the blk layer's job, so
+ * the BPB PartitionOffset field is deliberately not added to I/O
+ * addresses (it is boot-chain information, not a mapping input).
  */
 #include "fs_exfat.h"
 #include "types.h"
```

## BUG-0198 (P2, p2fix2) — commit 539bbb8
- Location: fs_ext4.c:669-717
- Issue: 、695   mount 无 incompat 特征检查；log_block_size 移位 UB；inode_size 不验证
- BEFORE hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_ext4_init. Memory comes from kmalloc/kfree; sector I/O goes
- * through driver_block_ata_read_sectors (drive 0..3, LBA 0-based).
  *
- * The `device` string passed to mount is parsed into a drive number 0..3
- * (e.g. "ata0" -> 0). ext4 is mounted on the whole disk starting at LBA 0
- * (no partition offset). The superblock is read from byte 1024 (sector 2).
  */
 #include "fs_ext4.h"
 #include "types.h"
```
- AFTER hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_ext4_init. Memory comes from kmalloc/kfree; sector I/O goes
+ * through the generic blk layer (driver_block_read_sectors_raw) so ext4
+ * can live on ANY registered block device - whole disks ("hda", "sda",
+ * "vda", "nvme0", ...) as well as partition sub-devices created by
+ * driver_block_part.c ("hdap1", "sdap2", ...).
  *
+ * BUG-0197 FIX (A12-032): the `device` string passed to mount is
+ * resolved through driver_block_find_device() (legacy "ata0".."ata3"
+ * aliases map onto the corresponding "hd?" block device). All LBAs are
+ * volume-relative - the partition mapping is the blk layer's job, so
+ * the legacy whole-disk-at-LBA0 restriction is gone.
  */
 #include "fs_ext4.h"
 #include "types.h"
```

## BUG-0199 (P2, p2fix2) — commit 539bbb8
- Location: fs_ext4.c:515-516
- Issue: >2GB 文件 read 直接返回 0
- BEFORE hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_ext4_init. Memory comes from kmalloc/kfree; sector I/O goes
- * through driver_block_ata_read_sectors (drive 0..3, LBA 0-based).
  *
- * The `device` string passed to mount is parsed into a drive number 0..3
- * (e.g. "ata0" -> 0). ext4 is mounted on the whole disk starting at LBA 0
- * (no partition offset). The superblock is read from byte 1024 (sector 2).
  */
 #include "fs_ext4.h"
 #include "types.h"
```
- AFTER hunk:
```
  *
  * On-disk structures use #pragma pack(push, 1). All functions are static
  * except fs_ext4_init. Memory comes from kmalloc/kfree; sector I/O goes
+ * through the generic blk layer (driver_block_read_sectors_raw) so ext4
+ * can live on ANY registered block device - whole disks ("hda", "sda",
+ * "vda", "nvme0", ...) as well as partition sub-devices created by
+ * driver_block_part.c ("hdap1", "sdap2", ...).
  *
+ * BUG-0197 FIX (A12-032): the `device` string passed to mount is
+ * resolved through driver_block_find_device() (legacy "ata0".."ata3"
+ * aliases map onto the corresponding "hd?" block device). All LBAs are
+ * volume-relative - the partition mapping is the blk layer's job, so
+ * the legacy whole-disk-at-LBA0 restriction is gone.
  */
 #include "fs_ext4.h"
 #include "types.h"
```

## BUG-0200 (P2, p2fix2) — commit 539bbb8
- Location: fs_ext4.c:328-368
- Issue: extent 深度 >1 不支持且不检测
- BEFORE hunk:
```
 /* Map a logical block index to a physical block number via the extent
  * tree starting at the inode's i_block[0..] (root header). Returns
  * physical block, or 0 if unmapped. */
 static u64 fs_ext4_extent_lookup(fs_ext4_ctx_t *ctx, const u32 *i_block,
                               u32 logical) {
-    const fs_ext4_extent_header_t *hdr = (const fs_ext4_extent_header_t *)i_block;
     if (hdr->eh_magic != EXT4_EXT_MAGIC) return 0;
-    /* P1-8 FIX: bound eh_entries to prevent OOB reads on corrupt disks.
-     * The inode i_block array is 60 bytes = 15 u32s. The header is 12 bytes
-     * (3 u32s), leaving 48 bytes = 12 u32s for entries. Each extent entry
-     * is 12 bytes (3 u32s), so max 4 entries in the root. Each index entry
-     * is also 12 bytes, so max 4 indices. */
-    u16 max_entries = 4;  /* (60 - 12) / 12 */
-    u16 n_entries = hdr->eh_entries;
-    if (n_entries > max_entries) n_entries = max_entries;
-    if (hdr->eh_depth == 0) {
-        /* BUG-0060 FIX: extent entries start at i_block + 12 bytes (the
-         * extent header is 12 bytes: magic/entries/max/depth/generation).
-         * The old pointer arithmetic used i_block + 4 where i_block is a
-        
```
- AFTER hunk:
```
 /* Map a logical block index to a physical block number via the extent
  * tree starting at the inode's i_block[0..] (root header). Returns
  * physical block, or 0 if unmapped. */
+/* BUG-0200 FIX (A12-035): the old lookup supported exactly ONE index
+ * level and silently mis-parsed deeper trees - a depth-2 node's index
+ * entries were read as leaf extents, returning garbage physical blocks.
+ * Now the tree is walked level by level: take the LAST index entry
+ * whose ei_block is <= the logical block, read the block it points to,
+ * repeat until a depth-0 (leaf) node is reached. ext4 bounds the extent
+ * depth at 5 (linux fs/ext4/extents.h, EXT4_MAX_EXTENT_DEPTH); a
+ * deeper tree is corruption and yields a clean "unmapped" result
+ * instead of silent wrong data. */
 static u64 fs_ext4_extent_lookup(fs_ext4_ctx_t *ctx, const u32 *i_block,
                               u32 logical) {
+    const fs_ext4_extent_header_t *hdr =
+        (const fs_ext4_extent_header_t *)i_block;
     if (hdr->eh_magic != EXT4_EXT_MAGIC) return 0;
+    if (hdr->eh_depth > 5) return 0;     /* impossible depth = corruption */
+
+    u8 *heap_buf = NULL;   /* current block-backed node (NULL: the r
```

## BUG-0201 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:33-50
- Issue: dma_alloc：先查余量后对齐 → 最多 15+size 字节越页写；>4KB 路径单帧无校验
- BEFORE hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
     if (size > PMM_PAGE_SIZE) {
-        /* Need a full page. */
-        return (void *)mem_pmm_alloc_frame();
-    }
-    /* Sub-allocate from the current page. */
-    if (g_dma_page == NULL || g_dma_page_offset + size > PMM_PAGE_SIZE) {
-        /* Allocate a new page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
-        g_dma_page_offset = 0;
     }
-    /* Align to 16 bytes. */
-    g_dma_page_offset = (g_dma_page_offset + 15) & ~15;
-    void *p = g_dma_page + g_dma_page_offset;
-    g_dma_page_offset += size;
     return p;
 }
 
 static char n_tmp[20];  /* shared buffer for number formatting */
 
 /* Forward declarations. */
-void net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
-                            const void *data, int len);
 void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
-void net_udp_handle_packet(u32 src_ip, const void *data, int len);
 void net_tcp_handle_packet(u32 src_ip, const void *data, int len);
 
 /* ============================================================
```
- AFTER hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
+    if (size <= 0) return NULL;
     if (size > PMM_PAGE_SIZE) {
+        /* BUG-0201: a single frame cannot back a request larger than the
+         * frame itself. Use a physically-contiguous multi-frame run (the
+         * low identity-mapped region covers all PMM frames, so the DMA
+         * address stays valid); fail when PMM cannot provide one. */
+        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
+        u64 pa = mem_pmm_alloc_contig((u64)npages);
+        if (pa == 0) return NULL;
+        return (void *)(uintptr_t)pa;
+    }
+    /* BUG-0201: sub-allocate from the current page. The alignment must be
+     * applied BEFORE the bounds check: the old order checked
+     * "offset + size <= 4096" on the unaligned offset and only then
+     * aligned, so up to 15+size bytes could be handed out past the end
+     * of the frame. */
+    int aligned = (g_dma_page_offset + 15) & ~15;
+    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
+        /* Need a fresh page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
+
```

## BUG-0202 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:390-404
- Issue: , 447-448, 463   virtio TX/RX 用硬编码 VIRTIO_NUM_DESC=256 取模，而非协商出的 rx_size/tx_size
- BEFORE hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
     if (size > PMM_PAGE_SIZE) {
-        /* Need a full page. */
-        return (void *)mem_pmm_alloc_frame();
-    }
-    /* Sub-allocate from the current page. */
-    if (g_dma_page == NULL || g_dma_page_offset + size > PMM_PAGE_SIZE) {
-        /* Allocate a new page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
-        g_dma_page_offset = 0;
     }
-    /* Align to 16 bytes. */
-    g_dma_page_offset = (g_dma_page_offset + 15) & ~15;
-    void *p = g_dma_page + g_dma_page_offset;
-    g_dma_page_offset += size;
     return p;
 }
 
 static char n_tmp[20];  /* shared buffer for number formatting */
 
 /* Forward declarations. */
-void net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
-                            const void *data, int len);
 void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
-void net_udp_handle_packet(u32 src_ip, const void *data, int len);
 void net_tcp_handle_packet(u32 src_ip, const void *data, int len);
 
 /* ============================================================
```
- AFTER hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
+    if (size <= 0) return NULL;
     if (size > PMM_PAGE_SIZE) {
+        /* BUG-0201: a single frame cannot back a request larger than the
+         * frame itself. Use a physically-contiguous multi-frame run (the
+         * low identity-mapped region covers all PMM frames, so the DMA
+         * address stays valid); fail when PMM cannot provide one. */
+        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
+        u64 pa = mem_pmm_alloc_contig((u64)npages);
+        if (pa == 0) return NULL;
+        return (void *)(uintptr_t)pa;
+    }
+    /* BUG-0201: sub-allocate from the current page. The alignment must be
+     * applied BEFORE the bounds check: the old order checked
+     * "offset + size <= 4096" on the unaligned offset and only then
+     * aligned, so up to 15+size bytes could be handed out past the end
+     * of the frame. */
+    int aligned = (g_dma_page_offset + 15) & ~15;
+    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
+        /* Need a fresh page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
+
```

## BUG-0203 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:2280-2284
- Issue: TCP data_offset 未验证
- BEFORE hunk:
```
     u64 now = core_timer_ticks();
     for (int i = 0; i < TCP_MAX_CONNS; i++) {
         net_tcp_conn_t *c = &g_tcp_conns[i];
-        if (!c->in_use || c->state != TCP_ESTABLISHED) continue;
         /* BUG-0069 FIX: connections stuck in SYN_RCVD used to live
          * forever, so 32 forged SYNs permanently filled the 32-slot
          * connection table (remote DoS). The handshake deadline is
```
- AFTER hunk:
```
     u64 now = core_timer_ticks();
     for (int i = 0; i < TCP_MAX_CONNS; i++) {
         net_tcp_conn_t *c = &g_tcp_conns[i];
+        if (!c->in_use) continue;
+        /* BUG-0208: retire TIME_WAIT connections once the 10 s dwell
+         * (rto_deadline holds the TIME_WAIT start tick) expires. */
+        if (c->state == TCP_TIME_WAIT) {
+            if (now >= c->rto_deadline) {
+                c->state = TCP_CLOSED;
+                c->in_use = 0;
+            }
+            continue;
+        }
+        if (c->state != TCP_ESTABLISHED) continue;
         /* BUG-0069 FIX: connections stuck in SYN_RCVD used to live
          * forever, so 32 forged SYNs permanently filled the 32-slot
          * connection table (remote DoS). The handshake deadline is
```

## BUG-0204 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:1024-1044
- Issue: , 1046-1081, 1083-1114   ARP：无老化（timestamp 字段从未赋值/检查）、满表固定覆盖 0 号、单次请求无重试、报文长度被 (void)len 忽略
- BEFORE hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
     if (size > PMM_PAGE_SIZE) {
-        /* Need a full page. */
-        return (void *)mem_pmm_alloc_frame();
-    }
-    /* Sub-allocate from the current page. */
-    if (g_dma_page == NULL || g_dma_page_offset + size > PMM_PAGE_SIZE) {
-        /* Allocate a new page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
-        g_dma_page_offset = 0;
     }
-    /* Align to 16 bytes. */
-    g_dma_page_offset = (g_dma_page_offset + 15) & ~15;
-    void *p = g_dma_page + g_dma_page_offset;
-    g_dma_page_offset += size;
     return p;
 }
 
 static char n_tmp[20];  /* shared buffer for number formatting */
 
 /* Forward declarations. */
-void net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
-                            const void *data, int len);
 void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
-void net_udp_handle_packet(u32 src_ip, const void *data, int len);
 void net_tcp_handle_packet(u32 src_ip, const void *data, int len);
 
 /* ============================================================
```
- AFTER hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
+    if (size <= 0) return NULL;
     if (size > PMM_PAGE_SIZE) {
+        /* BUG-0201: a single frame cannot back a request larger than the
+         * frame itself. Use a physically-contiguous multi-frame run (the
+         * low identity-mapped region covers all PMM frames, so the DMA
+         * address stays valid); fail when PMM cannot provide one. */
+        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
+        u64 pa = mem_pmm_alloc_contig((u64)npages);
+        if (pa == 0) return NULL;
+        return (void *)(uintptr_t)pa;
+    }
+    /* BUG-0201: sub-allocate from the current page. The alignment must be
+     * applied BEFORE the bounds check: the old order checked
+     * "offset + size <= 4096" on the unaligned offset and only then
+     * aligned, so up to 15+size bytes could be handed out past the end
+     * of the frame. */
+    int aligned = (g_dma_page_offset + 15) & ~15;
+    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
+        /* Need a fresh page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
+
```

## BUG-0205 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:2200-2225
- Issue: net_tcp_send：rtx_buf 满时照发但不入重传队列（静默丢可靠性）；无 Nagle；peer 零窗口时 sendable=0 返回 0
- BEFORE hunk:
```
     return net_ip_send(c->remote_ip, IP_PROTO_TCP, h, hdr_len + len);
 }
 
 int net_tcp_connect(u32 dst_ip, u16 dst_port) {
     net_tcp_conn_t *c = net_tcp_alloc_conn();
     if (!c) return -1;
     c->state = TCP_SYN_SENT;
     c->remote_ip = dst_ip;
-    c->local_port = 40000 + (g_stats.net_tcp_connections % 10000);
     c->remote_port = dst_port;
     c->our_seq = 0x1000;
     c->our_ack = 0;
```
- AFTER hunk:
```
     return net_ip_send(c->remote_ip, IP_PROTO_TCP, h, hdr_len + len);
 }
 
+/* BUG-0207: is a local TCP port already taken? Defined after the listener
+ * table (which lives further down, next to net_tcp_listen). */
+static int net_tcp_port_in_use(u16 port);
+
 int net_tcp_connect(u32 dst_ip, u16 dst_port) {
     net_tcp_conn_t *c = net_tcp_alloc_conn();
     if (!c) return -1;
     c->state = TCP_SYN_SENT;
     c->remote_ip = dst_ip;
+    /* BUG-0207: pick a local port that is NOT in use by any live
+     * connection or listener. The old "counter modulo 10000" scheme
+     * silently collided with surviving connections (same 4-tuple), and
+     * find_conn then routed the new SYN into the OLD connection's state
+     * machine. Scan the ephemeral range starting from the counter value,
+     * bounded at 10000 tries. */
+    {
+        u16 lport = (u16)(40000 + (g_stats.net_tcp_connections % 10000));
+        int tries = 0;
+        while (net_tcp_port_in_use(lport) && tries < 10000) {
+            lport = (u16)(40000 + ((lport - 40000 + 1) % 10000));
+            tries++;
+        }
+        if (net_tcp_port_in_use(lport)) {
+            /* Entire ephemeral range busy — fail hon
```

## BUG-0206 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:2685-2712
- Issue: net_accept 超时单位错误：注释 "120 s @1000 Hz"，实际 OC_TIMER_HZ=100 → 120*1000 ticks = 1200 秒（20 分钟）
- BEFORE hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
     if (size > PMM_PAGE_SIZE) {
-        /* Need a full page. */
-        return (void *)mem_pmm_alloc_frame();
-    }
-    /* Sub-allocate from the current page. */
-    if (g_dma_page == NULL || g_dma_page_offset + size > PMM_PAGE_SIZE) {
-        /* Allocate a new page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
-        g_dma_page_offset = 0;
     }
-    /* Align to 16 bytes. */
-    g_dma_page_offset = (g_dma_page_offset + 15) & ~15;
-    void *p = g_dma_page + g_dma_page_offset;
-    g_dma_page_offset += size;
     return p;
 }
 
 static char n_tmp[20];  /* shared buffer for number formatting */
 
 /* Forward declarations. */
-void net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
-                            const void *data, int len);
 void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
-void net_udp_handle_packet(u32 src_ip, const void *data, int len);
 void net_tcp_handle_packet(u32 src_ip, const void *data, int len);
 
 /* ============================================================
```
- AFTER hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
+    if (size <= 0) return NULL;
     if (size > PMM_PAGE_SIZE) {
+        /* BUG-0201: a single frame cannot back a request larger than the
+         * frame itself. Use a physically-contiguous multi-frame run (the
+         * low identity-mapped region covers all PMM frames, so the DMA
+         * address stays valid); fail when PMM cannot provide one. */
+        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
+        u64 pa = mem_pmm_alloc_contig((u64)npages);
+        if (pa == 0) return NULL;
+        return (void *)(uintptr_t)pa;
+    }
+    /* BUG-0201: sub-allocate from the current page. The alignment must be
+     * applied BEFORE the bounds check: the old order checked
+     * "offset + size <= 4096" on the unaligned offset and only then
+     * aligned, so up to 15+size bytes could be handed out past the end
+     * of the frame. */
+    int aligned = (g_dma_page_offset + 15) & ~15;
+    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
+        /* Need a fresh page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
+
```

## BUG-0207 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:2070
- Issue: 客户端本地端口 = 40000 + (总连接数 % 10000)，无在用冲突检查
- BEFORE hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
     if (size > PMM_PAGE_SIZE) {
-        /* Need a full page. */
-        return (void *)mem_pmm_alloc_frame();
-    }
-    /* Sub-allocate from the current page. */
-    if (g_dma_page == NULL || g_dma_page_offset + size > PMM_PAGE_SIZE) {
-        /* Allocate a new page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
-        g_dma_page_offset = 0;
     }
-    /* Align to 16 bytes. */
-    g_dma_page_offset = (g_dma_page_offset + 15) & ~15;
-    void *p = g_dma_page + g_dma_page_offset;
-    g_dma_page_offset += size;
     return p;
 }
 
 static char n_tmp[20];  /* shared buffer for number formatting */
 
 /* Forward declarations. */
-void net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
-                            const void *data, int len);
 void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
-void net_udp_handle_packet(u32 src_ip, const void *data, int len);
 void net_tcp_handle_packet(u32 src_ip, const void *data, int len);
 
 /* ============================================================
```
- AFTER hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
+    if (size <= 0) return NULL;
     if (size > PMM_PAGE_SIZE) {
+        /* BUG-0201: a single frame cannot back a request larger than the
+         * frame itself. Use a physically-contiguous multi-frame run (the
+         * low identity-mapped region covers all PMM frames, so the DMA
+         * address stays valid); fail when PMM cannot provide one. */
+        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
+        u64 pa = mem_pmm_alloc_contig((u64)npages);
+        if (pa == 0) return NULL;
+        return (void *)(uintptr_t)pa;
+    }
+    /* BUG-0201: sub-allocate from the current page. The alignment must be
+     * applied BEFORE the bounds check: the old order checked
+     * "offset + size <= 4096" on the unaligned offset and only then
+     * aligned, so up to 15+size bytes could be handed out past the end
+     * of the frame. */
+    int aligned = (g_dma_page_offset + 15) & ~15;
+    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
+        /* Need a fresh page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
+
```

## BUG-0208 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:2228-2247
- Issue: net_tcp_close 只等 1 秒即释放；LAST_ACK 状态定义了但从未进入；无 TIME_WAIT
- BEFORE hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
     if (size > PMM_PAGE_SIZE) {
-        /* Need a full page. */
-        return (void *)mem_pmm_alloc_frame();
-    }
-    /* Sub-allocate from the current page. */
-    if (g_dma_page == NULL || g_dma_page_offset + size > PMM_PAGE_SIZE) {
-        /* Allocate a new page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
-        g_dma_page_offset = 0;
     }
-    /* Align to 16 bytes. */
-    g_dma_page_offset = (g_dma_page_offset + 15) & ~15;
-    void *p = g_dma_page + g_dma_page_offset;
-    g_dma_page_offset += size;
     return p;
 }
 
 static char n_tmp[20];  /* shared buffer for number formatting */
 
 /* Forward declarations. */
-void net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
-                            const void *data, int len);
 void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
-void net_udp_handle_packet(u32 src_ip, const void *data, int len);
 void net_tcp_handle_packet(u32 src_ip, const void *data, int len);
 
 /* ============================================================
```
- AFTER hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
+    if (size <= 0) return NULL;
     if (size > PMM_PAGE_SIZE) {
+        /* BUG-0201: a single frame cannot back a request larger than the
+         * frame itself. Use a physically-contiguous multi-frame run (the
+         * low identity-mapped region covers all PMM frames, so the DMA
+         * address stays valid); fail when PMM cannot provide one. */
+        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
+        u64 pa = mem_pmm_alloc_contig((u64)npages);
+        if (pa == 0) return NULL;
+        return (void *)(uintptr_t)pa;
+    }
+    /* BUG-0201: sub-allocate from the current page. The alignment must be
+     * applied BEFORE the bounds check: the old order checked
+     * "offset + size <= 4096" on the unaligned offset and only then
+     * aligned, so up to 15+size bytes could be handed out past the end
+     * of the frame. */
+    int aligned = (g_dma_page_offset + 15) & ~15;
+    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
+        /* Need a fresh page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
+
```

## BUG-0209 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:2341-2348
- Issue: SYN_SENT 收 SYN+ACK 不验证 ack==our_seq 即建立
- BEFORE hunk:
```
 }
 
 
 int net_tcp_send(int sock, const void *data, int len) {
     if (sock < 0 || sock >= TCP_MAX_CONNS) return -1;
     net_tcp_conn_t *c = &g_tcp_conns[sock];
-    if (!c->in_use || c->state != TCP_ESTABLISHED) {
         /* WP-09 SSH debug: log why net_tcp_send failed */
         static const char *state_names[] = {
             "CLOSED", "SYN_SENT", "SYN_RCVD", "ESTABLISHED",
-            "FIN_WAIT_1", "FIN_WAIT_2", "CLOSE_WAIT", "LAST_ACK", "CLOSING"
         };
-        const char *sn = c->state < 9 ? state_names[c->state] : "?";
         char dbg[100];
         strcpy(dbg, "[tcp] send fail: sock=");
         char num[10];
```
- AFTER hunk:
```
 }
 
 
+/* BUG-0205/BUG-0212: transmit as much queued data as Nagle, the peer's
+ * advertised window and the CUBIC congestion window allow. Called after
+ * data is accepted into the send buffer and from the ACK path (every ACK
+ * may open window/cwnd). Nagle rule (conservative, RFC 1122 4.2.3.4 /
+ * RFC 9293 3.7.2): with unacked data in flight only FULL segments are
+ * sent; when nothing is in flight even a small tail goes out immediately. */
+static void net_tcp_flush_queued(net_tcp_conn_t *c) {
+    if (!c->in_use) return;
+    if (c->state != TCP_ESTABLISHED && c->state != TCP_CLOSE_WAIT) return;
+    u32 mss = (c->mss > 0) ? (u32)c->mss : 1460u;
+    while (c->rtx_len > c->rtx_sent && c->driver_snd_wnd > 0) {
+        u32 queued = (u32)(c->rtx_len - c->rtx_sent);
+        /* Nagle: coalesce when in-flight > 0 and the tail < MSS. */
+        if (c->rtx_sent > 0 && queued < mss) break;
+        /* Congestion window (bytes) minus the in-flight amount:
+         * sendable = min(peer_window, cwnd - in_flight, queued). */
+        u64 cwnd_bytes = (u64)c->cwnd * mss;
+        u64 in_flight = (u64)c->rtx_sent;   /* bytes sent, unacked */
+        u64 cwnd_avail = (cwnd_bytes > i
```

## BUG-0210 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:1489-1514
- Issue: , 1516-1520   无 IP 分片重组（flags_frag 完全忽略）、无 IP 选项处理、目的地址以"低字节==0xFF"当广播接受、版本号不校验
- BEFORE hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
     if (size > PMM_PAGE_SIZE) {
-        /* Need a full page. */
-        return (void *)mem_pmm_alloc_frame();
-    }
-    /* Sub-allocate from the current page. */
-    if (g_dma_page == NULL || g_dma_page_offset + size > PMM_PAGE_SIZE) {
-        /* Allocate a new page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
-        g_dma_page_offset = 0;
     }
-    /* Align to 16 bytes. */
-    g_dma_page_offset = (g_dma_page_offset + 15) & ~15;
-    void *p = g_dma_page + g_dma_page_offset;
-    g_dma_page_offset += size;
     return p;
 }
 
 static char n_tmp[20];  /* shared buffer for number formatting */
 
 /* Forward declarations. */
-void net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
-                            const void *data, int len);
 void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
-void net_udp_handle_packet(u32 src_ip, const void *data, int len);
 void net_tcp_handle_packet(u32 src_ip, const void *data, int len);
 
 /* ============================================================
```
- AFTER hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
+    if (size <= 0) return NULL;
     if (size > PMM_PAGE_SIZE) {
+        /* BUG-0201: a single frame cannot back a request larger than the
+         * frame itself. Use a physically-contiguous multi-frame run (the
+         * low identity-mapped region covers all PMM frames, so the DMA
+         * address stays valid); fail when PMM cannot provide one. */
+        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
+        u64 pa = mem_pmm_alloc_contig((u64)npages);
+        if (pa == 0) return NULL;
+        return (void *)(uintptr_t)pa;
+    }
+    /* BUG-0201: sub-allocate from the current page. The alignment must be
+     * applied BEFORE the bounds check: the old order checked
+     * "offset + size <= 4096" on the unaligned offset and only then
+     * aligned, so up to 15+size bytes could be handed out past the end
+     * of the frame. */
+    int aligned = (g_dma_page_offset + 15) & ~15;
+    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
+        /* Need a fresh page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
+
```

## BUG-0211 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:3218-3232
- Issue: , 3343-3356   DNS 查询构造无总长上界（`(void)buf_len` 明示忽略）写入 buf[512]
- BEFORE hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
     if (size > PMM_PAGE_SIZE) {
-        /* Need a full page. */
-        return (void *)mem_pmm_alloc_frame();
-    }
-    /* Sub-allocate from the current page. */
-    if (g_dma_page == NULL || g_dma_page_offset + size > PMM_PAGE_SIZE) {
-        /* Allocate a new page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
-        g_dma_page_offset = 0;
     }
-    /* Align to 16 bytes. */
-    g_dma_page_offset = (g_dma_page_offset + 15) & ~15;
-    void *p = g_dma_page + g_dma_page_offset;
-    g_dma_page_offset += size;
     return p;
 }
 
 static char n_tmp[20];  /* shared buffer for number formatting */
 
 /* Forward declarations. */
-void net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
-                            const void *data, int len);
 void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
-void net_udp_handle_packet(u32 src_ip, const void *data, int len);
 void net_tcp_handle_packet(u32 src_ip, const void *data, int len);
 
 /* ============================================================
```
- AFTER hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
+    if (size <= 0) return NULL;
     if (size > PMM_PAGE_SIZE) {
+        /* BUG-0201: a single frame cannot back a request larger than the
+         * frame itself. Use a physically-contiguous multi-frame run (the
+         * low identity-mapped region covers all PMM frames, so the DMA
+         * address stays valid); fail when PMM cannot provide one. */
+        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
+        u64 pa = mem_pmm_alloc_contig((u64)npages);
+        if (pa == 0) return NULL;
+        return (void *)(uintptr_t)pa;
+    }
+    /* BUG-0201: sub-allocate from the current page. The alignment must be
+     * applied BEFORE the bounds check: the old order checked
+     * "offset + size <= 4096" on the unaligned offset and only then
+     * aligned, so up to 15+size bytes could be handed out past the end
+     * of the frame. */
+    int aligned = (g_dma_page_offset + 15) & ~15;
+    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
+        /* Need a fresh page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
+
```

## BUG-0212 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:2200-2209
- Issue: + tcp_cc 集成   拥塞窗口实际不生效：sendable 恒被钳到 1 MSS
- BEFORE hunk:
```
     return net_ip_send(c->remote_ip, IP_PROTO_TCP, h, hdr_len + len);
 }
 
 int net_tcp_connect(u32 dst_ip, u16 dst_port) {
     net_tcp_conn_t *c = net_tcp_alloc_conn();
     if (!c) return -1;
     c->state = TCP_SYN_SENT;
     c->remote_ip = dst_ip;
-    c->local_port = 40000 + (g_stats.net_tcp_connections % 10000);
     c->remote_port = dst_port;
     c->our_seq = 0x1000;
     c->our_ack = 0;
```
- AFTER hunk:
```
     return net_ip_send(c->remote_ip, IP_PROTO_TCP, h, hdr_len + len);
 }
 
+/* BUG-0207: is a local TCP port already taken? Defined after the listener
+ * table (which lives further down, next to net_tcp_listen). */
+static int net_tcp_port_in_use(u16 port);
+
 int net_tcp_connect(u32 dst_ip, u16 dst_port) {
     net_tcp_conn_t *c = net_tcp_alloc_conn();
     if (!c) return -1;
     c->state = TCP_SYN_SENT;
     c->remote_ip = dst_ip;
+    /* BUG-0207: pick a local port that is NOT in use by any live
+     * connection or listener. The old "counter modulo 10000" scheme
+     * silently collided with surviving connections (same 4-tuple), and
+     * find_conn then routed the new SYN into the OLD connection's state
+     * machine. Scan the ephemeral range starting from the counter value,
+     * bounded at 10000 tries. */
+    {
+        u16 lport = (u16)(40000 + (g_stats.net_tcp_connections % 10000));
+        int tries = 0;
+        while (net_tcp_port_in_use(lport) && tries < 10000) {
+            lport = (u16)(40000 + ((lport - 40000 + 1) % 10000));
+            tries++;
+        }
+        if (net_tcp_port_in_use(lport)) {
+            /* Entire ephemeral range busy — fail hon
```

## BUG-0213 (P2, p2fix2) — commit 539bbb8
- Location: ld_so.c:506-514
- Issue: , 196-219   DT_NEEDED 只计数不加载（无依赖递归）；符号查找范围仅 libfoo.so；硬编码 4096 条 dynsym 上限；强未定义符号静默解析为 0+addend
- BEFORE hunk:
```
         sys_exit2(1);
     }
 
-    /* --- Find PT_DYNAMIC + DT_STRTAB + DT_NEEDED in main --- */
-    elf64_dyn *main_dyn = find_dynamic(ehdr, MAIN_ELF_BASE);
-    if (!main_dyn) {
-        puts_str("ld.so: main has no PT_DYNAMIC\n");
         sys_exit2(1);
     }
-    unsigned long dyn_addr = (unsigned long)main_dyn;
-    /* P4 fix: silenced — was puts_str("ld.so: PT_DYNAMIC at 0x..."); */
-    (void)dyn_addr;
-
-    unsigned long main_strtab_addr = 0;
-    unsigned long main_symtab_addr = 0;
-    int i;
-    for (i = 0; i < 64; i++) {
-        if (main_dyn[i].tag == DT_NULL) break;
-        if (main_dyn[i].tag == DT_STRTAB) {
-            main_strtab_addr = MAIN_ELF_BASE + main_dyn[i].val;
-        } else if (main_dyn[i].tag == DT_SYMTAB) {
-            main_symtab_addr = MAIN_ELF_BASE + main_dyn[i].val;
-        }
     }
-    if (!main_strtab_addr) {
         puts_str("ld.so: no DT_STRTAB\n");
         sys_exit2(1);
     }
 
-    /* Print DT_NEEDED entries. */
-    int needed_count = 0;
-    for (i = 0; i < 64; i++) {
-        if (main_dyn[i].tag == DT_NULL) break;
-        if (main_dyn[i].tag == DT_NEEDED) {
-            /* P4 fix: silenced — was puts_str("ld.so: DT_NEEDED: <
```
- AFTER hunk:
```
         sys_exit2(1);
     }
 
+    /* --- Register main in the loaded-module table ---
+     * module_init re-checks the header with full bounds (BUG-0215 FIX:
+     * the phnum walk here is bounded now too) and parses .dynamic. */
+    main_idx = add_module("main");
+    if (main_idx < 0) {
+        puts_str("ld.so: module table full (main)\n");
         sys_exit2(1);
     }
+    if (module_init(main_idx, "main", main_base, 1) != 0) {
+        sys_exit2(1);
     }
+    if (g_modules[main_idx].strtab == 0) {
         puts_str("ld.so: no DT_STRTAB\n");
         sys_exit2(1);
     }
 
+    /* --- Validate libfoo.so (kernel pre-maps it; base from API page) --- */
+    {
+        elf64_hdr *libfoo_ehdr = (elf64_hdr *)libfoo_base;
+        if (libfoo_ehdr->ident[0] != 0x7f || libfoo_ehdr->ident[1] != 'E' ||
+            libfoo_ehdr->ident[2] != 'L'  || libfoo_ehdr->ident[3] != 'F') {
+            puts_str("ld.so: libfoo.so is not an ELF\n");
+            sys_exit2(1);
+        }
+        if (libfoo_ehdr->ident[4] != 2) {
+            puts_str("ld.so: libfoo.so is not ELF64\n");
+            sys_exit2(1);
+        }
+        if (libfoo_ehdr->type != ET_DYN) {
+            puts_str("ld.
```

## BUG-0214 (P2, p2fix2) — commit 539bbb8
- Location: ld_so.c:647-656
- Issue: 跳转 main 入口前不构造 argc/argv/envp/auxv，也无返回蹦床
- BEFORE hunk:
```
         sys_exit2(1);
     }
 
-    /* --- Find PT_DYNAMIC + DT_STRTAB + DT_NEEDED in main --- */
-    elf64_dyn *main_dyn = find_dynamic(ehdr, MAIN_ELF_BASE);
-    if (!main_dyn) {
-        puts_str("ld.so: main has no PT_DYNAMIC\n");
         sys_exit2(1);
     }
-    unsigned long dyn_addr = (unsigned long)main_dyn;
-    /* P4 fix: silenced — was puts_str("ld.so: PT_DYNAMIC at 0x..."); */
-    (void)dyn_addr;
-
-    unsigned long main_strtab_addr = 0;
-    unsigned long main_symtab_addr = 0;
-    int i;
-    for (i = 0; i < 64; i++) {
-        if (main_dyn[i].tag == DT_NULL) break;
-        if (main_dyn[i].tag == DT_STRTAB) {
-            main_strtab_addr = MAIN_ELF_BASE + main_dyn[i].val;
-        } else if (main_dyn[i].tag == DT_SYMTAB) {
-            main_symtab_addr = MAIN_ELF_BASE + main_dyn[i].val;
-        }
     }
-    if (!main_strtab_addr) {
         puts_str("ld.so: no DT_STRTAB\n");
         sys_exit2(1);
     }
 
-    /* Print DT_NEEDED entries. */
-    int needed_count = 0;
-    for (i = 0; i < 64; i++) {
-        if (main_dyn[i].tag == DT_NULL) break;
-        if (main_dyn[i].tag == DT_NEEDED) {
-            /* P4 fix: silenced — was puts_str("ld.so: DT_NEEDED: <
```
- AFTER hunk:
```
         sys_exit2(1);
     }
 
+    /* --- Register main in the loaded-module table ---
+     * module_init re-checks the header with full bounds (BUG-0215 FIX:
+     * the phnum walk here is bounded now too) and parses .dynamic. */
+    main_idx = add_module("main");
+    if (main_idx < 0) {
+        puts_str("ld.so: module table full (main)\n");
         sys_exit2(1);
     }
+    if (module_init(main_idx, "main", main_base, 1) != 0) {
+        sys_exit2(1);
     }
+    if (g_modules[main_idx].strtab == 0) {
         puts_str("ld.so: no DT_STRTAB\n");
         sys_exit2(1);
     }
 
+    /* --- Validate libfoo.so (kernel pre-maps it; base from API page) --- */
+    {
+        elf64_hdr *libfoo_ehdr = (elf64_hdr *)libfoo_base;
+        if (libfoo_ehdr->ident[0] != 0x7f || libfoo_ehdr->ident[1] != 'E' ||
+            libfoo_ehdr->ident[2] != 'L'  || libfoo_ehdr->ident[3] != 'F') {
+            puts_str("ld.so: libfoo.so is not an ELF\n");
+            sys_exit2(1);
+        }
+        if (libfoo_ehdr->ident[4] != 2) {
+            puts_str("ld.so: libfoo.so is not ELF64\n");
+            sys_exit2(1);
+        }
+        if (libfoo_ehdr->type != ET_DYN) {
+            puts_str("ld.
```

## BUG-0215 (P2, p2fix2) — commit 539bbb8
- Location: ld_so.c:364-394
- Issue: vs 405-411   ldso_dlopen 不校验 ELF 魔数（dlsym 校验了）且 phnum 无界
- BEFORE hunk:
```
  * 0x08000000. Marked noinline+used so they get stable addresses even
  * though they're only reached through function pointers. */
 
-/* dlopen: ask the kernel to map a .so by name. Returns base address
- * (or 0 on failure). The kernel maps at proc->next_solib_addr (bump
- * allocator from 0x50000000).
- * BUG-018 FIX: After mapping, process the .so's relocations (.rela.dyn
- * and .rela.plt) so that RELATIVE/GLOB_DAT/JUMP_SLOT entries are patched.
- * Old code just mapped the raw bytes without relocation. */
 __attribute__((noinline, used))
 static void *ldso_dlopen(const char *name, int flags) {
-    long len = strlen_(name);
     long base;
-    __asm__ volatile (
-        "int $0x80"
-        : "=a"(base)
-        : "a"((long)SYS_MAP_SOLIB), "D"(name), "S"((unsigned long)len),
-          "d"((long)flags)
-        : "memory", "rcx", "r11"
-    );
     if (base <= 0) return 0;
 
-    /* BUG-018 FIX: Process relocations on the newly mapped .so. */
-    elf64_hdr *eh = (elf64_hdr *)base;
-    elf64_dyn *dyn = find_dynamic(eh, (unsigned long)base);
-    if (dyn) {
-        unsigned long so_symtab = 0, so_strtab = 0;
-        unsigned long so_rela = 0, so_relasz = 0;
-        unsi
```
- AFTER hunk:
```
  * 0x08000000. Marked noinline+used so they get stable addresses even
  * though they're only reached through function pointers. */
 
+/* dlopen: ask the kernel to map a .so by name (base comes from the
+ * kernel's per-process bump allocator). The new module is registered in
+ * the loaded-module table, validated (BUG-0215 FIX), relocated against
+ * ALL loaded modules and W^X-hardened before the handle is returned.
+ * Returns the base address (or 0 on failure). */
 __attribute__((noinline, used))
 static void *ldso_dlopen(const char *name, int flags) {
+    long len;
     long base;
+    int idx;
+
+    if (name == 0) return 0;
+    len = strlen_(name);
+    if (len <= 0 || len >= LDSO_NAME_MAX) return 0;
+    base = sys_map_solib(name, len, flags);
     if (base <= 0) return 0;
 
+    idx = add_module(name);
+    if (idx < 0) return 0;
+    if (module_init(idx, name, (unsigned long)base, 0) != 0) {
+        drop_module(idx);
+        return 0;
+    }
+    if (finish_module(idx, 0) != 0) {
+        drop_module(idx);
+        return 0;
     }
     return (void *)base;
 }
 
+/* dlsym: walk the HANDLE module's .dynsym, find name, return
+ * base + st_value. handle is the base addr
```

## BUG-0216 (P2, p2fix2) — commit 539bbb8
- Location: ld_so.c:7-11
- Issue: , 142-144   无加载基址随机化（固定 0x20000000/0x30000000/0x50000000 bump）、全部 PT_LOAD 映射 R+W+E（无 W^X）
- BEFORE hunk:
```
 
 /* Open Cube OS WP-08b Batch 5 - ld.so generalized dynamic linker.
  *
- * The kernel maps:
- *   - ld.so (this program) at 0x10000000 (R+E, single PT_LOAD)
- *   - main program ELF (PIE bytes) at 0x20000000 (R+W+E, all PT_LOADs)
- *   - libfoo.so (PIE bytes) at 0x30000000 (R+W+E, all PT_LOADs)
- *   - API table page at 0x08000000 (R+W, 1 page) for ld.so to publish
- *     dlopen/dlsym/dlclose function pointers.
  *
  * _start flow:
- *   1. Print "ld.so started"
- *   2. Validate main ELF at 0x20000000 (magic/ELF64/ET_DYN)
- *   3. Find PT_DYNAMIC, find DT_STRTAB/DT_SYMTAB/DT_NEEDED -> print names
- *   4. Validate libfoo.so at 0x30000000 (magic/ELF64/ET_DYN/phoff)
- *   5. Parse libfoo.so .dynamic -> find DT_SYMTAB/DT_STRTAB
- *   6. Process libfoo.so .rela.dyn (RELATIVE + GLOB_DAT for undef weaks)
- *   7. Process main's .rela.dyn (if DT_RELA present)
- *   8. Process main's .rela.plt (if DT_JMPREL present)
- *   9. Install API table at 0x08000000 (dlopen/dlsym/dlclose ptrs)
- *  10. Print "jumping to main entry at 0x<addr>" and jmp there
  *
  * The generalized process_relocations() handles R_X86_64_RELATIVE,
  * R_X86_64_64, R_X86_64_GLOB_DAT, R_X86_64_JUMP_SLOT, R_X86_64_C
```
- AFTER hunk:
```
 
 /* Open Cube OS WP-08b Batch 5 - ld.so generalized dynamic linker.
  *
+ * The kernel maps (BUG-0216 FIX: the main/libfoo/dlopen bases are
+ * randomized per process WITHIN the regions below; only the API table
+ * page keeps a fixed address):
+ *   - ld.so (this program) at 0x10000000 (single PT_LOAD)
+ *   - main program ELF (PIE bytes) in 0x20000000..0x2FF00000
+ *   - libfoo.so (PIE bytes) in 0x30000000..0x37F00000
+ *   - API table page at 0x08000000 (R+W, 1 page, FIXED):
+ *       offset  0/ 8/16 : dlopen/dlsym/dlclose function pointers
+ *       offset 24/32    : main / libfoo.so load bases (written by the
+ *                         kernel, read by ld.so — the kernel owns the
+ *                         randomization, ld.so owns no fixed base)
+ *   - dlopen'd .so files: kernel bump allocator from 0x38000000
+ *     (start offset randomized per process)
  *
  * _start flow:
+ *   1. Read main/libfoo bases from the API page, sanity-check them
+ *   2. Validate main ELF (magic/ELF64/ET_DYN/bounded program headers)
+ *   3. Register main + libfoo in the loaded-module table
+ *   4. Finish libfoo: load its DT_NEEDED dependencies (recursive,
+ *      depth-bounded at 8, via S
```

## BUG-0217 (P2, p2fix2) — commit 539bbb8
- Location: net_core.c:1695-1712
- Issue: , 2629-2645   UDP：未绑定端口不发 ICMP 端口不可达；socket rx 满即丢包；同端口多 socket 只有第一个收到
- BEFORE hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
     if (size > PMM_PAGE_SIZE) {
-        /* Need a full page. */
-        return (void *)mem_pmm_alloc_frame();
-    }
-    /* Sub-allocate from the current page. */
-    if (g_dma_page == NULL || g_dma_page_offset + size > PMM_PAGE_SIZE) {
-        /* Allocate a new page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
-        g_dma_page_offset = 0;
     }
-    /* Align to 16 bytes. */
-    g_dma_page_offset = (g_dma_page_offset + 15) & ~15;
-    void *p = g_dma_page + g_dma_page_offset;
-    g_dma_page_offset += size;
     return p;
 }
 
 static char n_tmp[20];  /* shared buffer for number formatting */
 
 /* Forward declarations. */
-void net_udp_socket_handler(u32 src_ip, u16 src_port, u16 dst_port,
-                            const void *data, int len);
 void net_icmp_handle_packet(u32 src_ip, const void *data, int len);
-void net_udp_handle_packet(u32 src_ip, const void *data, int len);
 void net_tcp_handle_packet(u32 src_ip, const void *data, int len);
 
 /* ============================================================
```
- AFTER hunk:
```
 static int g_dma_page_offset = 0;
 
 static void *dma_alloc(int size) {
+    if (size <= 0) return NULL;
     if (size > PMM_PAGE_SIZE) {
+        /* BUG-0201: a single frame cannot back a request larger than the
+         * frame itself. Use a physically-contiguous multi-frame run (the
+         * low identity-mapped region covers all PMM frames, so the DMA
+         * address stays valid); fail when PMM cannot provide one. */
+        int npages = (int)(((u64)size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
+        u64 pa = mem_pmm_alloc_contig((u64)npages);
+        if (pa == 0) return NULL;
+        return (void *)(uintptr_t)pa;
+    }
+    /* BUG-0201: sub-allocate from the current page. The alignment must be
+     * applied BEFORE the bounds check: the old order checked
+     * "offset + size <= 4096" on the unaligned offset and only then
+     * aligned, so up to 15+size bytes could be handed out past the end
+     * of the frame. */
+    int aligned = (g_dma_page_offset + 15) & ~15;
+    if (g_dma_page == NULL || aligned + size > PMM_PAGE_SIZE) {
+        /* Need a fresh page. */
         g_dma_page = (u8 *)mem_pmm_alloc_frame();
         if (g_dma_page == NULL) return NULL;
+
```

## BUG-0218 (P2, p2fix2) — commit 539bbb8
- Location: net/net_ssh.c:725-1041
- Issue: 握手失败路径泄漏 TCP socket
- BEFORE hunk:
```
 /* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
 /* Open Cube OS - WP-09
  * File: kernel/ssh.c
- * Purpose: SSH-2.0 client — minimal implementation.
  *
  * Implements (subset of RFC 4251-4254):
  *   - SSH-2.0 version banner exchange
- *   - SSH_MSG_KEXINIT (algorithm negotiation)
- *   - SSH_MSG_KEXDH_INIT / KEXDH_REPLY (DH group 14, 2048-bit + SHA-256)
- *   - SSH_MSG_NEWKEYS (transition to encrypted mode)
- *   - SSH_MSG_USERAUTH_REQUEST (password)
- *   - SSH_MSG_CHANNEL_OPEN + CHANNEL_REQUEST (exec)
- *   - SSH_MSG_CHANNEL_DATA (receive output)
  *
- * Ciphers chosen:
- *   - KEX:    diffie-hellman-group14-sha256 (paramiko default)
- *   - Cipher: aes128-cbc
- *   - MAC:    hmac-sha1 (20-byte tag)
- *   - Host key verification: skipped (accept any)
- *   - Compression: none
  *
- * WP-09 design note: 2048-bit DH modexp takes ~60s in QEMU. This is a
- * one-time cost per session. The handshake then proceeds with AES-128-CBC
- * encrypted packets. Server-side encrypted packets are decrypted using
- * crypto_aes128_cbc_decrypt + hmac-sha1 verify.
  */
 #include "net_ssh.h"
 #include "crypto_core.h"
```
- AFTER hunk:
```
 /* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
 /* Open Cube OS - WP-09
  * File: kernel/ssh.c
+ * Purpose: SSH-2.0 client.
  *
  * Implements (subset of RFC 4251-4254):
  *   - SSH-2.0 version banner exchange
+ *   - SSH_MSG_KEXINIT (algorithm negotiation), incl. the strict-kex
+ *     extension tokens (RFC 9144, Terrapin hardening)
+ *   - SSH_MSG_KEXDH_INIT / KEXDH_REPLY: curve25519-sha256 (preferred,
+ *     RFC 8731) or diffie-hellman-group14-sha256 (RFC 8268)
+ *   - SSH_MSG_NEWKEYS transition to encrypted mode; with strict-kex both
+ *     sequence numbers restart at 0 after every NEWKEYS (RFC 9144)
+ *   - byte-threshold rekey: at 64 MiB per direction the client starts a
+ *     new KEXINIT at a packet boundary, reusing the KEX machinery (the
+ *     rekey exchange itself runs under the still-active keys)
+ *   - SSH_MSG_SERVICE_REQUEST / SERVICE_ACCEPT service dance before
+ *     userauth (RFC 4252 S5)
+ *   - SSH_MSG_USERAUTH_REQUEST: password, or publickey when the password
+ *     is empty
+ *   - SSH_MSG_CHANNEL_OPEN + CHANNEL_REQUEST (exec) + CHANNEL_DATA
  *
+ * Algorithms / trust model:
+ *   - Cipher: aes128-ctr (preferred), aes128-cbc fallback (RFC 4253
```

## BUG-0219 (P2, p2fix2) — commit 539bbb8
- Location: net/net_ssh.c
- Issue: （全文）  无密钥重交换（rekey）支持
- BEFORE hunk:
```
 /* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
 /* Open Cube OS - WP-09
  * File: kernel/ssh.c
- * Purpose: SSH-2.0 client — minimal implementation.
  *
  * Implements (subset of RFC 4251-4254):
  *   - SSH-2.0 version banner exchange
- *   - SSH_MSG_KEXINIT (algorithm negotiation)
- *   - SSH_MSG_KEXDH_INIT / KEXDH_REPLY (DH group 14, 2048-bit + SHA-256)
- *   - SSH_MSG_NEWKEYS (transition to encrypted mode)
- *   - SSH_MSG_USERAUTH_REQUEST (password)
- *   - SSH_MSG_CHANNEL_OPEN + CHANNEL_REQUEST (exec)
- *   - SSH_MSG_CHANNEL_DATA (receive output)
  *
- * Ciphers chosen:
- *   - KEX:    diffie-hellman-group14-sha256 (paramiko default)
- *   - Cipher: aes128-cbc
- *   - MAC:    hmac-sha1 (20-byte tag)
- *   - Host key verification: skipped (accept any)
- *   - Compression: none
  *
- * WP-09 design note: 2048-bit DH modexp takes ~60s in QEMU. This is a
- * one-time cost per session. The handshake then proceeds with AES-128-CBC
- * encrypted packets. Server-side encrypted packets are decrypted using
- * crypto_aes128_cbc_decrypt + hmac-sha1 verify.
  */
 #include "net_ssh.h"
 #include "crypto_core.h"
```
- AFTER hunk:
```
 /* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
 /* Open Cube OS - WP-09
  * File: kernel/ssh.c
+ * Purpose: SSH-2.0 client.
  *
  * Implements (subset of RFC 4251-4254):
  *   - SSH-2.0 version banner exchange
+ *   - SSH_MSG_KEXINIT (algorithm negotiation), incl. the strict-kex
+ *     extension tokens (RFC 9144, Terrapin hardening)
+ *   - SSH_MSG_KEXDH_INIT / KEXDH_REPLY: curve25519-sha256 (preferred,
+ *     RFC 8731) or diffie-hellman-group14-sha256 (RFC 8268)
+ *   - SSH_MSG_NEWKEYS transition to encrypted mode; with strict-kex both
+ *     sequence numbers restart at 0 after every NEWKEYS (RFC 9144)
+ *   - byte-threshold rekey: at 64 MiB per direction the client starts a
+ *     new KEXINIT at a packet boundary, reusing the KEX machinery (the
+ *     rekey exchange itself runs under the still-active keys)
+ *   - SSH_MSG_SERVICE_REQUEST / SERVICE_ACCEPT service dance before
+ *     userauth (RFC 4252 S5)
+ *   - SSH_MSG_USERAUTH_REQUEST: password, or publickey when the password
+ *     is empty
+ *   - SSH_MSG_CHANNEL_OPEN + CHANNEL_REQUEST (exec) + CHANNEL_DATA
  *
+ * Algorithms / trust model:
+ *   - Cipher: aes128-ctr (preferred), aes128-cbc fallback (RFC 4253
```

## BUG-0220 (P2, p2fix2) — commit 539bbb8
- Location: net/net_ssh.c
- Issue: （KEX/NEWKEYS 段）  无 strict-kex（Terrapin，RFC 9144）加固
- BEFORE hunk:
```
 /* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
 /* Open Cube OS - WP-09
  * File: kernel/ssh.c
- * Purpose: SSH-2.0 client — minimal implementation.
  *
  * Implements (subset of RFC 4251-4254):
  *   - SSH-2.0 version banner exchange
- *   - SSH_MSG_KEXINIT (algorithm negotiation)
- *   - SSH_MSG_KEXDH_INIT / KEXDH_REPLY (DH group 14, 2048-bit + SHA-256)
- *   - SSH_MSG_NEWKEYS (transition to encrypted mode)
- *   - SSH_MSG_USERAUTH_REQUEST (password)
- *   - SSH_MSG_CHANNEL_OPEN + CHANNEL_REQUEST (exec)
- *   - SSH_MSG_CHANNEL_DATA (receive output)
  *
- * Ciphers chosen:
- *   - KEX:    diffie-hellman-group14-sha256 (paramiko default)
- *   - Cipher: aes128-cbc
- *   - MAC:    hmac-sha1 (20-byte tag)
- *   - Host key verification: skipped (accept any)
- *   - Compression: none
  *
- * WP-09 design note: 2048-bit DH modexp takes ~60s in QEMU. This is a
- * one-time cost per session. The handshake then proceeds with AES-128-CBC
- * encrypted packets. Server-side encrypted packets are decrypted using
- * crypto_aes128_cbc_decrypt + hmac-sha1 verify.
  */
 #include "net_ssh.h"
 #include "crypto_core.h"
```
- AFTER hunk:
```
 /* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
 /* Open Cube OS - WP-09
  * File: kernel/ssh.c
+ * Purpose: SSH-2.0 client.
  *
  * Implements (subset of RFC 4251-4254):
  *   - SSH-2.0 version banner exchange
+ *   - SSH_MSG_KEXINIT (algorithm negotiation), incl. the strict-kex
+ *     extension tokens (RFC 9144, Terrapin hardening)
+ *   - SSH_MSG_KEXDH_INIT / KEXDH_REPLY: curve25519-sha256 (preferred,
+ *     RFC 8731) or diffie-hellman-group14-sha256 (RFC 8268)
+ *   - SSH_MSG_NEWKEYS transition to encrypted mode; with strict-kex both
+ *     sequence numbers restart at 0 after every NEWKEYS (RFC 9144)
+ *   - byte-threshold rekey: at 64 MiB per direction the client starts a
+ *     new KEXINIT at a packet boundary, reusing the KEX machinery (the
+ *     rekey exchange itself runs under the still-active keys)
+ *   - SSH_MSG_SERVICE_REQUEST / SERVICE_ACCEPT service dance before
+ *     userauth (RFC 4252 S5)
+ *   - SSH_MSG_USERAUTH_REQUEST: password, or publickey when the password
+ *     is empty
+ *   - SSH_MSG_CHANNEL_OPEN + CHANNEL_REQUEST (exec) + CHANNEL_DATA
  *
+ * Algorithms / trust model:
+ *   - Cipher: aes128-ctr (preferred), aes128-cbc fallback (RFC 4253
```

## BUG-0221 (P2, p2fix2) — commit 539bbb8
- Location: net/net_ssh.c:786-790
- Issue: + net_sshd.c:689 + net_tls.c:530   X25519 共享密钥全零不检查
- BEFORE hunk:
```
 /* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
 /* Open Cube OS - WP-09
  * File: kernel/ssh.c
- * Purpose: SSH-2.0 client — minimal implementation.
  *
  * Implements (subset of RFC 4251-4254):
  *   - SSH-2.0 version banner exchange
- *   - SSH_MSG_KEXINIT (algorithm negotiation)
- *   - SSH_MSG_KEXDH_INIT / KEXDH_REPLY (DH group 14, 2048-bit + SHA-256)
- *   - SSH_MSG_NEWKEYS (transition to encrypted mode)
- *   - SSH_MSG_USERAUTH_REQUEST (password)
- *   - SSH_MSG_CHANNEL_OPEN + CHANNEL_REQUEST (exec)
- *   - SSH_MSG_CHANNEL_DATA (receive output)
  *
- * Ciphers chosen:
- *   - KEX:    diffie-hellman-group14-sha256 (paramiko default)
- *   - Cipher: aes128-cbc
- *   - MAC:    hmac-sha1 (20-byte tag)
- *   - Host key verification: skipped (accept any)
- *   - Compression: none
  *
- * WP-09 design note: 2048-bit DH modexp takes ~60s in QEMU. This is a
- * one-time cost per session. The handshake then proceeds with AES-128-CBC
- * encrypted packets. Server-side encrypted packets are decrypted using
- * crypto_aes128_cbc_decrypt + hmac-sha1 verify.
  */
 #include "net_ssh.h"
 #include "crypto_core.h"
```
- AFTER hunk:
```
 /* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
 /* Open Cube OS - WP-09
  * File: kernel/ssh.c
+ * Purpose: SSH-2.0 client.
  *
  * Implements (subset of RFC 4251-4254):
  *   - SSH-2.0 version banner exchange
+ *   - SSH_MSG_KEXINIT (algorithm negotiation), incl. the strict-kex
+ *     extension tokens (RFC 9144, Terrapin hardening)
+ *   - SSH_MSG_KEXDH_INIT / KEXDH_REPLY: curve25519-sha256 (preferred,
+ *     RFC 8731) or diffie-hellman-group14-sha256 (RFC 8268)
+ *   - SSH_MSG_NEWKEYS transition to encrypted mode; with strict-kex both
+ *     sequence numbers restart at 0 after every NEWKEYS (RFC 9144)
+ *   - byte-threshold rekey: at 64 MiB per direction the client starts a
+ *     new KEXINIT at a packet boundary, reusing the KEX machinery (the
+ *     rekey exchange itself runs under the still-active keys)
+ *   - SSH_MSG_SERVICE_REQUEST / SERVICE_ACCEPT service dance before
+ *     userauth (RFC 4252 S5)
+ *   - SSH_MSG_USERAUTH_REQUEST: password, or publickey when the password
+ *     is empty
+ *   - SSH_MSG_CHANNEL_OPEN + CHANNEL_REQUEST (exec) + CHANNEL_DATA
  *
+ * Algorithms / trust model:
+ *   - Cipher: aes128-ctr (preferred), aes128-cbc fallback (RFC 4253
```

## BUG-0222 (P2, p2fix2) — commit 539bbb8
- Location: net/net_sshd.c:1130-1153
- Issue: USERAUTH 无失败次数上限/延迟 → 无限口令爆破
- BEFORE hunk:
```
         net_sshd_write_str(sbuf, &sp, sig, 256);
         net_sshd_write_str(blob, &p, sbuf, sp);
     }
     return net_sshd_send_packet_unencrypted(ctx, SSHD_MSG_KEXDH_REPLY, blob, p);
 }
 
-static int net_sshd_send_kexdh_reply(net_sshd_ctx_t *ctx) {
-    if (ctx->kex_curve25519) return net_sshd_send_kexdh_reply_curve25519(ctx);
     /* server DH: y, f = g^y mod p, K = e^y mod p */
     crypto_random(ctx->crypto_dh_priv, SSHD_DH_BYTES);
     ctx->crypto_dh_priv[0] &= 0x7F;
```
- AFTER hunk:
```
         net_sshd_write_str(sbuf, &sp, sig, 256);
         net_sshd_write_str(blob, &p, sbuf, sp);
     }
+    if (encrypted)
+        return net_sshd_send_packet_encrypted(ctx, SSHD_MSG_KEXDH_REPLY, blob, p);
     return net_sshd_send_packet_unencrypted(ctx, SSHD_MSG_KEXDH_REPLY, blob, p);
 }
 
+static int net_sshd_send_kexdh_reply(net_sshd_ctx_t *ctx, int encrypted) {
+    if (ctx->kex_curve25519) return net_sshd_send_kexdh_reply_curve25519(ctx, encrypted);
     /* server DH: y, f = g^y mod p, K = e^y mod p */
     crypto_random(ctx->crypto_dh_priv, SSHD_DH_BYTES);
     ctx->crypto_dh_priv[0] &= 0x7F;
```

## BUG-0223 (P2, p2fix2) — commit 539bbb8
- Location: net/net_sshd.c:975-976
- Issue: 口令非常量时间比较 + 用户名实际不校验
- BEFORE hunk:
```
 #define SSHD_MSG_CHANNEL_SUCCESS  99
 #define SSHD_MSG_CHANNEL_FAILURE 100
 
 #define SSHD_DH_BYTES 256
 static const char *SSHD_BANNER = "SSH-2.0-OpenCubeOS_sshd_WP-09\r\n";
 
```
- AFTER hunk:
```
 #define SSHD_MSG_CHANNEL_SUCCESS  99
 #define SSHD_MSG_CHANNEL_FAILURE 100
 
+/* RFC 4253 §11.1 disconnect reason codes used by this server */
+#define SSHD_DISCONNECT_SERVICE_NOT_AVAILABLE   7
+#define SSHD_DISCONNECT_TOO_MANY_CONNECTIONS   12
+#define SSHD_DISCONNECT_NO_MORE_AUTH_METHODS   14
+
+/* BUG-0222 (A14-36): authentication attempt budget per connection */
+#define SSHD_AUTH_MAX_ATTEMPTS 6
+
+/* BUG-0224 (A14-39): payload capacity of one page frame (all packet
+ * payload buffers are heap frames, never stack arrays) */
+#define SSHD_PKT_CAP 4096
+
+/* BUG-0220 (A14-34): strict-kex tokens (RFC 9144). The server advertises
+ * ..._s_..., the client ..._c_...; each side looks for the PEER's token. */
+#define SSHD_KEX_STRICT_CLIENT "kex-strict-c-v00@openssh.com"
+#define SSHD_KEX_STRICT_SERVER "kex-strict-s-v00@openssh.com"
+
 #define SSHD_DH_BYTES 256
 static const char *SSHD_BANNER = "SSH-2.0-OpenCubeOS_sshd_WP-09\r\n";
 
```

## BUG-0224 (P2, p2fix2) — commit 539bbb8
- Location: net/net_sshd.c:1002-1011
- Issue: handle_exec 负 reqlen → 负偏移 OOB 读
- BEFORE hunk:
```
     return 0;
 }
 
-static int net_sshd_recv_kexinit(net_sshd_ctx_t *ctx) {
-    u8 rtype;
-    u8 payload[4096];
-    int plen = sizeof(payload);
-    if (net_sshd_recv_packet_unencrypted(ctx, &rtype, payload, &plen) < 0) return -1;
-    if (rtype != SSHD_MSG_KEXINIT) return -2;
-    u8 wire[4096];
-    wire[0] = rtype;
-    memcpy(wire + 1, payload, plen);
-    memcpy(ctx->client_kexinit, wire, plen + 1);
     ctx->client_kexinit_len = plen + 1;
     /* Negotiate: pick our first-listed algorithm that the client offers.
      * Client KEXINIT payload (after msg_type): cookie(16) + 10 name-lists. */
```
- AFTER hunk:
```
     return 0;
 }
 
+/* Save the client KEXINIT (msg_type included, matching paramiko's I_C)
+ * and negotiate algorithms. BUG-0224 (A14-39): split from recv_kexinit so
+ * the rekey responder (BUG-0219) can reuse it on a payload already
+ * received; the old recv path also staged the payload through a second
+ * 4 KiB stack array (wire[]), which is gone - the frame is copied
+ * straight into ctx->client_kexinit. */
+static int net_sshd_parse_kexinit(net_sshd_ctx_t *ctx, const u8 *payload, int plen) {
+    if (plen < 0 || 1 + plen > (int)sizeof(ctx->client_kexinit)) return -2;
+    ctx->client_kexinit[0] = SSHD_MSG_KEXINIT;
+    memcpy(ctx->client_kexinit + 1, payload, plen);
     ctx->client_kexinit_len = plen + 1;
     /* Negotiate: pick our first-listed algorithm that the client offers.
      * Client KEXINIT payload (after msg_type): cookie(16) + 10 name-lists. */
```

## BUG-0225 (P2, p2fix2) — commit 539bbb8
- Location: net/net_sshd.c:1080-1099
- Issue: + 627-637   嵌套栈帧 ~12KB 逼近 16KB 引导栈
- BEFORE hunk:
```
     u8 shared32[32];
     if (crypto_x25519_shared(ctx->crypto_x25519_priv, ctx->client_pub + SSHD_DH_BYTES - 32, shared32) != 0)
         return -1;
     memset(ctx->shared_secret, 0, SSHD_DH_BYTES);
     memcpy(ctx->shared_secret + SSHD_DH_BYTES - 32, shared32, 32);
     net_sshd_log("curve25519 KEX: shared secret computed");
```
- AFTER hunk:
```
     u8 shared32[32];
     if (crypto_x25519_shared(ctx->crypto_x25519_priv, ctx->client_pub + SSHD_DH_BYTES - 32, shared32) != 0)
         return -1;
+    if (net_sshd_secret_is_zero(shared32, 32)) {
+        /* BUG-0221 (A14-35): RFC 7748 §6.1 - an all-zero X25519 output means
+         * the client's public key was invalid (small-order point); the
+         * resulting session keys would be attacker-derivable. Abort KEX. */
+        net_sshd_log("curve25519 shared secret is all-zero (invalid client key)");
+        return -1;
+    }
     memset(ctx->shared_secret, 0, SSHD_DH_BYTES);
     memcpy(ctx->shared_secret + SSHD_DH_BYTES - 32, shared32, 32);
     net_sshd_log("curve25519 KEX: shared secret computed");
```

## BUG-0226 (P2, p2fix2) — commit 539bbb8
- Location: net/net_sshd.c:1212-1257
- Issue: 单连接服务器：并发会话数 = 1
- BEFORE hunk:
```
         net_sshd_write_str(blob, &p, sbuf, sp);
     }
     {
-        int rc = net_sshd_send_packet_unencrypted(ctx, SSHD_MSG_KEXDH_REPLY, blob, p);
         char b[64]; strcpy(b, "KEXDH_REPLY send rc=");
         char n[10]; u64_to_str((u64)(rc < 0 ? -rc : rc), n); strcat(b, n);
         strcat(b, " (p=");
```
- AFTER hunk:
```
         net_sshd_write_str(blob, &p, sbuf, sp);
     }
     {
+        int rc;
+        if (encrypted)
+            rc = net_sshd_send_packet_encrypted(ctx, SSHD_MSG_KEXDH_REPLY, blob, p);
+        else
+            rc = net_sshd_send_packet_unencrypted(ctx, SSHD_MSG_KEXDH_REPLY, blob, p);
         char b[64]; strcpy(b, "KEXDH_REPLY send rc=");
         char n[10]; u64_to_str((u64)(rc < 0 ? -rc : rc), n); strcat(b, n);
         strcat(b, " (p=");
```

## BUG-0227 (P2, p2fix2) — commit 539bbb8
- Location: net/net_tls.c:480-482
- Issue: + 1234   ServerHello 选择的套件不对照报价单校验
- BEFORE hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
 
 /* BUG-0078 note: the ctx now holds 32 KiB transcript + 32 KiB hs_log
  * (was 9 KiB each), which no longer fits in the kernel image's
```
- AFTER hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
+#define HT_HELLO_REQUEST 0
+
+/* ---------------- WP-10-AUDIT_P2-fix2 (G5) ----------------
+ * Alert handling, CBC hardening, downgrade protection, send bounds. */
+
+/* Alert levels and descriptions (RFC 5246 7.2 / RFC 8446 6 / RFC 7507). */
+#define TLS_ALERT_LEVEL_WARNING          1
+#define TLS_ALERT_LEVEL_FATAL            2
+#define TLS_ALERT_CLOSE_NOTIFY           0
+#define TLS_ALERT_HANDSHAKE_FAILURE      40
+#define TLS_ALERT_ILLEGAL_PARAMETER      47
+#define TLS_ALERT_PROTOCOL_VERSION       70
+#define TLS_ALERT_INAPPROPRIATE_FALLBACK 86   /* RFC 7507 */
+#define TLS_ALERT_NO_RENEGOTIATION       100  /* RFC 5246 7.2 / RFC 5746 */
+
+/* Internal record-layer / reader codes (mapped onto the public
+ * NET_TLS_ERR_* codes declared in net_tls.h by net_tls_recv). */
+#define TLS_RC_IO         (-1)
+#define TLS_RC_DECRYPT    (-2)
+#define TLS_RC_TRUNCATED  (-4)
+
+/* BUG-0228 (A14-42): net_tcp_read_exact results.  TLS_READ_EOF means the
+ * TCP peer is gone (peer FIN observed and the receive buffer drained, or
+ * the connection was reset) - no further bytes can ever arrive, which is
+ * exa
```

## BUG-0228 (P2, p2fix2) — commit 539bbb8
- Location: net/net_tls.c:1309-1313
- Issue: 告警与 close_notify 不可区分 → 截断攻击无检测
- BEFORE hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
 
 /* BUG-0078 note: the ctx now holds 32 KiB transcript + 32 KiB hs_log
  * (was 9 KiB each), which no longer fits in the kernel image's
```
- AFTER hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
+#define HT_HELLO_REQUEST 0
+
+/* ---------------- WP-10-AUDIT_P2-fix2 (G5) ----------------
+ * Alert handling, CBC hardening, downgrade protection, send bounds. */
+
+/* Alert levels and descriptions (RFC 5246 7.2 / RFC 8446 6 / RFC 7507). */
+#define TLS_ALERT_LEVEL_WARNING          1
+#define TLS_ALERT_LEVEL_FATAL            2
+#define TLS_ALERT_CLOSE_NOTIFY           0
+#define TLS_ALERT_HANDSHAKE_FAILURE      40
+#define TLS_ALERT_ILLEGAL_PARAMETER      47
+#define TLS_ALERT_PROTOCOL_VERSION       70
+#define TLS_ALERT_INAPPROPRIATE_FALLBACK 86   /* RFC 7507 */
+#define TLS_ALERT_NO_RENEGOTIATION       100  /* RFC 5246 7.2 / RFC 5746 */
+
+/* Internal record-layer / reader codes (mapped onto the public
+ * NET_TLS_ERR_* codes declared in net_tls.h by net_tls_recv). */
+#define TLS_RC_IO         (-1)
+#define TLS_RC_DECRYPT    (-2)
+#define TLS_RC_TRUNCATED  (-4)
+
+/* BUG-0228 (A14-42): net_tcp_read_exact results.  TLS_READ_EOF means the
+ * TCP peer is gone (peer FIN observed and the receive buffer drained, or
+ * the connection was reset) - no further bytes can ever arrive, which is
+ * exa
```

## BUG-0229 (P2, p2fix2) — commit 539bbb8
- Location: net/net_tls.c:797-823
- Issue: TLS1.2 CBC 填充预言（Lucky13 类）
- BEFORE hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
 
 /* BUG-0078 note: the ctx now holds 32 KiB transcript + 32 KiB hs_log
  * (was 9 KiB each), which no longer fits in the kernel image's
```
- AFTER hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
+#define HT_HELLO_REQUEST 0
+
+/* ---------------- WP-10-AUDIT_P2-fix2 (G5) ----------------
+ * Alert handling, CBC hardening, downgrade protection, send bounds. */
+
+/* Alert levels and descriptions (RFC 5246 7.2 / RFC 8446 6 / RFC 7507). */
+#define TLS_ALERT_LEVEL_WARNING          1
+#define TLS_ALERT_LEVEL_FATAL            2
+#define TLS_ALERT_CLOSE_NOTIFY           0
+#define TLS_ALERT_HANDSHAKE_FAILURE      40
+#define TLS_ALERT_ILLEGAL_PARAMETER      47
+#define TLS_ALERT_PROTOCOL_VERSION       70
+#define TLS_ALERT_INAPPROPRIATE_FALLBACK 86   /* RFC 7507 */
+#define TLS_ALERT_NO_RENEGOTIATION       100  /* RFC 5246 7.2 / RFC 5746 */
+
+/* Internal record-layer / reader codes (mapped onto the public
+ * NET_TLS_ERR_* codes declared in net_tls.h by net_tls_recv). */
+#define TLS_RC_IO         (-1)
+#define TLS_RC_DECRYPT    (-2)
+#define TLS_RC_TRUNCATED  (-4)
+
+/* BUG-0228 (A14-42): net_tcp_read_exact results.  TLS_READ_EOF means the
+ * TCP peer is gone (peer FIN observed and the receive buffer drained, or
+ * the connection was reset) - no further bytes can ever arrive, which is
+ * exa
```

## BUG-0230 (P2, p2fix2) — commit 539bbb8
- Location: net/net_tls.c:609-611
- Issue: + 1074   CertificateVerify/SKE 的 sig_len 不与消息长度核对
- BEFORE hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
 
 /* BUG-0078 note: the ctx now holds 32 KiB transcript + 32 KiB hs_log
  * (was 9 KiB each), which no longer fits in the kernel image's
```
- AFTER hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
+#define HT_HELLO_REQUEST 0
+
+/* ---------------- WP-10-AUDIT_P2-fix2 (G5) ----------------
+ * Alert handling, CBC hardening, downgrade protection, send bounds. */
+
+/* Alert levels and descriptions (RFC 5246 7.2 / RFC 8446 6 / RFC 7507). */
+#define TLS_ALERT_LEVEL_WARNING          1
+#define TLS_ALERT_LEVEL_FATAL            2
+#define TLS_ALERT_CLOSE_NOTIFY           0
+#define TLS_ALERT_HANDSHAKE_FAILURE      40
+#define TLS_ALERT_ILLEGAL_PARAMETER      47
+#define TLS_ALERT_PROTOCOL_VERSION       70
+#define TLS_ALERT_INAPPROPRIATE_FALLBACK 86   /* RFC 7507 */
+#define TLS_ALERT_NO_RENEGOTIATION       100  /* RFC 5246 7.2 / RFC 5746 */
+
+/* Internal record-layer / reader codes (mapped onto the public
+ * NET_TLS_ERR_* codes declared in net_tls.h by net_tls_recv). */
+#define TLS_RC_IO         (-1)
+#define TLS_RC_DECRYPT    (-2)
+#define TLS_RC_TRUNCATED  (-4)
+
+/* BUG-0228 (A14-42): net_tcp_read_exact results.  TLS_READ_EOF means the
+ * TCP peer is gone (peer FIN observed and the receive buffer drained, or
+ * the connection was reset) - no further bytes can ever arrive, which is
+ * exa
```

## BUG-0231 (P2, p2fix2) — commit 539bbb8
- Location: net/net_tls.c:856-925
- Issue: net_tls12_send_record 对静态 rec[16640] 无长度校验
- BEFORE hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
 
 /* BUG-0078 note: the ctx now holds 32 KiB transcript + 32 KiB hs_log
  * (was 9 KiB each), which no longer fits in the kernel image's
```
- AFTER hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
+#define HT_HELLO_REQUEST 0
+
+/* ---------------- WP-10-AUDIT_P2-fix2 (G5) ----------------
+ * Alert handling, CBC hardening, downgrade protection, send bounds. */
+
+/* Alert levels and descriptions (RFC 5246 7.2 / RFC 8446 6 / RFC 7507). */
+#define TLS_ALERT_LEVEL_WARNING          1
+#define TLS_ALERT_LEVEL_FATAL            2
+#define TLS_ALERT_CLOSE_NOTIFY           0
+#define TLS_ALERT_HANDSHAKE_FAILURE      40
+#define TLS_ALERT_ILLEGAL_PARAMETER      47
+#define TLS_ALERT_PROTOCOL_VERSION       70
+#define TLS_ALERT_INAPPROPRIATE_FALLBACK 86   /* RFC 7507 */
+#define TLS_ALERT_NO_RENEGOTIATION       100  /* RFC 5246 7.2 / RFC 5746 */
+
+/* Internal record-layer / reader codes (mapped onto the public
+ * NET_TLS_ERR_* codes declared in net_tls.h by net_tls_recv). */
+#define TLS_RC_IO         (-1)
+#define TLS_RC_DECRYPT    (-2)
+#define TLS_RC_TRUNCATED  (-4)
+
+/* BUG-0228 (A14-42): net_tcp_read_exact results.  TLS_READ_EOF means the
+ * TCP peer is gone (peer FIN observed and the receive buffer drained, or
+ * the connection was reset) - no further bytes can ever arrive, which is
+ * exa
```

## BUG-0232 (P2, p2fix2) — commit 539bbb8
- Location: net/net_tls.c
- Issue: （全文）  无重协商处理（RFC 5746）
- BEFORE hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
 
 /* BUG-0078 note: the ctx now holds 32 KiB transcript + 32 KiB hs_log
  * (was 9 KiB each), which no longer fits in the kernel image's
```
- AFTER hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
+#define HT_HELLO_REQUEST 0
+
+/* ---------------- WP-10-AUDIT_P2-fix2 (G5) ----------------
+ * Alert handling, CBC hardening, downgrade protection, send bounds. */
+
+/* Alert levels and descriptions (RFC 5246 7.2 / RFC 8446 6 / RFC 7507). */
+#define TLS_ALERT_LEVEL_WARNING          1
+#define TLS_ALERT_LEVEL_FATAL            2
+#define TLS_ALERT_CLOSE_NOTIFY           0
+#define TLS_ALERT_HANDSHAKE_FAILURE      40
+#define TLS_ALERT_ILLEGAL_PARAMETER      47
+#define TLS_ALERT_PROTOCOL_VERSION       70
+#define TLS_ALERT_INAPPROPRIATE_FALLBACK 86   /* RFC 7507 */
+#define TLS_ALERT_NO_RENEGOTIATION       100  /* RFC 5246 7.2 / RFC 5746 */
+
+/* Internal record-layer / reader codes (mapped onto the public
+ * NET_TLS_ERR_* codes declared in net_tls.h by net_tls_recv). */
+#define TLS_RC_IO         (-1)
+#define TLS_RC_DECRYPT    (-2)
+#define TLS_RC_TRUNCATED  (-4)
+
+/* BUG-0228 (A14-42): net_tcp_read_exact results.  TLS_READ_EOF means the
+ * TCP peer is gone (peer FIN observed and the receive buffer drained, or
+ * the connection was reset) - no further bytes can ever arrive, which is
+ * exa
```

## BUG-0233 (P2, p2fix2) — commit 539bbb8
- Location: net/net_tls.c:508-521
- Issue: + 1223-1237   TLS1.2 回退无降级哨兵检查
- BEFORE hunk:
```
 static int net_tls13_hs_feed(net_tls_ctx_t *c, int *ctype_out) {
     if (tls_hs_ensure() < 0) return -1;
     int payload = net_tls13_recv_record(c, ctype_out, g_hsrec, TLS_HSREC_SIZE);
     if (payload < 0) return -1;
     if (*ctype_out == CT_CCS) return 0;          /* legacy CCS: skip */
     if (*ctype_out != CT_HANDSHAKE && *ctype_out != CT_APPDATA) return -2;
```
- AFTER hunk:
```
 static int net_tls13_hs_feed(net_tls_ctx_t *c, int *ctype_out) {
     if (tls_hs_ensure() < 0) return -1;
     int payload = net_tls13_recv_record(c, ctype_out, g_hsrec, TLS_HSREC_SIZE);
+    if (payload == TLS_RC_TRUNCATED) return TLS_RC_TRUNCATED;   /* BUG-0228 */
     if (payload < 0) return -1;
     if (*ctype_out == CT_CCS) return 0;          /* legacy CCS: skip */
     if (*ctype_out != CT_HANDSHAKE && *ctype_out != CT_APPDATA) return -2;
```

## BUG-0234 (P2, p2fix2) — commit 539bbb8
- Location: net/net_tls.c:1333
- Issue: net_tls_close 有效性判断写错（fd 0 有效却提前返回）
- BEFORE hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
 
 /* BUG-0078 note: the ctx now holds 32 KiB transcript + 32 KiB hs_log
  * (was 9 KiB each), which no longer fits in the kernel image's
```
- AFTER hunk:
```
 #define HT_CLIENT_KEY_EXCHANGE 16
 #define HT_FINISHED 20
 #define HT_KEY_UPDATE 24
+#define HT_HELLO_REQUEST 0
+
+/* ---------------- WP-10-AUDIT_P2-fix2 (G5) ----------------
+ * Alert handling, CBC hardening, downgrade protection, send bounds. */
+
+/* Alert levels and descriptions (RFC 5246 7.2 / RFC 8446 6 / RFC 7507). */
+#define TLS_ALERT_LEVEL_WARNING          1
+#define TLS_ALERT_LEVEL_FATAL            2
+#define TLS_ALERT_CLOSE_NOTIFY           0
+#define TLS_ALERT_HANDSHAKE_FAILURE      40
+#define TLS_ALERT_ILLEGAL_PARAMETER      47
+#define TLS_ALERT_PROTOCOL_VERSION       70
+#define TLS_ALERT_INAPPROPRIATE_FALLBACK 86   /* RFC 7507 */
+#define TLS_ALERT_NO_RENEGOTIATION       100  /* RFC 5246 7.2 / RFC 5746 */
+
+/* Internal record-layer / reader codes (mapped onto the public
+ * NET_TLS_ERR_* codes declared in net_tls.h by net_tls_recv). */
+#define TLS_RC_IO         (-1)
+#define TLS_RC_DECRYPT    (-2)
+#define TLS_RC_TRUNCATED  (-4)
+
+/* BUG-0228 (A14-42): net_tcp_read_exact results.  TLS_READ_EOF means the
+ * TCP peer is gone (peer FIN observed and the receive buffer drained, or
+ * the connection was reset) - no further bytes can ever arrive, which is
+ * exa
```

## BUG-0235 (P2, p2fix2) — commit 539bbb8
- Location: net/net_ssh.c:953-957
- Issue: ,1010-1014（对照 net_sshd.c:1127-1148 注释）  SSH 客户端不发 SERVICE_REQUEST 即发 USERAUTH
- BEFORE hunk:
```
     strcpy(ctx->client_banner, "SSH-2.0-OpenCubeOS_WP-09");
     if (net_ssh_send_version(ctx) < 0) {
         net_ssh_debug("[ssh] failed to send version banner");
-        return -2;
     }
     if (net_ssh_recv_version(ctx) < 0) {
         net_ssh_debug("[ssh] failed to receive server banner");
-        return -3;
     }
     net_ssh_debug("[ssh] version banner exchange OK");
     net_ssh_debug(ctx->server_banner);
 
     /* KEXINIT exchange */
-    if (net_ssh_send_kexinit(ctx) < 0) {
         net_ssh_debug("[ssh] failed to send KEXINIT");
-        return -4;
     }
-    if (net_ssh_recv_kexinit(ctx) < 0) {
         net_ssh_debug("[ssh] failed to receive KEXINIT");
-        return -5;
     }
     net_ssh_debug("[ssh] KEXINIT exchange OK");
 
     /* Key exchange: curve25519-sha256 (modern default) or group14 */
     if (ctx->kex_curve25519) {
-        if (net_ssh_send_kex_ecdh_init(ctx) < 0) {
             net_ssh_debug("[ssh] failed to send KEX_ECDH_INIT");
-            return -6;
         }
-        if (net_ssh_recv_kex_reply(ctx) < 0) {
             net_ssh_debug("[ssh] failed to receive KEX_ECDH_REPLY");
-            return -7;
         }
         /* K = X25519(x, f): 32-b
```
- AFTER hunk:
```
     strcpy(ctx->client_banner, "SSH-2.0-OpenCubeOS_WP-09");
     if (net_ssh_send_version(ctx) < 0) {
         net_ssh_debug("[ssh] failed to send version banner");
+        return net_ssh_connect_fail(ctx, -2);
     }
     if (net_ssh_recv_version(ctx) < 0) {
         net_ssh_debug("[ssh] failed to receive server banner");
+        return net_ssh_connect_fail(ctx, -3);
     }
     net_ssh_debug("[ssh] version banner exchange OK");
     net_ssh_debug(ctx->server_banner);
 
     /* KEXINIT exchange */
+    if (net_ssh_send_kexinit(ctx, 0) < 0) {
         net_ssh_debug("[ssh] failed to send KEXINIT");
+        return net_ssh_connect_fail(ctx, -4);
     }
+    if (net_ssh_recv_kexinit(ctx, 0) < 0) {
         net_ssh_debug("[ssh] failed to receive KEXINIT");
+        return net_ssh_connect_fail(ctx, -5);
     }
     net_ssh_debug("[ssh] KEXINIT exchange OK");
 
     /* Key exchange: curve25519-sha256 (modern default) or group14 */
     if (ctx->kex_curve25519) {
+        if (net_ssh_send_kex_ecdh_init(ctx, 0) < 0) {
             net_ssh_debug("[ssh] failed to send KEX_ECDH_INIT");
+            return net_ssh_connect_fail(ctx, -6);
         }
+        if (net_ssh_recv_kex_reply(ctx, 0)
```

## BUG-0236 (P2, p2fix2) — commit 539bbb8
- Location: shell.c:566
- Issue: 单帧 8 KiB 栈数组逼近 16 KiB 内核栈
- BEFORE hunk:
```
     if (!path || maxlen < 2) return -1;
     if (path[0] != '/') return -1;
 
-    /* In-place normalization using a write pointer. */
-    char comps[SHELL_CWD_LEN / 2][VFS_NAME_LEN];
     int ncomp = 0;
     int i = 0;
     while (path[i]) {
```
- AFTER hunk:
```
     if (!path || maxlen < 2) return -1;
     if (path[0] != '/') return -1;
 
+    /* BUG-0236 FIX (A15-10): comps used to be a stack array
+     *   char comps[SHELL_CWD_LEN / 2][VFS_NAME_LEN]  = 128*64 = 8192 B.
+     * On the 16 KiB kernel stack the deepest path is
+     * shell_normalize_path <- shell_resolve_path <- shell_exec_stage
+     * (~3 KiB with its scratch) <- shell_exec_segment (~1.6 KiB) <- a
+     * command frame (~0.8 KiB), plus a full IRQ frame (~0.5 KiB) that
+     * lands on the SAME stack: 8 KiB of comps left well under 2 KiB of
+     * headroom. comps lives on the heap now and is freed on EVERY exit
+     * path below. */
+    char (*comps)[VFS_NAME_LEN] = (char (*)[VFS_NAME_LEN])kmalloc(
+        (u64)sizeof(char[VFS_NAME_LEN]) * (u64)(SHELL_CWD_LEN / 2));
+    if (!comps) return -1;
     int ncomp = 0;
     int i = 0;
     while (path[i]) {
```

## BUG-0237 (P2, p2fix2) — commit 539bbb8
- Location: shell.c:275
- Issue: help -w 潜伏越界读 + 未知 tag
- BEFORE hunk:
```
                 shell_wp_print_entry(&g_commands[idx[i]], w);
         shown += count;
     }
-    /* unknown tags (L1 drivers may register their own): append A-Z */
     for (int i = 0; i < n; i++) {
         int known = 0;
         for (int k = 0; k < (int)(sizeof(g_wp_order) / sizeof(g_wp_order[0])); k++)
             if (strcmp(g_commands[idx[i]].wp, g_wp_order[k].tag) == 0) { known = 1; break; }
         if (known) continue;
-        if (shown == 0 || g_commands[idx[i - 1]].wp[0] == 0 ||
-            strcmp(g_commands[idx[i - 1]].wp, g_commands[idx[i]].wp) != 0) {
-            /* first command of an unknown tag: header once per tag */
-            int first = 1;
-            for (int j = 0; j < i; j++) {
-                int kknown = 0;
-                for (int k = 0; k < (int)(sizeof(g_wp_order) / sizeof(g_wp_order[0])); k++)
-                    if (strcmp(g_commands[idx[j]].wp, g_wp_order[k].tag) == 0) { kknown = 1; break; }
-                if (!kknown && strcmp(g_commands[idx[j]].wp,
-                                         g_commands[idx[i]].wp) == 0) { first = 0; break; }
-            }
-            if (first) {
-                screen_console_puts("\n=== ");
-      
```
- AFTER hunk:
```
                 shell_wp_print_entry(&g_commands[idx[i]], w);
         shown += count;
     }
+    /* BUG-0237 FIX (A15-11): unknown tags now go to ONE bounded "other"
+     * fallback bucket. The old loop evaluated g_commands[idx[i - 1]] at
+     * i == 0 whenever at least one known group had already been shown
+     * (shown > 0), i.e. it read idx[-1] - an out-of-bounds read of the
+     * sort index that could make the g_commands access run far past the
+     * table on garbage data. Every access here is bounds-checked and no
+     * tag is silently dropped: commands with an unregistered tag are
+     * always printed under "other". */
+    int other_shown = 0;
     for (int i = 0; i < n; i++) {
         int known = 0;
         for (int k = 0; k < (int)(sizeof(g_wp_order) / sizeof(g_wp_order[0])); k++)
             if (strcmp(g_commands[idx[i]].wp, g_wp_order[k].tag) == 0) { known = 1; break; }
         if (known) continue;
+        if (other_shown == 0) {
+            screen_console_puts("\n=== other (commands with unregistered work-package tags) ===\n");
+            other_shown = 1;
         }
         shell_wp_print_entry(&g_commands[idx[i]], w);
         shown++;
```

## BUG-0238 (P2, p2fix2) — commit 539bbb8
- Location: shell.c:1145-1157
- Issue: alias 目标含操作符被静默截断
- BEFORE hunk:
```
                 shell_wp_print_entry(&g_commands[idx[i]], w);
         shown += count;
     }
-    /* unknown tags (L1 drivers may register their own): append A-Z */
     for (int i = 0; i < n; i++) {
         int known = 0;
         for (int k = 0; k < (int)(sizeof(g_wp_order) / sizeof(g_wp_order[0])); k++)
             if (strcmp(g_commands[idx[i]].wp, g_wp_order[k].tag) == 0) { known = 1; break; }
         if (known) continue;
-        if (shown == 0 || g_commands[idx[i - 1]].wp[0] == 0 ||
-            strcmp(g_commands[idx[i - 1]].wp, g_commands[idx[i]].wp) != 0) {
-            /* first command of an unknown tag: header once per tag */
-            int first = 1;
-            for (int j = 0; j < i; j++) {
-                int kknown = 0;
-                for (int k = 0; k < (int)(sizeof(g_wp_order) / sizeof(g_wp_order[0])); k++)
-                    if (strcmp(g_commands[idx[j]].wp, g_wp_order[k].tag) == 0) { kknown = 1; break; }
-                if (!kknown && strcmp(g_commands[idx[j]].wp,
-                                         g_commands[idx[i]].wp) == 0) { first = 0; break; }
-            }
-            if (first) {
-                screen_console_puts("\n=== ");
-      
```
- AFTER hunk:
```
                 shell_wp_print_entry(&g_commands[idx[i]], w);
         shown += count;
     }
+    /* BUG-0237 FIX (A15-11): unknown tags now go to ONE bounded "other"
+     * fallback bucket. The old loop evaluated g_commands[idx[i - 1]] at
+     * i == 0 whenever at least one known group had already been shown
+     * (shown > 0), i.e. it read idx[-1] - an out-of-bounds read of the
+     * sort index that could make the g_commands access run far past the
+     * table on garbage data. Every access here is bounds-checked and no
+     * tag is silently dropped: commands with an unregistered tag are
+     * always printed under "other". */
+    int other_shown = 0;
     for (int i = 0; i < n; i++) {
         int known = 0;
         for (int k = 0; k < (int)(sizeof(g_wp_order) / sizeof(g_wp_order[0])); k++)
             if (strcmp(g_commands[idx[i]].wp, g_wp_order[k].tag) == 0) { known = 1; break; }
         if (known) continue;
+        if (other_shown == 0) {
+            screen_console_puts("\n=== other (commands with unregistered work-package tags) ===\n");
+            other_shown = 1;
         }
         shell_wp_print_entry(&g_commands[idx[i]], w);
         shown++;
```

## BUG-0239 (P2, p2fix2) — commit 539bbb8
- Location: shell_cmds_disk.c:179-197
- Issue: mkfs.* 无任何确认
- BEFORE hunk:
```
     return 0;
 }
 
 static int shell_cmd_mkfs_fat32(const char *args) {
-    if (!args[0]) {
-        screen_console_puts("usage: mkfs.fat32 <device>\n");
         return 1;
     }
-    int dev_idx = driver_block_find_device(args);
     if (dev_idx < 0) {
         screen_console_puts("mkfs.fat32: device not found\n");
         return 1;
```
- AFTER hunk:
```
     return 0;
 }
 
+/* ---- BUG-0239 FIX (A15-13): mkfs.* confirmation gate ----
+ * Formatting DESTROYS ALL DATA on the target device, and a typo'd device
+ * name (hda vs hdb) used to wipe it on Enter with no way back. All three
+ * mkfs.* commands now require the literal token `confirm` as the LAST
+ * argument:
+ *   mkfs.fat32 hda confirm
+ * Without it NOTHING is written to the device - the command only prints
+ * the data-loss warning and the usage line. Returns 0 when the caller may
+ * proceed (device token copied into devbuf), 1 when refused (device
+ * untouched). */
+static int shell_mkfs_gate(const char *cmd, const char *args,
+                           char *devbuf, int devbuf_len) {
+    /* Extract the device token (first word). */
+    int i = 0;
+    while (args[i] && args[i] != ' ' && args[i] != '\t' && i < devbuf_len - 1) {
+        devbuf[i] = args[i];
+        i++;
+    }
+    if (args[i] && args[i] != ' ' && args[i] != '\t') {
+        /* Device token did not fit - refuse, never guess. */
+        screen_console_puts(cmd);
+        screen_console_puts(": device name too long\n");
+        return 1;
+    }
+    devbuf[i] = 0;
+    if (!devbuf[0]) {
+        s
```

## BUG-0240 (P2, p2fix2) — commit 539bbb8
- Location: shell_cmds_disk_test.c:302-307
- Issue: disk_rw_test 用未初始化栈数据"恢复"扇区
- BEFORE hunk:
```
      * then verify through the raw API. */
     u64 lba = safe_test_lba(d) + 8;
     u8 orig[512], back[512], pat[512];
-    driver_block_read_sectors_raw(idx, lba, 1, orig);
     for (int i = 0; i < 512; i++) pat[i] = (u8)(0x5Au ^ i);
-    driver_block_write_sectors(idx, lba, 1, pat);
-    driver_block_flush(driver_block_get_device(idx));
-    driver_block_read_sectors_raw(idx, lba, 1, back);
     driver_block_write_sectors_raw(idx, lba, 1, orig);
-    if (memcmp(back, pat, 512) == 0) {
         t_pass("disk_rw_test", "cached write + blk_flush + raw verify");
     } else {
         t_fail("disk_rw_test", "cached write + blk_flush", "mismatch");
```
- AFTER hunk:
```
      * then verify through the raw API. */
     u64 lba = safe_test_lba(d) + 8;
     u8 orig[512], back[512], pat[512];
+    /* BUG-0240 FIX (A15-14): the original sector must actually be READ
+     * into the save buffer before the test touches the device. The old
+     * code ignored the read's return value, so on an I/O error `orig`
+     * held uninitialized stack bytes and the "restore" below wrote stack
+     * garbage onto the disk (violating this file's "No silent damage"
+     * rule). Fail fast BEFORE any write instead - if we never wrote,
+     * there is nothing to restore. */
+    if (driver_block_read_sectors_raw(idx, lba, 1, orig) != 0) {
+        t_fail("disk_rw_test", "save original sector", "io error");
+        return 1;
+    }
     for (int i = 0; i < 512; i++) pat[i] = (u8)(0x5Au ^ i);
+    int wrc = driver_block_write_sectors(idx, lba, 1, pat);
+    if (wrc == 0) {
+        driver_block_flush(driver_block_get_device(idx));
+    }
+    int brc = (wrc == 0) ? driver_block_read_sectors_raw(idx, lba, 1, back) : -1;
+    /* Restore the TRUE original bytes read above (BUG-0240). */
     driver_block_write_sectors_raw(idx, lba, 1, orig);
+    driver_block_flush(driv
```

## BUG-0241 (P2, p2fix2) — commit 539bbb8
- Location: shell_cmds_file.c:708-716
- Issue: write 失败误报成功
- BEFORE hunk:
```
     if (fd < 0) { screen_console_puts("write: open failed\n"); return 1; }
     int len = (int)strlen(rest);
     int n = fs_vfs_write(fd, rest, len);
     char msg[60]; char num[20];
     strcpy(msg, "wrote ");
-    fmt_u64((u64)(n > 0 ? n : 0), num);
     strcpy(msg + strlen(msg), num);
     strcpy(msg + strlen(msg), " bytes\n");
     screen_console_puts(msg);
-    fs_vfs_close(fd);
     return 0;
 }
 
```
- AFTER hunk:
```
     if (fd < 0) { screen_console_puts("write: open failed\n"); return 1; }
     int len = (int)strlen(rest);
     int n = fs_vfs_write(fd, rest, len);
+    fs_vfs_close(fd);
+    /* BUG-0241 FIX (A15-15): fs_vfs_write's return was ignored - a failed
+     * write still printed "wrote 0 bytes" and returned 0, so
+     * `write /full/disk text && echo ok` wrongly printed ok, and with
+     * O_TRUNC a short write silently destroyed data. Report failures (and
+     * short writes) and fail the command; print the byte count only on a
+     * complete write. */
+    if (n < 0) {
+        screen_console_puts("write: WRITE FAILED (");
+        screen_console_puts(resolved);
+        screen_console_puts(") - nothing written\n");
+        return 1;
+    }
+    if (n < len) {
+        char num[20];
+        fmt_u64((u64)n, num);
+        screen_console_puts("write: SHORT WRITE (");
+        screen_console_puts(num);
+        screen_console_puts(" of ");
+        fmt_u64((u64)len, num);
+        screen_console_puts(num);
+        screen_console_puts(" bytes) - file now holds partial content! disk full?\n");
+        return 1;
+    }
     char msg[60]; char num[20];
     strcpy(msg, "wrote ")
```

## BUG-0242 (P2, p2fix3-G1) — commit 98a8dc7
- Location: editor.c:148-163
- Issue: , 167-172   nano/vi 大文件静默截断 + 读错误当 EOF
- BEFORE hunk:
```
         int  cl = 0;
         cur[0] = 0;
         for (;;) {
             int n = fs_vfs_read(fd, rbuf, 4096);
-            if (n <= 0) break;
             for (int i = 0; i < n; i++) {
                 if (rbuf[i] == '\n') {
                     if (ed_nlines < EDITOR_MAX_LINES) {
                         strncpy(ed_lines[ed_nlines++], cur, EDITOR_LINE_CAP - 1);
                         ed_lines[ed_nlines - 1][EDITOR_LINE_CAP - 1] = 0;
                     }
                     cl = 0;
                     cur[0] = 0;
                 } else if (cl + 1 < EDITOR_LINE_CAP) {
                     cur[cl++] = rbuf[i];
                     cur[cl] = 0;
                 }
             }
         }
```
- AFTER hunk:
```
         int  cl = 0;
         cur[0] = 0;
         for (;;) {
+            /* BUG-0242 FIX (A15-16): n < 0 is a READ ERROR, not EOF. The
+             * old `if (n <= 0) break;` opened the editor on a partial
+             * view as if the file simply ended (and ^O then truncated
+             * it). A read error now aborts the open with -4 (the value
+             * editor.h has always documented) and leaves the file
+             * untouched. */
             int n = fs_vfs_read(fd, rbuf, 4096);
+            if (n < 0) {
+                kfree(rbuf);
+                fs_vfs_close(fd);
+                kfree(ed_lines);
+                ed_lines = NULL;
+                ed_nlines = 0;
+                ed_active = 0;
+                ed_partial = 0;
+                ed_dropped_lines = 0;
+                ed_dropped_chars = 0;
+                return -4;
+            }
+            if (n == 0) break;
             for (int i = 0; i < n; i++) {
                 if (rbuf[i] == '\n') {
                     if (ed_nlines < EDITOR_MAX_LINES) {
                         strncpy(ed_lines[ed_nlines++], cur, EDITOR_LINE_CAP - 1);
                         ed_lines[ed_nlines - 1][EDITOR_LINE_CAP 
```

## BUG-0243 (P2, p2fix3-G1) — commit 98a8dc7
- Location: shell_cmds_snd_test.c:479
- Issue: play 潜在除零
- BEFORE hunk:
```
     strcpy(line, "play: ");
     strcat(line, dev->name);
     strcat(line, " 440Hz ");
-    u64_to_str((u64)(bytes / (u32)(dev->channels * 2)), n);
     strcat(line, n);
     strcat(line, " frames @ ");
     u64_to_str(rate, n); strcat(line, n);
```
- AFTER hunk:
```
     strcpy(line, "play: ");
     strcat(line, dev->name);
     strcat(line, " 440Hz ");
+    /* BUG-0243 FIX (A15-17): a card that reports channels == 0 (broken
+     * descriptor / HID quirk) made this line a kernel divide-by-zero:
+     * driver_snd_make_tone() returns 0 bytes for channels < 1, and
+     * 0 / (0 * 2) is still a #DE fault. Compute the frame count only
+     * for a usable channel count and report 0 frames otherwise (the
+     * play below then reports the device error honestly, since a
+     * zero-byte PCM is rejected by driver_snd_play). */
+    if (dev->channels >= 1) {
+        u64_to_str((u64)(bytes / (u32)(dev->channels * 2)), n);
+    } else {
+        u64_to_str(0, n);
+    }
     strcat(line, n);
     strcat(line, " frames @ ");
     u64_to_str(rate, n); strcat(line, n);
```

## BUG-0244 (P2, p2fix3-G1) — commit 98a8dc7
- Location: shell_cmds_disk.c:212-219
- Issue: mkfs.exfat 无最小尺寸检查
- BEFORE hunk:
```
             return 1;
         }
         dev_idx = 0;
-        while (!driver_block_get_device(dev_idx) && dev_idx < 8) dev_idx++;
     }
     driver_block_part_table_t tbl;
     if (driver_block_part_parse(dev_idx, &tbl) != 0) {
```
- AFTER hunk:
```
             return 1;
         }
         dev_idx = 0;
+        /* BUG-0246 FIX (A15-20): the bound check used to come SECOND
+         * (`!get_device(dev_idx) && dev_idx < 8`), so dev_idx == 8 was
+         * still passed to driver_block_get_device() once before the
+         * loop noticed - the driver's own guard happens to catch it,
+         * but the shell must not hand out an out-of-range index in the
+         * first place. Test the bound FIRST, and use the driver's own
+         * BLK_MAX_DEVICES instead of a literal. */
+        while (dev_idx < BLK_MAX_DEVICES &&
+               !driver_block_get_device(dev_idx)) {
+            dev_idx++;
+        }
+        if (dev_idx >= BLK_MAX_DEVICES ||
+            !driver_block_get_device(dev_idx)) {
+            /* Slots exist (num_devices() > 0) but none is present. */
+            screen_console_puts("no block devices\n");
+            return 1;
+        }
     }
     driver_block_part_table_t tbl;
     if (driver_block_part_parse(dev_idx, &tbl) != 0) {
```

## BUG-0245 (P2, p2fix3-G1) — commit 98a8dc7
- Location: shell.c:61-67
- Issue: 注册"替换"路径不保证 NUL
- BEFORE hunk:
```
     for (int i = 0; i < SHELL_MAX_COMMANDS; i++) {
         if (g_commands[i].in_use && strcmp(g_commands[i].name, name) == 0) {
             g_commands[i].handler = handler;
-            if (help) strncpy(g_commands[i].help, help, sizeof(g_commands[i].help) - 1);
-            if (wp) strncpy(g_commands[i].wp, wp, sizeof(g_commands[i].wp) - 1);
             return 0;
         }
     }
```
- AFTER hunk:
```
     for (int i = 0; i < SHELL_MAX_COMMANDS; i++) {
         if (g_commands[i].in_use && strcmp(g_commands[i].name, name) == 0) {
             g_commands[i].handler = handler;
+            /* BUG-0245 FIX (A15-19): strncpy(dst, src, sizeof-1) does NOT
+             * write a terminator when src is the longer string, so the
+             * replace path used to leave help/wp NUL-termination to luck
+             * (BSS zero or leftovers from the previous registration).
+             * Terminate explicitly, exactly like the new-slot branch
+             * below - every other strncpy in this file is paired with an
+             * explicit NUL store. */
+            if (help) {
+                strncpy(g_commands[i].help, help, sizeof(g_commands[i].help) - 1);
+                g_commands[i].help[sizeof(g_commands[i].help) - 1] = 0;
+            }
+            if (wp) {
+                strncpy(g_commands[i].wp, wp, sizeof(g_commands[i].wp) - 1);
+                g_commands[i].wp[sizeof(g_commands[i].wp) - 1] = 0;
+            }
             return 0;
         }
     }
```

## BUG-0246 (P2, p2fix3-G1) — commit 98a8dc7
- Location: shell_cmds_disk.c:53
- Issue: parted 边界检查顺序
- BEFORE hunk:
```
             return 1;
         }
         dev_idx = 0;
-        while (!driver_block_get_device(dev_idx) && dev_idx < 8) dev_idx++;
     }
     driver_block_part_table_t tbl;
     if (driver_block_part_parse(dev_idx, &tbl) != 0) {
```
- AFTER hunk:
```
             return 1;
         }
         dev_idx = 0;
+        /* BUG-0246 FIX (A15-20): the bound check used to come SECOND
+         * (`!get_device(dev_idx) && dev_idx < 8`), so dev_idx == 8 was
+         * still passed to driver_block_get_device() once before the
+         * loop noticed - the driver's own guard happens to catch it,
+         * but the shell must not hand out an out-of-range index in the
+         * first place. Test the bound FIRST, and use the driver's own
+         * BLK_MAX_DEVICES instead of a literal. */
+        while (dev_idx < BLK_MAX_DEVICES &&
+               !driver_block_get_device(dev_idx)) {
+            dev_idx++;
+        }
+        if (dev_idx >= BLK_MAX_DEVICES ||
+            !driver_block_get_device(dev_idx)) {
+            /* Slots exist (num_devices() > 0) but none is present. */
+            screen_console_puts("no block devices\n");
+            return 1;
+        }
     }
     driver_block_part_table_t tbl;
     if (driver_block_part_parse(dev_idx, &tbl) != 0) {
```

## BUG-0247 (P2, p2fix3-G1) — commit 98a8dc7
- Location: shell.c:1333-1350
- Issue: capture 缓冲泄漏
- BEFORE hunk:
```
     for (int i = 0; i < SHELL_MAX_COMMANDS; i++) {
         if (g_commands[i].in_use && strcmp(g_commands[i].name, name) == 0) {
             g_commands[i].handler = handler;
-            if (help) strncpy(g_commands[i].help, help, sizeof(g_commands[i].help) - 1);
-            if (wp) strncpy(g_commands[i].wp, wp, sizeof(g_commands[i].wp) - 1);
             return 0;
         }
     }
```
- AFTER hunk:
```
     for (int i = 0; i < SHELL_MAX_COMMANDS; i++) {
         if (g_commands[i].in_use && strcmp(g_commands[i].name, name) == 0) {
             g_commands[i].handler = handler;
+            /* BUG-0245 FIX (A15-19): strncpy(dst, src, sizeof-1) does NOT
+             * write a terminator when src is the longer string, so the
+             * replace path used to leave help/wp NUL-termination to luck
+             * (BSS zero or leftovers from the previous registration).
+             * Terminate explicitly, exactly like the new-slot branch
+             * below - every other strncpy in this file is paired with an
+             * explicit NUL store. */
+            if (help) {
+                strncpy(g_commands[i].help, help, sizeof(g_commands[i].help) - 1);
+                g_commands[i].help[sizeof(g_commands[i].help) - 1] = 0;
+            }
+            if (wp) {
+                strncpy(g_commands[i].wp, wp, sizeof(g_commands[i].wp) - 1);
+                g_commands[i].wp[sizeof(g_commands[i].wp) - 1] = 0;
+            }
             return 0;
         }
     }
```

## BUG-0248 (P2, p2fix3-G2) — commit 25304ec
- Location: l1/l1_wp8b.c:431-435
- Issue: 自测断言过期：BUG-007 修复后 so_unload(0) 返回 -1，"always succeeds"测试必失败；且整个 ext_wp8b_selftest 无调用方
- BEFORE hunk:
```
     /* Check e_type. */
     u16 e_type = elf_data[16] | (elf_data[17] << 8);
     if (e_type != ET_DYN) return 0; /* not dynamic */
-    /* Read phoff + phnum. */
     u64 e_phoff = 0;
     for (int b = 0; b < 8; b++) e_phoff |= ((u64)elf_data[32 + b]) << (b * 8);
     u16 e_phnum = elf_data[56] | (elf_data[57] << 8);
     /* Find PT_DYNAMIC. */
     u64 dyn_offset = 0, dyn_filesz = 0;
     for (int i = 0; i < e_phnum; i++) {
-        const u8 *ph = elf_data + e_phoff + (u64)i * 56;
         u32 p_type = ph[0] | (ph[1] << 8) | (ph[2] << 16) | (ph[3] << 24);
         if (p_type == PT_DYNAMIC) {
             for (int b = 0; b < 8; b++) dyn_offset |= ((u64)ph[8 + b]) << (b * 8);
             for (int b = 0; b < 8; b++) dyn_filesz |= ((u64)ph[32 + b]) << (b * 8);
             break;
         }
     }
-    if (dyn_filesz == 0) return 0;
-    /* Find DT_STRTAB. */
-    u64 strtab_val = 0;
-    u64 num_dyn = dyn_filesz / 16;
     for (u64 j = 0; j < num_dyn; j++) {
-        const u8 *de = elf_data + dyn_offset + j * 16;
         u64 tag = 0, val = 0;
         for (int b = 0; b < 8; b++) tag |= ((u64)de[b]) << (b * 8);
         for (int b = 0; b < 8; b++) val |= ((u64)de[8 + b]) << (b * 
```
- AFTER hunk:
```
     /* Check e_type. */
     u16 e_type = elf_data[16] | (elf_data[17] << 8);
     if (e_type != ET_DYN) return 0; /* not dynamic */
+    /* Read phoff + phentsize + phnum, all bounds-checked. */
     u64 e_phoff = 0;
     for (int b = 0; b < 8; b++) e_phoff |= ((u64)elf_data[32 + b]) << (b * 8);
+    u16 e_phentsize = elf_data[54] | (elf_data[55] << 8);
     u16 e_phnum = elf_data[56] | (elf_data[57] << 8);
+    if (e_phnum == 0 || e_phnum > 64) return 0;
+    if (e_phentsize != sizeof(elf64_phdr_t)) return 0;
+    if (e_phoff > elf_size ||
+        e_phoff + (u64)e_phnum * sizeof(elf64_phdr_t) > elf_size) return 0;
     /* Find PT_DYNAMIC. */
     u64 dyn_offset = 0, dyn_filesz = 0;
+    int have_dyn = 0;
     for (int i = 0; i < e_phnum; i++) {
+        const u8 *ph = elf_data + e_phoff + (u64)i * sizeof(elf64_phdr_t);
         u32 p_type = ph[0] | (ph[1] << 8) | (ph[2] << 16) | (ph[3] << 24);
         if (p_type == PT_DYNAMIC) {
             for (int b = 0; b < 8; b++) dyn_offset |= ((u64)ph[8 + b]) << (b * 8);
             for (int b = 0; b < 8; b++) dyn_filesz |= ((u64)ph[32 + b]) << (b * 8);
+            have_dyn = 1;
             break;
         }
     }
+    if (!have_dyn
```

## BUG-0249 (P2, p2fix3-G2) — commit 25304ec
- Location: l1/l1_wp8cd.c:113-186
- Issue: job_create 取"最高 pid 活进程"的竞态启发式；fg 不等待
- BEFORE hunk:
```
     return g_tool_count;
 }
 
-/* Interface 55: job_create — P1-6 FIX
- * Creates a job entry for tracking. The actual process creation is done
- * by the caller (e.g., kernel shell's 'run cmd &' background mode).
- * This function registers the job in the tracking table so that job_list
- * and job_control can find it. */
 int job_create(const char *cmd) {
     if (!cmd || !cmd[0]) return -1;
-    if (g_job_count >= MAX_JOBS) return -2;
-
-    /* Find the most recently created user process (highest pid) */
-    extern user_proc_t g_procs[];
-    extern int g_next_pid;
-    (void)g_next_pid;  /* not used directly, but kept for API compat */
-    int found = -1;
-    int max_pid = -1;
     for (int i = 0; i < MAX_USER_PROCS; i++) {
-        if (g_procs[i].alive && g_procs[i].pid > max_pid) {
-            max_pid = g_procs[i].pid;
-            found = i;
         }
     }
-    if (found < 0) return -3;
 
-    /* Register the job */
-    g_jobs[g_job_count].pid = g_procs[found].pid;
-    g_jobs[g_job_count].tid = g_procs[found].tid;
-    strncpy(g_jobs[g_job_count].name, cmd, 31);
-    g_jobs[g_job_count].active = 1;
-    g_job_count++;
-    return g_job_count - 1;
 }
 
-/* Interface
```
- AFTER hunk:
```
     return g_tool_count;
 }
 
+/* Interface 55: job_create — BUG-0249 FIX (A16-11)
+ * Real accounting: this function now CREATES the background process
+ * for `cmd` (resolved through the shared embedded-program lookup, the
+ * same table sys_execve uses) and binds the job entry to the pid/task
+ * that the spawn actually returned. The old "scan for the highest
+ * alive pid" heuristic is gone: between a caller's spawn and this
+ * call, any other process (timer helper, second shell, another run)
+ * could steal the binding, and a recycled pid could alias an
+ * unrelated task - the old code even documented the race away as
+ * "finds the most recently created process".
+ * Returns the job id (index for job_list/job_control),
+ *   -1 bad/unknown name or spawn failure,
+ *   -2 job table full. */
 int job_create(const char *cmd) {
     if (!cmd || !cmd[0]) return -1;
+    /* Resolve the program name exactly like sys_execve does. */
+    extern const u8 *core_userprog_lookup(const char *name, u64 *size_out);
+    u64 elf_size = 0;
+    const u8 *elf = core_userprog_lookup(cmd, &elf_size);
+    if (!elf || elf_size == 0) return -1;
+    pid_t pid = user_process_create(elf, elf_size
```

## BUG-0250 (P2, p2fix3-G3) — commit a8c48ab
- Location: userprogs/ush.c:1068
- Issue: 、1230、1693   tail/sort/sed 实际只读前 12KB（16KB 缓冲只用到 12288）
- BEFORE hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
-        sys_exit2(argc > 1 ? 0 : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```
- AFTER hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
+        /* A16-15 FIX: both arms of the ternary were 0, so the documented
+         * `exit [code]` argument was silently dropped (status always 0).
+         * Parse the argument (atoi_: non-numeric -> 0) and pass it on so
+         * a parent's wait4 can observe the real status; no arg stays 0. */
+        sys_exit2(argc > 1 ? atoi_(argv[1]) : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```

## BUG-0251 (P2, p2fix3-G3) — commit a8c48ab
- Location: userprogs/ush.c:1812-1816
- Issue: awk 模式过滤：带右斜杠的 `/pat/` 反而把过滤整个禁用
- BEFORE hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
-        sys_exit2(argc > 1 ? 0 : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```
- AFTER hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
+        /* A16-15 FIX: both arms of the ternary were 0, so the documented
+         * `exit [code]` argument was silently dropped (status always 0).
+         * Parse the argument (atoi_: non-numeric -> 0) and pass it on so
+         * a parent's wait4 can observe the real status; no arg stays 0. */
+        sys_exit2(argc > 1 ? atoi_(argv[1]) : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```

## BUG-0252 (P2, p2fix3-G3) — commit a8c48ab
- Location: userprogs/ush.c:2014-2072
- Issue: 别名不在重定向路径展开
- BEFORE hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
-        sys_exit2(argc > 1 ? 0 : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```
- AFTER hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
+        /* A16-15 FIX: both arms of the ternary were 0, so the documented
+         * `exit [code]` argument was silently dropped (status always 0).
+         * Parse the argument (atoi_: non-numeric -> 0) and pass it on so
+         * a parent's wait4 can observe the real status; no arg stays 0. */
+        sys_exit2(argc > 1 ? atoi_(argv[1]) : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```

## BUG-0253 (P2, p2fix3-G3) — commit a8c48ab
- Location: userprogs/ush.c:679-682
- Issue: `exit [code]` 的退出码被丢弃
- BEFORE hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
-        sys_exit2(argc > 1 ? 0 : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```
- AFTER hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
+        /* A16-15 FIX: both arms of the ternary were 0, so the documented
+         * `exit [code]` argument was silently dropped (status always 0).
+         * Parse the argument (atoi_: non-numeric -> 0) and pass it on so
+         * a parent's wait4 can observe the real status; no arg stays 0. */
+        sys_exit2(argc > 1 ? atoi_(argv[1]) : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```

## BUG-0254 (P2, p2fix3-G2) — commit 25304ec
- Location: l1/l1_wp8a.c:9-29
- Issue: WP-08a 全部 21 个 int 0x80 包装编进内核二进制却不可从内核态调用（死层）
- BEFORE hunk:
```
 #include "screen_font.h"
 #include "screen_console.h"
 #include "l1_ext.h"
 #include "lib_log.h"
 #include "lib_string.h"
 #include "crypto_dh_scale_vectors.h"  /* WP-09 debug: modexp scale-sweep truth vectors */
```
- AFTER hunk:
```
 #include "screen_font.h"
 #include "screen_console.h"
 #include "l1_ext.h"
+#include "l1_wp8a.h"   /* BUG-0254 FIX: the 21 int 0x80 wrappers get kernel-side callers (l1test step 8) */
 #include "lib_log.h"
 #include "lib_string.h"
 #include "crypto_dh_scale_vectors.h"  /* WP-09 debug: modexp scale-sweep truth vectors */
```

## BUG-0255 (P2, p2fix3-G3) — commit a8c48ab
- Location: userprogs/ush.c:916
- Issue: `wc` 以 WRONLY CREAT 打开只读用途的文件
- BEFORE hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
-        sys_exit2(argc > 1 ? 0 : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```
- AFTER hunk:
```
         return 1;
     }
     if (streq(argv[0], "exit")) {
+        /* A16-15 FIX: both arms of the ternary were 0, so the documented
+         * `exit [code]` argument was silently dropped (status always 0).
+         * Parse the argument (atoi_: non-numeric -> 0) and pass it on so
+         * a parent's wait4 can observe the real status; no arg stays 0. */
+        sys_exit2(argc > 1 ? atoi_(argv[1]) : 0);
         return 1;
     }
     /* P1-4 FIX: add help builtin */
```

## BUG-0256 (P2, p2fix3-G2) — commit 25304ec
- Location: l1/l1_wp8b.c:159-184
- Issue: so_load 的 BSS 清零跳过"已映射"的边界页（该页尾部为脏物理内存）
- BEFORE hunk:
```
         if (map_user_pages(proc->as, load_vaddr,
                            data + phdr[i].offset, phdr[i].filesz) != 0)
             return 0;
-        /* bss zero pages. */
         if (phdr[i].memsz > phdr[i].filesz) {
-            u64 bs = load_vaddr + phdr[i].filesz;
-            u64 be = bs + (phdr[i].memsz - phdr[i].filesz);
-            u64 page = bs & ~0xFFFULL;
-            while (page < be) {
-                u64 phys;
-                if (!mem_vmm_is_mapped(proc->as, page, &phys)) {
-                    phys = mem_pmm_alloc_frame();
-                    if (phys) {
-                        mem_vmm_map_page(proc->as, page, phys,
-                            VMM_FLAG_PRESENT | VMM_FLAG_WRITE | VMM_FLAG_USER);
-                        memset((void*)phys, 0, PMM_PAGE_SIZE);
-                    }
-                }
-                page += PMM_PAGE_SIZE;
-            }
         }
     }
     /* Advance bump allocator. */
```
- AFTER hunk:
```
         if (map_user_pages(proc->as, load_vaddr,
                            data + phdr[i].offset, phdr[i].filesz) != 0)
             return 0;
+        /* bss zero pages (BUG-0256 FIX: also zeroes the mapped boundary
+         * page's tail and any fully mapped bss page). */
         if (phdr[i].memsz > phdr[i].filesz) {
+            so_bss_zero(proc->as,
+                        load_vaddr + phdr[i].filesz,
+                        load_vaddr + phdr[i].memsz);
         }
     }
     /* Advance bump allocator. */
```

## BUG-0257 (P2, p2fix3-G2) — commit 25304ec
- Location: l1/l1_wp8b.c:257
- Issue: 、312、333   symbol_resolve / reloc_apply 符号表扫描无边界
- BEFORE hunk:
```
         if (phdr[i].type == PT_DYNAMIC) { dyn_ph = &phdr[i]; break; }
     }
     if (!dyn_ph) return 0;
-    elf64_dyn_t *dyn = (elf64_dyn_t*)(handle + dyn_ph->vaddr);
-    /* Find DT_SYMTAB and DT_STRTAB. */
-    u64 symtab = 0, strtab = 0;
-    for (int i = 0; ; i++) {
         if (dyn[i].tag == DT_NULL) break;
-        if (dyn[i].tag == DT_SYMTAB) symtab = handle + dyn[i].val;
-        else if (dyn[i].tag == DT_STRTAB) strtab = handle + dyn[i].val;
     }
-    if (!symtab || !strtab) return 0;
     /* Iterate .dynsym, find symbol by name.
-     * BUG-044 FIX: Iterate up to 4096 entries (was hardcoded 64).
      * Don't break on null entry at index 0 — it's the standard ELF
      * undefined entry, not a terminator. Just skip st_name==0 entries. */
-    elf64_sym_t *sym = (elf64_sym_t*)symtab;
-    for (int i = 0; i < 4096; i++) {
         if (sym[i].st_name == 0) continue;
-        const char *s = (const char*)(strtab + sym[i].st_name);
-        /* Compare name byte by byte. */
-        int k = 0;
-        while (s[k] && s[k] == name[k]) k++;
-        if (s[k] == '\0' && name[k] == '\0') {
-            /* Found! Return base + st_value. */
-            if (sym[i].st_shndx == 0)
```
- AFTER hunk:
```
         if (phdr[i].type == PT_DYNAMIC) { dyn_ph = &phdr[i]; break; }
     }
     if (!dyn_ph) return 0;
+    /* .dynamic content must lie inside the image. */
+    u64 dyn_rt = handle + dyn_ph->vaddr;
+    if (dyn_ph->filesz > img_end - dyn_rt) return 0;
+    elf64_dyn_t *dyn = (elf64_dyn_t*)dyn_rt;
+    /* Find DT_SYMTAB / DT_STRTAB / DT_STRSZ / DT_HASH. */
+    u64 symtab_val = 0, strtab_val = 0, strsz_val = 0, hash_val = 0;
+    u64 ndyn = dyn_ph->filesz / sizeof(elf64_dyn_t);
+    for (u64 i = 0; i < ndyn; i++) {
         if (dyn[i].tag == DT_NULL) break;
+        if (dyn[i].tag == DT_SYMTAB) symtab_val = dyn[i].val;
+        else if (dyn[i].tag == DT_STRTAB) strtab_val = dyn[i].val;
+        else if (dyn[i].tag == 10 /* DT_STRSZ */) strsz_val = dyn[i].val;
+        else if (dyn[i].tag == 4 /* DT_HASH */) hash_val = dyn[i].val;
+    }
+    if (!symtab_val || !strtab_val) return 0;
+    u64 symtab_rt = handle + symtab_val;
+    u64 strtab_rt = handle + strtab_val;
+    u64 hash_rt   = hash_val ? handle + hash_val : 0;
+    /* BUG-0257 FIX: every table must sit inside the loaded image. */
+    if (symtab_rt < handle + sizeof(elf64_hdr_t) || symtab_rt >= img_end) return 0;
+    
```

## BUG-0258 (P2, p2fix3-G2) — commit 25304ec
- Location: l1/l1_wp8b.c:357-408
- Issue: elf_get_needed 无缓冲尺寸参数，越界读 + vaddr 当文件偏移
- BEFORE hunk:
```
 }
 
 /* ---- Interface 50: elf_get_needed ---- */
-int elf_get_needed(const u8 *elf_data, const char *needed_out[], int max_count) {
     if (!elf_data || max_count <= 0) return 0;
     /* Validate ELF magic. */
     if (elf_data[0] != 0x7f || elf_data[1] != 'E' ||
         elf_data[2] != 'L'  || elf_data[3] != 'F') return 0;
```
- AFTER hunk:
```
 }
 
 /* ---- Interface 50: elf_get_needed ---- */
+/* BUG-0258 FIX (A16-9): the signature now carries the buffer size.
+ * The old prototype had no way for a caller to pass the boundary, so
+ * e_phoff/e_phnum/dyn_offset were read unchecked and a truncated ELF
+ * walked straight off the end of the buffer. DT_STRTAB's value is a
+ * LINK-TIME vaddr: it is now converted to a real file offset through
+ * the PT_LOAD that covers it (the old code used it as a file offset,
+ * which only works when vaddr happens to equal offset). Any boundary
+ * violation makes the function return 0 - malformed input is rejected,
+ * never partially parsed. */
+int elf_get_needed(const u8 *elf_data, u64 elf_size,
+                   const char *needed_out[], int max_count) {
     if (!elf_data || max_count <= 0) return 0;
+    if (elf_size < sizeof(elf64_hdr_t)) return 0;
     /* Validate ELF magic. */
     if (elf_data[0] != 0x7f || elf_data[1] != 'E' ||
         elf_data[2] != 'L'  || elf_data[3] != 'F') return 0;
```

## BUG-0259 (P2, p2fix3-G4) — commit 48b5655
- Location: docs/
- Issue: ** README 统计区：129 接口（实际 138）、14 WP（实际 15，WP-10-wp08fix1 无章节）、75,806 行（其自带验证命令现在返回 46,595）。
- BEFORE hunk:
```
   (real FAT drivers add a numeric suffix, that machinery is not ported).
 
 ### 5.2 Public-internet TLS endpoints reject the kernel TLS client —
-     KNOWN LIMITATION (WP-09 scope, unchanged by fix5)
-- The kernel TLS client offers TLS 1.2 with `DHE-RSA-AES128-SHA256`
-  (1024-bit DH) only. Public servers (modern stacks) require ECDHE/AEAD
-  or TLS 1.3 and answer the ClientHello with an alert. `checkupdate`
-  therefore works against any server configured for the kernel cipher
-  (e.g. tools/update_server.py, TLS 1.2 DHE-RSA-AES128-SHA256) but not
-  against arbitrary public HTTPS URLs. DNS + TCP to the default URL
-  succeed; the alert is answered cleanly (no crash, explicit
-  `connect failed` message). Extending the TLS cipher suite is WP-10+
-  work.
 
 ## 6. WP-09 mainstreaming additions (2026-10)
 
```
- AFTER hunk:
```
   (real FAT drivers add a numeric suffix, that machinery is not ported).
 
 ### 5.2 Public-internet TLS endpoints reject the kernel TLS client —
+     RESOLVED (superseded by the mainstreamed TLS client; re-verified
+     2026-10-09, WP-10-AUDIT_P2-fix3)
+- **Current behavior**: the kernel TLS client offers TLS 1.3 (RFC 8446:
+  X25519 key share, AES-128/256-GCM + ChaCha20-Poly1305, full HKDF key
+  schedule) preferred, with a TLS 1.2 ECDHE_RSA fallback (AES-GCM /
+  ChaCha20-Poly1305; legacy DHE-CBC 0x0067 retained for old servers) and
+  X.509 chain + SAN dNSName hostname verification against embedded public
+  CA roots (handshake fails closed on verification errors). Public
+  HTTPS endpoints are verified working end-to-end:
+  cubestudio-dev.github.io, google.com, cloudflare.com (README WP-09
+  section).
+- **History (WP-09-fix5 scope, 2026-10-02)**: the fix5-era client offered
+  TLS 1.2 with `DHE-RSA-AES128-SHA256` (1024-bit DH) only, so modern
+  public stacks answered the ClientHello with an alert and `checkupdate`
+  worked only against servers configured for that cipher
+  (tools/update_server.py). DNS + TCP to the default URL succeeded and
+  the alert was answered cle
```

## BUG-0260 (P2, p2fix3-G4) — commit 48b5655
- Location: docs/
- Issue: ** README/INTERFACES.md "37 syscalls" vs core_syscall.h 实际 46 个 SYS_。
- BEFORE hunk:
```
   driver_usb_isochronous_transfer / driver_usb_register_driver (class-driver registry:
   HID keyboard + mouse, MSC storage, CDC-ACM/FTDI serial, UAC audio),
   driver_usb_uhci_init / driver_usb_ohci_init / driver_usb_ehci_init / driver_usb_xhci_init(driver_pci_dev) — four host
-  controller backends (drivers/usb/driver_usb.h)
-- **System calls**: 44
 - **Audit bugs fixed**: 47 from the original WP-08 audit (P0=2, P1=8, P2=29, P3=8)
   + 4 additional P0 + 8 P1 + 20 P2 from subsequent independent audits and
   the P2-batch fix-ups (P2-BATCH-1 + P2-BATCH-2), bringing the running
```
- AFTER hunk:
```
   driver_usb_isochronous_transfer / driver_usb_register_driver (class-driver registry:
   HID keyboard + mouse, MSC storage, CDC-ACM/FTDI serial, UAC audio),
   driver_usb_uhci_init / driver_usb_ohci_init / driver_usb_ehci_init / driver_usb_xhci_init(driver_pci_dev) — four host
+  controller backends (drivers/usb/driver_usb.h),
+  + 7 WP-10d-fix2 items: core_power_shutdown / core_power_suspend /
+  core_power_halt / core_power_reboot + shell_register_command_ex /
+  shell_list_commands_a_z / shell_list_commands_by_wp,
+  + 9 WP-10-wp08fix1 items: shell_lineedit_init / shell_lineedit_history_add /
+  shell_lineedit_history_get / shell_lineedit_cursor_move /
+  shell_lineedit_tab_complete / shell_lineedit_ctrlc (shell/shell_lineedit.h)
+  + editor_open / editor_save / editor_close (shell/editor.h)
+  (57 + 8 + 13 + 7 + 26 + 11 + 7 + 9 = 138; plus 5 unnumbered WP-09-fix5
+  config/check-update interfaces and 5 rule-9 self-hosting interfaces
+  outside the 1-138 numbering)
+- **System calls**: 46 (verify: `grep -c '#define SYS_' kernel/core/core_syscall.h`)
 - **Audit bugs fixed**: 47 from the original WP-08 audit (P0=2, P1=8, P2=29, P3=8)
   + 4 additional P0 + 8 P1 + 20 P2 from subs
```

## BUG-0261 (P2, p2fix3-G4) — commit 48b5655
- Location: docs/
- Issue: ** 版本口径分裂：README 标题 WP-10c / 统计 WP-10d / Makefile 默认 WP-10-project_restructure-fix1 / HEAD 为 WP-10-wp08fix1；TRY-IT 承诺 `uname -a`→WP-10c 与默认构建不符。
- BEFORE hunk:
```
 <!-- SPDX-License-Identifier: Apache-2.0 -->
 <!-- Copyright 2026 cubestudio-dev <cubestudio@qq.com> -->
 
-# Open Cube OS - WP-AUDIT-01-p1fix3
 
 **官网**: https://cubestudio-dev.github.io/OpenCubeOS
 **GitHub**: https://github.com/cubestudio-dev/OpenCubeOS
```
- AFTER hunk:
```
 <!-- SPDX-License-Identifier: Apache-2.0 -->
 <!-- Copyright 2026 cubestudio-dev <cubestudio@qq.com> -->
 
+# Open Cube OS
+
+**Version string**: generated at build time from the checked-out tree by
+`git describe --tags` (Makefile `OC_RELEASE_VERSION`); the boot banner,
+`uname -a` and `update --status` all report it verbatim. There is no
+hardcoded release name in this file on purpose. Current source batch:
+WP-10-AUDIT_P2-fix3 (in progress; latest tagged release:
+WP-10-AUDIT_P2-fix2b).
 
 **官网**: https://cubestudio-dev.github.io/OpenCubeOS
 **GitHub**: https://github.com/cubestudio-dev/OpenCubeOS
```

## BUG-0262 (P2, p2fix3-G4) — commit 48b5655
- Location: docs/
- Issue: ** KNOWN_ISSUES §2A.2/§2A.4/§5.2 声称"不验证证书/主机密钥/公网 TLS 被拒"，代码已实现 TLS1.3+X.509 链验证+Finished 验证+SSH 主机密钥签名验证。
- BEFORE hunk:
```
 
 ### Known / accepted behaviors
 
-See docs/KNOWN_ISSUES.md §2A (7 items: close_notify, server Finished,
-stale comment, no cert/host-key verification, paramiko probe, QEMU modexp
-speed, crashlog tick display).
 
 ## WP-03: Physical memory + Virtual memory + Kernel heap
 
```
- AFTER hunk:
```
 
 ### Known / accepted behaviors
 
+See docs/KNOWN_ISSUES.md §2A. Current state (2026-10-09): close_notify is
+sent in ESTABLISHED or CLOSE_WAIT (superseded by WP-10-AUDIT_P2-fix2,
+KNOWN_ISSUES §7); the server Finished IS cryptographically verified; the
+X.509 chain + SAN hostname verification is live and fails closed; SSH
+verifies the host-key signature over H with a TOFU anchor and implements
+publickey auth - see §2A.2/§2A.4 for the exact trust model and what
+remains deferred (keepalive, algorithm negotiation whitelist).
 
 ## WP-03: Physical memory + Virtual memory + Kernel heap
 
```

## BUG-0263 (P2, p2fix3-G4) — commit 48b5655
- Location: docs/
- Issue: ** EXTENSIONS_WP10d.md 尾表 OHCI=open 与同文 §9 及 README "ALL PASS" 直接矛盾。
- BEFORE hunk:
```
 | XHCI    | PASS     | PASS       | PASS        | PASS| n/a | qemu-xhci's storage model is
           |          |            |             |     |     | SuperSpeed; BOT on SS is an
           |          |            |             |     |     | open gap (see report) |
-| OHCI    | PASS     | PASS       | open        | open| open| TDs verified executed;
-          |          |            |             |     |     | device-level STALL under
-          |          |            |             |     |     | investigation |
```
- AFTER hunk:
```
 | XHCI    | PASS     | PASS       | PASS        | PASS| n/a | qemu-xhci's storage model is
           |          |            |             |     |     | SuperSpeed; BOT on SS is an
           |          |            |             |     |     | open gap (see report) |
+| OHCI    | PASS     | PASS       | PASS        | PASS| PASS| device-level STALL/underrun fixed in the
+          |          |            |             |     |     | bring-up and live-verified (see section 9);
+          |          |            |             |     |     | re-fixed + regression-green in
+          |          |            |             |     |     | WP-10-AUDIT_P2-fix1 (BUG-0159..0165) |
+
+(Row update 2026-10-09, WP-10-AUDIT_P2-fix3: the delivery-time "open"
+cells above predate the section-9 live-verification session; the row now
+states the final verified state. Re-confirmed live on the current tree:
+QEMU `-device pci-ohci` + usb-kbd/usb-mouse/usb-storage -
+usb_core_test 5/5 PASS, usb_kbd_test PASS, usb_mouse_test PASS,
+usb_storage_test PASS (capacity/MBR/write-read-back/restore).)
```

## BUG-0264 (P2, p2fix3-G4) — commit 48b5655
- Location: docs/
- Issue: ** INTERFACES.md（"as of WP-10d-fix2"）缺接口 130-138 等，§4 文件名为重构前名字、计数 4 处不符。
- BEFORE hunk:
```
 - L0 is licensed Apache 2.0.
 - Design principle: "everything is extensible".
 
-## Stats (WP-10-AUDIT_P2-fix2b)
 
-- **Source code**: 101,150 lines (kernel + boot + userprogs + fs + net + shell + l1 + drivers + libs, incl. headers, no docs;
   verify: `find kernel boot userprogs fs net shell l1 drivers libs \( -name '*.c' -o -name '*.h' -o -name '*.S' \) | xargs wc -l`)
-- **Work packages**: 16 (WP-01 ~ WP-09, WP-10a, WP-10b, WP-10u, WP-10c, WP-10d, project restructure, WP-10-wp08fix1, WP-AUDIT-01 + p0fix1)
   + the rule-9 self-hosting batch (WP-10c-selfhost): in-system `abdisk`,
   `install` and `grub-install` - create A/B update disks, install the OS
   to a disk and write the GRUB BIOS boot loader entirely from the oc>
   shell (no host tools; the kernel payload travels with the boot media as
   a multiboot2 module).
-- **L1 extension interfaces**: 129 (57 through WP-09 + 8 WP-10a items:
   driver_block_register / driver_block_read / driver_block_write / driver_block_flush (+ driver_block_set_ops),
   driver_block_ahci_init(driver_pci_dev), driver_block_nvme_init(driver_pci_dev), driver_block_ata_dma_init(driver_pci_dev),
   + 13 WP-10b items:
```
- AFTER hunk:
```
 - L0 is licensed Apache 2.0.
 - Design principle: "everything is extensible".
 
+## Stats (WP-10-AUDIT_P2-fix3)
 
+- **Source code**: 101,332 lines (kernel + boot + userprogs + fs + net + shell + l1 + drivers + libs, incl. headers, no docs;
   verify: `find kernel boot userprogs fs net shell l1 drivers libs \( -name '*.c' -o -name '*.h' -o -name '*.S' \) | xargs wc -l`)
+- **Work packages**: 15 (WP-01 ~ WP-09, WP-10a, WP-10b, WP-10u, WP-10c,
+  WP-10d, WP-10-wp08fix1) — one `## WP-*` section each below
+  + auxiliary batches (not counted as WPs): project restructure,
+  WP-10d-fix2, WP-09-fix5, and the audit batches WP-AUDIT-01
+  (+p0fix/p1fix) and WP-10-AUDIT_P2-fix1 / fix2 / fix2b / fix3.
   + the rule-9 self-hosting batch (WP-10c-selfhost): in-system `abdisk`,
   `install` and `grub-install` - create A/B update disks, install the OS
   to a disk and write the GRUB BIOS boot loader entirely from the oc>
   shell (no host tools; the kernel payload travels with the boot media as
   a multiboot2 module).
+- **L1 extension interfaces**: 138 (57 through WP-09 + 8 WP-10a items:
   driver_block_register / driver_block_read / driver_block_write / driver_block_flush (+ driver_block_set_
```

## BUG-0265 (P2, p2fix3-G4) — commit 48b5655
- Location: docs/
- Issue: ** STATUS.md 停在 WP-09+fix5，15 个 WP 只覆盖 2 个，违反 WORKFLOW §5 第 10 项自己的流程要求。
- BEFORE hunk:
```
 <!-- SPDX-License-Identifier: Apache-2.0 -->
 <!-- Copyright 2026 cubestudio-dev <cubestudio@qq.com> -->
 
-# Open Cube OS - WP-AUDIT-01-p1fix3
 
 **官网**: https://cubestudio-dev.github.io/OpenCubeOS
 **GitHub**: https://github.com/cubestudio-dev/OpenCubeOS
```
- AFTER hunk:
```
 <!-- SPDX-License-Identifier: Apache-2.0 -->
 <!-- Copyright 2026 cubestudio-dev <cubestudio@qq.com> -->
 
+# Open Cube OS
+
+**Version string**: generated at build time from the checked-out tree by
+`git describe --tags` (Makefile `OC_RELEASE_VERSION`); the boot banner,
+`uname -a` and `update --status` all report it verbatim. There is no
+hardcoded release name in this file on purpose. Current source batch:
+WP-10-AUDIT_P2-fix3 (in progress; latest tagged release:
+WP-10-AUDIT_P2-fix2b).
 
 **官网**: https://cubestudio-dev.github.io/OpenCubeOS
 **GitHub**: https://github.com/cubestudio-dev/OpenCubeOS
```

## BUG-0266 (P2, p2fix3-G5) — commit 1353e71
- Location: .gitignore 体系
- Issue: worklog.md 声明不跟踪却实际跟踪；否定规则把 159MB 二进制提交进公开仓
- BEFORE hunk:
```
 # committing operational credentials/paths is bad practice.
 # The worklog stays at /home/z/my-project/worklog.md for local agent
 # coordination, but is no longer tracked in git.
 worklog.md
 tool-results/
```
- AFTER hunk:
```
 # committing operational credentials/paths is bad practice.
 # The worklog stays at /home/z/my-project/worklog.md for local agent
 # coordination, but is no longer tracked in git.
+# BUG-0266 (fix3 G5): the declaration above had been FALSE since the P4
+# fix - the file stayed tracked. Tracking status is now made consistent
+# with the declaration (git rm --cached; the file remains on disk
+# untracked). The older history still contains worklog.md and the big
+# binaries; per the fix3 policy git history is NOT rewritten - recorded
+# as a known historical fact in the fix3 evidence instead.
 worklog.md
 tool-results/
```

## BUG-0267 (P2, p2fix3-G5) — commit 1353e71
- Location: releases/isos/ 归档资产
- Issue: 同名文件多重哈希，归档与任何 manifest 都对不上
- BEFORE hunk:
```
 This is the **private archive** of Open Cube OS. It contains EVERYTHING —
 not just the public source code, but also:
 - Build artifacts (.o, .elf, .iso)
-- Internal docs (worklog, HANDOFF, WORKFLOW)
 - Old audit reports
-- Website source (Next.js page.tsx, layout.tsx, globals.css)
-- All ISOs + SRC zips (in releases/)
 - Release notes (in releases/notes/)
 - Toolchain setup (tools/env.sh)
 
-## Repository Structure
 
 ```
 archive-repo/
-├── oc-os/                    # Public repo content + build/ + archive/ + releases/
-│   ├── kernel/               # 94 source files (.c/.h/.S)
-│   ├── userprogs/            # 21 files (.c/.asm/.ld + .elf/.o binaries)
-│   ├── boot/                  # 3 assembly stubs (.S)
-│   ├── tools/                # 5 public tools (.sh/.py)
-│   ├── docs/                 # 15 documentation files (.md/.txt)
-│   ├── archive/              # Old source trees (WP06, old-src-tree, old-tests, old-ldso)
-│   ├── releases/             # Local release snapshots (WP08b Batch 6)
-│   ├── build/                # Build artifacts (.o/.d + opencube.elf + opencube.iso)
-│   ├── README.md
-│   ├── LICENSE
-│   ├── NOTICE
-│   ├── Makefile
-│   └── ... (all root files)
-├──
```
- AFTER hunk:
```
 This is the **private archive** of Open Cube OS. It contains EVERYTHING —
 not just the public source code, but also:
 - Build artifacts (.o, .elf, .iso)
+- Internal docs (audit docs, handover, workflow notes)
 - Old audit reports
+- The website source, twice: the canonical copy under oc-os/website/ and a
+  source-only mirror under website/ (see SYNC-RULES.md for which is which)
+- All ISOs + SRC zips (in releases/, hash-pinned by releases/SHA256SUMS.txt)
 - Release notes (in releases/notes/)
 - Toolchain setup (tools/env.sh)
 
+This file was rewritten at WP-10-AUDIT_P2-fix3 (fix3 G5, BUG-0273); the
+previous edition described the WP-08-era layout (pre-restructure) and no
+longer matched the tree.
+
+## Repository Structure (current)
 
 ```
 archive-repo/
+├── oc-os/                    # The OS tree (this content = the public repo)
+│   ├── boot/                 # Assembly boot stubs (.S)
+│   ├── kernel/               # C kernel: core/, mem/, drivers/…
+│   ├── fs/  net/  shell/     # Subsystems (post-restructure layout)
+│   ├── l1/                   # L1 extension headers
+│   ├── drivers/              # block/ nic/ snd/ usb/ display/ pci/ …
+│   ├── libs/                 # Sh
```

## BUG-0268 (P2, p2fix3-G5) — commit 1353e71
- Location: 双 website 副本
- Issue: 三方不同步 + 根副本含不可构建的遗留文件
- BEFORE hunk:
```
 This is the **private archive** of Open Cube OS. It contains EVERYTHING —
 not just the public source code, but also:
 - Build artifacts (.o, .elf, .iso)
-- Internal docs (worklog, HANDOFF, WORKFLOW)
 - Old audit reports
-- Website source (Next.js page.tsx, layout.tsx, globals.css)
-- All ISOs + SRC zips (in releases/)
 - Release notes (in releases/notes/)
 - Toolchain setup (tools/env.sh)
 
-## Repository Structure
 
 ```
 archive-repo/
-├── oc-os/                    # Public repo content + build/ + archive/ + releases/
-│   ├── kernel/               # 94 source files (.c/.h/.S)
-│   ├── userprogs/            # 21 files (.c/.asm/.ld + .elf/.o binaries)
-│   ├── boot/                  # 3 assembly stubs (.S)
-│   ├── tools/                # 5 public tools (.sh/.py)
-│   ├── docs/                 # 15 documentation files (.md/.txt)
-│   ├── archive/              # Old source trees (WP06, old-src-tree, old-tests, old-ldso)
-│   ├── releases/             # Local release snapshots (WP08b Batch 6)
-│   ├── build/                # Build artifacts (.o/.d + opencube.elf + opencube.iso)
-│   ├── README.md
-│   ├── LICENSE
-│   ├── NOTICE
-│   ├── Makefile
-│   └── ... (all root files)
-├──
```
- AFTER hunk:
```
 This is the **private archive** of Open Cube OS. It contains EVERYTHING —
 not just the public source code, but also:
 - Build artifacts (.o, .elf, .iso)
+- Internal docs (audit docs, handover, workflow notes)
 - Old audit reports
+- The website source, twice: the canonical copy under oc-os/website/ and a
+  source-only mirror under website/ (see SYNC-RULES.md for which is which)
+- All ISOs + SRC zips (in releases/, hash-pinned by releases/SHA256SUMS.txt)
 - Release notes (in releases/notes/)
 - Toolchain setup (tools/env.sh)
 
+This file was rewritten at WP-10-AUDIT_P2-fix3 (fix3 G5, BUG-0273); the
+previous edition described the WP-08-era layout (pre-restructure) and no
+longer matched the tree.
+
+## Repository Structure (current)
 
 ```
 archive-repo/
+├── oc-os/                    # The OS tree (this content = the public repo)
+│   ├── boot/                 # Assembly boot stubs (.S)
+│   ├── kernel/               # C kernel: core/, mem/, drivers/…
+│   ├── fs/  net/  shell/     # Subsystems (post-restructure layout)
+│   ├── l1/                   # L1 extension headers
+│   ├── drivers/              # block/ nic/ snd/ usb/ display/ pci/ …
+│   ├── libs/                 # Sh
```

## BUG-0269 (P2, p2fix3-G5) — commit 1353e71
- Location: oc-os/website 内部
- Issue: i18n / site.ts / home.ts 三处数据互相矛盾；site.STATS 是死代码
- BEFORE hunk:
```
 // SPDX-License-Identifier: Apache-2.0
 // Copyright 2026 cubestudio-dev <cubestudio@qq.com>
 //
-// Central site data. Every number is a real WP-10d value
 // taken from the repository docs (README.md, docs/INTERFACES.md,
-// docs/EXTENSIONS_WP10d.md, docs/TRY-IT.md, docs/UPDATE-HOWTO.md)
 // and real sha256sum/build outputs.
-// 3-way identical: local build + GitHub Release wp10d + this site /downloads/
 
 export const BASE = "/OpenCubeOS";
 
 export const GITHUB_REPO = "https://github.com/cubestudio-dev/OpenCubeOS";
 export const RELEASE_LATEST =
-  "https://github.com/cubestudio-dev/OpenCubeOS/releases/tag/wp10d";
 export const RELEASES = "https://github.com/cubestudio-dev/OpenCubeOS/releases";
 export const SITE_URL = "https://cubestudio-dev.github.io/OpenCubeOS/";
 
-// Real assets (build/ + GitHub Release wp10d + this site /downloads/, 3-way identical)
-export const ISO_FILE = "opencube-wp10d.iso";
-export const ISO_SIZE_B = 11282432;
-export const ISO_SIZE_MB = "10.76";
 export const ISO_SHA256 =
-  "8e257255b63f15f6d04f0b67621d1095749247e5398cf0cd84b6538fffd78fc2";
 export const ISO_URL = `${BASE}/downloads/${ISO_FILE}`;
 
-export const SRC_FILE = "opencube-wp10d-src.zip"
```
- AFTER hunk:
```
 // SPDX-License-Identifier: Apache-2.0
 // Copyright 2026 cubestudio-dev <cubestudio@qq.com>
 //
+// Central site data. Every number is a real WP-10-AUDIT_P2-fix2b value
 // taken from the repository docs (README.md, docs/INTERFACES.md,
+// docs/EXTENSIONS_WP10-wp08fix1.md, docs/TRY-IT.md, docs/UPDATE-HOWTO.md)
 // and real sha256sum/build outputs.
+// 3-way identical: local build + GitHub WP-10-AUDIT_P2-fix2b tag + this site /downloads/
 
 export const BASE = "/OpenCubeOS";
 
 export const GITHUB_REPO = "https://github.com/cubestudio-dev/OpenCubeOS";
 export const RELEASE_LATEST =
+  "https://github.com/cubestudio-dev/OpenCubeOS/releases/tag/WP-10-AUDIT_P2-fix2b";
 export const RELEASES = "https://github.com/cubestudio-dev/OpenCubeOS/releases";
 export const SITE_URL = "https://cubestudio-dev.github.io/OpenCubeOS/";
 
+// Real assets (build/ + GitHub WP-10-AUDIT_P2-fix2b tag + this site /downloads/, 3-way identical)
+export const ISO_FILE = "opencube-WP-10-AUDIT_P2-fix2b.iso";
+export const ISO_SIZE_B = 11433984;
+export const ISO_SIZE_MB = "10.90";
 export const ISO_SHA256 =
+  "6f5d7c2c63394dc261d5a2125d01aaccdfbf23b1f726869ac7001dc815d8a656";
 export const ISO_URL = `${BASE}/d
```

## BUG-0270 (P2, p2fix3-G5) — commit 1353e71
- Location: docs-zh/
- Issue: 中文翻译滞后英文原文约两代（结构性漂移）
- BEFORE hunk:
```
docs-zh 翻译滞后英文原文约两代（结构性漂移）——G5 提交 1353e71 全量重译 BUILD/INTERFACES 等 6 个中文文档
```
- AFTER hunk:
```
git show --stat 1353e71: docs-zh/BUILD.md 88 行、docs-zh/INTERFACES.md 168 行等全量重写
```

## BUG-0271 (P2, p2fix3-G5) — commit 1353e71
- Location: 页面 metadata
- Issue: 全线过期（SEO/分享摘要与内容不符）
- BEFORE hunk:
```
-# Worklog
-
----
-Task ID: wp10-wp08fix1
-Agent: main agent (Z.ai Code)
-Task: WP-10-wp08_shell_and_tools_completion-fix1 — 按 WP-08 工作包规格补做缺失功能：oc> 行编辑全键位、ush 行编辑全键位、ush 补 13+2 命令、双端 nano 编辑器、9 个扩展接口
-
-Work Log:
-- 制作前：git fetch/pull（up to date）、git config 检查（cubestudio-dev / cubestudio@qq.com）、工具链可用
-- 勘察：上个会话已写 ush.c 大部分（13 命令+行编辑+nano）与 shell_lineedit.h/editor.h 头文件；缺：内核 syscall 96-102、shell_lineedit.c、editor.c、shell.c/main.c 集成、fs 层 mode/uid/gid/nlink、stat/env 命令、Tab 补全 dirent 布局 bug（32 字节 name 栈溢出）
-- ush.c 修复：dirent 布局对齐内核（64 字节 name）、补 stat/env 命令、history 连续去重、Tab 补全后整行重绘、parse_args 单引号感知、stat mode 显示 0600 格式、ln 打印错误码
-- fs 层：fs_vfs_node_t/stat_t 增 mode/uid/gid/nlink；VFS_TYPE_SYMLINK=4；dir_ops 增 link/symlink/readlink 回调；fs_vfs_link/symlink/readlink/chmod/chown 实现；ramfs 真实硬链接（共享 inode + nlink 计数）、symlink 路径解析跟随（8 跳 ELOOP 上限，仅绝对 target）
-- 内核：syscall 96-102（SYMLINK/READLINK/LINK/CHMOD/CHOWN/NETCMD 复用 shell_execute_captured 桥接 oc> 网络命令/PS 用 core_sched_task_info_get）；core_syscall 错误码透传
-- shell/shell_lineedit.c：oc> 全键位行编辑（Up/Down 历史 32 条翻页、Left/Right/Home/End、Ctrl+A/E/U/K/W、Delete、Ctrl+C、Tab 补全=命令表+VFS 路径）
-- shell/editor.c：oc> nano 编辑器（editor_open/save/close 三接口；行数组 kmalloc 化
```
- AFTER hunk:
```

```

## BUG-0272 (P2, p2fix3-G5) — commit 1353e71
- Location: 发布脚本
- Issue: 硬编码路径 + 时代错位的写死提交信息 + 无部署前哈希校验
- BEFORE hunk:
```
 #!/bin/bash
-# WP-09 website build script — cd is IN the file, cannot be forgotten
-set -e
-cd /home/z/my-project/oc-work/oc-os/website
 echo "PWD=$(pwd)"
 # WP-09-fix5 FIX: start from a clean out/ — a stale out/ kept the OLD
 # downloads/ directory alive and gh-pages shipped stale assets while the
 # new files landed at out/ root (mixed layouts). Always rebuild fresh.
```
- AFTER hunk:
```
 #!/bin/bash
+# Website local build + pre-deploy asset self-check.
+#
+# fix3 G5 (BUG-0272): all paths are derived from THIS script's location —
+# no hardcoded /home/z/... any more, the script runs from any checkout.
+# The pre-deploy hash gate: every download asset referenced by
+# lib/site.ts must match the actual file in public/downloads/ before the
+# build is allowed to succeed, and the exported out/downloads/ is
+# re-checked after the build (A18-1/A18-8 lesson: the site once shipped
+# SHA claims that no longer matched the deployed bytes).
+set -euo pipefail
+SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
+cd "$SCRIPT_DIR"
 echo "PWD=$(pwd)"
+
+command -v bun >/dev/null 2>&1 || { echo "ERROR: bun not found in PATH"; exit 1; }
+
+echo "--- pre-deploy asset hash check (lib/site.ts vs public/downloads) ---"
+# Extract the release-asset constants straight from lib/site.ts so the
+# gate can never drift from what the site will actually display.
+ISO_FILE=$(sed -n 's/^export const ISO_FILE = "\(.*\)";$/\1/p' lib/site.ts)
+ISO_SHA=$(sed -n '/^export const ISO_SHA256 = *$/{n;s/^  "\(.*\)";$/\1/p}' lib/site.ts)
+SRC_FILE=$(sed -n 's/^export const SRC_FILE = "\(.*\)";$/\1
```

## BUG-0273 (P2, p2fix3-G5) — commit 1353e71
- Location: 归档说明三件套 + releases/notes
- Issue: 与现实严重脱节 + note SHA 自相矛盾
- BEFORE hunk:
```
 This is the **private archive** of Open Cube OS. It contains EVERYTHING —
 not just the public source code, but also:
 - Build artifacts (.o, .elf, .iso)
-- Internal docs (worklog, HANDOFF, WORKFLOW)
 - Old audit reports
-- Website source (Next.js page.tsx, layout.tsx, globals.css)
-- All ISOs + SRC zips (in releases/)
 - Release notes (in releases/notes/)
 - Toolchain setup (tools/env.sh)
 
-## Repository Structure
 
 ```
 archive-repo/
-├── oc-os/                    # Public repo content + build/ + archive/ + releases/
-│   ├── kernel/               # 94 source files (.c/.h/.S)
-│   ├── userprogs/            # 21 files (.c/.asm/.ld + .elf/.o binaries)
-│   ├── boot/                  # 3 assembly stubs (.S)
-│   ├── tools/                # 5 public tools (.sh/.py)
-│   ├── docs/                 # 15 documentation files (.md/.txt)
-│   ├── archive/              # Old source trees (WP06, old-src-tree, old-tests, old-ldso)
-│   ├── releases/             # Local release snapshots (WP08b Batch 6)
-│   ├── build/                # Build artifacts (.o/.d + opencube.elf + opencube.iso)
-│   ├── README.md
-│   ├── LICENSE
-│   ├── NOTICE
-│   ├── Makefile
-│   └── ... (all root files)
-├──
```
- AFTER hunk:
```
 This is the **private archive** of Open Cube OS. It contains EVERYTHING —
 not just the public source code, but also:
 - Build artifacts (.o, .elf, .iso)
+- Internal docs (audit docs, handover, workflow notes)
 - Old audit reports
+- The website source, twice: the canonical copy under oc-os/website/ and a
+  source-only mirror under website/ (see SYNC-RULES.md for which is which)
+- All ISOs + SRC zips (in releases/, hash-pinned by releases/SHA256SUMS.txt)
 - Release notes (in releases/notes/)
 - Toolchain setup (tools/env.sh)
 
+This file was rewritten at WP-10-AUDIT_P2-fix3 (fix3 G5, BUG-0273); the
+previous edition described the WP-08-era layout (pre-restructure) and no
+longer matched the tree.
+
+## Repository Structure (current)
 
 ```
 archive-repo/
+├── oc-os/                    # The OS tree (this content = the public repo)
+│   ├── boot/                 # Assembly boot stubs (.S)
+│   ├── kernel/               # C kernel: core/, mem/, drivers/…
+│   ├── fs/  net/  shell/     # Subsystems (post-restructure layout)
+│   ├── l1/                   # L1 extension headers
+│   ├── drivers/              # block/ nic/ snd/ usb/ display/ pci/ …
+│   ├── libs/                 # Sh
```

## BUG-0274 (P2, p2fix3-G6) — commit 51d1edb
- Location: core_syscall.c:296-363
- Issue: sys_fork 不继承 mmap_base/next_solib_addr
- BEFORE hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
-    /* Now resolve against cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```
- AFTER hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
+    /* BUG-0278 FIX (A2-14): resolve against the CALLER's per-process cwd
+     * (copied in at fork, seeded from the kernel shell at spawn time,
+     * changed only by this process's own chdir). The old code resolved
+     * every relative path against the kernel shell's single global
+     * g_cwd, so any process's chdir moved the path base of ALL
+     * processes - relative opens/stat/mkdirs could land in a directory
+     * the caller never selected. */
+    user_proc_t *proc = user_process_current();
+    if (proc) {
+        extern int shell_resolve_path_base(const char *cwd, const char *path,
+                                           char *out, int out_len);
+        if (shell_resolve_path_base(proc->cwd, user_buf, out, out_len) < 0) return -1;
+        return 0;
+    }
+    /* Defensive fallback (no current user process): kernel shell cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```

## BUG-0275 (P2, p2fix3-G6) — commit 51d1edb
- Location: core_usermode.c:215-249
- Issue: SYS_EXIT(0) 清理路径与 EXIT2 不一致
- Manual HEAD verification: core_usermode.c:278 修复注释在（grep 实证）
- BEFORE hunk:
```
     tid_t tid = core_kthread_current_tid();
     for (int i = 0; i < MAX_USER_PROCS; i++) {
         if (g_procs[i].alive && g_procs[i].tid == tid) {
-            g_procs[i].alive = 0;
             /* P0fix2 BUG-0032 (A2-2): n was char[8] while u64_to_str can
              * emit up to 20 digits + NUL for a user-controlled exit code —
              * an up-to-13-byte overflow of this kernel stack frame.  24
```
- AFTER hunk:
```
     tid_t tid = core_kthread_current_tid();
     for (int i = 0; i < MAX_USER_PROCS; i++) {
         if (g_procs[i].alive && g_procs[i].tid == tid) {
             /* P0fix2 BUG-0032 (A2-2): n was char[8] while u64_to_str can
              * emit up to 20 digits + NUL for a user-controlled exit code —
              * an up-to-13-byte overflow of this kernel stack frame.  24
```

## BUG-0276 (P2, p2fix3-G6) — commit 51d1edb
- Location: core_syscall.c:1525-1575
- Issue: sys_write2(72) 管道分支缺"无读者"检查 + 控制台回退无原子窗口
- BEFORE hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
-    /* Now resolve against cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```
- AFTER hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
+    /* BUG-0278 FIX (A2-14): resolve against the CALLER's per-process cwd
+     * (copied in at fork, seeded from the kernel shell at spawn time,
+     * changed only by this process's own chdir). The old code resolved
+     * every relative path against the kernel shell's single global
+     * g_cwd, so any process's chdir moved the path base of ALL
+     * processes - relative opens/stat/mkdirs could land in a directory
+     * the caller never selected. */
+    user_proc_t *proc = user_process_current();
+    if (proc) {
+        extern int shell_resolve_path_base(const char *cwd, const char *path,
+                                           char *out, int out_len);
+        if (shell_resolve_path_base(proc->cwd, user_buf, out, out_len) < 0) return -1;
+        return 0;
+    }
+    /* Defensive fallback (no current user process): kernel shell cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```

## BUG-0277 (P2, p2fix3-G6) — commit 51d1edb
- Location: core_syscall.c:993-1236
- Issue: ; core_usermode.c:284-299   exec 不重置信号状态；信号 handler 无栈上 restorer
- BEFORE hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
-    /* Now resolve against cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```
- AFTER hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
+    /* BUG-0278 FIX (A2-14): resolve against the CALLER's per-process cwd
+     * (copied in at fork, seeded from the kernel shell at spawn time,
+     * changed only by this process's own chdir). The old code resolved
+     * every relative path against the kernel shell's single global
+     * g_cwd, so any process's chdir moved the path base of ALL
+     * processes - relative opens/stat/mkdirs could land in a directory
+     * the caller never selected. */
+    user_proc_t *proc = user_process_current();
+    if (proc) {
+        extern int shell_resolve_path_base(const char *cwd, const char *path,
+                                           char *out, int out_len);
+        if (shell_resolve_path_base(proc->cwd, user_buf, out, out_len) < 0) return -1;
+        return 0;
+    }
+    /* Defensive fallback (no current user process): kernel shell cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```

## BUG-0278 (P2, p2fix3-G6) — commit 51d1edb
- Location: core_syscall.c:113-141
- Issue: , 870-888   chdir/getcwd/相对路径解析基于全局 g_cwd，无进程隔离
- BEFORE hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
-    /* Now resolve against cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```
- AFTER hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
+    /* BUG-0278 FIX (A2-14): resolve against the CALLER's per-process cwd
+     * (copied in at fork, seeded from the kernel shell at spawn time,
+     * changed only by this process's own chdir). The old code resolved
+     * every relative path against the kernel shell's single global
+     * g_cwd, so any process's chdir moved the path base of ALL
+     * processes - relative opens/stat/mkdirs could land in a directory
+     * the caller never selected. */
+    user_proc_t *proc = user_process_current();
+    if (proc) {
+        extern int shell_resolve_path_base(const char *cwd, const char *path,
+                                           char *out, int out_len);
+        if (shell_resolve_path_base(proc->cwd, user_buf, out, out_len) < 0) return -1;
+        return 0;
+    }
+    /* Defensive fallback (no current user process): kernel shell cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```

## BUG-0279 (P2, p2fix3-G6) — commit 51d1edb
- Location: core_usermode.c:544-567
- Issue: , 444-522   launcher 死眠泄漏线程槽；fork AS 拷贝 OOM 返回半成品
- BEFORE hunk:
```
 
                 if (!(dst_pde & VMM_FLAG_PRESENT)) {
                     u64 pt_phys = mem_pmm_alloc_frame();
-                    if (pt_phys == 0) return dst_as;
                     dst_pt = (u64*)pt_phys;
                     memset(dst_pt, 0, PMM_PAGE_SIZE);
                     dst_pd[pd_idx] = pt_phys | 0x007;
```
- AFTER hunk:
```
 
                 if (!(dst_pde & VMM_FLAG_PRESENT)) {
                     u64 pt_phys = mem_pmm_alloc_frame();
+                    if (pt_phys == 0) {
+                        /* BUG-0279 FIX (A2-15b): OOM must not return a
+                         * half-copied address space (the old code returned
+                         * the partial dst_as and sys_fork spawned a child
+                         * on a broken AS that died at its first missing
+                         * page). Tear the partial copy down and report
+                         * failure so the fork fails cleanly. */
+                        mem_vmm_destroy_address_space(dst_as);
+                        return 0;
+                    }
                     dst_pt = (u64*)pt_phys;
                     memset(dst_pt, 0, PMM_PAGE_SIZE);
                     dst_pd[pd_idx] = pt_phys | 0x007;
```

## BUG-0280 (P2, p2fix3-G6) — commit 51d1edb
- Location: core_syscall.c:1261-1345
- Issue: sys_map_solib 失败不回滚；内联 ELF 解析无 bounds 校验
- BEFORE hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
-    /* Now resolve against cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```
- AFTER hunk:
```
         if (copy_from_user(user_buf, user_path, n + 1) != 0) return -1;
         user_buf[n] = 0;
     }
+    /* BUG-0278 FIX (A2-14): resolve against the CALLER's per-process cwd
+     * (copied in at fork, seeded from the kernel shell at spawn time,
+     * changed only by this process's own chdir). The old code resolved
+     * every relative path against the kernel shell's single global
+     * g_cwd, so any process's chdir moved the path base of ALL
+     * processes - relative opens/stat/mkdirs could land in a directory
+     * the caller never selected. */
+    user_proc_t *proc = user_process_current();
+    if (proc) {
+        extern int shell_resolve_path_base(const char *cwd, const char *path,
+                                           char *out, int out_len);
+        if (shell_resolve_path_base(proc->cwd, user_buf, out, out_len) < 0) return -1;
+        return 0;
+    }
+    /* Defensive fallback (no current user process): kernel shell cwd. */
     extern int shell_resolve_path(const char *path, char *out, int out_len);
     if (shell_resolve_path(user_buf, out, out_len) < 0) return -1;
     return 0;
```

## BUG-0281 (P2, p2fix3-G7) — commit c1f68a7
- Location: core_syscall.c:614-656
- Issue: , 671-733   mmap/munmap/mprotect 区域上限不一致；prot/addr 被忽略
- BEFORE hunk:
```
     return (u64)newfd;
 }
 
 static u64 sys_mem_mmap(u64 addr, u64 length, u64 prot, u64 a4) {
-    (void)addr;(void)prot;(void)a4;
     if (length == 0) return (u64)-1;
     user_proc_t *proc = user_process_current();
     if (!proc) return (u64)-1;
-    /* P3-6 FIX: Reject unaligned / overflowing length to prevent
-     * arithmetic bugs in the page-count calculation. */
     if (length > 0x40000000ULL) return (u64)-1;  /* 1 GiB sanity cap */
     u64 pages = (length + 0xFFF) / 0x1000;
-    /* BUG-010 FIX: Use per-process mmap_base instead of a global static.
-     * The old `static u64 mmap_base` was shared across all processes,
-     * causing cross-process memory corruption when multiple processes
-     * called mmap. Now each process gets its own bump allocator. */
-    if (proc->mmap_base == 0) proc->mmap_base = USER_MMAP_BASE;
-    u64 result = proc->mmap_base;
     u64 mapped = 0;  /* P3-5: track how many we successfully mapped */
     for (u64 i = 0; i < pages; i++) {
         u64 phys = mem_pmm_alloc_frame();
         if (phys == 0) {
-            /* P3-5 FIX: Partial-failure cleanup. Old code just returned
-             * -1, leaving the already-mapped pages (and the u
```
- AFTER hunk:
```
     return (u64)newfd;
 }
 
+/* BUG-0281 (A2-9) FIX: mmap window region-table helpers. Regions are
+ * non-overlapping by construction (mmap refuses overlaps), so coverage
+ * and overlap tests reduce to interval arithmetic over the table. All
+ * of these run on the CALLER'S OWN process table - "foreign" here means
+ * a window range this process never mapped, which is exactly what the
+ * teardown calls must refuse instead of silently ignoring. */
+static int mmap_regions_overlaps(user_proc_t *p, u64 s, u64 e) {
+    for (int i = 0; i < PROC_MAX_MMAP_REGIONS; i++) {
+        if (p->mmap_regions[i].start == 0) continue;
+        u64 rs = p->mmap_regions[i].start;
+        u64 re = rs + p->mmap_regions[i].pages * 0x1000;
+        if (s < re && rs < e) return 1;
+    }
+    return 0;
+}
+
+/* 1 = every page of [s, e) lies inside some region of p. */
+static int mmap_regions_covered(user_proc_t *p, u64 s, u64 e) {
+    u64 covered = 0;
+    for (int i = 0; i < PROC_MAX_MMAP_REGIONS; i++) {
+        if (p->mmap_regions[i].start == 0) continue;
+        u64 rs = p->mmap_regions[i].start;
+        u64 re = rs + p->mmap_regions[i].pages * 0x1000;
+        u64 os = s > rs ? s : rs;
+    
```

## BUG-0282 (P2, p2fix3-G7) — commit c1f68a7
- Location: core_sched.c:608-621
- Issue: （对照 489-494、623-626）  reap 无互斥 → 栈双重释放窄窗口
- BEFORE hunk:
```
     /* P3-19 FIX: allocate a single page for the idle task stack (removed
      * duplicate allocation that leaked 4 pages). */
     g_idle_task->stack_base = (u64*)mem_pmm_alloc_frame();
     g_idle_task->stack_size = PMM_PAGE_SIZE;
 
     /* Set up the idle task's saved state. */
```
- AFTER hunk:
```
     /* P3-19 FIX: allocate a single page for the idle task stack (removed
      * duplicate allocation that leaked 4 pages). */
     g_idle_task->stack_base = (u64*)mem_pmm_alloc_frame();
+    /* BUG-0283 (A3-06) FIX: check the allocation. core_kthread_create has
+     * checked its stack allocation from the start; this path did not. On
+     * failure the old code computed sp = 0x1000, stored rsp = 0xff8 and
+     * kept booting - the first context switch into idle would then
+     * save/restore context through an invalid stack. The idle task is the
+     * system's fallback context; without its stack there is no correct
+     * way forward, so this is a fail-stop, not an error return (there is
+     * no caller to return to during early init; the audit notes boot-time
+     * PMM failure is unlikely - the defect is that it was unchecked). */
+    if (g_idle_task->stack_base == 0) {
+        screen_console_puts("PANIC: idle task stack allocation failed - halting\n");
+        __asm__ volatile("cli");
+        for (;;) __asm__ volatile("hlt");
+    }
     g_idle_task->stack_size = PMM_PAGE_SIZE;
 
     /* Set up the idle task's saved state. */
```

## BUG-0283 (P2, p2fix3-G7) — commit c1f68a7
- Location: core_sched.c:164-168
- Issue: idle 栈分配失败未检查
- BEFORE hunk:
```
     /* P3-19 FIX: allocate a single page for the idle task stack (removed
      * duplicate allocation that leaked 4 pages). */
     g_idle_task->stack_base = (u64*)mem_pmm_alloc_frame();
     g_idle_task->stack_size = PMM_PAGE_SIZE;
 
     /* Set up the idle task's saved state. */
```
- AFTER hunk:
```
     /* P3-19 FIX: allocate a single page for the idle task stack (removed
      * duplicate allocation that leaked 4 pages). */
     g_idle_task->stack_base = (u64*)mem_pmm_alloc_frame();
+    /* BUG-0283 (A3-06) FIX: check the allocation. core_kthread_create has
+     * checked its stack allocation from the start; this path did not. On
+     * failure the old code computed sp = 0x1000, stored rsp = 0xff8 and
+     * kept booting - the first context switch into idle would then
+     * save/restore context through an invalid stack. The idle task is the
+     * system's fallback context; without its stack there is no correct
+     * way forward, so this is a fail-stop, not an error return (there is
+     * no caller to return to during early init; the audit notes boot-time
+     * PMM failure is unlikely - the defect is that it was unchecked). */
+    if (g_idle_task->stack_base == 0) {
+        screen_console_puts("PANIC: idle task stack allocation failed - halting\n");
+        __asm__ volatile("cli");
+        for (;;) __asm__ volatile("hlt");
+    }
     g_idle_task->stack_size = PMM_PAGE_SIZE;
 
     /* Set up the idle task's saved state. */
```

## BUG-0284 (P2, p2fix3-G7) — commit c1f68a7
- Location: core_sched.c:451-455
- Issue: switch_to 违反"idle 永不入队"不变量
- BEFORE hunk:
```
     /* P3-19 FIX: allocate a single page for the idle task stack (removed
      * duplicate allocation that leaked 4 pages). */
     g_idle_task->stack_base = (u64*)mem_pmm_alloc_frame();
     g_idle_task->stack_size = PMM_PAGE_SIZE;
 
     /* Set up the idle task's saved state. */
```
- AFTER hunk:
```
     /* P3-19 FIX: allocate a single page for the idle task stack (removed
      * duplicate allocation that leaked 4 pages). */
     g_idle_task->stack_base = (u64*)mem_pmm_alloc_frame();
+    /* BUG-0283 (A3-06) FIX: check the allocation. core_kthread_create has
+     * checked its stack allocation from the start; this path did not. On
+     * failure the old code computed sp = 0x1000, stored rsp = 0xff8 and
+     * kept booting - the first context switch into idle would then
+     * save/restore context through an invalid stack. The idle task is the
+     * system's fallback context; without its stack there is no correct
+     * way forward, so this is a fail-stop, not an error return (there is
+     * no caller to return to during early init; the audit notes boot-time
+     * PMM failure is unlikely - the defect is that it was unchecked). */
+    if (g_idle_task->stack_base == 0) {
+        screen_console_puts("PANIC: idle task stack allocation failed - halting\n");
+        __asm__ volatile("cli");
+        for (;;) __asm__ volatile("hlt");
+    }
     g_idle_task->stack_size = PMM_PAGE_SIZE;
 
     /* Set up the idle task's saved state. */
```

## BUG-0285 (P2, p2fix3-G7) — commit c1f68a7
- Location: core_sync.c:28-46
- Issue: 自旋锁非中断安全（有文档的设计决定）
- BEFORE hunk:
```
 void spin_init(spinlock_t *lock) {
     lock->locked = 0;
     lock->lock_count = 0;
 }
 
-/* P2-46: spinlock does NOT cli/sti. On this single-CPU kernel, IRQ
- * handlers (timer, keyboard, network poll) do not acquire spinlocks
- * except in carefully controlled paths (timer IRQ calls net_poll which
- * uses e1000 registers directly, not spinlocks). Disabling interrupts
- * in spin_lock would prevent the timer from firing, causing tasks that
- * spin on a lock to monopolize the CPU (verified: synctest dropped to
- * 515/3000). So we keep the simple non-IRQ-safe spinlock. */
 void spin_lock(spinlock_t *lock) {
     while (__sync_lock_test_and_set(&lock->locked, 1)) {
         __asm__ volatile("pause");
     }
     lock->lock_count++;
     g_stats.spin_locks++;
 }
 
 void spin_unlock(spinlock_t *lock) {
     __sync_lock_release(&lock->locked);
     g_stats.spin_unlocks++;
 }
 
 int spin_trylock(spinlock_t *lock) {
     if (__sync_lock_test_and_set(&lock->locked, 1) == 0) {
         lock->lock_count++;
         g_stats.spin_locks++;
         return 1;
     }
     return 0;
 }
 
```
- AFTER hunk:
```
 void spin_init(spinlock_t *lock) {
     lock->locked = 0;
     lock->lock_count = 0;
+    lock->_saved_flags = 0;
 }
 
+/* BUG-0285 (A3-08) FIX: spinlocks are now IRQ-safe (irqsave/irqrestore
+ * semantics). The old P2-46 decision left the lock non-IRQ-safe with
+ * only a comment as protection: on this single-CPU kernel, if an IRQ
+ * handler ever acquired a spinlock held by the interrupted context, the
+ * handler would spin forever on a holder that can no longer run - an
+ * unpreemptible deadlock with no assertion to catch it (verified: the
+ * timer -> net_poll path does not take these locks today, but nothing
+ * enforced that invariant). Now spin_lock saves RFLAGS and clears IF
+ * before the test-and-set, and spin_unlock releases the lock FIRST and
+ * only then restores the IF state recorded at acquisition time (the
+ * _saved_flags slot reserved by P2-46). Release-before-restore is what
+ * makes the scheme correct on one CPU: at the instant IF comes back the
+ * lock is already free, so a preemption can never observe a held lock
+ * whose holder is no longer running. A holder can no longer be
+ * interrupted, so an IRQ can never contend with its own holder; timer
+ * de
```

## BUG-0286 (P2, p2fix3-G7) — commit c1f68a7
- Location: core_sync.c:172-192
- Issue: （对照 core_sync.h:40-46）  mutex 无优先级继承、无等待者管理
- BEFORE hunk:
```
     }
 }
 
-/* ---- Mutex ---- */
 void mutex_init(mutex_t *m) {
     m->locked = 0;
     m->owner = -1;
-    m->owner_prio = 0;
     m->lock_count = 0;
 }
 
 void mutex_lock(mutex_t *m) {
     tid_t my_tid = core_kthread_current_tid();
-    while (__sync_lock_test_and_set(&m->locked, 1)) {
-        /* Contended: yield and retry. */
-        core_sched_yield();
     }
-    m->owner = my_tid;
-    m->owner_prio = core_kthread_current()->priority;
-    m->lock_count++;
-    g_stats.mutex_locks++;
 }
 
 void mutex_unlock(mutex_t *m) {
-    /* P1-11 FIX: check that the caller actually owns the mutex. */
     tid_t my_tid = core_kthread_current_tid();
-    if (m->owner != my_tid) return;  /* not the owner — ignore */
     m->owner = -1;
-    __sync_lock_release(&m->locked);
     g_stats.mutex_unlocks++;
-    core_sched_yield();
 }
 
 /* ---- Condition variable ---- */
```
- AFTER hunk:
```
     }
 }
 
+/* ---- Mutex ----
+ * BUG-0286 (A3-09) FIX: real FIFO waiter management. The old lock was a
+ * bare test-and-set + yield-retry loop with an owner_prio field that no
+ * PI logic ever read (the header claimed priority inheritance; none
+ * existed). Three cli windows make the object internally consistent on
+ * this single CPU:
+ *   (1) mutex_lock: test-and-set + owner registration are ONE window,
+ *       so locked==1 always implies a registered, resolvable owner;
+ *   (2) mutex_lock (contended): waiter registration + BLOCKED is ONE
+ *       window (same lost-wakeup shape as sem_wait's P0-5 fix);
+ *   (3) mutex_unlock: owner clear + release + FIFO sweep is ONE window.
+ * mutex_unlock wakes the FIFO head, sweeping waiters whose tid died
+ * while queued. The dead-owner case is also handled: a contended
+ * mutex_lock that finds its owner destroyed/EXITED force-releases the
+ * lock so the object cannot wedge forever (the dead holder's critical
+ * section is not rolled back - documented exposure, like a POSIX mutex
+ * held by a cancelled thread). There is deliberately NO priority
+ * inheritance - see core_sync.h. */
 void mutex_init(mutex_t *m) {
     m->locke
```

## BUG-0287 (P2, p2fix3-G8) — commit 65a55eb
- Location: core_rtc.c:63-79
- Issue: 12 小时制换算错误
- BEFORE hunk:
```
         regb = core_rtc_reg(0x0B);
     }
 
     if (!(regb & 0x04)) {
         /* BCD mode */
         #define BCD(v) ((u8)(((v) & 0x0F) + ((v) >> 4) * 10))
```
- AFTER hunk:
```
         regb = core_rtc_reg(0x0B);
     }
 
+    /* Hand the raw register snapshot to the production decoder
+     * (BUG-0287 FIX: PM flag stripped before BCD, 12h civil fix-up).
+     * Named entry point so g8test can also drive it with injected
+     * snapshots. */
+    core_rtc_decode(second, minute, hour, day, month, year, century, regb, out);
+}
+
+/* Decode a raw CMOS register snapshot into civil time (BUG-0287 FIX,
+ * A3-10).  Split out of core_rtc_read so the regression suite can drive
+ * the real production decoder with injected raw snapshots (g8test A
+ * group) in addition to live CMOS reads.
+ *
+ * Register B conventions (MC146818 / PIIX4):
+ *   bit1 = 0 -> 12-hour mode: bit7 of the HOUR register is the PM flag
+ *              and bit[6:0] hold the hour; bit1 = 1 -> 24-hour mode.
+ *   bit2 = 0 -> BCD digits; bit2 = 1 -> binary.
+ * The PM flag must be stripped BEFORE the BCD conversion - otherwise it
+ * is folded into the tens digit (0x87 -> 87) and the PM information is
+ * destroyed (7 PM decoded as 15, 12 AM as 12). */
+void core_rtc_decode(u8 second, u8 minute, u8 hour, u8 day, u8 month,
+                     u8 year, u8 century, u8 regb, core_rtc_time_t *
```

## BUG-0288 (P2, p2fix3-G8) — commit 65a55eb
- Location: core_power.c:70-75
- Issue: （对照 58-64、81-95）  halt 不刷块设备缓存
- BEFORE hunk:
```
 /* ------------------------------------------------------------------ */
 
 void core_power_halt(void) {
     screen_console_puts("System halted.\n");
     screen_console_show_cursor(0);
     __asm__ volatile("cli");
```
- AFTER hunk:
```
 /* ------------------------------------------------------------------ */
 
 void core_power_halt(void) {
+    /* BUG-0288 FIX (A3-11): halt previously stopped the CPU WITHOUT
+     * flushing the block write-back cache, while shutdown/reboot both
+     * flush first.  Dirty cache contents (driver_block_write_sectors
+     * callers) were silently lost at the next power transition, and the
+     * shutdown-failure fallback below halts too - one fix covers both.
+     * Same ordering as the other two paths: flush BEFORE any output or
+     * state change so a flush error is still visible. */
+    core_power_flush_blk();
     screen_console_puts("System halted.\n");
     screen_console_show_cursor(0);
     __asm__ volatile("cli");
```

## BUG-0289 (P2, p2fix3-G8) — commit 65a55eb
- Location: core_timer.c:128-142
- Issue: one-shot 注册与 IRQ0 扫描的竞态
- BEFORE hunk:
```
     return -2;
 }
 
 int core_timer_register_oneshot(core_timer_cb_fn fn, void *ctx, u64 delay_ms) {
     if (!fn || delay_ms == 0) return -1;
     for (int i = 0; i < OC_MAX_TIMERS; i++) {
         if (!g_timers[i].in_use) {
-            g_timers[i].in_use        = 1;
             g_timers[i].periodic      = 0;
             g_timers[i].interval_ms   = delay_ms;
             g_timers[i].next_fire_ms  = core_timer_now_ms() + delay_ms;
             g_timers[i].fn            = fn;
             g_timers[i].ctx           = ctx;
             return i;
         }
     }
     return -2;
 }
 
```
- AFTER hunk:
```
     return -2;
 }
 
+/* BUG-0289 FIX (A3-12): the whole find+fill sequence runs inside an
+ * irqsave window.  The old code published in_use FIRST and filled
+ * next_fire_ms/fn afterwards with interrupts enabled, so an IRQ0 scan
+ * hitting that window saw a timer that was "in use, due now, with a
+ * NULL fn" and released the slot (in_use = 0) - the registration then
+ * completed into a cancelled slot and returned a valid id for a timer
+ * that would never fire (or, on slot reuse, fire a stale callback).
+ * Two defences, both cheap: interrupts stay disabled for the few
+ * instructions of the fill (so the IRQ0 scan cannot interleave at
+ * all), and in_use is published LAST so even a hypothetical observer
+ * never sees a half-filled slot.  Flags are restored with popfq (not
+ * sti) so a caller that is already inside a cli section keeps IF=0,
+ * same convention as the spinlocks. */
 int core_timer_register_oneshot(core_timer_cb_fn fn, void *ctx, u64 delay_ms) {
     if (!fn || delay_ms == 0) return -1;
+    u64 flags;
+    __asm__ volatile(
+        "pushfq\n"
+        "popq %0\n"
+        "cli\n"
+        : "=r"(flags)
+        :
+        : "memory");
     for (int i = 0; 
```

## BUG-0290 (P2, p2fix3-G8) — commit 65a55eb
- Location: main.c:1813-1823（l1/l1_wp8cd.c:60-64
- Issue: 同）  非 volatile 标志自旋等待
- BEFORE hunk:
```
 #include "l1_ext.h"
 #include "l1_wp8a.h"   /* BUG-0254 FIX: the 21 int 0x80 wrappers get kernel-side callers (l1test step 8) */
 #include "g7test.h"   /* WP-10-AUDIT_P2-fix3 G7: sched/sync regression suite (BUG-0282..0286), l1test step 9 */
 #include "lib_log.h"
 #include "lib_string.h"
 #include "crypto_dh_scale_vectors.h"  /* WP-09 debug: modexp scale-sweep truth vectors */
```
- AFTER hunk:
```
 #include "l1_ext.h"
 #include "l1_wp8a.h"   /* BUG-0254 FIX: the 21 int 0x80 wrappers get kernel-side callers (l1test step 8) */
 #include "g7test.h"   /* WP-10-AUDIT_P2-fix3 G7: sched/sync regression suite (BUG-0282..0286), l1test step 9 */
+#include "g8test.h"   /* WP-10-AUDIT_P2-fix3 G8: clock/power/timer regression suite (BUG-0287..0289,0291), l1test step 10 */
 #include "lib_log.h"
 #include "lib_string.h"
 #include "crypto_dh_scale_vectors.h"  /* WP-09 debug: modexp scale-sweep truth vectors */
```

## BUG-0291 (P2, p2fix3-G8) — commit 65a55eb
- Location: main.c:1382-1383
- Issue: cr3test 不检查 alloc_frame 失败
- BEFORE hunk:
```
 #include "l1_ext.h"
 #include "l1_wp8a.h"   /* BUG-0254 FIX: the 21 int 0x80 wrappers get kernel-side callers (l1test step 8) */
 #include "g7test.h"   /* WP-10-AUDIT_P2-fix3 G7: sched/sync regression suite (BUG-0282..0286), l1test step 9 */
 #include "lib_log.h"
 #include "lib_string.h"
 #include "crypto_dh_scale_vectors.h"  /* WP-09 debug: modexp scale-sweep truth vectors */
```
- AFTER hunk:
```
 #include "l1_ext.h"
 #include "l1_wp8a.h"   /* BUG-0254 FIX: the 21 int 0x80 wrappers get kernel-side callers (l1test step 8) */
 #include "g7test.h"   /* WP-10-AUDIT_P2-fix3 G7: sched/sync regression suite (BUG-0282..0286), l1test step 9 */
+#include "g8test.h"   /* WP-10-AUDIT_P2-fix3 G8: clock/power/timer regression suite (BUG-0287..0289,0291), l1test step 10 */
 #include "lib_log.h"
 #include "lib_string.h"
 #include "crypto_dh_scale_vectors.h"  /* WP-09 debug: modexp scale-sweep truth vectors */
```

## BUG-0292 (P2, p2fix3-G9) — commit 2df3cf7
- Location: crypto_sha512.c:143-181
- Issue: crypto_hmac_sha384 实为 HMAC-SHA-512 截断（休眠缺陷，POC 证实）
- BEFORE hunk:
```
 
 #define HMAC_BLOCK_SHA512 128
 
-static void crypto_hmac_sha512_core(const u8 *key, int key_len,
                              const u8 *data, int data_len,
                              u8 *out, int out_len) {
     u8 k[HMAC_BLOCK_SHA512], ipad[HMAC_BLOCK_SHA512], opad[HMAC_BLOCK_SHA512];
     u8 key_hash[64];
     if (key_len > HMAC_BLOCK_SHA512) {
-        sha512(key, key_len, key_hash);
         key = key_hash;
-        key_len = 64;
     }
     memset(k, 0, HMAC_BLOCK_SHA512);
     if (key_len > 0) memcpy(k, key, key_len);
```
- AFTER hunk:
```
 
 #define HMAC_BLOCK_SHA512 128
 
+/* BUG-0292 (A4-05) FIX: the two variants used to share one core that always
+ * seeded the SHA-512 IV and hashed oversized keys with SHA-512, so
+ * crypto_hmac_sha384 really produced truncated HMAC-SHA-512 (RFC 4231
+ * KATs diverge). The core is now keyed by variant: HMAC-SHA-384 seeds the
+ * SHA-384 IV, hashes oversized keys with SHA-384 (48-byte padded key) and
+ * feeds the 48-byte inner digest to the outer pass (RFC 2104 / RFC 4868);
+ * HMAC-SHA-512 keeps the SHA-512 behaviour. Both share the 128-byte block
+ * size, so ipad/opad construction is identical. */
+static void crypto_hmac_sha512_core(int is384, const u8 *key, int key_len,
                              const u8 *data, int data_len,
                              u8 *out, int out_len) {
     u8 k[HMAC_BLOCK_SHA512], ipad[HMAC_BLOCK_SHA512], opad[HMAC_BLOCK_SHA512];
     u8 key_hash[64];
+    int inner_len = is384 ? 48 : 64;
     if (key_len > HMAC_BLOCK_SHA512) {
+        if (is384) { sha384(key, key_len, key_hash); key_len = 48; }
+        else       { sha512(key, key_len, key_hash); key_len = 64; }
         key = key_hash;
     }
     memset(k, 0, HMAC_BLOCK_SHA512);
     if (
```

## BUG-0293 (P2, p2fix3-G9) — commit 2df3cf7
- Location: crypto_aead.c:500-531
- Issue: g_mac_buf 静态共享缓冲 + 超限静默垃圾 tag
- BEFORE hunk:
```
 }
 
 /* mac_data = aad || pad16 || ct || pad16 || le64(aad_len) || le64(ct_len).
- * Built into one static buffer (single-threaded kernel; documented limit).
- * TLS records: aad <= 5+32, ct <= 16384+256+16 -> buffer 20480 is ample. */
-#define OC_MAC_BUF_SIZE 20480
-static u8 g_mac_buf[OC_MAC_BUF_SIZE];
 
-static void crypto_poly1305_aead_tag(const u8 poly_key[32], const u8 *aad, int aad_len,
                               const u8 *ct, int ct_len, u8 tag[16]) {
-    int aad_pad = (16 - (aad_len % 16)) % 16;
-    int ct_pad = (16 - (ct_len % 16)) % 16;
-    int total = aad_len + aad_pad + ct_len + ct_pad + 16;
 
     u8 lens[16];
     u64 al = (u64)aad_len, cl = (u64)ct_len;
     for (int i = 0; i < 8; i++) lens[i] = (u8)(al >> (8 * i));
     for (int i = 0; i < 8; i++) lens[8 + i] = (u8)(cl >> (8 * i));
 
     crypto_poly1305_ctx_t st;
     crypto_poly1305_init_ctx(&st, poly_key);
-    if (total <= OC_MAC_BUF_SIZE) {
-        u8 *p = g_mac_buf;
-        if (aad_len) { memcpy(p, aad, aad_len); p += aad_len; }
-        if (aad_pad) { memset(p, 0, aad_pad); p += aad_pad; }
-        if (ct_len) { memcpy(p, ct, ct_len); p += ct_len; }
-        if (ct_pad) { memset(p, 0, ct_pad); p +=
```
- AFTER hunk:
```
 }
 
 /* mac_data = aad || pad16 || ct || pad16 || le64(aad_len) || le64(ct_len).
+ * BUG-0293 (A4-06) FIX: this used to be assembled into one shared static
+ * staging buffer (g_mac_buf, 20480 B): concurrent/reentrant seal/open calls
+ * raced on it, the `int total` size check could overflow negative and pass,
+ * and an oversized input silently produced an all-0xEE tag with seal still
+ * returning 0 (worse: an oversized record replayed to open() computed the
+ * same 0xEE tag and was ACCEPTED - no authentication at all).
+ * Poly1305 is a streaming MAC, so the mac_data is now fed directly through
+ * the context with a per-call 16-byte tail register: no shared state, no
+ * staging cap, no giant memcpy. Lengths are validated fail-closed: negative
+ * or absurd lengths (> OC_AEAD_MAX_INPUT) make seal/open return -1 instead
+ * of ever producing or accepting a tag. */
+#define OC_AEAD_MAX_INPUT (1 << 30)   /* sanity cap: 1 GiB of aad or ct */
+
+static void poly_stream(crypto_poly1305_ctx_t *st, u8 tail[16], int *tail_len,
+                 const u8 *d, int len) {
+    while (len > 0) {
+        int take = 16 - *tail_len;
+        if (take > len) take = len;
+        memcpy(tail +
```

## BUG-0294 (P2, p2fix3-G9) — commit 2df3cf7
- Location: crypto_bn.c:199-201
- Issue: （+ crypto_ec_nist.c:91-92、crypto_core.c:39-40）  静态工作区/惰性初始化无锁，不可重入
- BEFORE hunk:
```
     crypto_bn_mont_redc(out, t, m, n, n0inv);
 }
 
-/* ---- Shared workspace for modexp ---- */
-static u64 ws_a[BN_MAX_LIMBS];   /* accumulator */
-static u64 ws_b[BN_MAX_LIMBS];   /* base in Montgomery domain */
-static u64 ws_m[BN_MAX_LIMBS];   /* modulus */
 
 int crypto_bn_mod_exp(u8 *out, int out_len,
                const u8 *base, int base_len,
```
- AFTER hunk:
```
     crypto_bn_mont_redc(out, t, m, n, n0inv);
 }
 
+/* ---- modexp workspace ----
+ * BUG-0294 (A4-07) FIX: these were three file-static 576 B arrays shared by
+ * every crypto_bn_mod_exp call, making the whole bignum layer (RSA verify
+ * in tls/ssh/x509, ECDSA scalar math) non-reentrant: an interleaved call
+ * trampled the accumulator/base/modulus mid-exponentiation and could flip
+ * verification results either way. They are now per-call locals (3 x 576 B
+ * on the caller's stack, kthread stacks are 24 KiB); no cli window is
+ * needed because there is no shared state left at all, and modexp runs
+ * with interrupts enabled as before (a seconds-long cli window would stall
+ * IRQ0 timekeeping). */
 
 int crypto_bn_mod_exp(u8 *out, int out_len,
                const u8 *base, int base_len,
```

## BUG-0295 (P2, p2fix4-G1) — commit d01bf5a
- Location: crypto_x509.c:470-472
- Issue: + crypto_ec_nist.c:485-552   ecdsa_verify 不校验公钥在曲线上（防御深度缺失）
- BEFORE hunk:
```

```
- AFTER hunk:
```
+/* Host-side regression test for the WP-10-AUDIT_P2-fix4 crypto batch
+ * (BUG-0295..0298). NOT part of the kernel build.
+ *
+ * Covers:
+ *   BUG-0295 (A4-08): ecdsa_verify rejects public keys that are not a point
+ *                     on the curve (defense in depth).
+ *   BUG-0296 (A4-09): crypto_x25519_shared fails closed on the all-zero
+ *                     shared secret (RFC 8446 7.4.3 small-order peer keys).
+ *   BUG-0297 (A4-10): crypto_bn_mod_bytes validates out_len BEFORE the
+ *                     big-endian store (no stack overflow for 577..583).
+ *   BUG-0298 (A4-11): hkdf_expand / crypto_dh_modexp_n / crypto_bn_mod
+ *                     fail closed (deterministic zero output) and bound
+ *                     their frame-based work buffers.
+ *
+ * Build:
+ *   gcc -O2 -Ikernel -Ikernel/mem -Ikernel/lib -Ikernel/crypto \
+ *       tests/host_fix4_crypto_test.c kernel/crypto/crypto_bn.c \
+ *       kernel/crypto/crypto_ec_nist.c kernel/crypto/crypto_curve25519.c \
+ *       kernel/crypto/crypto_core.c kernel/crypto/crypto_sha512.c \
+ *       -o /tmp/fix4_crypto_test
+ * (do NOT link kernel/lib/lib_string.c: its libc-named definitions
+ * interpose glibc an
```

## BUG-0296 (P2, p2fix4-G1) — commit d01bf5a
- Location: crypto_curve25519.c:175-231
- Issue: + crypto_curve25519.h:16-19   X25519 无全零共享密钥检查，且调用方也未检查
- BEFORE hunk:
```
 }
 
 int crypto_x25519_shared(const u8 priv[32], const u8 peer_pub[32], u8 shared[32]) {
-    return x25519(shared, priv, peer_pub);
 }
```
- AFTER hunk:
```
 }
 
 int crypto_x25519_shared(const u8 priv[32], const u8 peer_pub[32], u8 shared[32]) {
+    int rc = x25519(shared, priv, peer_pub);
+    if (rc != 0) return rc;
+    /* BUG-0296 (A4-09) / RFC 8446 section 7.4.3: a peer public key of small
+     * order collapses the shared secret to the all-zero value. The function
+     * now fails closed itself (constant-time check) instead of leaving the
+     * RFC-mandated check to every caller - net_tls/net_ssh/net_sshd already
+     * treat a non-zero return as a handshake failure. */
+    u8 acc = 0;
+    for (int i = 0; i < 32; i++) acc |= shared[i];
+    if (acc == 0) return -1;
+    return 0;
 }
```

## BUG-0297 (P2, p2fix4-G1) — commit d01bf5a
- Location: crypto_bn.c:282-286
- Issue: crypto_bn_mod_bytes：上限检查在使用之后（潜在栈溢出写）
- BEFORE hunk:
```
 int crypto_bn_mod_bytes(u8 *out, int out_len, const u8 *x, int x_len,
                  const u8 *m, int m_len) {
     if (m_len <= 0 || m_len > BN_MAX_BYTES || x_len > BN_MAX_BYTES) return -1;
     int xn = (x_len + 7) / 8;
     int mn = (m_len + 7) / 8;
     int nn = (xn > mn) ? xn : mn;
```
- AFTER hunk:
```
 int crypto_bn_mod_bytes(u8 *out, int out_len, const u8 *x, int x_len,
                  const u8 *m, int m_len) {
     if (m_len <= 0 || m_len > BN_MAX_BYTES || x_len > BN_MAX_BYTES) return -1;
+    /* BUG-0297 (A4-10): out_len is validated BEFORE the big-endian store so a
+     * caller passing an oversized out_len can never run crypto_bn_to_be into
+     * tmp with on > sizeof(tmp) (the old order wrote first and checked after:
+     * out_len in (BN_MAX_BYTES, (BN_MAX_BYTES+7)/8*8] overwrote up to 7 stack
+     * bytes past tmp before returning -1). */
+    if (out_len <= 0 || out_len > BN_MAX_BYTES) return -1;
     int xn = (x_len + 7) / 8;
     int mn = (m_len + 7) / 8;
     int nn = (xn > mn) ? xn : mn;
```

## BUG-0298 (P2, p2fix4-G1) — commit d01bf5a
- Location: crypto_core.c:386-393
- Issue: + 596-607   分配失败静默返回（密钥材料为垃圾）+ 帧大小假设
- BEFORE hunk:
```
  * HKDF-Expand (RFC 5869)
  * ============================================================ */
 void hkdf_expand(const u8 *prk, int prk_len, const u8 *info, int info_len, u8 *out, int out_len) {
     u8 counter = 1;
     int offset = 0;
     u8 prev[32];
     int prev_len = 0;
     while (offset < out_len) {
         /* T(i) = HMAC(prk, T(i-1) || info || counter) */
-        u8 *msg = (u8 *)(uintptr_t)mem_pmm_alloc_frame();
-        if (!msg) return;
         int mlen = 0;
         if (prev_len > 0) { memcpy(msg, prev, prev_len); mlen += prev_len; }
         if (info_len > 0) { memcpy(msg + mlen, info, info_len); mlen += info_len; }
         msg[mlen++] = counter;
         crypto_hmac_sha256(prk, prk_len, msg, mlen, prev);
-        mem_pmm_free_frame((u64)(uintptr_t)msg);
         int copy = out_len - offset;
         if (copy > 32) copy = 32;
         memcpy(out + offset, prev, copy);
```
- AFTER hunk:
```
  * HKDF-Expand (RFC 5869)
  * ============================================================ */
 void hkdf_expand(const u8 *prk, int prk_len, const u8 *info, int info_len, u8 *out, int out_len) {
+    /* BUG-0298 (A4-11): fail-closed rewrite.
+     *  - the T(i) message buffer is allocated ONCE before the loop (the old
+     *    code allocated a fresh frame per block, so a mid-loop PMM exhaustion
+     *    returned after having written only the first blocks of `out`, leaving
+     *    the tail as caller-controlled garbage with no error code);
+     *  - info_len is bounded so prev(32) + info + counter always fits one
+     *    4 KiB frame;
+     *  - every failure path zeroes the WHOLE out buffer: callers that ignore
+     *    the void status now see deterministic all-zero key material instead
+     *    of stack garbage (TLS sessions built on it fail their Finished MAC
+     *    and abort instead of shipping a half-random key). */
+    if (out_len < 0) return;
+    if (out_len > 0) memset(out, 0, out_len);
+    if (prk_len <= 0 || prk_len > 32 || info_len < 0 || out_len <= 0) return;
+    if (info_len > PMM_PAGE_SIZE - 33) return;   /* 32 prev + info + 1 counter */
+    u8 *m
```

## BUG-0299 (P2, p2fix4-G2) — commit 8a08d40
- Location: kernel/ota/ota_ab.c:64
- Issue: ,343-350（+ l1/l1_ext.h:160、ota_ab.c:1005）  版本缓冲 64B 修复不完整（任务专项核对项）
- BEFORE hunk:
```
 
 /* last update-check result cache (for status) */
 static int  g_last_check_rc = -100;  /* -100 = never checked          */
-static char g_last_check_version[32];
 
 /* ------------------------------------------------------------------ */
 /* 1. partition block devices                                          */
```
- AFTER hunk:
```
 
 /* last update-check result cache (for status) */
 static int  g_last_check_rc = -100;  /* -100 = never checked          */
+static char g_last_check_version[64];   /* BUG-0299 (A5-10): matches ota_update_info_t.version[64]; 32 truncated the official 44-char version in update --status */
 
 /* ------------------------------------------------------------------ */
 /* 1. partition block devices                                          */
```

## BUG-0300 (P2, p2fix4-G2) — commit 8a08d40
- Location: kernel/lib/lib_tar.c:152-158
- Issue: （另 96-106）  逻辑：非普通条目带 body 时不同步跳过
- BEFORE hunk:
```
         return 0;
     }
     if (type != '0' && type != '\0' && type != '7') {
-        /* hard/symlink/special entries carry no body here: skip them */
         t->file_type = OC_TAR_FILE;
-        t->file_size = 0;
-        t->file_size_total = 0;
-        t->state = (size > 0) ? TS_PADDING : TS_HEADER;
         return 0;
     }
 
```
- AFTER hunk:
```
         return 0;
     }
     if (type != '0' && type != '\0' && type != '7') {
+        /* hard/symlink/special/pax-metadata ('x'/'g') entries: no callback,
+         * and their body MUST be skipped by the size the header declares.
+         * BUG-0300 (A5-11): the old code zeroed file_size, so a size>0 body
+         * ('x'/'g' pax headers, GNU 'K') went straight back to TS_HEADER and
+         * the body blocks were parsed as headers - almost always a bogus
+         * ERR_CSUM that rejected the whole package. file_size now carries
+         * body + padding for the TS_PADDING skip. */
         t->file_type = OC_TAR_FILE;
+        u64 pad = (TAR_BLOCK - (size & (TAR_BLOCK - 1))) & (TAR_BLOCK - 1);
+        t->file_size = size + pad;
+        t->file_size_total = size;
+        t->state = (t->file_size > 0) ? TS_PADDING : TS_HEADER;
         return 0;
     }
 
```

## BUG-0301 (P2, p2fix4-G2) — commit 8a08d40
- Location: kernel/lib/lib_tar.c:165-169
- Issue: + kernel/ota/ota_ab.c:822-847   逻辑：空文件被安装器丢弃
- BEFORE hunk:
```
         return 0;
     }
     if (type != '0' && type != '\0' && type != '7') {
-        /* hard/symlink/special entries carry no body here: skip them */
         t->file_type = OC_TAR_FILE;
-        t->file_size = 0;
-        t->file_size_total = 0;
-        t->state = (size > 0) ? TS_PADDING : TS_HEADER;
         return 0;
     }
 
```
- AFTER hunk:
```
         return 0;
     }
     if (type != '0' && type != '\0' && type != '7') {
+        /* hard/symlink/special/pax-metadata ('x'/'g') entries: no callback,
+         * and their body MUST be skipped by the size the header declares.
+         * BUG-0300 (A5-11): the old code zeroed file_size, so a size>0 body
+         * ('x'/'g' pax headers, GNU 'K') went straight back to TS_HEADER and
+         * the body blocks were parsed as headers - almost always a bogus
+         * ERR_CSUM that rejected the whole package. file_size now carries
+         * body + padding for the TS_PADDING skip. */
         t->file_type = OC_TAR_FILE;
+        u64 pad = (TAR_BLOCK - (size & (TAR_BLOCK - 1))) & (TAR_BLOCK - 1);
+        t->file_size = size + pad;
+        t->file_size_total = size;
+        t->state = (t->file_size > 0) ? TS_PADDING : TS_HEADER;
         return 0;
     }
 
```

## BUG-0302 (P2, p2fix4-G2) — commit 8a08d40
- Location: kernel/ota/ota_ab.c:1010-1013
- Issue: ,1106-1115   错误处理/安全设计：--local 校验形同虚设
- BEFORE hunk:
```
 
     /* manifest checks: version present + payload checksum */
     if (ictx.manifest_len == 0) return OC_UPDATE_E_TARGZ;
-    char mver[32];
     char msha[80];
     if (ota_update_json_string(ictx.manifest, "version", mver,
                               (int)sizeof(mver)) != 0)
         return OC_UPDATE_E_TARGZ;
     if (ota_update_json_string(ictx.manifest, "sha256", msha,
-                              (int)sizeof(msha)) == 0) {
-        if (!sha_hex_eq(pkg_digest, msha)) return OC_UPDATE_E_SHA;
-    }
     return 0;
 }
 
```
- AFTER hunk:
```
 
     /* manifest checks: version present + payload checksum */
     if (ictx.manifest_len == 0) return OC_UPDATE_E_TARGZ;
+    char mver[64];   /* BUG-0299 (A5-10): 32 rejected official 44-char versions at parse time */
     char msha[80];
     if (ota_update_json_string(ictx.manifest, "version", mver,
                               (int)sizeof(mver)) != 0)
         return OC_UPDATE_E_TARGZ;
+    /* BUG-0302 (A5-13): the manifest sha256 is no longer optional. A package
+     * without the field used to skip verification entirely (and --local still
+     * printed "verifying SHA256... OK"), making --local install a purely
+     * structural check. The field is now mandatory and must match the
+     * digest computed over the installed file bodies. Honest scope note: the
+     * manifest travels inside the package, so this is an integrity check
+     * against truncation/corruption, not an authenticity signature. */
     if (ota_update_json_string(ictx.manifest, "sha256", msha,
+                              (int)sizeof(msha)) != 0)
+        return OC_UPDATE_E_SHA;
+    if (!sha_hex_eq(pkg_digest, msha)) return OC_UPDATE_E_SHA;
     return 0;
 }
 
```

## BUG-0303 (P2, p2fix4-G2) — commit 8a08d40
- Location: tools/host_gzip_test.c:14-34
- Issue: 工具损坏（重构遗留）
- BEFORE hunk:
```
 /* SPDX-License-Identifier: Apache-2.0 */
-/* Host-side debug harness for kernel/gzip.c + kernel/tar.c (WP-10u). */
 #include <stdio.h>
-#include <string.h>
 #include <stdlib.h>
 #include <stdint.h>
 #include "kernel/types.h"
 
-/* host kmalloc shim */
-static void *kmalloc(u64 n) { return malloc(n); }
-static void kfree(void *p) { free(p); }
 
-/* oc_* string shims (kernel/string.h declares them) */
-void *memset(void *d, int c, usize n) { return memset(d, c, n); }
-void *memcpy(void *d, const void *s, usize n) { return memcpy(d, s, n); }
-int   memcmp(const void *a, const void *b, usize n) { return memcmp(a, b, n); }
-usize strlen(const char *s) { return strlen(s); }
-int   strcmp(const char *a, const char *b) { return strcmp(a, b); }
-int   strncmp(const char *a, const char *b, usize n) { return strncmp(a, b, n); }
-char *strcpy(char *d, const char *s) { return strcpy(d, s); }
-char *strncpy(char *d, const char *s, usize n) {
-    strncpy(d, s, n);
-    if (n > 0) d[n - 1] = 0;
-    return d;
-}
-usize u64_to_str(u64 v, char *out) { sprintf(out, "%llu", (unsigned long long)v); return strlen(out); }
 static int run_one(const char *name, const u8 *gz, int len, const char *expect,
```
- AFTER hunk:
```
 /* SPDX-License-Identifier: Apache-2.0 */
+/* Host-side debug harness for kernel/lib/lib_gzip.c + kernel/lib/lib_tar.c.
+ *
+ * BUG-0303 (A5-14) repair history: the WP-10 project restructure moved
+ * kernel/gzip.c to kernel/lib/lib_gzip.c and kernel/tar.c to
+ * kernel/lib/lib_tar.c, so this harness #include-ed files that no longer
+ * existed (the WP-10u gzip/tar regression was dead since then). The
+ * restructure script had also mechanically renamed the old correct
+ * oc_memset->libc forwarding shims into `memset` CALLING ITSELF - guaranteed
+ * infinite recursion even once the include paths were fixed. That class of
+ * libc-shadowing shim is gone entirely: glibc provides memset/memcpy/strcmp/
+ * ... and the kernel sources bind to it (usize == size_t on this platform).
+ * The strncpy shim that forced d[n-1] = 0 (masking real kernel strncpy
+ * semantics, see A5-08/A5-14) is gone with it.
+ *
+ * NOTE: do NOT include <string.h> in this TU - lib_string.h (pulled in by
+ * the kernel sources) declares strchr with a kernel signature that
+ * conflicts with glibc's, which hard-errors the build.
+ *
+ * Build (from oc-os/):
+ *   gcc -O2 -I. -Ikernel/lib -Ikernel/mem tools/host_
```

## BUG-0304 (P2, p2fix4-G2) — commit 8a08d40
- Location: kernel/ota/ota_ab.c:497
- Issue: ,510-511,637-641,646,653-659   错误处理：下载路径不查写返回值 + Content-Length 整型溢出
- BEFORE hunk:
```
             /* body bytes already received with the header */
             int blen = hlen - (header_end + 4);
             if (blen > 0) {
-                fs_vfs_write(fd, hdr + header_end + 4, blen);
-                total += blen;
             }
         }
         kfree(hdr);
```
- AFTER hunk:
```
             /* body bytes already received with the header */
             int blen = hlen - (header_end + 4);
             if (blen > 0) {
+                /* BUG-0304 (A5-15): a failed write must abort the download -
+                 * a silently short package used to be counted as received. */
+                int w = fs_vfs_write(fd, hdr + header_end + 4, blen);
+                if (w != blen) err = OC_UPDATE_E_IO;
+                else total += blen;
             }
         }
         kfree(hdr);
```

## BUG-0305 (P2, p2fix4-G3) — commit a4ba09d
- Location: kernel/ota/ota_ab.h:69-71
- Issue: + grub-ab.cfg:25-38   设计：无启动尝试计数，bootfail 兜不住"起不来"的 B
- BEFORE hunk:
```
 #define OC_AB_FLAG_OK_B        "/boot/ok_B"
 #define OC_AB_FLAG_BOOTFAIL_B  "/boot/bootfail_B"
 
 /* Default location of a downloaded update package. */
 #define OC_UPDATE_PKG_PATH  "/data/update-pkg.tar.gz"
 #define OC_UPDATE_PKG_TMP   "/tmp/update-pkg.tar.gz"
```
- AFTER hunk:
```
 #define OC_AB_FLAG_OK_B        "/boot/ok_B"
 #define OC_AB_FLAG_BOOTFAIL_B  "/boot/bootfail_B"
 
+/* BUG-0305 (A5-16): boot-attempt budget for slot B.
+ *
+ * bootfail_B is written by the B kernel ITSELF once it runs; a B image that
+ * never comes up at all (corrupt ELF, crash before ota_ab_init) would loop
+ * forever under the old protocol. The disk GRUB config therefore counts
+ * attempts in the standard GRUB environment block
+ *   /boot/grub/grubenv  (1024 bytes, "ab_attempts" variable)
+ * which tools/make_ab_disk.sh pre-creates on the flags partition:
+ *   - every B boot attempt increments ab_attempts (GRUB save_env);
+ *   - at OC_AB_MAX_ATTEMPTS (3) GRUB boots slot A instead and the pending
+ *     request is burned;
+ *   - the kernel resets ab_attempts to 0 when slot A finishes booting or
+ *     slot B confirms (ab_reset_boot_attempts), so the next update starts
+ *     from a clean slate;
+ *   - the disk grub.cfg also falls back to slot A within the same boot
+ *     when the B multiboot2 image cannot even be loaded. */
+#define OC_AB_GRUBENV_PATH     "/boot/grub/grubenv"
+#define OC_AB_MAX_ATTEMPTS     3
+
 /* Default location of a downloaded update package. */
 
```

## BUG-0306 (P2, p2fix4-G4) — commit c106755
- Location: driver_block_virtio_blk.c:373-377
- Issue: used ring 轮询无超时 → 设备不完成即整机死循环
- BEFORE hunk:
```
     /* Notify the queue. outl is serialising on x86 -> full barrier. */
     outw((u16)(d->io_base + VIRTIO_REG_QUEUE_NOTIFY), 0);
 
-    /* Poll the used ring until the device advances its idx. */
-    while (d->last_used_idx == d->used->idx) {
-        /* spin */
     }
     d->last_used_idx = d->used->idx;
 
```
- AFTER hunk:
```
     /* Notify the queue. outl is serialising on x86 -> full barrier. */
     outw((u16)(d->io_base + VIRTIO_REG_QUEUE_NOTIFY), 0);
 
+    /* Poll the used ring until the device advances its idx.
+     * BUG-0306 (A6-10): bounded wait - the open-ended spin hung the whole
+     * machine whenever the device stopped completing requests. */
+    {
+        u64 t0 = core_timer_ticks();
+        while (d->last_used_idx == d->used->idx) {
+            if (core_timer_ticks() - t0 > VIRTIO_BLK_TIMEOUT_TICKS) {
+                driver_block_virtio_blk_log("virtio-blk: used-ring poll timeout\n");
+                (void)inb((u16)(d->io_base + VIRTIO_REG_ISR));
+                return -1;
+            }
+        }
     }
     d->last_used_idx = d->used->idx;
 
```

## BUG-0307 (P2, p2fix4-G4) — commit c106755
- Location: driver_block_virtio_blk.c:226-229
- Issue: , 323-333, 405-408   完全不读 host features：FLUSH 未协商就下发、RO 盘不识别
- BEFORE hunk:
```
     /* 2-3. ACK | DRIVER. */
     driver_block_virtio_blk_status_set(io_base, (u8)(VIRTIO_STATUS_ACK | VIRTIO_STATUS_DRIVER));
 
-    /* 4. Feature negotiation: we accept none of the optional features.
-     * Reset already cleared the guest feature mask, so no write to
-     * GUEST_FEATURES is needed (an explicit 0 write here clears the
-     * device status on QEMU 10, so it is deliberately skipped). */
 
     /* 5. Select queue 0, read size.  (WP-10a: DRIVER_OK is set only
      * AFTER the queue is live -- setting it before the queue is active
```
- AFTER hunk:
```
     /* 2-3. ACK | DRIVER. */
     driver_block_virtio_blk_status_set(io_base, (u8)(VIRTIO_STATUS_ACK | VIRTIO_STATUS_DRIVER));
 
+    /* 4. Feature negotiation.
+     * BUG-0307 (A6-11): we previously accepted NO optional features yet
+     * still issued T_FLUSH requests - a spec-conformant device answers
+     * those with VIRTIO_BLK_S_UNSUPP, so driver_block_flush() failed on
+     * every conformant device, and a read-only disk went undetected.
+     * Read HOST_FEATURES and accept exactly the two bits we act on. (An
+     * explicit 0 write to GUEST_FEATURES clears the device status on QEMU
+     * 10, so the write only happens when at least one bit is accepted.) */
+    {
+        u32 host = inl((u16)(io_base + VIRTIO_REG_HOST_FEATURES));
+        u32 want = 0;
+        if (host & VIRTIO_BLK_F_FLUSH) { want |= VIRTIO_BLK_F_FLUSH; g_dev.has_flush = 1; }
+        if (host & VIRTIO_BLK_F_RO)    { g_dev.readonly = 1; }
+        if (want)
+            outl((u16)(io_base + VIRTIO_REG_GUEST_FEATURES), want);
+        if (g_dev.readonly)
+            driver_block_virtio_blk_log("virtio-blk: device is read-only\n");
+    }
 
     /* 5. Select queue 0, read size.  (WP-10a: DRIVER_OK i
```

## BUG-0308 (P2, p2fix4-G4) — commit c106755
- Location: driver_block_virtio_blk.c:391
- Issue: , 401   `count * 512u` u32 乘法溢出（重点整数安全类，当前堆上限下不可达）
- BEFORE hunk:
```
     driver_block_virtio_blk_dev_t *d = (driver_block_virtio_blk_dev_t *)dev->priv;
     if (!d || !d->io_base) return -1;
     if (count == 0) return 0;
     return driver_block_virtio_blk_xfer(d, VIRTIO_BLK_T_IN, lba, buf,
-                           count * VIRTIO_BLK_SECTOR_SIZE);
 }
 
 static int driver_block_virtio_blk_write(driver_block_device_t *dev, u64 lba, u32 count, const void *buf) {
     driver_block_virtio_blk_dev_t *d = (driver_block_virtio_blk_dev_t *)dev->priv;
     if (!d || !d->io_base) return -1;
     if (count == 0) return 0;
     /* Cast away const: the device reads from this memory during a write
      * request, so we never mutate it. */
     return driver_block_virtio_blk_xfer(d, VIRTIO_BLK_T_OUT, lba, (void *)buf,
-                           count * VIRTIO_BLK_SECTOR_SIZE);
 }
 
 /* WP-10a: flush hook - issue VIRTIO_BLK_T_FLUSH. */
 static int driver_block_virtio_blk_flush(driver_block_device_t *dev) {
     driver_block_virtio_blk_dev_t *d = (driver_block_virtio_blk_dev_t *)dev->priv;
     if (!d || !d->io_base) return -1;
     return driver_block_virtio_blk_xfer(d, VIRTIO_BLK_T_FLUSH, 0, NULL, 0);
 }
```
- AFTER hunk:
```
     driver_block_virtio_blk_dev_t *d = (driver_block_virtio_blk_dev_t *)dev->priv;
     if (!d || !d->io_base) return -1;
     if (count == 0) return 0;
+    /* BUG-0308 (A6-12): count * 512 must be computed in 64 bits - a u32
+     * product wrapped for count >= 2^23 and the truncated request completed
+     * with status 0 while transferring far less data. Refuse instead of
+     * silently short-changing the caller. */
+    u64 bytes = (u64)count * VIRTIO_BLK_SECTOR_SIZE;
+    if (bytes > 0xFFFFFFFFull) return -1;
     return driver_block_virtio_blk_xfer(d, VIRTIO_BLK_T_IN, lba, buf,
+                           (u32)bytes);
 }
 
 static int driver_block_virtio_blk_write(driver_block_device_t *dev, u64 lba, u32 count, const void *buf) {
     driver_block_virtio_blk_dev_t *d = (driver_block_virtio_blk_dev_t *)dev->priv;
     if (!d || !d->io_base) return -1;
     if (count == 0) return 0;
+    if (d->readonly) {
+        driver_block_virtio_blk_log("virtio-blk: write rejected (device is read-only)\n");
+        return -1;
+    }
     /* Cast away const: the device reads from this memory during a write
      * request, so we never mutate it. */
+    u64 bytes = (u64)count * VIRTIO
```

## BUG-0309 (P2, p2fix4-G4) — commit c106755
- Location: driver_block_part.c:144-146
- Issue: , 118-124   GPT 项校验不足：无 CRC32、无 first/last 排序校验、不与盘容量核对
- BEFORE hunk:
```
         need = (u64)num_entries * (u64)entry_size;
     }
     u32 sectors_to_read = (u32)((need + 511) / 512);
     if (sectors_to_read > 8) sectors_to_read = 8;
     if (driver_block_read_sectors_raw(dev_idx, entry_start, sectors_to_read, entry_buf) != 0) return -1;
 
     for (u32 i = 0; i < num_entries; i++) {
         gpt_entry_t *e = (gpt_entry_t *)(entry_buf + (u64)i * entry_size);
```
- AFTER hunk:
```
         need = (u64)num_entries * (u64)entry_size;
     }
     u32 sectors_to_read = (u32)((need + 511) / 512);
+    /* BUG-0309 (A6-13): when the FULL on-disk entry array (spec size)
+     * fits the buffer, read enough sectors to verify its CRC32 even if
+     * the clamped entry count reads fewer. */
+    u64 spec_bytes = (u64)gh->num_entries * (u64)gh->entry_size;
+    if (spec_bytes > need && spec_bytes <= sizeof(entry_buf))
+        sectors_to_read = (u32)((spec_bytes + 511) / 512);
     if (sectors_to_read > 8) sectors_to_read = 8;
     if (driver_block_read_sectors_raw(dev_idx, entry_start, sectors_to_read, entry_buf) != 0) return -1;
+    /* BUG-0309 (A6-13): the partition entry array carries its own CRC32.
+     * The spec CRC covers num_entries*entry_size bytes; the checksum is
+     * enforced whenever the whole array fits the bytes actually read.
+     * A WRONG CRC means a torn array - refuse the table instead of
+     * registering phantom partitions. Zero is tolerated (some tools
+     * leave it 0). */
+    if (gh->entries_crc32 != 0 &&
+        spec_bytes <= (u64)sectors_to_read * 512 &&
+        driver_block_part_crc32(entry_buf, spec_bytes) != gh->entries_crc32
```

## BUG-0310 (P2, p2fix4-G4) — commit c106755
- Location: driver_block_part.c:189-199
- Issue: 分区子设备读写不做 lba+count ≤ sectors 边界检查
- BEFORE hunk:
```
     return 0;
 }
 
 int driver_block_part_parse_gpt(int dev_idx, driver_block_part_table_t *out) {
     if (!out) return -1;
     memset(out, 0, sizeof(*out));
     out->dev_idx = dev_idx;
     out->table_type = PART_TYPE_GPT;
 
     u8 buf[512];
     /* Read GPT header at LBA 1. */
     if (driver_block_read_sectors_raw(dev_idx, 1, 1, buf) != 0) return -1;
     gpt_header_t *gh = (gpt_header_t *)buf;
     if (memcmp(gh->sig, "EFI PART", 8) != 0) return -1;
 
     u32 num_entries = gh->num_entries;
     u32 entry_size = gh->entry_size;
     u64 entry_start = gh->driver_block_part_entry_start;
```
- AFTER hunk:
```
     return 0;
 }
 
+/* BUG-0309 (A6-13): IEEE CRC32 (bitwise, same polynomial as gzip) used
+ * for the GPT header and partition-entry-array checksums. */
+static u32 driver_block_part_crc32(const u8 *buf, u64 len) {
+    u32 crc = 0xFFFFFFFFu;
+    for (u64 i = 0; i < len; i++) {
+        crc ^= buf[i];
+        for (int k = 0; k < 8; k++)
+            crc = (crc >> 1) ^ (0xEDB88320u & (u32)(-(int)(crc & 1)));
+    }
+    return ~crc;
+}
+
 int driver_block_part_parse_gpt(int dev_idx, driver_block_part_table_t *out) {
     if (!out) return -1;
     memset(out, 0, sizeof(*out));
     out->dev_idx = dev_idx;
     out->table_type = PART_TYPE_GPT;
 
+    /* BUG-0309 (A6-13): the parent capacity for the per-entry range check. */
+    driver_block_device_t *pdev = driver_block_get_device(dev_idx);
+    u64 disk_sectors = pdev ? pdev->sectors : 0;
+
     u8 buf[512];
     /* Read GPT header at LBA 1. */
     if (driver_block_read_sectors_raw(dev_idx, 1, 1, buf) != 0) return -1;
     gpt_header_t *gh = (gpt_header_t *)buf;
     if (memcmp(gh->sig, "EFI PART", 8) != 0) return -1;
 
+    /* BUG-0309 (A6-13): validate the header before trusting any field in
+     * it. Header CRC covers Hea
```

## BUG-0311 (P2, p2fix4-G4) — commit c106755
- Location: driver_block_disk_setup.c:333-350
- Issue: （对照 install 的 495 行）  abdisk 不检查父盘整盘挂载
- BEFORE hunk:
```
         return 1;
     }
     /* Refuse when any of this disk's partitions is currently mounted
-     * (the old FAT would stay cached in VFS while we reformat below). */
     for (int p = 1; p <= 4; p++) {
         char pname[BLK_DEV_NAME_LEN];
         strncpy(pname, dev->name, BLK_DEV_NAME_LEN - 4);
```
- AFTER hunk:
```
         return 1;
     }
     /* Refuse when any of this disk's partitions is currently mounted
+     * (the old FAT would stay cached in VFS while we reformat below).
+     * BUG-0311 (A6-15): also refuse when the WHOLE DISK is mounted as a
+     * superfloppy (install has checked driver_block_part_is_mounted(dev->name)
+     * since its BUG-017 fix; abdisk only checked p1..p4, so it happily
+     * rewrote the MBR under an active whole-disk FAT32 mount). */
+    if (driver_block_part_is_mounted(dev->name)) {
+        driver_block_disk_setup_puts("abdisk: whole-disk mount on ");
+        driver_block_disk_setup_puts(dev->name);
+        driver_block_disk_setup_puts(" is active (reboot to release mounts, "
+                        "then retry)\n");
+        return 1;
+    }
     for (int p = 1; p <= 4; p++) {
         char pname[BLK_DEV_NAME_LEN];
         strncpy(pname, dev->name, BLK_DEV_NAME_LEN - 4);
```

## BUG-0312 (P2, p2fix4-G4) — commit c106755
- Location: driver_block_disk_setup.c:508
- Issue: install 分区大小 64→32 位截断，>2TiB 盘不拒绝
- BEFORE hunk:
```
     driver_block_disk_setup_puts(dev->name);
     driver_block_disk_setup_puts(" will be destroyed\n");
 
-    /* 1. MBR: one FAT32 partition from LBA 2048 to the end. */
     u8 types[4] = { 0x0B, 0, 0, 0 };
     u32 starts[4] = { 2048, 0, 0, 0 };
     u32 sect[4] = { (u32)(dev->sectors - 2048), 0, 0, 0 };
```
- AFTER hunk:
```
     driver_block_disk_setup_puts(dev->name);
     driver_block_disk_setup_puts(" will be destroyed\n");
 
+    /* 1. MBR: one FAT32 partition from LBA 2048 to the end.
+     * BUG-0312 (A6-16): the size used to be cast straight to u32, so a
+     * >2 TiB disk silently produced a wrapped-around small partition.
+     * MBR cannot express >2 TiB at all - refuse instead of lying. */
+    if (dev->sectors <= 2048 || (dev->sectors - 2048) > 0xFFFFFFFFull) {
+        driver_block_disk_setup_puts("install: disk too large for MBR (>2TiB) or too small\n");
+        return 1;
+    }
     u8 types[4] = { 0x0B, 0, 0, 0 };
     u32 starts[4] = { 2048, 0, 0, 0 };
     u32 sect[4] = { (u32)(dev->sectors - 2048), 0, 0, 0 };
```

## BUG-0313 (P2, p2fix4-G4) — commit c106755
- Location: driver_block_blk.c:32
- Issue: /53-57/125   unregister 后 g_blk_count 不回缩：满表注销一个后无法再注册；注销不清 name/ops/stats
- BEFORE hunk:
```
 
 int driver_block_unregister_device(int index) {
     if (index < 0 || index >= BLK_MAX_DEVICES) return -1;
-    g_blk_devs[index].present = 0;
     return 0;
 }
 
```
- AFTER hunk:
```
 
 int driver_block_unregister_device(int index) {
     if (index < 0 || index >= BLK_MAX_DEVICES) return -1;
+    driver_block_device_t *d = &g_blk_devs[index];
+    if (!d->present) return -1;
+    d->present = 0;
+    /* BUG-0313 (A6-17): unregister used to only clear `present`, leaving
+     * name/ops/priv and the per-slot stats behind, and never shrank
+     * g_blk_count - once all 8 slots had been used, a later unregister +
+     * register failed forever with -ENOSPC even though a slot was free.
+     * Clear the stale identity, reset the per-slot stats, and shrink the
+     * high-water mark while the top slots are all free. */
+    d->name[0] = 0;
+    d->ops = NULL;
+    d->priv = NULL;
+    memset(&g_blk_stats[index], 0, sizeof(g_blk_stats[index]));
+    while (g_blk_count > 0 && !g_blk_devs[g_blk_count - 1].present)
+        g_blk_count--;
     return 0;
 }
 
```

## BUG-0314 (P2, p2fix4-G4) — commit c106755
- Location: driver_block_cache.c
- Issue: 全文件 + driver_block_blk.c 缓存路径   块缓存全程无锁（并发任务 I/O 竞态）
- BEFORE hunk:
```
 #include "driver_block_cache.h"
 #include "driver_block_blk.h"
 #include "core_timer.h"
 #include "mem_heap.h"
 #include "lib_string.h"
 #include "screen_console.h"
```
- AFTER hunk:
```
 #include "driver_block_cache.h"
 #include "driver_block_blk.h"
 #include "core_timer.h"
+#include "core_sync.h"
 #include "mem_heap.h"
 #include "lib_string.h"
 #include "screen_console.h"
```

## BUG-0315 (P2, p2fix4-G5) — commit dd0882f
- Location: driver_block_ata_dma.c:99-103
- Issue: , 221-225, 391   BMDMA PRD 构造违反 PCI IDE 规范：EOT 位放错 + 计数 off-by-one + 未用表项不清零
- BEFORE hunk:
```
 static const int g_drive_chan[4] = { 0, 0, 1, 1 };  /* BMDMA channel */
 static const u8  g_drive_slave[4] = { 0, 1, 0, 1 };
 
-/* PRDT: 8 entries x 8 bytes, 4-byte aligned. */
 #define PRDT_MAX 8
 typedef struct __attribute__((packed)) {
     u32 addr;
-    u16 count_eot;   /* bits 14:0 = byte count, bit 15 = EOT */
-    u16 rsvd;
 } driver_block_ata_dma_prdt_t;
 
 /* Command can move at most 64 KiB (PRDT 16-bit count) - we use one entry
```
- AFTER hunk:
```
 static const int g_drive_chan[4] = { 0, 0, 1, 1 };  /* BMDMA channel */
 static const u8  g_drive_slave[4] = { 0, 1, 0, 1 };
 
+/* PRDT: 8 entries x 8 bytes, 4-byte aligned.
+ * BUG-0315 (A6-7): entry layout per the PCI IDE (Bus Master IDE) spec -
+ * byte 0-3 address, byte 4-5 the EXACT byte count (0 encodes 64 KiB),
+ * byte 6 reserved, byte 7 bit 7 = EOT. The old layout packed EOT into
+ * the count field's bit 15 and stored bytes-1 (the AHCI DBC convention),
+ * which real PIIX/ICH controllers read as a never-ending table whose
+ * unused entries are heap garbage. */
 #define PRDT_MAX 8
+#define ATA_PRD_EOT 0x8000u
 typedef struct __attribute__((packed)) {
     u32 addr;
+    u16 byte_count;   /* exact byte count; 0 = 64 KiB */
+    u16 eot_rsvd;     /* bit 15 (byte 7 bit 7) = EOT, rest reserved 0 */
 } driver_block_ata_dma_prdt_t;
 
 /* Command can move at most 64 KiB (PRDT 16-bit count) - we use one entry
```

## BUG-0316 (P2, p2fix4-G5) — commit dd0882f
- Location: driver_block_ahci.c:428-436
- Issue: IDENTIFY 容量只取 words 100/101（32 位）→ >2TiB SATA 盘容量截断
- BEFORE hunk:
```
         driver_block_ahci_log(buf);
         return -1;
     }
-    /* Capacity: words 100/101 (48-bit LBA user-addressable sectors). */
     u16 *id = (u16 *)p->bounce;
-    u64 lo = id[100];
-    u64 hi = id[101];
-    p->sectors = lo | (hi << 16);
     /* Fall back to 28-bit capacity (words 60/61) if EXT is 0. */
     if (p->sectors == 0) {
         p->sectors = (u64)id[60] | ((u64)id[61] << 16);
```
- AFTER hunk:
```
         driver_block_ahci_log(buf);
         return -1;
     }
+    /* Capacity: words 100-103 (48-bit LBA user-addressable sectors).
+     * BUG-0316 (A6-8): only words 100/101 were consumed - bits 47:32 live
+     * in words 102/103, so a >2 TiB SATA disk reported a wrapped 32-bit
+     * capacity and its tail was unreachable. */
     u16 *id = (u16 *)p->bounce;
+    p->sectors = (u64)id[100] | ((u64)id[101] << 16) |
+                 ((u64)id[102] << 32) | ((u64)id[103] << 48);
     /* Fall back to 28-bit capacity (words 60/61) if EXT is 0. */
     if (p->sectors == 0) {
         p->sectors = (u64)id[60] | ((u64)id[61] << 16);
```

## BUG-0317 (P2, p2fix4-G5) — commit dd0882f
- Location: driver_block_nvme.c:450-451
- Issue: , 434-437   admin 队列固定 64 深不按 MQES 收缩（I/O 队列收缩了）
- BEFORE hunk:
```
 
     /* Allocate admin queues (page-aligned). */
     g_nvme.asq = (driver_block_nvme_sqe_t *)driver_block_nvme_kmalloc_page_aligned(
-        NVME_ADMIN_QSIZE * sizeof(driver_block_nvme_sqe_t));
     g_nvme.acq = (driver_block_nvme_cqe_t *)driver_block_nvme_kmalloc_page_aligned(
-        NVME_ADMIN_QSIZE * sizeof(driver_block_nvme_cqe_t));
     if (!g_nvme.asq || !g_nvme.acq) {
         driver_block_nvme_log("nvme: out of memory (admin queue)\n");
         return -1;
     }
-    memset(g_nvme.asq, 0, NVME_ADMIN_QSIZE * sizeof(driver_block_nvme_sqe_t));
-    memset(g_nvme.acq, 0, NVME_ADMIN_QSIZE * sizeof(driver_block_nvme_cqe_t));
     g_nvme.asq_tail   = 0;
     g_nvme.acq_head   = 0;
     g_nvme.acq_phase  = 1;   /* first completion phase after CC.EN=1 */
     g_nvme.admin_cid  = 1;
 
     /* Program AQA, ASQ, ACQ. */
-    u32 aqa = ((NVME_ADMIN_QSIZE - 1u) << 16) | (NVME_ADMIN_QSIZE - 1u);
     driver_block_nvme_write(&g_nvme, NVME_REG_AQA, aqa);
     {
         u64 asq_phys = (u64)(uintptr_t)g_nvme.asq;
```
- AFTER hunk:
```
 
     /* Allocate admin queues (page-aligned). */
     g_nvme.asq = (driver_block_nvme_sqe_t *)driver_block_nvme_kmalloc_page_aligned(
+        g_nvme.admin_qsize * sizeof(driver_block_nvme_sqe_t));
     g_nvme.acq = (driver_block_nvme_cqe_t *)driver_block_nvme_kmalloc_page_aligned(
+        g_nvme.admin_qsize * sizeof(driver_block_nvme_cqe_t));
     if (!g_nvme.asq || !g_nvme.acq) {
         driver_block_nvme_log("nvme: out of memory (admin queue)\n");
         return -1;
     }
+    memset(g_nvme.asq, 0, g_nvme.admin_qsize * sizeof(driver_block_nvme_sqe_t));
+    memset(g_nvme.acq, 0, g_nvme.admin_qsize * sizeof(driver_block_nvme_cqe_t));
     g_nvme.asq_tail   = 0;
     g_nvme.acq_head   = 0;
     g_nvme.acq_phase  = 1;   /* first completion phase after CC.EN=1 */
     g_nvme.admin_cid  = 1;
 
     /* Program AQA, ASQ, ACQ. */
+    u32 aqa = ((g_nvme.admin_qsize - 1u) << 16) | (g_nvme.admin_qsize - 1u);
     driver_block_nvme_write(&g_nvme, NVME_REG_AQA, aqa);
     {
         u64 asq_phys = (u64)(uintptr_t)g_nvme.asq;
```

## BUG-0318 (P2, p2fix4-G6) — commit 239f298
- Location: screen_console.c:50-53
- Issue: 整数安全（cols/rows 为 0 时状态回绕）
- BEFORE hunk:
```
 #include "screen_console.h"
 #include "screen_font.h"
 #include "screen_fb.h"
 #include "lib_string.h"
 #include "l1_ext.h"   /* for the console output hook */
 
 static screen_console_t g_console;
 
 static void draw_cell(u32 cx, u32 cy, char ch, u32 fg_pixel, u32 bg_pixel) {
     if (!screen_active_renderer) return;
```
- AFTER hunk:
```
 #include "screen_console.h"
 #include "screen_font.h"
 #include "screen_fb.h"
+#include "core_sync.h"
 #include "lib_string.h"
 #include "l1_ext.h"   /* for the console output hook */
 
 static screen_console_t g_console;
+/* BUG-0319 (A7-04): the console state (cur_x/cur_y/scroll memmoves) had no
+ * lock at all. The keyboard IRQ1 -> L1 handler chain can reach console
+ * output from interrupt context (an L1 hook that prints) while a task is
+ * mid-putc, tearing cursor state and interleaving scroll memmoves. Every
+ * state-mutating entry point now runs under one irqsave spinlock
+ * (BUG-0285 semantics). Contract: the L1 console hook must not call back
+ * into screen_console output from inside the hook (it runs before the
+ * lock is taken and re-entry would self-deadlock). */
+static spinlock_t g_console_lock;
 
 static void draw_cell(u32 cx, u32 cy, char ch, u32 fg_pixel, u32 bg_pixel) {
     if (!screen_active_renderer) return;
```

## BUG-0319 (P2, p2fix4-G6) — commit 239f298
- Location: screen_console.c
- Issue: 全文件（putc/scroll_up_one）+ driver_input_keyboard.c:239-245   并发/中断安全
- BEFORE hunk:
```
 #include "screen_console.h"
 #include "screen_font.h"
 #include "screen_fb.h"
 #include "lib_string.h"
 #include "l1_ext.h"   /* for the console output hook */
 
 static screen_console_t g_console;
 
 static void draw_cell(u32 cx, u32 cy, char ch, u32 fg_pixel, u32 bg_pixel) {
     if (!screen_active_renderer) return;
```
- AFTER hunk:
```
 #include "screen_console.h"
 #include "screen_font.h"
 #include "screen_fb.h"
+#include "core_sync.h"
 #include "lib_string.h"
 #include "l1_ext.h"   /* for the console output hook */
 
 static screen_console_t g_console;
+/* BUG-0319 (A7-04): the console state (cur_x/cur_y/scroll memmoves) had no
+ * lock at all. The keyboard IRQ1 -> L1 handler chain can reach console
+ * output from interrupt context (an L1 hook that prints) while a task is
+ * mid-putc, tearing cursor state and interleaving scroll memmoves. Every
+ * state-mutating entry point now runs under one irqsave spinlock
+ * (BUG-0285 semantics). Contract: the L1 console hook must not call back
+ * into screen_console output from inside the hook (it runs before the
+ * lock is taken and re-entry would self-deadlock). */
+static spinlock_t g_console_lock;
 
 static void draw_cell(u32 cx, u32 cy, char ch, u32 fg_pixel, u32 bg_pixel) {
     if (!screen_active_renderer) return;
```

## BUG-0320 (P2, p2fix4-G6) — commit 239f298
- Location: screen_console_in.c:62-66
- Issue: + 92-99   逻辑（inject 双跑 hook）
- BEFORE hunk:
```
     if (!text) return;
     int len = 0;
     while (text[len]) len++;
-    for (int j = 0; j < OC_CONS_HOOK_LEN; j++) {
-        if (g_hooks[j]) {
-            g_hooks[j](text, len);
-        }
-    }
     /* Push each character into the keyboard queue. */
     for (int i = 0; i < len; i++) {
         char c = text[i];
```
- AFTER hunk:
```
     if (!text) return;
     int len = 0;
     while (text[len]) len++;
+    /* BUG-0320 (A7-08): the per-character hooks fired TWICE for injected
+     * lines - once here on the raw text, then again in finish_line() when
+     * the assembled line reached ENTER. A hook now sees every logical line
+     * exactly once (from finish_line, with the assembled buffer and its
+     * length, matching typed input). */
     /* Push each character into the keyboard queue. */
     for (int i = 0; i < len; i++) {
         char c = text[i];
```

## BUG-0321 (P2, p2fix4-G6) — commit 239f298
- Location: screen_console_in.c:158-167
- Issue: 并发/中断（readline lost-wakeup）
- BEFORE hunk:
```
         while (!g_line_ready && screen_console_in_pump()) pumped = 1;
         if (g_line_ready) break;
         if (pumped) continue;   /* buffer had data; drain more next spin */
-        /* Enable interrupts so keyboard IRQs fire while we wait. */
         __asm__ volatile("sti");
         __asm__ volatile("hlt");
         screen_console_in_pump();
```
- AFTER hunk:
```
         while (!g_line_ready && screen_console_in_pump()) pumped = 1;
         if (g_line_ready) break;
         if (pumped) continue;   /* buffer had data; drain more next spin */
+        /* BUG-0321 (A7-09): close most of the lost-wakeup window. A
+         * keystroke landing between the final pump() and the sti used to
+         * be consumed by its own IRQ, so the hlt then slept until the next
+         * timer tick (or, with ticks masked, until the NEXT keystroke).
+         * The decision to sleep is now cli-protected with a final pump
+         * inside the closed window, and every wake drains immediately.
+         * The residual race - an IRQ landing between sti and hlt - is
+         * bounded by the IRQ0 tick waking the hlt. */
+        __asm__ volatile("cli");
+        if (g_line_ready || screen_console_in_pump()) {
+            __asm__ volatile("sti");
+            continue;
+        }
         __asm__ volatile("sti");
         __asm__ volatile("hlt");
         screen_console_in_pump();
```

## BUG-0322 (P2, p2fix4-G6) — commit 239f298
- Location: screen_fb.c:12-38
- Issue: 错误处理（fb_init 校验不足）
- BEFORE hunk:
```
     if (f->framebuffer_bpp != 32) {
         return -3;
     }
     g_fb.addr   = (u8*)(uintptr_t)f->framebuffer_addr;
     g_fb.pitch  = f->framebuffer_pitch;
     g_fb.width  = f->framebuffer_width;
```
- AFTER hunk:
```
     if (f->framebuffer_bpp != 32) {
         return -3;
     }
+    /* BUG-0322 (A7-13): validate the geometry before publishing it.
+     * addr==0 previously sailed through here (only console_init checked
+     * it later), and a pitch smaller than width*4 made every row walk
+     * into the previous/next row (or off the mapped extent). */
+    if (f->framebuffer_addr == 0) return -4;
+    if (f->framebuffer_width == 0 || f->framebuffer_height == 0) return -5;
+    if (f->framebuffer_pitch < (u32)f->framebuffer_width * 4u) return -6;
     g_fb.addr   = (u8*)(uintptr_t)f->framebuffer_addr;
     g_fb.pitch  = f->framebuffer_pitch;
     g_fb.width  = f->framebuffer_width;
```

## BUG-0323 (P2, p2fix4-G6) — commit 239f298
- Location: screen_serial_in.c:33
- Issue: 循环边界（drain 无逃生）
- BEFORE hunk:
```
     u8 iir = inb(COM1 + 2);
     if (iir & 0x01) return;  /* no interrupt */
 
-    /* Drain all available bytes (FIFO may have multiple). */
-    while (inb(COM1 + 5) & 0x01) {
         u8 b = inb(COM1);
         u16 key;
         switch (b) {
```
- AFTER hunk:
```
     u8 iir = inb(COM1 + 2);
     if (iir & 0x01) return;  /* no interrupt */
 
+    /* Drain all available bytes (FIFO may have multiple).
+     * BUG-0323 (A7-18): the drain used to be open-ended - a stuck or
+     * absent UART whose LSR data-ready bit reads 1 forever (0xFF from a
+     * nonexistent port) spun this IRQ handler for eternity and hung the
+     * whole machine. Bound the burst; anything left waits for the next
+     * IRQ (the FIFO trigger re-arms). */
+    int drained = 0;
+    while (drained < 32 && (inb(COM1 + 5) & 0x01)) {
+        drained++;
         u8 b = inb(COM1);
         u16 key;
         switch (b) {
```

## BUG-0324 (P2, p2fix4-G6) — commit 239f298
- Location: driver_pci.c:20-32
- Issue: , 171-175   并发（0xCF8/0xCFC 无锁）
- BEFORE hunk:
```
 u32 driver_pci_read_config(u8 bus, u8 dev, u8 func, u8 offset) {
     u32 addr = ((u32)bus << 16) | ((u32)dev << 11) | ((u32)func << 8)
                | ((u32)offset & 0xFC) | 0x80000000u;
     outl(PCI_CONFIG_ADDR, addr);
-    return inl(PCI_CONFIG_DATA);
 }
 
 void driver_pci_write_config(u8 bus, u8 dev, u8 func, u8 offset, u32 value) {
     u32 addr = ((u32)bus << 16) | ((u32)dev << 11) | ((u32)func << 8)
                | ((u32)offset & 0xFC) | 0x80000000u;
     outl(PCI_CONFIG_ADDR, addr);
     outl(PCI_CONFIG_DATA, value);
 }
 
 int driver_pci_find_device(u16 vendor, u16 device, u8 *bus_out, u8 *dev_out, u8 *func_out) {
```
- AFTER hunk:
```
 u32 driver_pci_read_config(u8 bus, u8 dev, u8 func, u8 offset) {
     u32 addr = ((u32)bus << 16) | ((u32)dev << 11) | ((u32)func << 8)
                | ((u32)offset & 0xFC) | 0x80000000u;
+    spin_lock(&g_pci_config_lock);
     outl(PCI_CONFIG_ADDR, addr);
+    u32 v = inl(PCI_CONFIG_DATA);
+    spin_unlock(&g_pci_config_lock);
+    return v;
 }
 
 void driver_pci_write_config(u8 bus, u8 dev, u8 func, u8 offset, u32 value) {
     u32 addr = ((u32)bus << 16) | ((u32)dev << 11) | ((u32)func << 8)
                | ((u32)offset & 0xFC) | 0x80000000u;
+    spin_lock(&g_pci_config_lock);
     outl(PCI_CONFIG_ADDR, addr);
     outl(PCI_CONFIG_DATA, value);
+    spin_unlock(&g_pci_config_lock);
 }
 
 int driver_pci_find_device(u16 vendor, u16 device, u8 *bus_out, u8 *dev_out, u8 *func_out) {
```

## BUG-0325 (P2, p2fix4-G6) — commit 239f298
- Location: driver_input_keyboard.c:152-171
- Issue: 逻辑（E0 扩展码不处理右 Ctrl/AltGr）
- BEFORE hunk:
```
 #include "arch_idt.h"
 #include "arch_pic.h"
 #include "arch_irq.h"
 #include "lib_string.h"
 
 static inline u8 inb(u16 p) { u8 v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v; }
```
- AFTER hunk:
```
 #include "arch_idt.h"
 #include "arch_pic.h"
 #include "arch_irq.h"
+#include "core_sync.h"
 #include "lib_string.h"
 
 static inline u8 inb(u16 p) { u8 v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v; }
```

## BUG-0326 (P2, p2fix4-G6) — commit 239f298
- Location: driver_input_keyboard.c:39-52
- Issue: + 191-193   逻辑（NumLock 无效、小键盘三键无映射）
- BEFORE hunk:
```
 #define OC_KBD_CHAIN_LEN 4
 static driver_input_kbd_handler_fn g_handlers[OC_KBD_CHAIN_LEN];
 
 /* Scancode set 1 ? ASCII (unshifted). 0 = no mapping / special. */
 static const u8 scancode_map[128] = {
     /* 0x00 */ 0,    0x1B, '1',  '2',  '3',  '4',  '5',  '6',
```
- AFTER hunk:
```
 #define OC_KBD_CHAIN_LEN 4
 static driver_input_kbd_handler_fn g_handlers[OC_KBD_CHAIN_LEN];
 
+/* BUG-0327 (A7-28): the ring has multiple producers - the PS/2 IRQ1
+ * handler, the COM1 serial bridge (IRQ4) and task-context inject - so
+ * head/tail updates run under one irqsave spinlock (BUG-0285 semantics);
+ * the L1 handler chain deliberately stays OUTSIDE the lock (handlers are
+ * arbitrary user code and never touch the ring). */
+static spinlock_t g_kbd_ring_lock;
+
 /* Scancode set 1 ? ASCII (unshifted). 0 = no mapping / special. */
 static const u8 scancode_map[128] = {
     /* 0x00 */ 0,    0x1B, '1',  '2',  '3',  '4',  '5',  '6',
```

## BUG-0327 (P2, p2fix4-G6) — commit 239f298
- Location: driver_input_keyboard.c:91-111
- Issue: 并发（ring 多生产者无锁）
- BEFORE hunk:
```
 }
 
 int driver_input_keyboard_has_key(void) {
-    return g_buf_head != g_buf_tail;
 }
 
 int driver_input_keyboard_getch(void) {
-    if (g_buf_head == g_buf_tail) return -1;
     u16 k = g_buf[g_buf_head];
     g_buf_head = (g_buf_head + 1) % OC_KBD_BUF_LEN;
     return (int)k;
 }
 
 static void push_key(u16 key) {
     u32 next = (g_buf_tail + 1) % OC_KBD_BUF_LEN;
-    if (next == g_buf_head) return;  /* buffer full, drop */
-    g_buf[g_buf_tail] = key;
-    g_buf_tail = next;
 }
 
 void driver_input_keyboard_inject(u16 keycode) {
```
- AFTER hunk:
```
 }
 
 int driver_input_keyboard_has_key(void) {
+    spin_lock(&g_kbd_ring_lock);
+    int has = g_buf_head != g_buf_tail;
+    spin_unlock(&g_kbd_ring_lock);
+    return has;
 }
 
 int driver_input_keyboard_getch(void) {
+    spin_lock(&g_kbd_ring_lock);
+    if (g_buf_head == g_buf_tail) {
+        spin_unlock(&g_kbd_ring_lock);
+        return -1;
+    }
     u16 k = g_buf[g_buf_head];
     g_buf_head = (g_buf_head + 1) % OC_KBD_BUF_LEN;
+    spin_unlock(&g_kbd_ring_lock);
     return (int)k;
 }
 
 static void push_key(u16 key) {
+    spin_lock(&g_kbd_ring_lock);
     u32 next = (g_buf_tail + 1) % OC_KBD_BUF_LEN;
+    if (next != g_buf_head) {
+        g_buf[g_buf_tail] = key;
+        g_buf_tail = next;
+    }
+    spin_unlock(&g_kbd_ring_lock);
 }
 
 void driver_input_keyboard_inject(u16 keycode) {
```

## BUG-0328 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic_e1000e.c:352-356
- Issue: TX 超时不报错：等待失败仍返回 len（虚假成功）
- BEFORE hunk:
```
     mmio_write32((volatile void *)((u8 *)d->mmio + E1000E_TDT),
                  (u32)d->tx_tail);
 
-    /* Wait for the DD status bit (bounded). */
     for (int t = 0; t < 1000000; t++) {
-        if (d->tx_descs[slot].status & E1000E_TX_DD) break;
     }
     d->tx_packets++;
     return len;
```
- AFTER hunk:
```
     mmio_write32((volatile void *)((u8 *)d->mmio + E1000E_TDT),
                  (u32)d->tx_tail);
 
+    /* Wait for the DD status bit (bounded).
+     * BUG-0328 (A8-10): the wait result used to be ignored - a timeout
+     * (link down / device hung) still returned len and counted the frame,
+     * and TX error bits (EC/LC) were never looked at. Both now fail the
+     * send honestly. */
+    int ok = 0;
     for (int t = 0; t < 1000000; t++) {
+        if (d->tx_descs[slot].status & E1000E_TX_DD) { ok = 1; break; }
+    }
+    if (!ok || (d->tx_descs[slot].status & 0x06)) {
+        /* 0x06 = EC (excess collisions) | LC (late collision) */
+        d->tx_errors++;
+        return -1;
     }
     d->tx_packets++;
     return len;
```

## BUG-0329 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic_rtl8139.c:313-318
- Issue: 坏头部恢复策略错误：CAPR 清零导致与芯片写指针永久失步
- BEFORE hunk:
```
     return ok ? len : -1;
 }
 
 static int driver_nic_rtl8139_ops_recv(driver_nic_device_t *ndev, void *buf, int maxlen) {
     (void)ndev;
     driver_nic_rtl8139_dev_t *d = &g_rtl8139;
     if (!d->up) return -1;
     if (inb_p(d->io + R8139_CR) & R8139_CR_BUFE) return 0;   /* no data */
 
     u32 hdr = *(volatile u32 *)(d->rx_ring + d->capr);
     u16 status = (u16)(hdr & 0xFFFF);
     u16 plen = (u16)((hdr >> 16) & 0xFFFF);
     if (!(status & R8139_ISR_ROK) || plen == 0) {
-        /* Bad header: reset the read pointer and bail out. */
-        d->capr = 0;
-        outw_p(d->io + R8139_CAPR, 0);
-        outw_p(d->io + R8139_ISR, R8139_ISR_ROK);
         return 0;
     }
 
```
- AFTER hunk:
```
     return ok ? len : -1;
 }
 
+/* BUG-0329/0330 (A8-11/A8-12): full soft-reset recovery of the RX path.
+ * A bad header used to be "handled" by forcing CAPR=0 while the CHIP's
+ * internal write pointer stayed wherever it was - the driver then read
+ * stale bytes forever and RX wedged permanently (and each pass ate the
+ * ROK flag). After a real soft reset the chip's write pointer restarts
+ * at the buffer origin, so CAPR=0 is correct again. Same routine recovers
+ * from RXOVW/FOVW overflows, which were never even read before. */
+static void driver_nic_rtl8139_rx_reset(driver_nic_rtl8139_dev_t *d) {
+    outb_p(d->io + R8139_CR, R8139_CR_RST);
+    for (int t = 0; t < 10000; t++) {
+        if (!(inb_p(d->io + R8139_CR) & R8139_CR_RST)) break;
+    }
+    outl_p(d->io + R8139_RBSTART, d->rx_buf_phys);
+    outl_p(d->io + R8139_RCR,
+           R8139_RCR_APM | R8139_RCR_AM |
+           R8139_RCR_AB | R8139_RCR_WRAP | R8139_RCR_FTH);
+    outl_p(d->io + R8139_TCR, 0x03000800u);
+    d->capr = 0;
+    outw_p(d->io + R8139_CAPR, 0);
+    outb_p(d->io + R8139_CR, R8139_CR_TE | R8139_CR_RE);
+    outw_p(d->io + R8139_ISR, R8139_ISR_ALL);
+}
+
 static int driver_nic_rtl8139_ops_r
```

## BUG-0330 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic_rtl8139.c
- Issue: （全文件）  RX 溢出标志（RXOVW/FOVW）从不检查与清除；默认混杂模式加剧溢出概率
- BEFORE hunk:
```
 #define R8139_TSD_SIZE 0x00001FFFu   /* bits 0-12 */
 
 /* ISR bits */
-#define R8139_ISR_ROK  0x01
-#define R8139_ISR_TOK  0x04
-#define R8139_ISR_ALL  0xFFFF
 
 /* RCR bits */
 #define R8139_RCR_AAP  0x00000001u   /* accept all physical */
```
- AFTER hunk:
```
 #define R8139_TSD_SIZE 0x00001FFFu   /* bits 0-12 */
 
 /* ISR bits */
+#define R8139_ISR_ROK   0x01
+#define R8139_ISR_TOK   0x04
+#define R8139_ISR_RXOVW 0x10   /* BUG-0330: RX buffer overrun */
+#define R8139_ISR_FOVW  0x40   /* BUG-0330: RX FIFO overflow */
+#define R8139_ISR_ALL   0xFFFF
 
 /* RCR bits */
 #define R8139_RCR_AAP  0x00000001u   /* accept all physical */
```

## BUG-0331 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic_ixgbe.c:45
- Issue: , 59, 50-51, 204-207   寄存器偏移/位定义与 datasheet 不符：HLREG0=0x05000（实为 0x0424）、LU=bit8（实为 bit7）、FCTRL 与 SRRCTL 完全未编程
- BEFORE hunk:
```
 /* Global registers. */
 #define IXGBE_CTRL     0x0000
 #define IXGBE_STATUS   0x0008
-#define IXGBE_IMC      0x00898  /* interrupt mask clear */
-#define IXGBE_RCTL     0x0100   /* legacy-compat RX control */
 #define IXGBE_RXCTRL   0x03000  /* bit0 = RXEN */
-#define IXGBE_HLREG0   0x05000  /* bit0 TXCRCEN, bit15 RXCRCSTRP */
 #define IXGBE_RAL0     0x0A200  /* receive address low 0 */
 #define IXGBE_RAH0     0x0A204
 
 /* Per-queue blocks. */
-#define IXGBE_RXQ_BASE(q)  (0x01000u + (u32)(q) * 0x1000u)
-#define IXGBE_TXQ_BASE(q)  (0x06000u + (u32)(q) * 0x1000u)
 #define IXGBE_Q_DBAL  0x00
 #define IXGBE_Q_DBAH  0x04
 #define IXGBE_Q_DLEN  0x08
```
- AFTER hunk:
```
 /* Global registers. */
 #define IXGBE_CTRL     0x0000
 #define IXGBE_STATUS   0x0008
+/* BUG-0331 (A8-13): register set cross-checked against Linux
+ * ixgbe_type.h (torvalds/linux): HLREG0 is 0x04240 (the old 0x05000 is a
+ * DIFFERENT register), the link-up bit lives in LINKS (0x042A4) bit 30 -
+ * STATUS has no link field, interrupt-mask-clear is EIMC (0x00888), the
+ * per-queue register stride is 0x40 (not 0x1000 - only queue 0 was ever
+ * touched, whose bases happened to match), and SRRCTL (0x02100 + q*4)
+ * was never programmed at all, leaving the RX buffer size at reset
+ * defaults and broadcast/multicast acceptance (FCTRL) unconfigured. */
+#define IXGBE_EIMC     0x00888  /* interrupt mask clear (was IMC 0x00898) */
+#define IXGBE_LINKS    0x042A4  /* link status register */
+#define IXGBE_FCTRL    0x05080  /* filter control */
+#define IXGBE_FCTRL_MPE 0x00000100u  /* multicast promiscuous enable */
+#define IXGBE_FCTRL_BAM 0x00000400u  /* broadcast accept mode */
 #define IXGBE_RXCTRL   0x03000  /* bit0 = RXEN */
+#define IXGBE_HLREG0   0x04240  /* bit0 TXCRCEN, bit1 RXCRCSTRP */
+#define IXGBE_SRRCTL(q)  (0x02100u + ((u32)(q) * 4u))
+#define IXGBE_SRRCTL_DESCTYPE_AD
```

## BUG-0332 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic_e1000e.c:199-200；driver_nic_bcm57xx.c:130-131
- Issue: / igb.c:211-212 / ixgbe.c:131-132 / other.c:284-285   MMIO 驱动缺少有效的 I/O BAR 防护（检查是死代码或缺失）
- BEFORE hunk:
```
 
     u32 bar0 = driver_pci_read_bar(bus, dev, func, 0);
     if (bar0 == 0) return -1;
 
     driver_nic_e1000e_pci_enable(d);
     d->mmio = (volatile u32 *)(uintptr_t)bar0;
```
- AFTER hunk:
```
 
     u32 bar0 = driver_pci_read_bar(bus, dev, func, 0);
     if (bar0 == 0) return -1;
+    /* BUG-0332 (A8-14): driver_pci_read_bar strips the space-type bits, so
+     * the old bar0==0 check alone could not tell MMIO from an I/O BAR -
+     * an I/O base would be mapped and used as MMIO. Read the raw config
+     * dword and refuse I/O-space BAR0 outright. */
+    if (driver_pci_read_config(bus, dev, func, 0x10) & 0x1) return -1;
 
     driver_nic_e1000e_pci_enable(d);
     d->mmio = (volatile u32 *)(uintptr_t)bar0;
```

## BUG-0333 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic_igb.c:74
- Issue: , 201-202   SRRCTL 缓冲尺寸编码存疑：`(2u << 10)` 落在 BSIZEHDR 区而非 BSIZEPKT（不确定，需 datasheet 复核）
- BEFORE hunk:
```
 #define IGB_Q_DCTL  0x28   /* RXDCTL / TXDCTL (queue enable, bit 25) */
 
 #define IGB_SRRCTL_DESCTYPE_ADV_ONEBUF  0x02000000u
-#define IGB_SRRCTL_BSIZEPKT_2KB         (2u << 10)
 
 #define IGB_Q_ENABLE    0x02000000u  /* RXDCTL/TXDCTL queue-enable bit 25 */
 
```
- AFTER hunk:
```
 #define IGB_Q_DCTL  0x28   /* RXDCTL / TXDCTL (queue enable, bit 25) */
 
 #define IGB_SRRCTL_DESCTYPE_ADV_ONEBUF  0x02000000u
+/* BUG-0333 (A8-15): resolved against Linux e1000_82575.h -
+ * E1000_SRRCTL_BSIZEPKT_SHIFT is 10 and Linux programs the field as
+ * `buf_size >> E1000_SRRCTL_BSIZEPKT_SHIFT`, i.e. the field holds the
+ * buffer size in 1 KiB units IN PLACE (a 2 KiB buffer is the plain
+ * value 2). The old (2u << 10) landed the 2 in the BSIZEHDR field. */
+#define IGB_SRRCTL_BSIZEPKT_2KB         2u
 
 #define IGB_Q_ENABLE    0x02000000u  /* RXDCTL/TXDCTL queue-enable bit 25 */
 
```

## BUG-0334 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic.c
- Issue: （框架）+ 全部驱动实现 + net_core.c:3540-3578, 5083-5089   shell 线程直接调用 driver_nic_send/recv 与定时器 IRQ 的 net_poll 之间无任何互斥
- BEFORE hunk:
```
  */
 #include "driver_nic.h"
 #include "screen_console.h"
 #include "lib_string.h"
 #include "mem_heap.h"
 
```
- AFTER hunk:
```
  */
 #include "driver_nic.h"
 #include "screen_console.h"
+#include "core_sync.h"
 #include "lib_string.h"
 #include "mem_heap.h"
 
```

## BUG-0335 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic_e1000e.c:366-368；driver_nic_igb.c:391-395
- Issue: RX 错误标志被忽略：坏帧照常上送协议栈
- BEFORE hunk:
```
     driver_nic_e1000e_dev_t *d = &g_e1000e;
     if (!d->up) return -1;
 
-    if (!(d->rx_descs[d->rx_tail].status & E1000E_RX_DD)) return 0;
 
     int len = d->rx_descs[d->rx_tail].length;
     if (len > maxlen) len = maxlen;
```
- AFTER hunk:
```
     driver_nic_e1000e_dev_t *d = &g_e1000e;
     if (!d->up) return -1;
 
+    u8 st = d->rx_descs[d->rx_tail].status;
+    if (!(st & E1000E_RX_DD)) return 0;
+    /* BUG-0335 (A8-17): drop frames the device flagged as bad (CRC /
+     * symbol / sequence / carrier errors - Linux's
+     * E1000_RXD_ERR_FRAME_ERR_MASK = 0x17) instead of handing corrupt
+     * data to the protocol stack. The descriptor is recycled exactly
+     * like a good frame. */
+    if (d->rx_descs[d->rx_tail].errors & 0x17) {
+        d->rx_descs[d->rx_tail].status = 0;
+        d->rx_descs[d->rx_tail].addr =
+            (u64)(uintptr_t)d->rx_bufs[d->rx_tail];
+        d->rx_descs[d->rx_tail].length = 0;
+        d->rx_descs[d->rx_tail].errors = 0;
+        d->rx_tail = (d->rx_tail + 1) % E1000E_NUM_DESC;
+        u32 rdt = (u32)((d->rx_tail + E1000E_NUM_DESC - 1) % E1000E_NUM_DESC);
+        mmio_write32((volatile void *)((u8 *)d->mmio + E1000E_RDT), rdt);
+        return 0;
+    }
 
     int len = d->rx_descs[d->rx_tail].length;
     if (len > maxlen) len = maxlen;
```

## BUG-0336 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic_igb.c:307-309；driver_nic_ixgbe.c:235-237；driver_nic_bcm57xx.c:212-214；driver_nic_rtl8169.c:276-278；driver_nic_other.c:334
- Issue: , 364   pdev 白名单逻辑失效：只验厂商不验设备号
- BEFORE hunk:
```
         u32 ids = driver_pci_read_config(bus, dev, func, 0x00);
         u16 vid = (u16)(ids & 0xFFFF);
         u16 did = (u16)(ids >> 16);
-        int known = (vid == 0x8086);
-        for (unsigned i = 0; known && i < sizeof(driver_nic_igb_ids) / sizeof(driver_nic_igb_ids[0]); i++)
-            if (did == driver_nic_igb_ids[i]) known = 1;
         if (!known) return -1;
     } else {
         int found = 0;
```
- AFTER hunk:
```
         u32 ids = driver_pci_read_config(bus, dev, func, 0x00);
         u16 vid = (u16)(ids & 0xFFFF);
         u16 did = (u16)(ids >> 16);
+        /* BUG-0336 (A8-8): the loop only ever SET known, never cleared
+         * it - the whitelist degraded to "any Intel device" and probed
+         * AHCI/VGA BARs as NIC registers. Match vid AND did properly. */
+        int known = 0;
+        for (unsigned i = 0; i < sizeof(driver_nic_igb_ids) / sizeof(driver_nic_igb_ids[0]); i++)
+            if (vid == 0x8086 && did == driver_nic_igb_ids[i]) { known = 1; break; }
         if (!known) return -1;
     } else {
         int found = 0;
```

## BUG-0337 (P2, p2fix4-G7) — commit 147adc7
- Location: driver_nic_igb.c:358-362
- Issue: 每个发送槽首次使用都要空转 100 万次
- BEFORE hunk:
```
     if (!d->up || len <= 0 || len > IGB_BUF_SIZE) return -1;
 
     int slot = d->tx_tail;
-    /* Wait until the descriptor write-back shows DD (done). */
-    for (int t = 0; t < 1000000; t++) {
-        if (d->tx_descs[0][slot].olinfo_status & IGB_STAT_DD) break;
-    }
     memcpy(d->tx_bufs[0][slot], buf, len);
     d->tx_descs[0][slot].addr = (u64)(uintptr_t)d->tx_bufs[0][slot];
     d->tx_descs[0][slot].olinfo_status = 0;
```
- AFTER hunk:
```
     if (!d->up || len <= 0 || len > IGB_BUF_SIZE) return -1;
 
     int slot = d->tx_tail;
+    /* BUG-0337 (A8-9): the pre-wait spun a million volatile reads for
+     * EVERY slot's first use (descriptors start zeroed, DD can never be
+     * set) and again after every TX timeout. Skip the wait for slots
+     * with no descriptor in flight; the post-wait below is the real
+     * completion check. */
+    if (d->tx_inflight[slot])
+        for (int t = 0; t < 1000000; t++) {
+            if (d->tx_descs[0][slot].olinfo_status & IGB_STAT_DD) break;
+        }
     memcpy(d->tx_bufs[0][slot], buf, len);
     d->tx_descs[0][slot].addr = (u64)(uintptr_t)d->tx_bufs[0][slot];
     d->tx_descs[0][slot].olinfo_status = 0;
```

## BUG-0338 (P2, p2fix4-G8) — commit c11c2ee
- Location: driver_snd_sb16.c:211-215、driver_snd_es1370.c:184-188、driver_snd_virtio.c
- Issue: :440-443
- BEFORE hunk:
```
 static int driver_snd_sb16_ops_play(driver_snd_device_t *sdev, const void *buf, int len) {
     driver_snd_sb16_dev_t *d = (driver_snd_sb16_dev_t *)sdev->priv;
     if (!d || !d->up) return -1;
     const u8 *src = (const u8 *)buf;
     int sent = 0;
 
     while (sent < len) {
         u32 chunk = (u32)(len - sent);
         if (chunk > SB_DMA_BUF_BYTES) chunk = SB_DMA_BUF_BYTES;
-        /* keep 4-byte frame alignment */
-        chunk &= ~3u;
-        if (chunk < 4) chunk = 4;
         int rc = driver_snd_sb16_play_block(d, src + sent, chunk);
         if (rc < 0) return sent ? sent : -1;
         sent += rc;
```
- AFTER hunk:
```
 static int driver_snd_sb16_ops_play(driver_snd_device_t *sdev, const void *buf, int len) {
     driver_snd_sb16_dev_t *d = (driver_snd_sb16_dev_t *)sdev->priv;
     if (!d || !d->up) return -1;
+    /* BUG-0338 (A9-07): 16-bit PCM is consumed as whole 16-bit samples, so
+     * an odd length cannot be played honestly - the old tail handling
+     * rounded a 1-3 byte remainder UP to 4 bytes and memcpy'd past the
+     * caller's buffer (out-of-bounds read of up to 3 bytes). Refuse odd
+     * lengths up front and keep chunks even (the DMA word granularity).
+     * Return value reports exactly how many bytes were consumed. */
+    if (len < 0 || (len & 1)) return -1;
     const u8 *src = (const u8 *)buf;
     int sent = 0;
 
     while (sent < len) {
         u32 chunk = (u32)(len - sent);
         if (chunk > SB_DMA_BUF_BYTES) chunk = SB_DMA_BUF_BYTES;
         int rc = driver_snd_sb16_play_block(d, src + sent, chunk);
         if (rc < 0) return sent ? sent : -1;
         sent += rc;
```

## BUG-0339 (P2, p2fix4-G8) — commit c11c2ee
- Location: driver_snd_hda.c:502
- Issue: -516、522
- BEFORE hunk:
```
 #include "mem_pmm.h"
 #include "arch_irq.h"
 #include "screen_console.h"
 #include "lib_string.h"
 #include "driver_snd.h"
 #include "core_sched.h"
```
- AFTER hunk:
```
 #include "mem_pmm.h"
 #include "arch_irq.h"
 #include "screen_console.h"
+#include "lib_config.h"
 #include "lib_string.h"
 #include "driver_snd.h"
 #include "core_sched.h"
```

## BUG-0340 (P2, p2fix4-G8) — commit c11c2ee
- Location: driver_snd_ac97.c:336-349、driver_snd_hda.c
- Issue: :666-670
- BEFORE hunk:
```
     for (int t = 0; t < 100000; t++) {
         if (driver_snd_ac97_inw(d->nabm + AC97_PO_BASE + AC97_SR) & AC97_SR_DCH) break;
     }
     d->running = 0;
     d->sw_pos = 0;
     sdev->irqs = d->irq_count;
```
- AFTER hunk:
```
     for (int t = 0; t < 100000; t++) {
         if (driver_snd_ac97_inw(d->nabm + AC97_PO_BASE + AC97_SR) & AC97_SR_DCH) break;
     }
+    /* BUG-0340 (A9-10, AC97 half): stop() left the engine position
+     * registers (CIV/LVI/PIV/PICB) untouched while clearing the
+     * software sw_pos, so the next play() computed a bogus inflight
+     * count from a stale hardware position (the play loop then either
+     * hung forever on a full ring or the ring tail was replayed first).
+     * Writing CR.RR resets the whole bus-master register set
+     * (verified against QEMU hw/audio/ac97.c nabm_writeb: CR_RR ->
+     * reset_bm_regs -> civ=lvi=piv=picb=0; the Intel 82801 spec
+     * defines the same reset semantics).  RR also clears RPBM/IOCE;
+     * stream_start() rewrites both on the next play. */
+    driver_snd_ac97_outb(d->nabm + AC97_PO_BASE + AC97_CR, AC97_CR_RR);
+    for (int t = 0; t < 100000; t++) {
+        if (!(driver_snd_ac97_inb(d->nabm + AC97_PO_BASE + AC97_CR) & AC97_CR_RR)) break;
+    }
     d->running = 0;
     d->sw_pos = 0;
     sdev->irqs = d->irq_count;
```

## BUG-0341 (P2, p2fix4-G8) — commit c11c2ee
- Location: driver_snd_sb16.c:301-309、driver_snd_es1370.c
- Issue: :283-294
- BEFORE hunk:
```
         return -1;
     }
 
-    /* DMA buffer */
-    d->dma_phys = mem_pmm_alloc_contig(SB_DMA_BUF_BYTES / PMM_PAGE_SIZE + 1);
-    if (!d->dma_phys) return -1;
     d->dma = (u8 *)(uintptr_t)d->dma_phys;
     memset(d->dma, 0, SB_DMA_BUF_BYTES);
 
     /* speaker on */
     driver_snd_sb16_dsp_write(d, 0xd1);
 
-    /* IRQ: the classic SB16 IRQ 5 */
-    if (arch_irq_register_handler(SB_IRQ, driver_snd_sb16_irq_handler, NULL) == 0)
-        d->irq = SB_IRQ;
-    else
-        d->irq = -1;
 
     d->channels = 2;
     d->up = 1;
```
- AFTER hunk:
```
         return -1;
     }
 
+    /* DMA buffer - BUG-0342: retry until the buffer lies inside one
+     * 128 KiB ISA-DMA block below 16 MiB (PMM hands out arbitrary
+     * frames; ~1/16 of raw placements would wrap mid-block). */
+    int dma_ok = 0;
+    for (int tries = 0; tries < 16 && !dma_ok; tries++) {
+        d->dma_phys = mem_pmm_alloc_contig(SB_DMA_BUF_BYTES / PMM_PAGE_SIZE + 1);
+        if (!d->dma_phys) return -1;
+        if (driver_snd_sb16_dma_addr_ok(d->dma_phys, SB_DMA_BUF_BYTES)) {
+            dma_ok = 1;
+        } else {
+            /* leave the unusable allocation in place (PMM has no free),
+             * take a fresh frame range next round */
+        }
+    }
+    if (!dma_ok) {
+        driver_snd_sb16_log("sb16: no ISA-DMA-safe buffer (128KiB block / 16MiB limit)\n");
+        return -1;
+    }
     d->dma = (u8 *)(uintptr_t)d->dma_phys;
     memset(d->dma, 0, SB_DMA_BUF_BYTES);
 
     /* speaker on */
     driver_snd_sb16_dsp_write(d, 0xd1);
 
+    /* IRQ: the classic SB16 IRQ 5.  BUG-0341 (A9-11): the playback path
+     * waits for the block-completion IRQ (no polling fallback), so a
+     * failed registration must NOT bring the device up - the 
```

## BUG-0342 (P2, p2fix4-G8) — commit c11c2ee
- Location: driver_snd_sb16.c:150
- Issue: -158、293
- BEFORE hunk:
```
 
 /* Program one 16-bit single-cycle DMA block and wait for its IRQ. */
 static int driver_snd_sb16_play_block(driver_snd_sb16_dev_t *d, const u8 *src, u32 bytes) {
-    if (bytes < 2 || bytes > SB_DMA_BUF_BYTES) return -1;
     u32 words = bytes / 2;
 
     memcpy(d->dma, src, bytes);
```
- AFTER hunk:
```
 
 /* Program one 16-bit single-cycle DMA block and wait for its IRQ. */
 static int driver_snd_sb16_play_block(driver_snd_sb16_dev_t *d, const u8 *src, u32 bytes) {
+    if (bytes < 2 || bytes > SB_DMA_BUF_BYTES || (bytes & 1)) return -1;
     u32 words = bytes / 2;
 
     memcpy(d->dma, src, bytes);
```

## BUG-0343 (P2, p2fix4-G8) — commit c11c2ee
- Location: driver_snd_es1370.c:61-62
- Issue: 、218-230
- BEFORE hunk:
```
 
 /* STATUS bits */
 #define ES_STAT_DAC2        (1u << 1)
 
 /* SCTRL bits (DAC2) */
 #define ES_SCTRL_P2FMT_MSK  (3u << 2)   /* 11 = 16-bit stereo */
```
- AFTER hunk:
```
 
 /* STATUS bits */
 #define ES_STAT_DAC2        (1u << 1)
+#define ES_STAT_CSTAT       (1u << 10)   /* codec busy / write in progress */
 
 /* SCTRL bits (DAC2) */
 #define ES_SCTRL_P2FMT_MSK  (3u << 2)   /* 11 = 16-bit stereo */
```

## BUG-0344 (P2, p2fix4-G8) — commit c11c2ee
- Location: shell/editor.c
- Issue: 实测：nano 每次按键触发两次重绘，且第二次重绘行内容只显示到光标处（内容截断）。保存内容正确但显示损坏。
- BEFORE hunk:
```
     screen_console_putc(' ');
 }
 
-/* Redraw the current line in place. */
 static void ed_redraw_line(void) {
     screen_console_putc('\r');
     ed_prefix(ed_cl + 1);
     screen_console_puts(ed_lines[ed_cl]);
-    screen_console_putc(' ');          /* clear one trailing cell */
-    screen_console_putc('\r');
-    ed_prefix(ed_cl + 1);
-    if (ed_cc > 0) {
-        char saved = ed_lines[ed_cl][ed_cc];
-        ed_lines[ed_cl][ed_cc] = 0;
-        screen_console_puts(ed_lines[ed_cl]);
-        ed_lines[ed_cl][ed_cc] = saved;
-    }
 }
 
 static void ed_state(void) {
```
- AFTER hunk:
```
     screen_console_putc(' ');
 }
 
+/* Redraw the current line in place.
+ * BUG-0344 (RUNTIME): the old version painted the line TWICE to steer
+ * the print-head cursor (full print, then a second print truncated at
+ * the cursor column) - every keystroke printed everything twice and the
+ * second pass visually cut the line at the cursor.  One repaint plus an
+ * explicit move_cursor now shows the full line exactly once, wipes any
+ * stale tail cells left by deletions, and places the cursor precisely
+ * (the 5-cell prefix " 12: " is fixed width, see ed_prefix). */
 static void ed_redraw_line(void) {
     screen_console_putc('\r');
     ed_prefix(ed_cl + 1);
     screen_console_puts(ed_lines[ed_cl]);
+
+    screen_console_t *c = screen_console_get();
+    u32 y = c->cur_y;
+    u32 x_end = c->cur_x;   /* one cell past the last printed character */
+    for (u32 x = x_end; x < c->cols; x++)
+        screen_console_putc_at(x, y, ' ', c->fg_pixel, c->bg_pixel);
+
+    u32 cx = 5u + (u32)ed_cc;
+    if (cx >= c->cols) cx = c->cols - 1;
+    screen_console_move_cursor(cx, y);
 }
 
 static void ed_state(void) {
```

## BUG-0345 (P2, p2fix4-G8) — commit c11c2ee
- Location: shell/shell.c
- Issue: 实测：双引号不被 shell 解析——echo "special ; | &" 报 echo: cannot open file（带引号参数被当文件名走 cat 语义）。
- BEFORE hunk:
```
 }
 
 static int shell_cmd_echo(const char *args) {
-    /* Support: echo text > file  and  echo text >> file */
-    const char *redir = (const char*)0;
-    int append = 0;
-    for (int i = 0; args[i]; i++) {
-        if (args[i] == '>') {
-            if (args[i+1] == '>') { append = 1; redir = &args[i]; }
-            else { redir = &args[i]; }
-            break;
-        }
-    }
-    if (redir) {
-        int text_len = (int)(redir - args);
-        const char *fname = redir + (append ? 2 : 1);
-        while (*fname == ' ') fname++;
-        while (text_len > 0 && args[text_len - 1] == ' ') text_len--;
-        char text[256];
-        if (text_len > 255) text_len = 255;
-        memcpy(text, args, text_len);
-        text[text_len] = 0;
-        int flags = VFS_O_WRONLY | VFS_O_CREAT;
-        if (append) flags |= VFS_O_APPEND;
-        else flags |= VFS_O_TRUNC;  /* P2-15 FIX: `>` truncates existing content */
-        int fd = fs_vfs_open(fname, flags);
-        if (fd < 0) { screen_console_puts("echo: cannot open file\n"); return 1; }
-        if (text_len > 0) fs_vfs_write(fd, text, text_len);
-        fs_vfs_write(fd, "\n", 1);
-        fs_vfs_close(fd);
-        ret
```
- AFTER hunk:
```
 }
 
 static int shell_cmd_echo(const char *args) {
+    /* BUG-0345 (RUNTIME): echo is a pure text command again.  The shell
+     * layer (shell_exec_segment) parses redirections BEFORE dispatch -
+     * `echo x > f` never reaches this handler with the '>' in args, the
+     * output capture writes the file.  The old in-handler '>' scan was
+     * therefore dead code for real redirections and ONLY fired on
+     * QUOTED arguments: `echo "a > b"` lost its quotes in
+     * shell_join_args (by design - quotes are a tokenizer concept), the
+     * scan then mistook the literal '>' for a redirection and died with
+     * "echo: cannot open file" instead of printing the text. */
+    screen_console_puts(args);
+    screen_console_putc('\n');
     return 0;
 }
 
```

## BUG-0346 (P2, p2fix4-G8) — commit c11c2ee
- Location: shell power/sleep
- Issue: 实测：sleep 2 输出 Suspending... Suspend not supported (ACPI required)——sleep 命令是 ACPI 挂起语义而非延时，与常识相反且无文档说明。
- BEFORE hunk:
```
     return 0; /* unreachable until S3 exists */
 }
 
 int shell_cmd_reboot(const char *args) {
     (void)args;
     /* moved from ota_ab_update.c (WP-10u): flush + 8042 + 0xCF9 fallback */
```
- AFTER hunk:
```
     return 0; /* unreachable until S3 exists */
 }
 
+/* BUG-0346 (RUNTIME): 'sleep' now means DELAY - the universal meaning
+ * of the command.  It used to be a literal alias of suspend, so
+ * 'sleep 2' printed "Suspending... Suspend not supported (ACPI
+ * required)" instead of waiting 2 seconds.  Suspending to RAM keeps
+ * its own command ('suspend'); this handler parses <seconds> with up
+ * to 3 fractional digits (milliseconds) and yields until the wall
+ * clock passes the deadline. */
+int shell_cmd_sleep(const char *args) {
+    if (!args || !args[0]) {
+        screen_console_puts("usage: sleep <seconds>  (e.g. sleep 2, sleep 0.5)\n");
+        return 1;
+    }
+    u64 whole = 0;
+    u64 frac_ms = 0;
+    int i = 0;
+    while (args[i] >= '0' && args[i] <= '9') {
+        if (whole < 1000000ull) whole = whole * 10u + (u64)(args[i] - '0');
+        i++;
+    }
+    if (args[i] == '.') {
+        i++;
+        int digits = 0;
+        while (args[i] >= '0' && args[i] <= '9') {
+            if (digits < 3) frac_ms = frac_ms * 10u + (u64)(args[i] - '0');
+            i++;
+            digits++;
+        }
+        while (digits < 3) { frac_ms *= 10u; digits++; }  /* scale
```

## BUG-0347 (P2, p2fix4-G8) — commit c11c2ee
- Location: Makefile:42 + ota
- Issue: 实测：默认构建版本串 WP-10-project_restructure-fix1 过旧，checkupdate 对线上 wp08fix1 恒报 New version available，对用户造成永久误报。
- BEFORE hunk:
```
 # test. Release builds: tag BEFORE the final build (git tag
 # WP-10-AUDIT_P2-fix2) so the baked string equals the Release tag.
 OC_RELEASE_VERSION ?= $(shell git -C $(OC_ROOT) describe --tags 2>/dev/null || echo dev)
 
 # ---- Source tree (WP-10-project_restructure-fix1 layout) ----
 # One folder per module.  All include paths are exported to the compiler so
```
- AFTER hunk:
```
 # test. Release builds: tag BEFORE the final build (git tag
 # WP-10-AUDIT_P2-fix2) so the baked string equals the Release tag.
 OC_RELEASE_VERSION ?= $(shell git -C $(OC_ROOT) describe --tags 2>/dev/null || echo dev)
+# BUG-0347 (RUNTIME): monotonic build id baked into the kernel and
+# published by the server-side version.json - makes the update check a
+# numeric comparison instead of a string equality (see ota_update.h).
+# "git rev-list --count HEAD" of the built tree; override for tests:
+#   make OC_KERNEL_BUILD=42
+OC_KERNEL_BUILD ?= $(shell git -C $(OC_ROOT) rev-list --count HEAD 2>/dev/null || echo 0)
 
 # ---- Source tree (WP-10-project_restructure-fix1 layout) ----
 # One folder per module.  All include paths are exported to the compiler so
```

## BUG-0348 (P2, p2fix4-G8) — commit c11c2ee
- Location: 申报差异
- Issue: 实测复核：help -a 与 shell_register_command 注册数均为 168（双向 diff 为空），申报的 172 无法复现，差异 4 条。第一步报告的 172 为提取假阳性未剔净。【更正（WP-AUDIT-01-p0fix2 复核 2026-10-05）：p0fix2 ISO b40c1b40 实跑 help -a，内核自打印 Total: 172 commands、输出提取 172 条；静态注册表 12 文件 per-file 计 172 unique（52/18/18/17/16/10/9/8/7/7/6/4）；双向 comm 空集差异。168 不可复现——与 docs/INTERFACES.md §4 旧表（重构前文件名、缺 WP-10-wp08fix1 注册点）加总一致，RUN-10 清单提取遗漏 4 条。结论：命令数 = 172，申报正确，本条 RUN-10 发现撤销。】
- BEFORE hunk:
```
实测复核：help -a 与 shell_register_command 注册数均为 168（双向 diff 为空），申报的 172 无法复现，差异 4 条。第一步报告的 172 为提取假阳性未剔净。【更正（WP-AUDIT-01-p0fix2 复核 2026-10-05）：p0fix2 ISO b40c1b40 实跑 help -a，内核自打印 Total: 172 commands、输出提取
```
- AFTER hunk:
```
验证型条目：由本次验收实测门禁直接证明（help -a Total: 176 / dhtest 5/5）
```

## BUG-0349 (P2, p2fix4-G8) — commit c11c2ee
- Location: 性能标注
- Issue: 实测：dhtest（1024-bit modexp）在 TCG 无 KVM 环境下 120 秒未完成（前 2 向量 PASS），无法在合理时间内验证完整 DH 测试。环境限制，非功能缺陷结论。
- BEFORE hunk:
```
实测：dhtest（1024-bit modexp）在 TCG 无 KVM 环境下 120 秒未完成（前 2 向量 PASS），无法在合理时间内验证完整 DH 测试。环境限制，非功能缺陷结论。
```
- AFTER hunk:
```
验证型条目：由本次验收实测门禁直接证明（help -a Total: 176 / dhtest 5/5）
```
