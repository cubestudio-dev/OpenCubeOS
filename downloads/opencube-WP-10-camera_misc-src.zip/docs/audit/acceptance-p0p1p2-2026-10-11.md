<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- Copyright 2026 cubestudio-dev <cubestudio@qq.com> -->

# WP-10-AUDIT P0/P1/P2 Full Acceptance Report (349 items + 12 checks)

Date: 2026-10-11 (Asia/Shanghai). Environment: fresh sandbox, toolchain rebuilt
(gcc 14.2.0, nasm 2.16.03, QEMU 10.0.13, xorriso 1.5.6, OVMF + SeaBIOS).
Repo state at acceptance: private main 8e44699 (= WP-10-AUDIT_P2-fix4 tag 95195ed
+ 2 docs/asset commits; `git diff WP-10-AUDIT_P2-fix4..HEAD` over all kernel dirs is EMPTY).

## Method

Per item: the fix commit(s) were located by BUG-ID/range search over all 159 commit
messages, the per-item diff hunk was extracted from the mapped commit, and the
"after" code was re-verified present at HEAD (327 items mechanically/grep-verified,
20 doc items verified against their doc commits, 2 verification-type items
(BUG-0348/0349) re-proven live in QEMU). Repro tests were run at fix time and are
recorded in the commit messages; this acceptance re-ran the whole live gate instead
of 349 individual repros (sandbox resets destroyed the original evidence trees).

## 12 checks — results

| # | Check | Result | Evidence |
|---|-------|--------|----------|
| 1 | Privacy | PASS | 0 token/secret hits in the source tree; commit messages 0 hits; embedded universal SSH key header absent (BUG-0075 regression intact); build/ ignored; worklog.md is the designated token store (private archive only) |
| 2 | Build | PASS | clean rebuild at HEAD: 0 errors, 0 warnings (-Wall -Wextra -Werror); tag-point rebuild identical 0/0 |
| 3 | Regression | PASS* | tools/run_fix4_regression.py 28/28 (boot self-tests, 15 ring-3 programs, g6_test T1..T7 failed=0, fstest+cryptotest+heaptest, l1test G7/G8); fstest p2 regressions ALL PASS. *The original 71-check script (run_g9_regression.py) was lost with a sandbox reset; 28/28 is its restored consolidated successor covering the same suites |
| 4 | dhtest + cryptotest | PASS | dhtest 5/5 correctness (TCG wall 195 s: g^0 PASS, 1^x PASS, 1024-bit 4040 ms, TLS KEX 9050 ms, group14 13536 ms, sweep 5/5); cryptotest 4/4 NIST (SHA-256/AES-128/HMAC-SHA256/HMAC-SHA384) |
| 5 | SSH both directions | PASS | tools/ssh_mainstream_test.py 5/5 ALL PASS (server password curve25519+ctr, server publickey rsa-sha2-512, client password, client publickey, legacy group14+cbc fallback) |
| 6 | HTTPS E2E | 6/7 | checks 1-6 PASS. Check 7 (hard-close truncation) fails ONLY its error-text assertion: this run the kernel received the complete body before the FIN (Saved 24 bytes, bounded ~25 s, clean teardown, never hangs); the fix4-session 7/7 run took the FIN-first branch. Kernel code is byte-identical to that run (diff vs tag empty) — the outcome flip is host-side TCP scheduling, not a code regression. Half-record diagnostic: EOF-without-close_notify is flagged (c->truncated, TLS_RC_TRUNCATED); net_recv does not wake early on FIN (15 s bounded wait) — noted as a future improvement, no P0/P1/P2 regression |
| 7 | 3-way SHA | PASS | fix4 ISO 3fbb69a5...852d and SRC f6960649...23f8 IDENTICAL across GitHub Release, site /downloads/, private archive; fix3 rebuilt ISO f1f3fe85...fb4686 identical across the same three. Tag-point rebuild: kernel ELF byte-identical (57df918f...e79b53); ISO bytes differ only in ISO9660 timestamps |
| 8 | Banner/protocol | PASS | boot banner "shell command system (176 commands) OK"; uname WP-10-AUDIT_P2-fix4(-2-g8e44699); 46 syscalls (SYS 0-102 macro count); L1 interface numbering 1-138 closed in INTERFACES.md |
| 9 | Release assets | PASS | fix4 Release 409343760 (ISO 11454464 B + SRC 2926443 B) and fix3 Release 409076645 (ISO 11446272 B + SRC 2893669 B) both online, state=uploaded, sizes match local |
| 10 | Docs | PASS w/ 2 minor observations | README Download section fix4-latest + fix3-rebuild correct; STATUS fix4 COMPLETE recorded; site.ts constants match verified SHAs; live site shows fix4 + 103,640 lines (verified live). Observations: (a) README Stats header label still says fix3 while the 103,640 count is the fix4 number (count re-measured live: 103,640 exact); (b) KNOWN_ISSUES has no fix4 section (fix4 notes live in STATUS + commit messages) |
| 11 | Extension interfaces | PASS | l1test PASS (G7+G8 suites); interface counts unchanged (46/138/176); no interface signatures changed by any audit batch |
| 12 | Open tracking | DOCUMENTED | P3 = 258 items deferred by owner decision; KNOWN_ISSUES: KI-SH-01 rtl8139 intermittent test, KI-SH-02 BIOS-only boot path, KI-SH-03 OVMF HDD/CD order; HTTPS E2E check-7 test raciness (this report); fix4 struct-verified-only items recorded in commit messages (0306/0308/0310/0313/0314/0317 class); virtio-snd ctl timeout (pre-existing QEMU-10 model incompatibility) |

## Boot evidence (this acceptance)

- SeaBIOS: banner + boot complete OK + uname `Open Cube OS WP-10-AUDIT_P2-fix4-2-g8e44699 x86_64`
- OVMF (UEFI): GRUB boots `Open Cube OS (slot ISO)`, kernel ready, same uname
- fix3 release ISO live re-check: uname `Open Cube OS WP-10-AUDIT_P2-fix3 x86_64`
- fix4 tag-point rebuild live check: uname `Open Cube OS WP-10-AUDIT_P2-fix4 x86_64`
- help three modes: help / help -a / help -w all list Total: 176 commands

## Per-item acceptance (349 items)


### P0 batch 1 (BUG-0001..0020) — commit 0ce616a  (20 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0001 | P0 | 0ce616a | PASS | fs_vfs.c:329-336 | 栈缓冲区溢出 |
| BUG-0002 | P0 | 0ce616a | PASS | fs_ramfs.c:177-192 | （配合 fs_vfs.c:799-819、fs_vfs.c:303-324）  rmdir/umount 跨文件系统误释放挂载根 —— BUG-019 根因 |
| BUG-0003 | P0 | 0ce616a | PASS * | fs_ext4.c:703、fs_ext4.c:279 | mount 时除零 panic |
| BUG-0004 | P0 | 0ce616a | PASS | fs_fat32.c:189-194 | 、262-267、211-224、1295-1296、1268-1273   簇号/保留扇区/扇区大小无校验 → 越出卷边界写盘 / 覆写引导扇区 |
| BUG-0005 | P0 | 0ce616a | PASS | net_core.c:5020-5035 | 内核栈溢出（确定性内存破坏） |
| BUG-0006 | P0 | 0ce616a | PASS | net_core.c:1685 | +1232+868+1995（发送路径三层嵌套 1.5KB 栈缓冲）vs core_sched.c:257-264（kthread 栈 4KB）  4KB 内核线程栈必然溢出 |
| BUG-0007 | P0 | 0ce616a | PASS | net/net_ssh.c:131-148 | 长度字段驱动的物理页溢出（SSH 客户端，预认证） |
| BUG-0008 | P0 | 0ce616a | PASS | net/net_ssh.c:180-191 | server_banner[64] 溢出（SSH 客户端，预认证） |
| BUG-0009 | P0 | 0ce616a | PASS | net/net_ssh.c:283-292 | （配合 202-212）  KEXINIT name-list 长度整数溢出 → OOB 读循环（SSH 客户端，预认证） |
| BUG-0010 | P0 | 0ce616a | PASS | net/net_ssh.c:338-345 | curve25519 路径 KEX_ECDH_REPLY 的 ks_len 负值 → 巨型 memcpy（SSH 客户端，预认证） |
| BUG-0011 | P0 | 0ce616a | PASS | net/net_ssh.c:428-464 | group14 路径 KEXDH_REPLY 的 ks_len/f_len 负值 → 野指针巨型 memcpy（SSH 客户端，预认证） |
| BUG-0012 | P0 | 0ce616a | PASS | net/net_ssh.c:576-628 | 交换哈希 H 输入溢出 4096B 物理页（SSH 客户端，预认证） |
| BUG-0013 | P0 | 0ce616a | PASS | net/net_ssh.c:1179-1235 | 加密收包 rest_buf/dec_rest 溢出（SSH 客户端，NEWKEYS 后） |
| BUG-0014 | P0 | 0ce616a | PASS | net/net_sshd.c:170-196 | 未认证收包 35000 字节读入 4096B 页（sshd，监听端口，预认证） |
| BUG-0015 | P0 | 0ce616a | PASS | net/net_sshd.c:1099-1111 | KEXDH_INIT e_len 负值 → 野指针巨型 memcpy（sshd，预认证） |
| BUG-0016 | P0 | 0ce616a | PASS | net/net_sshd.c:643-654 | KEXINIT name-list q+L 溢出 → 野地址读（sshd，预认证） |
| BUG-0017 | P0 | 0ce616a | PASS | net/net_sshd.c:484-518 | 交换哈希 H 输入溢出 4096B 页（sshd，预认证） |
| BUG-0018 | P0 | 0ce616a | PASS | net/net_sshd.c:310-373 | 加密收包 rest_buf/dec_rest/body/mac_input 四重溢出（sshd，KEX 后、认证前） |
| BUG-0019 | P0 | 0ce616a | PASS | net/net_sshd.c:838-841 | 与 965-969   USERAUTH 负长度 → 巨型 memcpy（sshd，凭证校验之前） |
| BUG-0020 | P0 | 0ce616a | PASS | net/net_sshd.c:1178-1185 | CHANNEL_OPEN_FAILURE 的 fail[16] 栈溢出（sshd，认证后；默认凭证 oc/oc） |

\* manual grep verification (the mechanical exact-string check missed because later refactors evolved the code around the fix):
- BUG-0003: fs_ext4.c:773-774 s_blocks_per_group==0 拒绝挂载（grep 实证）

### P0 batch 2 (BUG-0021..0041) — commit 9a06017  (21 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0021 | P0 | 9a06017 | PASS | net/net_tls.c:1352-1362 | https_get req[1024] 栈溢出（OTA 路径，远端内容驱动，4KB kthread 栈上） |
| BUG-0022 | P0 | 9a06017 | PASS | net/net_tls.c:152-158 | TLS1.3 记录长度检查比缓冲大 256 → 溢出（预认证，握手期明文记录即可） |
| BUG-0023 | P0 | 9a06017 | PASS | net/net_tls.c:783-823 | TLS1.2 记录长度检查 cap+2080 → 最高 2080 字节溢出；合法最大 CBC 记录也溢出（预认证） |
| BUG-0024 | P0 | 7fa48a1 | PASS | net/net_tls.c:939-942 | TLS1.2 Certificate 消息 mlen 拷入 body[12288] 溢出（证书校验之前，无需有效证书） |
| BUG-0025 | P0 | 9a06017 | PASS | net/net_tls.c:971-974 | TLS1.2 ServerKeyExchange 的 mlen 完全未检查（需有效证书链） |
| BUG-0026 | P0 | 9a06017 | PASS | net/net_tls.c:984-1008 | TLS1.2 DHE ServerKeyExchange 的 sbuf[384] 溢出（需有效证书） |
| BUG-0027 | P0 | 9a06017 | PASS | net/net_tls.c:656-671 | TLS1.3 CertificateVerify ECDSA 签名 DER r/s 长度未检查 → 栈下溢写（需有效 ECDSA 证书链） |
| BUG-0028 | P0 | 9a06017 | PASS | shell.c:875-885 | 字符串缓冲（栈溢出） |
| BUG-0029 | P0 | 9a06017 | PASS | shell_cmds_disk.c:380-394 | （二次使用 434-439）  字符串缓冲（无条件栈溢出） |
| BUG-0030 | P0 | 9a06017 | PASS | shell_cmds_file.c:344-346 | + 379-382   数据丢失 |
| BUG-0031 | P0 | 9a06017 | PASS | core_syscall.c:957-991 | sys_poll 的 `nfds * sizeof(pollfd_t)` 整数回绕绕过校验 → 内核对未映射用户地址写 → ring-0 #PF → 内核 HALT（用户态可触发  |
| BUG-0032 | P0 | 9a06017 | PASS | core_usermode.c:221-226 | SYS_EXIT(0) 用 `char n[8]` 接收无界 u64_to_str(用户可控 code) → 内核栈缓冲区溢出最多 13 字节 |
| BUG-0033 | P0 | 9a06017 | PASS | core_syscall.c:1089-1231 | sys_execve 在 CR3 已切到内核 AS、旧 AS 已销毁之后构造 argv/envp 与用户栈内容 → 所有用户 VA 读写走 0-4GiB 恒等映射窗口：argv 读 |
| BUG-0034 | P0 | 9a06017 | PASS | core_syscall.c:1787-1802 | sys_ps 栈上 `ktab[64]`=3584B，而内核线程栈只有 1 页 4096B（core_sched.c:264），入口已耗 ~3990B，余量 ~100B；0x80  |
| BUG-0035 | P0 | 9a06017 | PASS | crypto_x509.c:44-53 | + crypto_x509.c:456-467   整数溢出 → 负长度 memcpy → 内核内存破坏（远程可触发） |
| BUG-0036 | P0 | 9a06017 | PASS | kernel/lib/lib_config.c:285 | ,303-318   内存管理/堆溢出 |
| BUG-0037 | P0 | 9a06017 | PASS | kernel/ota/ota_update.c:692 | ,707-709   字符串缓冲/栈溢出（网络触发） |
| BUG-0038 | P0 | 9a06017 | PASS | kernel/ota/ota_update.c:272-278 | 字符串缓冲/栈溢出（URL 路径） |
| BUG-0039 | P0 | 9a06017 | PASS | kernel/ota/ota_ab.c:790-794 | ,880-886   路径遍历/任意文件写 |
| BUG-0040 | P0 | 9a06017 | PASS | driver_block_blk.c:96-109 | + driver_block_nvme.c:519-524, 634-646   块层/缓存层硬编码 512B 扇区 vs NVMe 注册非 512 sector_size → 4 |
| BUG-0041 | P0 | 9a06017 | PASS | net_core.c:5020/5034 + vmm | 实测复现：tcptest 命令完成后触发连环 #PF（cr2=0xFD1CF480 为 fb 区未映射页，即 KNOWN_ISSUES §6.1 地址），异常处理器自身递归 #PF |

### P1 batch 1 (BUG-0042..0072) — commit 1abc0c4  (31 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0042 | P1 | 1abc0c4 | PASS | kernel/arch/x86_64/arch_context_switch.S:75-115 | （全仓缺失）  ⑥并发/资源管理 |
| BUG-0043 | P1 | 1abc0c4 | PASS | kernel/mem/mem_pmm.c:193-202 | （及 229-247）  ⑥并发/中断安全 |
| BUG-0044 | P1 | 1abc0c4 | PASS | kernel/mem/mem_vmm.c:404-448 | ③⑤⑩（缺页处理语义错误） |
| BUG-0045 | P1 | 1abc0c4 | PASS | driver_usb_xhci.c:300-312 | , 1084-1097 |
| BUG-0046 | P1 | 1abc0c4 | PASS | driver_usb_xhci.c:965-976 | vs 564-575 |
| BUG-0047 | P1 | 1abc0c4 | PASS | driver_usb_xhci.c:415-419 | , 651, 682 |
| BUG-0048 | P1 | 1abc0c4 | PASS | driver_usb.c | :468-471 |
| BUG-0049 | P1 | 1abc0c4 | PASS * | driver_usb_ehci.c | :637-639 |
| BUG-0050 | P1 | 1abc0c4 | PASS | driver_usb_ohci.c:676-704 | , 452-506 |
| BUG-0051 | P1 | 1abc0c4 | PASS | driver_usb_ohci.c:407-413 | , 430-449 |
| BUG-0052 | P1 | 1abc0c4 | PASS | driver_usb_ohci.c | :728-731 |
| BUG-0053 | P1 | 1abc0c4 | PASS | driver_usb_msc.c:131-150 | , 178-200 |
| BUG-0054 | P1 | 1abc0c4 | PASS | driver_usb_msc.c:243-249 | , 375-380 |
| BUG-0055 | P1 | 1abc0c4 | PASS | driver_usb_serial.c:167-169 | , 135-138 |
| BUG-0056 | P1 | 1abc0c4 | PASS | fs_fat32.c:696-708 | rmdir 对含 `.`/`..` 的标准目录永远失败 |
| BUG-0057 | P1 | 1abc0c4 | PASS | fs_fat32.c:1321 | 、1367-1381   g_last_ctx 在 umount 后悬挂 → df 触发 UAF |
| BUG-0058 | P1 | 1abc0c4 | PASS | fs_fat32.c:251-259、389、443、696；fs_exfat.c:229-236 | 、319、576-580、801、406   FAT/exFAT 簇链遍历无环检测 → 内核死循环（挂死） |
| BUG-0059 | P1 | 1abc0c4 | PASS | fs_exfat.c:213-236 | （设计面）  exFAT 分配位图（0x81）从不读写 → 位图与 FAT 不一致 |
| BUG-0060 | P1 | 1abc0c4 | PASS * | fs_ext4.c:317 | 、348-349   extent 条目起始偏移错误（root +16 字节、child +8 字节，正确均为 +12）→ extent 卷读错数据 |
| BUG-0061 | P1 | 1abc0c4 | PASS | fs_ramfs.c:224-243；fs_fat32.c:812-907 | unlink 后仍打开的 fd 继续写：ramfs UAF 写 / FAT32 复活已释放簇链（可破坏他文件） |
| BUG-0062 | P1 | 1abc0c4 | PASS | fs_ext4.c:253-273 | 、276-297、444-472   crafted 卷多处越界读（栈/堆） |
| BUG-0063 | P1 | 1abc0c4 | PASS | net_core.c:3540-3578 | + 2212-2224 vs 2362-2395   IRQ 与线程对 TCP rtx/rx 状态的无锁竞态 |
| BUG-0064 | P1 | 1abc0c4 | PASS | net_core.c:566-573 | 与 645-657   e1000_init 对未初始化栈缓冲调用 strcat |
| BUG-0065 | P1 | 1abc0c4 | PASS * | ld_so.c:371-379 | , 419-426, 493-500, 508-514, 549-560, 590-597, 616-623   .dynamic 遍历无界（d_tag 循环仅靠 DT_NULL  |
| BUG-0066 | P1 | 1abc0c4 | PASS | net_core.c:1520 | , 1695-1712, 2823-2843, 3077-3199   IP/UDP 长度字段未与实际帧长核对 → 远程可触发 OOB 读 |
| BUG-0067 | P1 | 1abc0c4 | PASS | net_core.c:2359 | , 2425, 2481, 2487, 2495   TCP 序号比较无回绕保护（before/after 宏缺失） |
| BUG-0068 | P1 | 1abc0c4 | PASS | net_core.c:2334-2338 | RST 零验证盲注 |
| BUG-0069 | P1 | 1abc0c4 | PASS | net_core.c:2299-2327 | + 2143-2149   SYN_RCVD 永不超时 → 32 个 SYN 永久打满连接表（远程 DoS）；服务端 SYN 选项不解析 |
| BUG-0070 | P1 | 1abc0c4 | PASS | net_core.c:1669-1678 | + 3204/3239/3319/3369/3394/3416/3439 + 2881   net_udp_bind 无去重、无解绑，DNS 每次解析重复绑定，返回值全部被忽略 |
| BUG-0071 | P1 | 1abc0c4 | PASS | net_core.c:2084 | + 2049-2057   窗口缩放错配：通告 scale=7 但窗口值不缩放 → 对端以为有 1MB 缓冲（实际 8KB） |
| BUG-0072 | P1 | 7fa48a1 | PASS | net_core.c:2271-2606 | （全 RX 路径）  IP/TCP/UDP/ICMP 接收校验和一概不验证 |

\* manual grep verification (the mechanical exact-string check missed because later refactors evolved the code around the fix):
- BUG-0049: driver_usb_ehci.c:731 EHCI_CONFIGFLAG=1（grep 实证）
- BUG-0060: fs_ext4.c:374,392 hdr+12（grep 实证）
- BUG-0065: libs/ld_so.c:248 LDSO_DYN_MAX=64 两处循环有界（grep 实证）

### P1 batch 2 (BUG-0073..0103) — commits 906f151 + d373da5 (BUG-0075)  (31 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0073 | P1 | 906f151 | PASS | net/net_ssh.c:484-571 | （配合 net_ssh.h:21-23,31）  SSH 客户端主机密钥验证是"仅签名、无锚点"的 TOFU → 无 MITM 防护 |
| BUG-0074 | P1 | 906f151 | PASS | net/net_ssh.c:320 | ,389 / net_sshd.c:587-587,685,743 / net_tls.c:247-251,875,896   A4-02（xorshift32 PRNG）在协议层 |
| BUG-0075 | P1 | ad4ca78 | PASS | net/net_sshd_rsa_key.h:7-43 | + net_sshd.c:854-950 + net_ssh.c:870-957   内嵌"万能"RSA 私钥同时充当 sshd 主机密钥、sshd 授权用户密钥、SSH 客户端身 |
| BUG-0076 | P1 | 906f151 | PASS | net/net_tls.c:133-136 | + 1124   AES-256-GCM / ChaCha20-Poly1305 套件密钥长度硬编码 16 字节 → 选中即失败 |
| BUG-0077 | P1 | 906f151 | PASS | net/net_tls.c:587-588 | TLS1.3 CertificateEntry 扩展只跳长度不跳数据 → 带 SCT 的常见证书链解析错位 |
| BUG-0078 | P1 | 906f151 | PASS | net/net_tls.c:106-116 | + 420-424   transcript/hs_log 9216 字节静默截断 → 大证书链 Finished 必败 |
| BUG-0079 | P1 | 7fa48a1 | PASS | net/net_tls.c:476-507 | ServerHello 解析无边界（sid_len/ext_total 不设限）→ OOB 读至 #PF |
| BUG-0080 | P1 | 906f151 | PASS * | net/net_tls.c:382-407 | 0 长度记录导致握手无限循环（远程挂死） |
| BUG-0081 | P1 | 906f151 | PASS * | net/net_tls.c:1314-1318 | net_tls_recv 对 KEY_UPDATE/NEW_SESSION_TICKET 无界递归 → 远程栈耗尽 |
| BUG-0082 | P1 | 906f151 | PASS | net/net_tls.c:583 | ,592,957,963   A4-01（X509 DER 负长度 P0）从本路四个入口全部可达（影响面确认） |
| BUG-0083 | P1 | 906f151 | PASS | shell.c:1125-1129 | + 1361-1391   嵌套 capture 逻辑错误（可远程触发，含数据污染） |
| BUG-0084 | P1 | 906f151 | PASS | shell.c:892 | 别名/自覆盖（相对目录通配符全坏） |
| BUG-0085 | P1 | 906f151 | PASS | shell_cmds_file.c:860 | , 918 + 863-865   edit 命令三重缺陷（数据丢失） |
| BUG-0086 | P1 | 906f151 | PASS | shell_cmds_file.c:425-427 | , 436-439   cp 静默截断 |
| BUG-0087 | P1 | 906f151 | PASS | shell_cmds_file.c:132-139 | （ls）、482-489（tree_walk）、602-609（du_walk）  无界子路径拼接（条件性栈溢出） |
| BUG-0088 | P1 | 906f151 | PASS | userprogs/ush.c:803-812 | `unalias` 无参数时 NULL 指针解引用 |
| BUG-0089 | P1 | 906f151 | PASS | userprogs/ush.c:466 | 、1158、1189   写目标文件缺 O_TRUNC：nano/vi 保存、cp、mv 在覆盖较短内容时残留旧尾字节（数据损坏） |
| BUG-0090 | P1 | 906f151 | PASS | userprogs/ush.c:2014-2058 | 重定向路径 fd 泄漏 + 双重 close + stdin 永久改绑 |
| BUG-0091 | P1 | 906f151 | PASS | l1/l1_ext.h:111-128 | + l1/l1_ext.c:80-84 + drivers/display/screen_console.c:91-93   console hook 的"抑制字符"契约未实现 |
| BUG-0092 | P1 | 906f151 | PASS | l1/l1_wp8cd.c:39-81 | 、84-106 + l1/l1_wp8cd.h:26-46   WP-08cd"注册"类 L1 接口虚设：文档承诺 oc> 集成 / 可 exec，实为孤立静态表 |
| BUG-0093 | P1 | 906f151 | PASS (doc) | docs/ | ** CONFIG.md 全文把配置键写成 `ota_update_url`，代码实际解析 `update_url`。 |
| BUG-0094 | P1 | 906f151 | PASS (doc) | docs/ | ** TRY-IT.md OTA 演练第 4 节 `config set ota_update_url ...` 静默无效。 |
| BUG-0095 | P1 | 906f151 | PASS (doc) | docs/ | ** UPDATE-HOWTO.md 让用户运行不存在的 `tools/ota_update_server.py`（实际 `tools/update_server.py`）。 |
| BUG-0096 | P1 | 906f151 | PASS (doc) | 线上站点 ↔ GitHub Release | "三处 SHA256 字节级一致"声明已失效 |
| BUG-0097 | P1 | 68abf48 | PASS (doc) | update.json 全部副本 | 三代 manifest 并存，仓库非权威源，重建即回滚 |
| BUG-0098 | P1 | 906f151 | PASS | core_syscall.c:580-612 | /347-356/1437-1465   VFS fd(kind 1) 无引用计数：dup/dup2/fork 共享 fs_vfs_fd，任一方 close 即全局释放 → 幸存  |
| BUG-0099 | P1 | 906f151 | PASS | core_syscall.c:388 | /414; core_usermode.c:1048   陈旧 tid：子任务 EXITED 后调度器随时回收并复用槽位，wait4/kill/user_process_kill  |
| BUG-0100 | P1 | 906f151 | PASS | core_syscall.c:467-474 | /519-543/933-951   pipe/select 丢失唤醒竞态：数据检查与入队+block 之间可被定时器抢占，写者 wake 时读者未入队 → 读者永眠（数据已就绪） |
| BUG-0101 | P1 | 906f151 | PASS | core_syscall.c:897-953 | sys_select timeout_ms==0 语义颠倒（POSIX=立即返回，实现=永久阻塞）；未打开的 fd（stdin 0）既不 ready 也不入等待队列 |
| BUG-0102 | P1 | 906f151 | PASS | core_sched.c:623-639 | 调度器逻辑 — yield 自弹出后任务孤儿化 |
| BUG-0103 | P1 | 906f151 | PASS | arch_context_switch.S:127-156 | （经 core_sched.c:486、core_timer.c:180 触发）  上下文切换不恢复 RFLAGS — IF=0 泄漏 |

\* manual grep verification (the mechanical exact-string check missed because later refactors evolved the code around the fix):
- BUG-0080: net/net_tls.c:662-694 stalls 计数器（grep 实证）
- BUG-0081: net/net_tls.c:1850-1882 KEY_UPDATE 处理（grep 实证）

### P1 batch 3 (BUG-0104..0135) — commit 3bd374e (+7fa48a1 BUG-0072 hotfix)  (32 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0104 | P1 | 3bd374e | PASS | core_sync.c:82-92 | sem_wait 等待表满回退路径自死锁 |
| BUG-0105 | P1 | 3bd374e | PASS | core_sync.c:202-233 | cond_wait 等待表满时未注册即阻塞 → 永久睡眠 |
| BUG-0106 | P1 | 3bd374e | PASS | crypto_core.c:433-442 | 非密码学 PRNG 用于全部 TLS/SSH 密钥材料 |
| BUG-0107 | P1 | 3bd374e | PASS | crypto_x509.c:456-467 | ECDSA r/s 左侧未清零，使用未初始化栈数据验证 |
| BUG-0108 | P1 | 3bd374e | PASS | crypto_ec_nist.c:270-309 | + 468-483（另 crypto_core.c:618-656）  私钥标量乘/模幂非常量时间（时间侧信道） |
| BUG-0109 | P1 | 3bd374e | PASS | kernel/ota/ota_ab.c:1059-1063 | + kernel/ota/ota_update.c:559-563   整数安全/栈溢出 |
| BUG-0110 | P1 | 3bd374e | PASS | kernel/ota/ota_ab.c:1108 | ,1165,1117,1174   逻辑：更新目标槽硬编码 B |
| BUG-0111 | P1 | 3bd374e | PASS | kernel/ota/ota_update.c:487-499 | ,691-693（配合 core_sched.c:257-264）  资源管理：4 KiB 线程栈装不下 OTA 检查调用链 |
| BUG-0112 | P1 | 3bd374e | PASS | kernel/lib/lib_string.c:74-79 | 内存管理：strncpy 语义破坏（n+1 越界写） |
| BUG-0113 | P1 | 3bd374e | PASS | driver_block_part.c:120-134 | GPT entry_size 无上界 → 栈越界读 / #PF panic |
| BUG-0114 | P1 | dd0882f | PASS | driver_block_nvme.c:533-534 | vs 337/351   I/O 队列按 MQES 缩小创建但回绕固定 %64 → SQE 越界写 + 门铃值非法 |
| BUG-0115 | P1 | 3bd374e | PASS | driver_block_ata_dma.c:369 | （对照 ahci.c:567 的正确写法）  init_ctrl 无控制器表上界检查 → 重复/L1 扩展调用时 g_ctrls[2] 越界写 |
| BUG-0116 | P1 | 3bd374e | PASS | driver_block_cache.c:47-54 | + driver_block_blk.c:112-118   淘汰脏页回写失败被忽略 + 写路径恒返回 0 → 设备错误时静默丢数据 |
| BUG-0117 | P1 | 3bd374e | PASS | driver_block_part.c:223-224 | + driver_block_disk_setup.c:376/513   register_child 名字冲突返回旧几何子设备 → abdisk/install 二次布局沿用过 |
| BUG-0118 | P1 | 3bd374e | PASS | screen_console.c:48-51 | 整数安全（除零 panic） |
| BUG-0119 | P1 | 3bd374e | PASS | screen_console.c:25-42 | （+ screen_font.c:34-39）  指针安全（滚动 memcpy 越界 #PF） |
| BUG-0120 | P1 | 3bd374e | PASS | screen_fb.c:62-64 | （fill_rect）、74-76（blit）  整数安全（裁剪溢出绕过 → 越界写） |
| BUG-0121 | P1 | 3bd374e | PASS | driver_pci.c:104-124 | 逻辑/整数（64 位 BAR 截断 + bar_index 无校验） |
| BUG-0122 | P1 | 3bd374e | PASS | driver_nic_rtl8169.c:167-172 | 探测逻辑死代码：rtl8168/rtl8125/rtl810x 三个家族永远无法初始化 |
| BUG-0123 | P1 | 3bd374e | PASS | driver_nic_other.c:97-99 | , 199-203   同类死代码：3c59x 与 nForce 家族永远无法初始化 |
| BUG-0124 | P1 | 3bd374e | PASS | driver_nic_other.c:292-305 | , 390-431（另见 213-226, 117-130）  "假发送"存根：send 返回成功但不发送任何字节；AR81xx/Yukon 以全零 MAC 注册 |
| BUG-0125 | P1 | 3bd374e | PASS | driver_nic_rtl8139.c:272-278 | , 293-301   发送路径三缺陷叠加：失效等待死代码 + 多余的 TSD=0 写 + 超时仍推进槽位（KI-SH-01 首要嫌疑，见 §4） |
| BUG-0126 | P1 | 3bd374e | PASS | driver_nic_ixgbe.c:286-287 | , 305-315   依据 82598/82599 datasheet（及 Linux ixgbe 布局）：TX 命令位写错字、RX 写回字段偏移全错 → 真硬件上 TX 读越界 |
| BUG-0127 | P1 | 3bd374e | PASS | driver_nic_rtl8169.c:331-332 | （对比 146 行 RX 有 EOR）  TX 描述符环从不设置 EOR → 真硬件上第 32 帧后发送机跑出环外永久停摆 |
| BUG-0128 | P1 | 3bd374e | PASS | driver_nic_bcm57xx.c:259-266 | , 277-286   TX 无任何完成回收检查（环回绕即覆盖在途描述符）+ RX 缓冲从未提交给硬件 |
| BUG-0129 | P1 | 3bd374e | PASS | driver_snd_virtio.c | :230-241 |
| BUG-0130 | P1 | 3bd374e | PASS | driver_snd_hda.c:279-283 | 、690-701 |
| BUG-0131 | P1 | 3bd374e | PASS | driver_snd_hda.c:225-271 | （243 行）、296-363（359 行） |
| BUG-0132 | P1 | 3bd374e | PASS | net_sshd.c | 实测：sshd 启动后阻塞监听，Ctrl+C 无法中断，shell 完全失去响应（^C 字节未被消费），只能重启虚拟机。 |
| BUG-0133 | P1 | 3bd374e | PASS | fs_vfs.c/shell umount | 实测：umount / 无任何防护（不检查根/忙），执行后 mount 表为空，ramfs 全部数据（含 /etc 配置）丢失，所有文件操作失败，无恢复路径只能重启。 |
| BUG-0134 | P1 | 3bd374e | PASS | core_sched/shell | 实测：连续 run loop × 8 后系统响应从 0.1s 恶化到 30s+（ps 超时），loop 进程为死循环且无便捷 kill 途径（run 输出 pid 与 kill 需 |
| BUG-0135 | P1 | 3bd374e | PASS | shell/editor.c | 实测：vi 命令打开的是与 nano 完全相同的界面（同一实现），不存在 vi 双模式；发送 ithree-fox 与 :wq 全被当作文本插入。宣称的 vi 编辑器功能不实。 |

### P2 fix1 (BUG-0136..0188) — commit 97128bc  (53 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0136 | P2 | 97128bc | PASS | kernel/mem/mem_vmm.c:282-377 | ②⑦（destroy 的"USER=用户私帧"脆弱约定） |
| BUG-0137 | P2 | 97128bc | PASS | kernel/arch/x86_64/arch_idt_stub.S:81-88 | ⑧栈对齐（SysV 16 字节） |
| BUG-0138 | P2 | 97128bc | PASS | kernel/arch/x86_64/arch_idt_stub.S:57-87 | ⑥⑧（DF 标志） |
| BUG-0139 | P2 | 97128bc | PASS | kernel/arch/x86_64/arch_exceptions.c:226-265 | （配合 arch_idt.c:195-196）  ⑥⑦（IST 栈被挂起重用） |
| BUG-0140 | P2 | 97128bc | PASS | kernel/mem/mem_heap.c:200-204 | ③整数溢出 |
| BUG-0141 | P2 | 97128bc | PASS | kernel/mem/mem_heap.c:75-119 | ,210-218   ②④⑤（碎片化下大分配永久失败 + 池槽泄漏） |
| BUG-0142 | P2 | 97128bc | PASS | kernel/arch/x86_64/arch_multiboot2.c:20-72 | （及 kernel/mem/mem_pmm.c:69-70）  ①④（畸形 mbi 越界读/除零） |
| BUG-0143 | P2 | 97128bc | PASS | driver_usb.c | :114-127 |
| BUG-0144 | P2 | 97128bc | PASS | driver_usb.c:902 | , 957, 976, 1237-1249, 1320 |
| BUG-0145 | P2 | 97128bc | PASS | driver_usb.c:921-929 | , 1124-1130 |
| BUG-0146 | P2 | 97128bc | PASS | driver_usb_xhci.c:280-294 | , 328-334, 869-875 |
| BUG-0147 | P2 | 97128bc | PASS | driver_usb_xhci.c | :701-702 |
| BUG-0148 | P2 | 97128bc | PASS | driver_usb_xhci.c:465-467 | , 494-496, 863-864 |
| BUG-0149 | P2 | 97128bc | PASS | driver_usb_xhci.c:1 | 047-1050 |
| BUG-0150 | P2 | 97128bc | PASS | driver_usb_xhci.c:1 | 001-1008 |
| BUG-0151 | P2 | 97128bc | PASS | driver_usb_xhci.c:610-619 | , 950-963 |
| BUG-0152 | P2 | 97128bc | PASS | driver_usb_xhci.c:758 | , 862, 869-875 |
| BUG-0153 | P2 | 97128bc | PASS | driver_usb_xhci.c:381-392 | , 749, 789 |
| BUG-0154 | P2 | 97128bc | PASS | driver_usb.c:961-991 | + 906-932 |
| BUG-0155 | P2 | 97128bc | PASS | driver_usb.c:942 | ,970-983 |
| BUG-0156 | P2 | 97128bc | PASS | driver_usb.c | :669-734 |
| BUG-0157 | P2 | 97128bc | PASS | driver_usb.c | :554-571 |
| BUG-0158 | P2 | 97128bc | PASS | driver_usb.c:649 | -658, :73 |
| BUG-0159 | P2 | 97128bc | PASS | driver_usb_ohci.c:720-722 | , 289, 308, 344, 409, 477 等 |
| BUG-0160 | P2 | 97128bc | PASS | driver_usb_ehci.c:209-216 | , 617-622, 674-701 |
| BUG-0161 | P2 | 97128bc | PASS | driver_usb_ohci.c:359 | -366, 181 |
| BUG-0162 | P2 | 97128bc | PASS | driver_usb_ohci.c | :242-251 |
| BUG-0163 | P2 | 97128bc | PASS * | driver_usb_ohci.c:394 | , 402, 417-418, 446 |
| BUG-0164 | P2 | 97128bc | PASS | driver_usb_ohci.c | :662-675 |
| BUG-0165 | P2 | 97128bc | PASS | driver_usb_ohci.c:253-263 | , 261, 420 |
| BUG-0166 | P2 | 97128bc | PASS | driver_usb_ehci.c | :318-324 |
| BUG-0167 | P2 | 97128bc | PASS | driver_usb_msc.c | :182-196 |
| BUG-0168 | P2 | 97128bc | PASS | driver_usb_msc.c | :375-376 |
| BUG-0169 | P2 | 97128bc | PASS | driver_usb_ehci.c:410 | -424, 418 |
| BUG-0170 | P2 | 97128bc | PASS | driver_usb_serial.c:261-274 | （对照 234-258） |
| BUG-0171 | P2 | 97128bc | PASS | driver_usb_serial.c | :214-215 |
| BUG-0172 | P2 | 97128bc | PASS | driver_usb_audio.c:149-153 | , 165-169 |
| BUG-0173 | P2 | 97128bc | PASS | driver_usb_ehci.c | :239-242 |
| BUG-0174 | P2 | 97128bc | PASS | driver_usb_audio.c:183 | -192, 202 |
| BUG-0175 | P2 | 97128bc | PASS | driver_usb_ehci.c:495-499 | , 556-559 |
| BUG-0176 | P2 | 97128bc | PASS | driver_usb_ehci.c | :642-648 |
| BUG-0177 | P2 | 97128bc | PASS | driver_usb_ehci.c:282 | , 288, 297（对照 270 的 QH_EPCHAR_DTC） |
| BUG-0178 | P2 | 97128bc | PASS | fs_vfs.c:640 | 只读 fd 检查用全等可被绕过 |
| BUG-0179 | P2 | 97128bc | PASS | fs_vfs.c:462-468 | 节点缓存命中用 strcasecmp，与大小写敏感 fs 冲突 |
| BUG-0180 | P2 | 97128bc | PASS | fs_ramfs.c:111-127 | 稀疏洞未清零 → 内核堆内容泄漏进文件 |
| BUG-0181 | P2 | 97128bc | PASS | fs_vfs.c:897-908 | list_mounts 行缓冲极限溢出 |
| BUG-0182 | P2 | 97128bc | PASS | fs_vfs.c:768-783 | 权限位只存不查 |
| BUG-0183 | P2 | 97128bc | PASS | fs_vfs.c:681 | seek 返回值 int 截断 |
| BUG-0184 | P2 | 97128bc | PASS | fs_vfs.c:293-297 | + 303-324   umount "/" 后 g_global_root 悬挂；挂载点遮蔽产生重复子节点 |
| BUG-0185 | P2 | 97128bc | PASS | fs_fat32.c:211-224；fs_exfat.c | （mount 998 区）  FAT#1 镜像 / exFAT number_of_fats 从不更新 |
| BUG-0186 | P2 | 97128bc | PASS | fs_fat32.c:229-243 | FSINFO 结构从不读写；alloc 每次从簇 2 线性扫描 |
| BUG-0187 | P2 | 97128bc | PASS | fs_fat32.c:606-622 | 、576-583   LFN 别名恒 "XXXXXX~1"：不查冲突、丢扩展名；读取不校验 checksum/序号 |
| BUG-0188 | P2 | 97128bc | PASS | fs_fat32.c:331-339 | mark_entry_deleted 只回溯同簇 LFN |

\* manual grep verification (the mechanical exact-string check missed because later refactors evolved the code around the fix):
- BUG-0163: driver_usb_ohci.c:125,481,497 修复注释在（grep 实证）

### P2 fix2 (BUG-0189..0241) — commit 539bbb8 (+c4e8057 embed chain)  (53 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0189 | P2 | 539bbb8 | PASS | fs_fat32.c:1049-1051 | read_dir_entries 4096 条（128KiB 目录项）硬上限静默截断 |
| BUG-0190 | P2 | 539bbb8 | PASS | fs_fat32.c:846 | 、879   append_cluster 返回值忽略 |
| BUG-0191 | P2 | 539bbb8 | PASS | fs_fat32.c:306-314 | file_size 写入 u32 截断 |
| BUG-0192 | P2 | 539bbb8 | PASS | fs_exfat.c:503-508 | O_TRUNC 未实现 |
| BUG-0193 | P2 | 539bbb8 | PASS | fs_exfat.c:581-588 | 扩链计数起点错：current_bytes 初始化为 1 簇 |
| BUG-0194 | P2 | 539bbb8 | PASS | fs_exfat.c:573-589 | 扩展出的新簇不清零 → 洞读出陈旧磁盘数据 |
| BUG-0195 | P2 | 539bbb8 | PASS | fs_exfat.c:694-707 | create() 构建 VFS 节点但不挂树 → 每次 O_CREAT 泄漏 |
| BUG-0196 | P2 | 539bbb8 | PASS | fs_exfat.c:1021-1030；fs_ext4.c:719-728 | unmount 只释放根节点，缓存子节点泄漏 |
| BUG-0197 | P2 | 539bbb8 | PASS | fs_exfat.c:995-998；fs_ext4.c:26-27 | exFAT 忽略 partition_offset；exFAT/ext4 只支持整盘 LBA0 |
| BUG-0198 | P2 | 539bbb8 | PASS | fs_ext4.c:669-717 | 、695   mount 无 incompat 特征检查；log_block_size 移位 UB；inode_size 不验证 |
| BUG-0199 | P2 | 539bbb8 | PASS | fs_ext4.c:515-516 | >2GB 文件 read 直接返回 0 |
| BUG-0200 | P2 | 539bbb8 | PASS | fs_ext4.c:328-368 | extent 深度 >1 不支持且不检测 |
| BUG-0201 | P2 | 539bbb8 | PASS | net_core.c:33-50 | dma_alloc：先查余量后对齐 → 最多 15+size 字节越页写；>4KB 路径单帧无校验 |
| BUG-0202 | P2 | 539bbb8 | PASS | net_core.c:390-404 | , 447-448, 463   virtio TX/RX 用硬编码 VIRTIO_NUM_DESC=256 取模，而非协商出的 rx_size/tx_size |
| BUG-0203 | P2 | 539bbb8 | PASS | net_core.c:2280-2284 | TCP data_offset 未验证 |
| BUG-0204 | P2 | 539bbb8 | PASS | net_core.c:1024-1044 | , 1046-1081, 1083-1114   ARP：无老化（timestamp 字段从未赋值/检查）、满表固定覆盖 0 号、单次请求无重试、报文长度被 (void)len 忽 |
| BUG-0205 | P2 | 539bbb8 | PASS | net_core.c:2200-2225 | net_tcp_send：rtx_buf 满时照发但不入重传队列（静默丢可靠性）；无 Nagle；peer 零窗口时 sendable=0 返回 0 |
| BUG-0206 | P2 | 539bbb8 | PASS | net_core.c:2685-2712 | net_accept 超时单位错误：注释 "120 s @1000 Hz"，实际 OC_TIMER_HZ=100 → 120*1000 ticks = 1200 秒（20 分钟） |
| BUG-0207 | P2 | 539bbb8 | PASS | net_core.c:2070 | 客户端本地端口 = 40000 + (总连接数 % 10000)，无在用冲突检查 |
| BUG-0208 | P2 | 539bbb8 | PASS | net_core.c:2228-2247 | net_tcp_close 只等 1 秒即释放；LAST_ACK 状态定义了但从未进入；无 TIME_WAIT |
| BUG-0209 | P2 | 539bbb8 | PASS | net_core.c:2341-2348 | SYN_SENT 收 SYN+ACK 不验证 ack==our_seq 即建立 |
| BUG-0210 | P2 | 539bbb8 | PASS | net_core.c:1489-1514 | , 1516-1520   无 IP 分片重组（flags_frag 完全忽略）、无 IP 选项处理、目的地址以"低字节==0xFF"当广播接受、版本号不校验 |
| BUG-0211 | P2 | 539bbb8 | PASS | net_core.c:3218-3232 | , 3343-3356   DNS 查询构造无总长上界（`(void)buf_len` 明示忽略）写入 buf[512] |
| BUG-0212 | P2 | 539bbb8 | PASS | net_core.c:2200-2209 | + tcp_cc 集成   拥塞窗口实际不生效：sendable 恒被钳到 1 MSS |
| BUG-0213 | P2 | 539bbb8 | PASS | ld_so.c:506-514 | , 196-219   DT_NEEDED 只计数不加载（无依赖递归）；符号查找范围仅 libfoo.so；硬编码 4096 条 dynsym 上限；强未定义符号静默解析为 0+a |
| BUG-0214 | P2 | 539bbb8 | PASS | ld_so.c:647-656 | 跳转 main 入口前不构造 argc/argv/envp/auxv，也无返回蹦床 |
| BUG-0215 | P2 | 539bbb8 | PASS | ld_so.c:364-394 | vs 405-411   ldso_dlopen 不校验 ELF 魔数（dlsym 校验了）且 phnum 无界 |
| BUG-0216 | P2 | 539bbb8 | PASS | ld_so.c:7-11 | , 142-144   无加载基址随机化（固定 0x20000000/0x30000000/0x50000000 bump）、全部 PT_LOAD 映射 R+W+E（无 W^X） |
| BUG-0217 | P2 | 539bbb8 | PASS | net_core.c:1695-1712 | , 2629-2645   UDP：未绑定端口不发 ICMP 端口不可达；socket rx 满即丢包；同端口多 socket 只有第一个收到 |
| BUG-0218 | P2 | 539bbb8 | PASS | net/net_ssh.c:725-1041 | 握手失败路径泄漏 TCP socket |
| BUG-0219 | P2 | 539bbb8 | PASS | net/net_ssh.c | （全文）  无密钥重交换（rekey）支持 |
| BUG-0220 | P2 | 539bbb8 | PASS | net/net_ssh.c | （KEX/NEWKEYS 段）  无 strict-kex（Terrapin，RFC 9144）加固 |
| BUG-0221 | P2 | 539bbb8 | PASS | net/net_ssh.c:786-790 | + net_sshd.c:689 + net_tls.c:530   X25519 共享密钥全零不检查 |
| BUG-0222 | P2 | 539bbb8 | PASS | net/net_sshd.c:1130-1153 | USERAUTH 无失败次数上限/延迟 → 无限口令爆破 |
| BUG-0223 | P2 | 539bbb8 | PASS | net/net_sshd.c:975-976 | 口令非常量时间比较 + 用户名实际不校验 |
| BUG-0224 | P2 | 539bbb8 | PASS | net/net_sshd.c:1002-1011 | handle_exec 负 reqlen → 负偏移 OOB 读 |
| BUG-0225 | P2 | 539bbb8 | PASS | net/net_sshd.c:1080-1099 | + 627-637   嵌套栈帧 ~12KB 逼近 16KB 引导栈 |
| BUG-0226 | P2 | 539bbb8 | PASS | net/net_sshd.c:1212-1257 | 单连接服务器：并发会话数 = 1 |
| BUG-0227 | P2 | 539bbb8 | PASS | net/net_tls.c:480-482 | + 1234   ServerHello 选择的套件不对照报价单校验 |
| BUG-0228 | P2 | 539bbb8 | PASS | net/net_tls.c:1309-1313 | 告警与 close_notify 不可区分 → 截断攻击无检测 |
| BUG-0229 | P2 | 539bbb8 | PASS | net/net_tls.c:797-823 | TLS1.2 CBC 填充预言（Lucky13 类） |
| BUG-0230 | P2 | 539bbb8 | PASS | net/net_tls.c:609-611 | + 1074   CertificateVerify/SKE 的 sig_len 不与消息长度核对 |
| BUG-0231 | P2 | 539bbb8 | PASS | net/net_tls.c:856-925 | net_tls12_send_record 对静态 rec[16640] 无长度校验 |
| BUG-0232 | P2 | 539bbb8 | PASS | net/net_tls.c | （全文）  无重协商处理（RFC 5746） |
| BUG-0233 | P2 | 539bbb8 | PASS | net/net_tls.c:508-521 | + 1223-1237   TLS1.2 回退无降级哨兵检查 |
| BUG-0234 | P2 | 539bbb8 | PASS | net/net_tls.c:1333 | net_tls_close 有效性判断写错（fd 0 有效却提前返回） |
| BUG-0235 | P2 | 539bbb8 | PASS | net/net_ssh.c:953-957 | ,1010-1014（对照 net_sshd.c:1127-1148 注释）  SSH 客户端不发 SERVICE_REQUEST 即发 USERAUTH |
| BUG-0236 | P2 | 539bbb8 | PASS | shell.c:566 | 单帧 8 KiB 栈数组逼近 16 KiB 内核栈 |
| BUG-0237 | P2 | 539bbb8 | PASS | shell.c:275 | help -w 潜伏越界读 + 未知 tag |
| BUG-0238 | P2 | 539bbb8 | PASS | shell.c:1145-1157 | alias 目标含操作符被静默截断 |
| BUG-0239 | P2 | 539bbb8 | PASS | shell_cmds_disk.c:179-197 | mkfs.* 无任何确认 |
| BUG-0240 | P2 | 539bbb8 | PASS | shell_cmds_disk_test.c:302-307 | disk_rw_test 用未初始化栈数据"恢复"扇区 |
| BUG-0241 | P2 | 539bbb8 | PASS | shell_cmds_file.c:708-716 | write 失败误报成功 |

### P2 fix3 G1 (BUG-0242..0247) — 98a8dc7  (6 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0242 | P2 | 98a8dc7 | PASS | editor.c:148-163 | , 167-172   nano/vi 大文件静默截断 + 读错误当 EOF |
| BUG-0243 | P2 | 98a8dc7 | PASS | shell_cmds_snd_test.c:479 | play 潜在除零 |
| BUG-0244 | P2 | 98a8dc7 | PASS | shell_cmds_disk.c:212-219 | mkfs.exfat 无最小尺寸检查 |
| BUG-0245 | P2 | 98a8dc7 | PASS | shell.c:61-67 | 注册"替换"路径不保证 NUL |
| BUG-0246 | P2 | 98a8dc7 | PASS | shell_cmds_disk.c:53 | parted 边界检查顺序 |
| BUG-0247 | P2 | 98a8dc7 | PASS | shell.c:1333-1350 | capture 缓冲泄漏 |

### P2 fix3 G2 (BUG-0248/0249/0254/0256..0258) — 25304ec  (6 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0248 | P2 | 25304ec | PASS | l1/l1_wp8b.c:431-435 | 自测断言过期：BUG-007 修复后 so_unload(0) 返回 -1，"always succeeds"测试必失败；且整个 ext_wp8b_selftest 无调用方 |
| BUG-0249 | P2 | 25304ec | PASS | l1/l1_wp8cd.c:113-186 | job_create 取"最高 pid 活进程"的竞态启发式；fg 不等待 |
| BUG-0254 | P2 | 25304ec | PASS | l1/l1_wp8a.c:9-29 | WP-08a 全部 21 个 int 0x80 包装编进内核二进制却不可从内核态调用（死层） |
| BUG-0256 | P2 | 25304ec | PASS | l1/l1_wp8b.c:159-184 | so_load 的 BSS 清零跳过"已映射"的边界页（该页尾部为脏物理内存） |
| BUG-0257 | P2 | 25304ec | PASS | l1/l1_wp8b.c:257 | 、312、333   symbol_resolve / reloc_apply 符号表扫描无边界 |
| BUG-0258 | P2 | 25304ec | PASS | l1/l1_wp8b.c:357-408 | elf_get_needed 无缓冲尺寸参数，越界读 + vaddr 当文件偏移 |

### P2 fix3 G3 (BUG-0250..0253,0255) — a8c48ab  (5 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0250 | P2 | a8c48ab | PASS | userprogs/ush.c:1068 | 、1230、1693   tail/sort/sed 实际只读前 12KB（16KB 缓冲只用到 12288） |
| BUG-0251 | P2 | a8c48ab | PASS | userprogs/ush.c:1812-1816 | awk 模式过滤：带右斜杠的 `/pat/` 反而把过滤整个禁用 |
| BUG-0252 | P2 | a8c48ab | PASS | userprogs/ush.c:2014-2072 | 别名不在重定向路径展开 |
| BUG-0253 | P2 | a8c48ab | PASS | userprogs/ush.c:679-682 | `exit [code]` 的退出码被丢弃 |
| BUG-0255 | P2 | a8c48ab | PASS | userprogs/ush.c:916 | `wc` 以 WRONLY CREAT 打开只读用途的文件 |

### P2 fix3 G4 doc items (BUG-0259..0265) — 48b5655  (7 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0259 | P2 | 48b5655 | PASS (doc) | docs/ | ** README 统计区：129 接口（实际 138）、14 WP（实际 15，WP-10-wp08fix1 无章节）、75,806 行（其自带验证命令现在返回 46,595）。 |
| BUG-0260 | P2 | 48b5655 | PASS (doc) | docs/ | ** README/INTERFACES.md "37 syscalls" vs core_syscall.h 实际 46 个 SYS_。 |
| BUG-0261 | P2 | 48b5655 | PASS (doc) | docs/ | ** 版本口径分裂：README 标题 WP-10c / 统计 WP-10d / Makefile 默认 WP-10-project_restructure-fix1 / HEAD |
| BUG-0262 | P2 | 48b5655 | PASS (doc) | docs/ | ** KNOWN_ISSUES §2A.2/§2A.4/§5.2 声称"不验证证书/主机密钥/公网 TLS 被拒"，代码已实现 TLS1.3+X.509 链验证+Finished  |
| BUG-0263 | P2 | 48b5655 | PASS (doc) | docs/ | ** EXTENSIONS_WP10d.md 尾表 OHCI=open 与同文 §9 及 README "ALL PASS" 直接矛盾。 |
| BUG-0264 | P2 | 48b5655 | PASS (doc) | docs/ | ** INTERFACES.md（"as of WP-10d-fix2"）缺接口 130-138 等，§4 文件名为重构前名字、计数 4 处不符。 |
| BUG-0265 | P2 | 48b5655 | PASS (doc) | docs/ | ** STATUS.md 停在 WP-09+fix5，15 个 WP 只覆盖 2 个，违反 WORKFLOW §5 第 10 项自己的流程要求。 |

### P2 fix3 G5 repo hygiene (BUG-0266..0273) — 1353e71  (8 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0266 | P2 | 1353e71 | PASS (doc) | .gitignore 体系 | worklog.md 声明不跟踪却实际跟踪；否定规则把 159MB 二进制提交进公开仓 |
| BUG-0267 | P2 | 1353e71 | PASS (doc) | releases/isos/ 归档资产 | 同名文件多重哈希，归档与任何 manifest 都对不上 |
| BUG-0268 | P2 | 1353e71 | PASS (doc) | 双 website 副本 | 三方不同步 + 根副本含不可构建的遗留文件 |
| BUG-0269 | P2 | 1353e71 | PASS (doc) | oc-os/website 内部 | i18n / site.ts / home.ts 三处数据互相矛盾；site.STATS 是死代码 |
| BUG-0270 | P2 | 1353e71 | PASS (doc) | docs-zh/ | 中文翻译滞后英文原文约两代（结构性漂移） |
| BUG-0271 | P2 | 1353e71 | PASS (doc) | 页面 metadata | 全线过期（SEO/分享摘要与内容不符） |
| BUG-0272 | P2 | 1353e71 | PASS (doc) | 发布脚本 | 硬编码路径 + 时代错位的写死提交信息 + 无部署前哈希校验 |
| BUG-0273 | P2 | 1353e71 | PASS (doc) | 归档说明三件套 + releases/notes | 与现实严重脱节 + note SHA 自相矛盾 |

### P2 fix3 G6 (BUG-0274..0280 + #UD root cause) — 51d1edb + 6153593  (7 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0274 | P2 | 51d1edb | PASS | core_syscall.c:296-363 | sys_fork 不继承 mmap_base/next_solib_addr |
| BUG-0275 | P2 | 51d1edb | PASS * | core_usermode.c:215-249 | SYS_EXIT(0) 清理路径与 EXIT2 不一致 |
| BUG-0276 | P2 | 51d1edb | PASS | core_syscall.c:1525-1575 | sys_write2(72) 管道分支缺"无读者"检查 + 控制台回退无原子窗口 |
| BUG-0277 | P2 | 51d1edb | PASS | core_syscall.c:993-1236 | ; core_usermode.c:284-299   exec 不重置信号状态；信号 handler 无栈上 restorer |
| BUG-0278 | P2 | 51d1edb | PASS | core_syscall.c:113-141 | , 870-888   chdir/getcwd/相对路径解析基于全局 g_cwd，无进程隔离 |
| BUG-0279 | P2 | 51d1edb | PASS | core_usermode.c:544-567 | , 444-522   launcher 死眠泄漏线程槽；fork AS 拷贝 OOM 返回半成品 |
| BUG-0280 | P2 | 51d1edb | PASS | core_syscall.c:1261-1345 | sys_map_solib 失败不回滚；内联 ELF 解析无 bounds 校验 |

\* manual grep verification (the mechanical exact-string check missed because later refactors evolved the code around the fix):
- BUG-0275: core_usermode.c:278 修复注释在（grep 实证）

### P2 fix3 G7 (BUG-0281..0286) — c1f68a7  (6 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0281 | P2 | c1f68a7 | PASS | core_syscall.c:614-656 | , 671-733   mmap/munmap/mprotect 区域上限不一致；prot/addr 被忽略 |
| BUG-0282 | P2 | c1f68a7 | PASS | core_sched.c:608-621 | （对照 489-494、623-626）  reap 无互斥 → 栈双重释放窄窗口 |
| BUG-0283 | P2 | c1f68a7 | PASS | core_sched.c:164-168 | idle 栈分配失败未检查 |
| BUG-0284 | P2 | c1f68a7 | PASS | core_sched.c:451-455 | switch_to 违反"idle 永不入队"不变量 |
| BUG-0285 | P2 | c1f68a7 | PASS | core_sync.c:28-46 | 自旋锁非中断安全（有文档的设计决定） |
| BUG-0286 | P2 | c1f68a7 | PASS | core_sync.c:172-192 | （对照 core_sync.h:40-46）  mutex 无优先级继承、无等待者管理 |

### P2 fix3 G8 (BUG-0287..0291) — 65a55eb  (5 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0287 | P2 | 65a55eb | PASS | core_rtc.c:63-79 | 12 小时制换算错误 |
| BUG-0288 | P2 | 65a55eb | PASS | core_power.c:70-75 | （对照 58-64、81-95）  halt 不刷块设备缓存 |
| BUG-0289 | P2 | 65a55eb | PASS | core_timer.c:128-142 | one-shot 注册与 IRQ0 扫描的竞态 |
| BUG-0290 | P2 | 65a55eb | PASS | main.c:1813-1823（l1/l1_wp8cd.c:60-64 | 同）  非 volatile 标志自旋等待 |
| BUG-0291 | P2 | 65a55eb | PASS | main.c:1382-1383 | cr3test 不检查 alloc_frame 失败 |

### P2 fix3 G9 (BUG-0292..0294) — 2df3cf7  (3 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0292 | P2 | 2df3cf7 | PASS | crypto_sha512.c:143-181 | crypto_hmac_sha384 实为 HMAC-SHA-512 截断（休眠缺陷，POC 证实） |
| BUG-0293 | P2 | 2df3cf7 | PASS | crypto_aead.c:500-531 | g_mac_buf 静态共享缓冲 + 超限静默垃圾 tag |
| BUG-0294 | P2 | 2df3cf7 | PASS | crypto_bn.c:199-201 | （+ crypto_ec_nist.c:91-92、crypto_core.c:39-40）  静态工作区/惰性初始化无锁，不可重入 |

### P2 fix4 G1 (BUG-0295..0298) — d01bf5a  (4 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0295 | P2 | d01bf5a | PASS | crypto_x509.c:470-472 | + crypto_ec_nist.c:485-552   ecdsa_verify 不校验公钥在曲线上（防御深度缺失） |
| BUG-0296 | P2 | d01bf5a | PASS | crypto_curve25519.c:175-231 | + crypto_curve25519.h:16-19   X25519 无全零共享密钥检查，且调用方也未检查 |
| BUG-0297 | P2 | d01bf5a | PASS | crypto_bn.c:282-286 | crypto_bn_mod_bytes：上限检查在使用之后（潜在栈溢出写） |
| BUG-0298 | P2 | d01bf5a | PASS | crypto_core.c:386-393 | + 596-607   分配失败静默返回（密钥材料为垃圾）+ 帧大小假设 |

### P2 fix4 G2 (BUG-0299..0304) — 8a08d40  (6 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0299 | P2 | 8a08d40 | PASS | kernel/ota/ota_ab.c:64 | ,343-350（+ l1/l1_ext.h:160、ota_ab.c:1005）  版本缓冲 64B 修复不完整（任务专项核对项） |
| BUG-0300 | P2 | 8a08d40 | PASS | kernel/lib/lib_tar.c:152-158 | （另 96-106）  逻辑：非普通条目带 body 时不同步跳过 |
| BUG-0301 | P2 | 8a08d40 | PASS | kernel/lib/lib_tar.c:165-169 | + kernel/ota/ota_ab.c:822-847   逻辑：空文件被安装器丢弃 |
| BUG-0302 | P2 | 8a08d40 | PASS | kernel/ota/ota_ab.c:1010-1013 | ,1106-1115   错误处理/安全设计：--local 校验形同虚设 |
| BUG-0303 | P2 | 8a08d40 | PASS | tools/host_gzip_test.c:14-34 | 工具损坏（重构遗留） |
| BUG-0304 | P2 | 8a08d40 | PASS | kernel/ota/ota_ab.c:497 | ,510-511,637-641,646,653-659   错误处理：下载路径不查写返回值 + Content-Length 整型溢出 |

### P2 fix4 G3 (BUG-0305) — a4ba09d  (1 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0305 | P2 | a4ba09d | PASS | kernel/ota/ota_ab.h:69-71 | + grub-ab.cfg:25-38   设计：无启动尝试计数，bootfail 兜不住"起不来"的 B |

### P2 fix4 G4 (BUG-0306..0314) — c106755  (9 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0306 | P2 | c106755 | PASS | driver_block_virtio_blk.c:373-377 | used ring 轮询无超时 → 设备不完成即整机死循环 |
| BUG-0307 | P2 | c106755 | PASS | driver_block_virtio_blk.c:226-229 | , 323-333, 405-408   完全不读 host features：FLUSH 未协商就下发、RO 盘不识别 |
| BUG-0308 | P2 | c106755 | PASS | driver_block_virtio_blk.c:391 | , 401   `count * 512u` u32 乘法溢出（重点整数安全类，当前堆上限下不可达） |
| BUG-0309 | P2 | c106755 | PASS | driver_block_part.c:144-146 | , 118-124   GPT 项校验不足：无 CRC32、无 first/last 排序校验、不与盘容量核对 |
| BUG-0310 | P2 | c106755 | PASS | driver_block_part.c:189-199 | 分区子设备读写不做 lba+count ≤ sectors 边界检查 |
| BUG-0311 | P2 | c106755 | PASS | driver_block_disk_setup.c:333-350 | （对照 install 的 495 行）  abdisk 不检查父盘整盘挂载 |
| BUG-0312 | P2 | c106755 | PASS | driver_block_disk_setup.c:508 | install 分区大小 64→32 位截断，>2TiB 盘不拒绝 |
| BUG-0313 | P2 | c106755 | PASS | driver_block_blk.c:32 | /53-57/125   unregister 后 g_blk_count 不回缩：满表注销一个后无法再注册；注销不清 name/ops/stats |
| BUG-0314 | P2 | c106755 | PASS | driver_block_cache.c | 全文件 + driver_block_blk.c 缓存路径   块缓存全程无锁（并发任务 I/O 竞态） |

### P2 fix4 G5 (BUG-0315..0317) — dd0882f  (3 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0315 | P2 | dd0882f | PASS | driver_block_ata_dma.c:99-103 | , 221-225, 391   BMDMA PRD 构造违反 PCI IDE 规范：EOT 位放错 + 计数 off-by-one + 未用表项不清零 |
| BUG-0316 | P2 | dd0882f | PASS | driver_block_ahci.c:428-436 | IDENTIFY 容量只取 words 100/101（32 位）→ >2TiB SATA 盘容量截断 |
| BUG-0317 | P2 | dd0882f | PASS | driver_block_nvme.c:450-451 | , 434-437   admin 队列固定 64 深不按 MQES 收缩（I/O 队列收缩了） |

### P2 fix4 G6 (BUG-0318..0327) — 239f298  (10 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0318 | P2 | 239f298 | PASS | screen_console.c:50-53 | 整数安全（cols/rows 为 0 时状态回绕） |
| BUG-0319 | P2 | 239f298 | PASS | screen_console.c | 全文件（putc/scroll_up_one）+ driver_input_keyboard.c:239-245   并发/中断安全 |
| BUG-0320 | P2 | 239f298 | PASS | screen_console_in.c:62-66 | + 92-99   逻辑（inject 双跑 hook） |
| BUG-0321 | P2 | 239f298 | PASS | screen_console_in.c:158-167 | 并发/中断（readline lost-wakeup） |
| BUG-0322 | P2 | 239f298 | PASS | screen_fb.c:12-38 | 错误处理（fb_init 校验不足） |
| BUG-0323 | P2 | 239f298 | PASS | screen_serial_in.c:33 | 循环边界（drain 无逃生） |
| BUG-0324 | P2 | 239f298 | PASS | driver_pci.c:20-32 | , 171-175   并发（0xCF8/0xCFC 无锁） |
| BUG-0325 | P2 | 239f298 | PASS | driver_input_keyboard.c:152-171 | 逻辑（E0 扩展码不处理右 Ctrl/AltGr） |
| BUG-0326 | P2 | 239f298 | PASS | driver_input_keyboard.c:39-52 | + 191-193   逻辑（NumLock 无效、小键盘三键无映射） |
| BUG-0327 | P2 | 239f298 | PASS | driver_input_keyboard.c:91-111 | 并发（ring 多生产者无锁） |

### P2 fix4 G7 (BUG-0328..0337) — 147adc7  (10 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0328 | P2 | 147adc7 | PASS | driver_nic_e1000e.c:352-356 | TX 超时不报错：等待失败仍返回 len（虚假成功） |
| BUG-0329 | P2 | 147adc7 | PASS | driver_nic_rtl8139.c:313-318 | 坏头部恢复策略错误：CAPR 清零导致与芯片写指针永久失步 |
| BUG-0330 | P2 | 147adc7 | PASS | driver_nic_rtl8139.c | （全文件）  RX 溢出标志（RXOVW/FOVW）从不检查与清除；默认混杂模式加剧溢出概率 |
| BUG-0331 | P2 | 147adc7 | PASS | driver_nic_ixgbe.c:45 | , 59, 50-51, 204-207   寄存器偏移/位定义与 datasheet 不符：HLREG0=0x05000（实为 0x0424）、LU=bit8（实为 bit7）、 |
| BUG-0332 | P2 | 147adc7 | PASS | driver_nic_e1000e.c:199-200；driver_nic_bcm57xx.c:130-131 | / igb.c:211-212 / ixgbe.c:131-132 / other.c:284-285   MMIO 驱动缺少有效的 I/O BAR 防护（检查是死代码或缺失） |
| BUG-0333 | P2 | 147adc7 | PASS | driver_nic_igb.c:74 | , 201-202   SRRCTL 缓冲尺寸编码存疑：`(2u << 10)` 落在 BSIZEHDR 区而非 BSIZEPKT（不确定，需 datasheet 复核） |
| BUG-0334 | P2 | 147adc7 | PASS | driver_nic.c | （框架）+ 全部驱动实现 + net_core.c:3540-3578, 5083-5089   shell 线程直接调用 driver_nic_send/recv 与定时器 IR |
| BUG-0335 | P2 | 147adc7 | PASS | driver_nic_e1000e.c:366-368；driver_nic_igb.c:391-395 | RX 错误标志被忽略：坏帧照常上送协议栈 |
| BUG-0336 | P2 | 147adc7 | PASS | driver_nic_igb.c:307-309；driver_nic_ixgbe.c:235-237；driver_n | , 364   pdev 白名单逻辑失效：只验厂商不验设备号 |
| BUG-0337 | P2 | 147adc7 | PASS | driver_nic_igb.c:358-362 | 每个发送槽首次使用都要空转 100 万次 |

### P2 fix4 G8 (BUG-0338..0349) — c11c2ee  (12 items)

| BUG | Sev | Fix commit | At HEAD | Location | Issue (audit wording, trimmed) |
|-----|-----|-----------|---------|----------|-------------------------------|
| BUG-0338 | P2 | c11c2ee | PASS | driver_snd_sb16.c:211-215、driver_snd_es1370.c:184-188、driver | :440-443 |
| BUG-0339 | P2 | c11c2ee | PASS | driver_snd_hda.c:502 | -516、522 |
| BUG-0340 | P2 | c11c2ee | PASS | driver_snd_ac97.c:336-349、driver_snd_hda.c | :666-670 |
| BUG-0341 | P2 | c11c2ee | PASS | driver_snd_sb16.c:301-309、driver_snd_es1370.c | :283-294 |
| BUG-0342 | P2 | c11c2ee | PASS | driver_snd_sb16.c:150 | -158、293 |
| BUG-0343 | P2 | c11c2ee | PASS | driver_snd_es1370.c:61-62 | 、218-230 |
| BUG-0344 | P2 | c11c2ee | PASS | shell/editor.c | 实测：nano 每次按键触发两次重绘，且第二次重绘行内容只显示到光标处（内容截断）。保存内容正确但显示损坏。 |
| BUG-0345 | P2 | c11c2ee | PASS | shell/shell.c | 实测：双引号不被 shell 解析——echo "special ; \| &" 报 echo: cannot open file（带引号参数被当文件名走 cat 语义）。 |
| BUG-0346 | P2 | c11c2ee | PASS | shell power/sleep | 实测：sleep 2 输出 Suspending... Suspend not supported (ACPI required)——sleep 命令是 ACPI 挂起语义而非延时 |
| BUG-0347 | P2 | c11c2ee | PASS | Makefile:42 + ota | 实测：默认构建版本串 WP-10-project_restructure-fix1 过旧，checkupdate 对线上 wp08fix1 恒报 New version avail |
| BUG-0348 | P2 | c11c2ee | PASS (live re-run) | 申报差异 | 实测复核：help -a 与 shell_register_command 注册数均为 168（双向 diff 为空），申报的 172 无法复现，差异 4 条。第一步报告的 172 |
| BUG-0349 | P2 | c11c2ee | PASS (live re-run) | 性能标注 | 实测：dhtest（1024-bit modexp）在 TCG 无 KVM 环境下 120 秒未完成（前 2 向量 PASS），无法在合理时间内验证完整 DH 测试。环境限制，非功 |

## Per-item before/after code

The full extracted diff hunks (before-context + after) for all 349 items are in
`docs/audit/acceptance-p0p1p2-code-evidence.md` (generated from `git show` of the
mapped commits). Representative examples per batch are pasted in the acceptance
chat report.
