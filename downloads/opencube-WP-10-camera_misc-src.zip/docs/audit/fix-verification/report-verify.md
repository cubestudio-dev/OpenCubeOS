# Open Cube OS P0/P1/P2 修复验证报告（WP-AUDIT-01-VERIFY）

- **验证对象**：开发 AI 声称已全部修复的 P0（41 条）/ P1（94 条）/ P2（214 条），共 **349 条**（BUG-0001..BUG-0349）；P3（258 条）声明不修，不在验证范围
- **验证基线**：私密仓库 HEAD `8e44699`（WP-10-AUDIT_P2-fix4 发布链完成点，159 commits）；对照审查基线 `07caac0`（= 原 `152412b8` 的重写等价树，WP-10-wp08fix1）
- **验证人**：GLM-5.3（审计 AI）+ 24 路并行验证子代理
- **验证日期**：2026-10-11
- **验证方式**：三层——①声称映射核对 ②代码级逐条验证（24 组 × 平均 14.5 条，全部实际 Read 新旧两树源码）③编译 + QEMU 实测（含原 P0 崩溃复现项）

---

## 1. 执行摘要

| 层 | 结果 |
|---|---|
| ① 声称映射 | 349 条编号**无空隙**：P0=p0fix1(0001..0020)+p0fix2(0021..0041)；P1=p1fix1(0042..0072)+p1fix2(0073..0103)+p1fix3(0104..0135)+p1fix4 收尾；P2=fix1(0136..0188)+fix2(0189..0241)+fix3(0242..0294)+fix4(0295..0349)。开发侧 KNOWN_ISSUES §5/§5B 有 P0 逐条表，fix2 曾因上下文丢失被开发侧诚实标记 NOT STARTED 后重做 |
| ② 代码级逐条 | **FIXED 288（82.5%）/ PARTIAL 45（12.9%）/ WRONG 4（1.1%）/ DOC-FIXED 11 / NEEDS-RUNTIME 1 / NOT-FIXED 0** |
| ③ 实测 | `make clean && make` **0 err 0 warn**（-Werror 全开）✓；`make iso` 11.45MB BIOS+UEFI 双启动 ✓；tcptest（原 100% 崩溃）**ALL PASS** ✓；dhtest 5/5 ✓；回归套件（fstest/cryptotest/heaptest/pmmrace/vmtest/g6/fork/pipe/signal/sse/pf/select）全 PASS ✓；vi 双模式实测生效 ✓；rollback/update 无盘拒绝 ✓；**sshd 首次运行实测 FAIL（新回归，见 §4.1）** |

**一句话结论**：349 条声称修复中 **340 条属实**（FIXED 288 + DOC-FIXED 11 + NEEDS-RUNTIME 实测转正 1 + PARTIAL 45 中均有真实主体修复），**4 条修复本身写错（WRONG）**，**45 条修复不彻底（PARTIAL）**，其中 6 条 P0 级安全残留 + 1 条实测新回归需要优先处理。**无一条虚假声称**（NOT-FIXED=0：没有任何"说修了但实际没动代码"的条目）；但 4 条 WRONG 属于"修了但修错方向"，其中 2 条在真机上比原 bug 更糟。

---

## 2. 判定标准

| 判定 | 定义 |
|---|---|
| FIXED | 原 bug 已正确完整修复，修复本身再审未发现新问题 |
| PARTIAL | 主体已修，但审计点名的场景/路径仍有残留（每条报告均写明剩余部分） |
| WRONG | 修复本身错误：修错位置 / 引入新 bug / 从未生效 |
| DOC-FIXED | 纯文档/注释/发布产物类修复（A17/A18 域为主） |
| NEEDS-RUNTIME | 代码级无法判定，需运行时验证 |
| NOT-FIXED | 声称修复但原 bug 原样存在 |

---

## 3. 代码级验证统计（24 组 × 349 条）

| 组 | 域 | 条数 | FIXED | PARTIAL | WRONG | DOC | RUN | 明细文件 |
|---|---|---|---|---|---|---|---|---|
| G01 | A14 ssh/tls P0 重灾区 | 22 | 16 | 6 | 0 | 0 | 0 | G01.md |
| G02 | A14 ssh/tls/sshd | 14 | 12 | 2 | 0 | 0 | 0 | G02.md |
| G03 | A14 ssh/tls | 13 | 8 | 5 | 0 | 0 | 0 | G03.md |
| G04 | A12 fs | 22 | 21 | 1 | 0 | 0 | 0 | G04.md |
| G05 | A12 fs | 12 | 12 | 0 | 0 | 0 | 0 | G05.md |
| G06 | A13 net_core/tcp/ld_so | 15 | 11 | 3 | **1** | 0 | 0 | G06.md |
| G07 | A13 net_core/ld_so | 14 | 12 | 2 | 0 | 0 | 0 | G07.md |
| G08 | A11 usb 外设/ohci/ehci | 13 | 12 | 1 | 0 | 0 | 0 | G08.md |
| G09 | A11 usb 外设 | 13 | 11 | 0 | **1** | 1 | 0 | G09.md |
| G10 | A15 shell | 20 | 18 | 2 | 0 | 0 | 0 | G10.md |
| G11 | A10 usb 核心/xhci | 20 | 18 | 2 | 0 | 0 | 0 | G11.md |
| G12 | A6 block | 18 | 14 | 4 | 0 | 0 | 0 | G12.md |
| G13 | A8 nic 驱动 | 17 | 13 | 3 | **1** | 0 | 0 | G13.md |
| G14 | A2 syscall/usermode | 16 | 15 | 1 | 0 | 0 | 0 | G14.md |
| G15 | A16 l1/userprogs/构建 | 16 | 14 | 1 | **1** | 0 | 0 | G15.md |
| G16 | A5 lib/ota | 15 | 15 | 0 | 0 | 0 | 0 | G16.md |
| G17 | A3 core/main | 14 | 14 | 0 | 0 | 0 | 0 | G17.md |
| G18 | A7 display/pci/input | 14 | 14 | 0 | 0 | 0 | 0 | G18.md |
| G19 | A4 crypto | 11 | 9 | 2 | 0 | 0 | 0 | G19.md |
| G20 | RUNTIME 实测项 | 11 | 8 | 1 | 0 | 1 | 1 | G20.md |
| G21 | A1 arch/boot/mem | 10 | 10 | 0 | 0 | 0 | 0 | G21.md |
| G22 | A17 docs 一致性 | 10 | 0 | 1 | 0 | 9 | 0 | G22.md |
| G23 | A18 website/发布链 | 10 | 4 | 6 | 0 | 0 | 0 | G23.md |
| G24 | A9 声卡 | 9 | 7 | 2 | 0 | 0 | 0 | G24.md |
| **合计** | | **349** | **288** | **45** | **4** | **11** | **1** | |

NEEDS-RUNTIME 的 1 条（BUG-0349 dhtest TCG 时延）**实测已转正**：本轮 QEMU 实测 5/5 全 PASS（见 §5）。

---

## 4. 必须优先处理的问题

### 4.1 实测新回归（不在原 607 条内，本轮实测发现）

**NEW-01 · sshd 首次运行不可用（实测 FAIL）**
- 复现：全新会话（/etc 无持久化密钥）执行 `sshd` → 打印 `[sshd] generating per-installation host key (RSA-2048, one-time)...` 后**卡死 >300 秒**（TCG 下 RSA-2048 密钥生成未在观测窗内完成），期间：
  - `Ctrl+C` **完全无效**（密钥生成循环无键盘排水/取消钩子；启动横幅却写着 "Ctrl+C cancels wait"）
  - 整个 shell 不可用，后续命令（dhcp/ping/netstat/ps）全部无法执行
- 根因：p1fix2 的 BUG-0075 修复（每安装生成 host key，替换内嵌密钥）引入。原审计时 sshd 内嵌密钥秒启，RUN-02 卡死在 accept 环节（该环节已修）；现在卡死点**前移**到密钥生成
- 开发侧 "SSH 5/5 PASS" 为何没发现：验证环境的 etc.img 已带生成好的密钥（持久化），跳过了首次生成路径——典型的"验证环境带状态"陷阱
- 建议：密钥生成放后台线程 + shell 立即返回；或生成循环内加键盘取消检查；或降级密钥参数（首次安装体验优先）

### 4.2 WRONG（4 条——修复本身错误）

| BUG | id | sev | 问题 | 后果 |
|---|---|---|---|---|
| **BUG-0069** | A13-6 | P1 | SYN_RCVD 30s 回收是**死代码**：`net_tcp_check_rto` 中 `state != TCP_ESTABLISHED → continue`（net_core.c:2502）排在 SYN_RCVD 回收判定（:2507）**之前**，该"修复"从 p1fix1 引入起从未执行过，经三轮重排未被发现 | **审计原始远程 DoS 原样成立**：32 个伪造 SYN 永久占满 32 槽连接表，出站 connect 一并瘫痪 |
| **BUG-0175** | A11-22 | P2 | EHCI 速度判定读 PORTSC bits 13:12 当 "Port Speed"——**该字段在 EHCI 规范中不存在**（bit13=Port Owner、bit12=Port Power；经 Intel EHCI 1.0 spec Table 2-16 + QEMU ehci-regs.h + Linux ehci_port_speed() 三重核证）。与 xHCI Speed 域（bits 13:10）张冠李戴 | **真机 EHCI 全面失效**（比原 bug 更糟）：每个加电端口的每个设备（含 HS）误报 LS → QH EPS=LS 时序 + mps0 恒 8。QEMU 门禁仍绿仅因其 EHCI 不消费 EPS。续修：PED=1⇔HS + LINESTAT 判 LS 或 TDI PSPD bits 27:26 |
| **BUG-0335** | A8-17 | P2 | igb 把 e1000e **legacy** 描述符错误掩码 `status_error & 0x17` 原样搬到 igb **advanced** 描述符 status_error 低位——该区域是状态位（DD/EOP/IXSM/VP），**EOP=0x02 在其中**。正确掩码是 ≥bit24 的 E1000_RXDEXT_STATERR_* | **igb RX 全毁**（比原 bug 更糟）：ADV_ONEBUF 模式下每个完整帧写回都带 EOP → 全部正常帧被当错误帧丢弃。该文件无 QEMU 模型、仅编译验证，commit 自述不确。e1000e 半边基本正确但 Linux 实际掩码为 0x97（含 RXE=0x80），commit 声称 0x17 有误 |
| **BUG-0251** | A16-13 | P2 | ush awk 尾斜杠剥离 off-by-one：尾斜杠在 `argv[2][pl]`，代码写 `argv[2][pl-1]`——**往前一字节砍掉模式最后一个真实字符**。host C 模拟实证 `/apple/` 按 `"appl"` 过滤 | awk 模式匹配错乱；提交自述测试通过只因 "appl" 恰是 "apple" 子串。正确写法：`pattern[pl-1] = 0` |

### 4.3 P0 级安全残留（PARTIAL 中最严重，共 6 项）

| BUG | id | 残留 | 威胁 |
|---|---|---|---|
| **BUG-0024** | A14-18 | mlen 三重检查修好了 body 溢出，但 body 扩到 18432 后 blen 上限 18428 > chain_buf 14336，而证书链拆分循环（net_tls.c:1387-1391）只查迭代入口 `used`、**没有 `used + dlen ≤ sizeof(chain_buf)`** | **原 finding 复现值（Certificate mlen=0x4000）仍可在 verify_chain 之前越界写 chain_buf ~2KB**（构造多证书条目最高 ~4KB，内容=攻击者证书字节）。基线中此洞被 body 溢出掩盖，修复后成为首达溢出点 |
| **BUG-0035** | A4-01 | (size_t)-1 memcpy 写原语已闭环（u32 累加+拒>0x7FFFFFFF），但修复改写过的同一行 `d->len < hdr + l`（crypto_x509.c:56）**int 加法仍回绕**：DER 长度 [0x7FFFFFFA..0x7FFFFFFF]（6 个值通过 ul 门）使 hdr+l 变负绕过界检查 → 解析器读 der+~2GiB 野指针。**本轮自建 ASAN POC 复证 SEGV**；仓库自测 5 向量恰好全部落在溢出边之外 | 远程 TLS 证书可触发内核 #PF。一行修复：`if (l > d->len - hdr) return -1;`（审计原建议即纯比较形态） |
| **BUG-0040 + BUG-0054** | A6-1 + A11-36 | NVMe 侧修复正确；但 A11 修复（usb_msc.c:457 注册真实 block_size）与块层消费面**打架**：blk.c:115/133 仍按 BLK_SECTOR_SIZE=512 步进、cache 槽 512B、FS 缓冲按 512 分配 | **4Kn USB 存储上单扇区读越界写 3584 字节**——与原 P0 完全同型的堆溢出在最终树重新可达（两域修复互相冲突）。修法：blk 注册层统一拒绝非 512 或块层真正消费 sector_size |
| **BUG-0010/0011/0015/0019** | A14 族 | `off + len > plen` **有符号回绕家族**：四处修复在长度 ∈ [0x7FFFFFFC..0x7FFFFFFF] 时加法回绕为负绕过检查（net_ssh.c:444/539/550、net_sshd.c:1346/1417/1445/1582）→ off/ed 变野指针。BUG-0019 的 slen/mlen（net_sshd.c:1425-1429）完全未校验 | **预认证/预凭证远程 #PF**（读侧）。同批修复里 A14-03/A14-10 用了正确的减法式 `len > plen - q`，其余没跟上——建议一次性统一 |
| **BUG-0017** | A14-11 | K_S 段预算 `4 + 276` off-by-3：RSA-2048 模数 mpint 实际最大 `4 + 279`（带 need_zero 字节） | 攻击者可调 client_kexinit_len 使交换哈希实际写入超 4096B PMM 页 **1-3 字节**（内容为不可知共享密钥尾字节，半盲写） |
| （配套）BUG-0224 | A14-38 | reqlen∈[0x7FFFFFF8,0x7FFFFFFF] 时 `off+reqlen` 回绕仍得负 off → payload[off] 野读（认证后可达）；修复注释自称 "full window" 不成立 | 同回绕家族，net_sshd.c:1632 |

### 4.4 其他重要 PARTIAL（P1，节选）

- **BUG-0061**（A12-011）：unlink-后-写 UAF 只修了 FAT32（open_count 守卫），**ramfs unlink 与 exFAT unlink 均无守卫**——对已 kfree 节点/inode 的 UAF 写原样可达；VFS 层亦无统一闸
- **BUG-0066**（A13-3）：IP total_len 已 clamp，但 **UDP h->length 仍不 clamp**（:1970 只查 <0）——IP 如实 + UDP length=0xFFFF + checksum=0（RFC 768 豁免）仍可让 DHCP 选项循环/DNS 解析器越界读
- **BUG-0063**（A13-10）：RTO 扫描加了 cli/sti，但审计主场景——线程 `net_tcp_send` memcpy（:2633-2635）vs IRQ0 ACK 滑窗 memmove（:2874-2891）——**仍完全无锁**；`g_net_polling` 仍非原子；修复注释 "send_raw re-enables" 系虚假陈述
- **BUG-0072**（A13-9）：IP/TCP/UDP RX 校验和已验，**ICMP 仍不验证**（:1780-1805）
- **BUG-0228**（A14-42）：TLS 1.3 记录层三分（close_notify/告警/截断）已做，但 **TLS 1.2 全部套件上 EOF 塌缩成普通 -1**（net_tls.c:1168/1177）→ 截断不可区分；且 https_get 读循环使**截断 body 仍当成功返回**（wget/ota_update_check 受害），`c->truncated` 全树无消费者
- **BUG-0229**（A14-43）：Lucky13 半修复：错误码统一 + HMAC 恒算 + 常时比较到位，但 **HMAC 输入长度仍随 pad 有效性变化**（跨 64B 边界压缩块数不同）→ 时序残面；RFC 5246 填充字节全等校验仍缺
- **BUG-0233**（A14-47）：RFC 7507 SCSV 半边完整，但 **RFC 8446 §4.1.3 ServerHello.random "DOWNGRD" 哨兵检查全文未实现**
- **BUG-0081**（A14-30）：KEY_UPDATE 递归改循环已修，但 **KeyUpdate 不被应用**（收到仍只是跳过，无 traffic key 轮换），服务器重密钥后连接断——审计明言并入本条的功能缺陷未实现
- **BUG-0055**（A11-43）：CDC-ACM probe 补了 0x02/0x01/0x00，但合法值 **0xFF（厂商自定义）被丢弃**——旧代码支持，属小回归
- **BUG-0126/0128**（A8-5/7）：ixgbe TX 完成轮询查错 dword（DD 在 offset-12 wb.status，代码查 offset-8）；bcm57xx 完成检测仍轮询生产者 BD 而非 return ring——**真硬件上两者收发功能仍不成立**（QEMU 无模型未暴露）
- **BUG-0157**（A10-8）：hub 端口复位时序本体修对，但**伴随修改把速度掩码从正确的 0x0200/0x0400（bit9=LS/bit10=HS，USB 2.0 Table 11-21）改成保留位 0x0040/0x0080**——外部 hub 下 LS/HS 设备一律误判 FS；基线原本是对的（与 BUG-0175 同族同批）
- **BUG-0083**（A15-4）：嵌套 capture 三主场景修好，但**无命令词的重定向段（`> file`）**走 exec_stage 早退，captured 上下文仍把外层会话内容写进目标文件
- **BUG-0086**（A15-7）：cp 流式复制修好，但**空源文件首读即 EOF → 目标从不创建且 rc=0**（旧代码会创建空文件）——惰性打开引入的小回归
- **BUG-0259**（A17-004）：README 行数申报 103,640，干净树实测 **93,305——恒虚高 +10,335 行**（p1fix2→fix4 五次申报全部同偏移，疑似计数环境含未跟踪生成物），已扩散到 website 四处镜像
- **BUG-0092**（A16-5）：oc> 集成的分发钩子挂在**全仓零调用方的死代码**（legacy shell_execute）上——注册名在真实 oc> 路径仍是 "unknown command"，修复注释 "IS executable at oc>" 在活路径上不成立
- **BUG-0276**（A2-12）：sys_write2 管道分支未镜像 sys_write 在 BUG-0100 修复中获得的单一 cli 窗口——丢失唤醒挂死在 syscall 72 路径仍可达

P2 级 PARTIAL 其余项（GPT 项数组 CRC 仅 ≤4KiB 窗强制、blk 中间槽位注销后注册恒失败、AC97 stop→play 后 BDBAR=0 从 IVT 取 BD、hda.bdl=spec 开关移位方向反、发布链 G5 新规被后续发布提交系统性违反等）见各组明细。

### 4.5 系统性模式（横向发现，建议专项处理）

1. **"跨家族语义搬运"**：把 e1000e legacy 语义（错误位/轮询偏移/掩码）原样搬进 igb advanced 描述符、ixgbe、bcm57xx——4 个非 FIXED 项中 3 个源于此，且全部集中在声明"无 QEMU 模型、仅编译验证"的文件。建议对 drivers/nic 做"描述符格式-错误位-写回偏移"三列核对表复查后再上真机
2. **"速度位域解码"是修复批的系统性弱点**：BUG-0175（EHCI 读不存在字段）+ BUG-0157（hub 掩码改错）同族同批。建议全仓 speed 位域专项复核
3. **"off+len 有符号回绕"家族修复不彻底**：同批修复里部分用了正确的减法式，其余没跟上。建议对 net/ 全目录做一次 `+` 溢出审计（int 加法在长度校验中统一改减法式或 u64）
4. **发布流程未遵守自家新规**：fix3-G5 建立了哈希门/镜像规则/SUMS/MANIFEST 全套，但其后 4 个发布提交系统性违反（G23 的 6 条 PARTIAL 全部同根：只改权威副本不镜像、SUMS 不再生、i18n 不随代升级）。建议在 build-local.sh 哈希门旁补"site.ts 代际 vs i18n badge"一致性 grep 门

---

## 5. 实测验证（第 3 层）

环境：QEMU 10.0.13（与原审查一致）、SeaBIOS 1.16.3、OVMF（4M）、512MB 内存、e1000 用户网络。构建产物：`WP-10-AUDIT_P2-fix4-2-g8e44699`（正确反映 HEAD git-describe，BUG-0261 修复实测生效）。

| # | 测试 | 结果 | 备注 |
|---|---|---|---|
| 1 | `make clean && make` | **PASS** | 0 error / 0 warning（-Wall -Wextra -Werror 全开） |
| 2 | `make iso` | **PASS** | 11,454,464 B，El Torito 双启动映像（BIOS+UEFI）结构完整 |
| 3 | BIOS 引导 | **PASS** | SeaBIOS → GRUB → 内核 shell |
| 4 | UEFI 引导 | **PASS** | OVMF → 内核 shell，`echo` 存活 |
| 5 | `uname -a` | PASS | `Open Cube OS WP-10-AUDIT_P2-fix4-2-g8e44699 x86_64` |
| 6 | `help -a` | PASS | Total: **176 commands**（与 INTERFACES.md/静态注册表三方一致） |
| 7 | **`tcptest`（原 RUN-01 100% 复现内核崩溃）** | **PASS** | `tcptest: ALL PASS (syn-opts=ok parser=ok)` — 原 P0 崩溃实测消除（双 16.6KB 结构下堆 + #PF 递归守卫） |
| 8 | `fstest` | PASS | VFS 自检 + BUG-0178/0179/0180/0182/0184 p2 回归 ALL PASS |
| 9 | `cryptotest` | PASS | 4/4（SHA-256/AES-128/HMAC-SHA256/**HMAC-SHA384**——BUG-0294 修复实测生效） |
| 10 | `heaptest` | PASS | overhead 4%，free 后无泄漏 |
| 11 | `pmmrace` | PASS | 20000 轮 torn=0（PMM 原子性，BUG-0043 实测生效） |
| 12 | `vmtest` | PASS | map/protect/unmap/destroy 全过（含 BUG-0136 PT-ownership） |
| 13 | **`dhtest`（BUG-0349，静态 NEEDS-RUNTIME）** | **PASS** | g^0/1^x PASS、group14 2048-bit 固定向量 2/2 PASS、scale sweep **5/5**（1024→256 bit 全对）——TCG 时延项实测转正 |
| 14 | `dhcp` + `ping 10.0.2.2 3` | PASS | DHCP 获址 10.0.2.15；ping 收到 reply |
| 15 | 用户程序回归 | PASS | fork/pipe/signal/sse/pf/select_zero **全 PASS**；g6_test T1-T7 全 =PASS=、failed=0、dlopen 3704（fork rsp0 #UD 修复 + 分配器游标继承实测生效） |
| 16 | `echo "a > b"`（BUG-0345） | PASS | 正确打印 `a > b`（修复前死于 'echo: cannot open file'） |
| 17 | `sleep 2`（BUG-0346） | PASS | 实测 2.1s 真延时（修复前是 suspend 的报错别名） |
| 18 | **vi 双模式（RUN-05）** | **PASS** | NORMAL 模式 x/y/z 不入文件 + INSERT 生效（hello_from_insert 入文件）+ `:wq` 保存退出 + `cat` 复核——真双模式（修复前是 nano 别名） |
| 19 | `rollback`（无 A/B 盘） | PASS | `rollback: no A/B disk` 正确拒绝，内核存活 |
| 20 | `update`（无 A/B 盘） | PASS | `update: no A/B disk` 正确拒绝，内核存活 |
| 21 | **`sshd` 首次运行（原 RUN-02 场景）** | **FAIL** | 卡死在 per-installation host key 生成 >300s；`Ctrl+C` 无效；整个 shell 不可用（后续 dhcp/ping/netstat/ps 全部无法执行）。**新回归 NEW-01**，见 §4.1。注：原始 accept-环节卡死的修复代码存在（G20 判 FIXED），但被密钥生成卡死掩盖，无法在首次运行路径实测验证 |

---

## 6. 结论

1. **开发 AI 的"P0/P1/P2 全修"声称基本属实但有夸饰**：349 条中 288 条（82.5%）完整修复、11 条文档修复、45 条部分修复、4 条修错、0 条虚假声称。修复的工程质量整体较高（含大量 `_Static_assert`、双侧断言自测、RFC/Linux/QEMU 三方对照），多组子代理独立复核给予了正面评价。
2. **但"全部完成"不成立**：45 条 PARTIAL + 4 条 WRONG = 49 条（14%）未达"修复完成"标准，其中 **6 项 P0 级安全残留**（BUG-0024 证书链溢出仍可达、BUG-0035 DER 回绕 #PF ASAN 复证、BUG-0040+0054 4Kn USB 堆溢出回归、BUG-0010 族预认证野读、BUG-0017 半盲写、BUG-0224）与 **1 条实测新回归**（sshd 首次运行死机）应视为 P0 级待办。
3. **原审计的两个实测 P0 中，tcptest 崩溃已实测确认修复；sshd 卡死以另一种形式回归**（卡死点从 accept 前移到密钥生成，用户体验等价——sshd 仍不可用）。
4. **系统性风险集中在三处**：跨家族语义搬运（nic 驱动）、速度位域解码（usb）、有符号回绕家族（net）——建议各做一次专项复核，而不是逐条打补丁。
5. 验证全程未修改任何项目源代码（只读验证；构建产物在 build/ 下生成，未提交）。

---

## 7. 交付物索引

- 本报告：`docs/audit/fix-verification/report-verify.md`
- 24 组逐条明细：`docs/audit/fix-verification/G01.md` ~ `G24.md`（每条含原问题/旧树确认/新树修复检查/修复质量/判定五要素）
- 实测脚本与串口日志：沙箱 `/home/z/qemu-test/`（session1/sshd_session/more_session/uefi/vi/rollback/update 七组 log）
- 原 607 条审计：`docs/audit/report.md` + `bugs_final.json` + `findings/A1..A18.md`
