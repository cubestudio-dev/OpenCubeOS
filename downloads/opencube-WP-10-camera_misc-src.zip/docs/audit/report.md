# Open Cube OS 完整审查报告（WP-AUDIT-01）

- **审查对象**：Open Cube OS 私密仓库 `cubestudio-dev/tdghuczhdmkwicsxzjduaychuyzshjufajckafk`，HEAD `152412b8`（2026-10-04，"worklog: WP-10-wp08fix1 release completion"）
- **审查工作包**：WP-AUDIT-01（完整、逐行、逐代码、逐功能、逐用户场景审查；只审查不修复）
- **审查人**：GLM-5.3（审计 AI）+ 18 路并行审查子代理
- **审查日期**：2026-10-05
- **基线确认**：工作区干净，无未提交修改；83 commits；分支 main

---

## 1. 执行摘要

| 指标 | 结果 |
|---|---|
| 静态审查覆盖 | 18 路子代理，约 300 个源文件（.c/.h/.S/.asm/Makefile/linker/grub/文档/website），全部实际 Read 逐行读完 |
| 编译验证 | `make clean && make` → **0 error / 0 warning**（-Wall -Wextra -Werror 全开）；`make iso` → 成功（11.3MB，BIOS+UEFI 双启动） |
| QEMU 实测 | **168 条命令全部执行**（安全命令主会话 + 危险命令独立会话 + 交互命令专用会话），另加组合/暴力/兼容性 4 轮。【更正（WP-AUDIT-01-p0fix2 复核 2026-10-05）：清单数 168 系提取遗漏，实际共 172 条（内核自打印 Total: 172），见 BUG-0348 更正注】 |
| 实测崩溃 | 1 例 100% 复现内核崩溃（tcptest），1 例 shell 不可恢复卡死（sshd） |
| **总发现** | **607 条** |
| **P0（安全/崩溃/数据丢失）** | **41 条** |
| P1（功能不工作/明显错误） | 94 条 |
| P2（边界条件/质量） | 214 条 |
| P3（文档/注释/风格） | 258 条 |

### 最重要的结论

1. **网络栈预认证内存破坏成片**（A14 路发现 21 条 P0）：SSH 客户端、sshd、TLS 客户端在**握手完成/凭证校验之前**的解析路径上存在 21 处长度字段驱动的栈/页溢出。恶意服务器或任意网络客户端即可触发内核内存破坏。这是全项目最严重的系统性问题。
2. **X.509 DER 长度解析整数溢出**（A4-01，P0）：4 字节 DER 长度 `int l = (l<<8)|...` 可溢出为 -1，绕过边界检查后以 `(size_t)-1` 长度 memcpy——恶意 TLS 服务器发送一张构造证书即可破坏内核内存（host 侧 POC 已复现 SIGSEGV）。
3. **实测 100% 复现内核崩溃**（RUN-01）：`tcptest` 命令执行后触发连环 #PF——cr2=0xFD1CF480 正是 KNOWN_ISSUES §6.1 记录的 fb 区未映射页地址；且异常处理器自身在 #PF 处理中再次 #PF（rsp 每次 -0x230 递归下探）直至三重故障。静态根因：tcptest 在 16KB boot 栈上放置两个各 ~16.6KB 的连接结构（A13-1）。
4. **随机数发生器为 xorshift32 + 开机时间种子**（A4-02）：全部 TLS/SSH 会话密钥、X25519/ECDH 私钥、CBC IV、AEAD nonce 均由它生成，开机可预测——密码学层面全体系失效（注释自我声明"非生产"但已被用于实际网络功能）。
5. **文件系统校验缺失致数据损坏**（A12 路 4 条 P0）：FAT32 簇号无上界校验可越卷写盘、exFAT 分配位图从不更新（Windows 侧双分配数据丢失）、ext4 crafted 介质除零 panic、mount 消息 80 字节栈缓冲无界 strcpy。
6. **申报数字 172 命令无法复现**（RUN-10）：实测 `help -a` 与 `shell_register_command` 注册数均为 **168**（双向比对为空集差异），申报的 172 差 4 条；第一步报告中的"172 ✓"系提取假阳性未剔净，本报告予以更正。**【更正（WP-AUDIT-01-p0fix2 复核 2026-10-05）：在 p0fix2 ISO（b40c1b40）重跑 `help -a`，内核自打印 `Total: 172 commands`，输出提取 172 条；静态注册表 per-file 重计（kernel/main.c 52、shell/shell.c 6 等 12 文件）= 172 unique；双向 comm 空集差异。168 不可复现；168 与 docs/INTERFACES.md §4 旧表（重构前文件名、缺 WP-10-wp08fix1 注册点）加总一致，RUN-10 的"help -a=168"系清单提取遗漏。结论：命令数 = 172，申报正确，本条更正。】**
7. **`vi` 编辑器实为 nano 同一实现**（RUN-05）：不存在 vi 双模式，`:wq` 被当作文本插入，与 WP-08"nano editors both shells"的验收宣称不符。
8. **危险命令防护整体良好**（正面）：poweroff/reboot 真关机、update/rollback 无 A/B 盘正确拒绝、install/abdisk/fs_mount_test 强制显式参数 + DESTROYS 警告、badapp 用户态越权访问被 #PF 拦截且内核存活、fork/exec/pipe/mmap/mprotect/select/signal 用户程序全部 PASS、UEFI 启动与 256MB 内存启动正常。

---

## 2. 审查范围与方法

### 2.1 范围

- 源码：kernel/（arch/core/mem/lib/crypto/ota）、drivers/（block/nic/snd/usb/display/pci/input）、fs/、net/、shell/、l1/、libs/、boot/、userprogs/、tests/、tools/
- 构建系统：Makefile、linker.ld、grub.cfg、grub-ab.cfg、etc/opencube.conf
- 文档：oc-os/docs/ 全部 40 份（含 verification/ 7 份）、README、NOTICE
- 发布链：根部 website/ 与 oc-os/website/ 双副本、update.json/update-v2.json、releases/、website-snapshot/、归档元数据（ARCHIVE-README/SYNC-RULES/MANIFEST/worklog/.gitignore）
- 排除：build/ 产物目录内容（按任务书）；二进制产物（iso/zip/img）只登记存在性/大小/哈希

### 2.2 方法

1. **阶段 0 工具链**：无 root 重建 117 包工具链（apt-get download + dpkg-deb -x 到 /home/z/opt/extract），nasm 2.16.03 / xorriso 1.5.6 / grub-mkimage 2.12 / mtools 4.0.48 / QEMU 10.0.13 / OVMF / seabios 全部就绪。
2. **阶段 1 逐文件逐行**：18 路子代理（比计划的 15 路多拆 3 路以保证覆盖），每路按 10 项清单（指针/内存/整数/循环/错误处理/并发中断/资源/类型/字符串/逻辑注释）逐行审读指定文件清单，全部 Read 至 EOF；大数据头文件（userprogs_data.h 12593 行等）按抽读+声明一致性核对策略并在报告中声明。每路产出 findings/A<N>.md（含文件清单表、覆盖率与诚实声明）。
3. **阶段 2 编译**：`make clean && make`（-Wall -Wextra -Werror -O2）与 `make iso`，输出原样保存（/tmp/build-full.log、/tmp/build-iso.log）。
4. **阶段 3 QEMU 逐命令**：168 条命令按风险分 5 组执行【更正（p0fix2 复核）：实际命令总数 172，清单提取遗漏 4 条，见 BUG-0348 更正注】——G1 信息类（70 条主会话）、G2 文件+设备类（66 条）、G3 网络长时类（含独立重测会话）、G4 危险类（19 条，每条独立全新 QEMU 会话）、G5 交互类（nano/vi/edit/ush 专用会话）。pexpect 驱动串口，逐条记录状态/耗时/输出。
5. **阶段 4 功能缺失**：138 L1 接口算术闭合核对（A16）、46 syscall 注册核对（A2）、文档/代码/行为三方对照（A17 + 实测）。
6. **阶段 5 组合**：挂载周期、网络+文件交叉、连续 fork、别名链、异常后状态检查。
7. **阶段 6 UX**：六问逐项（见第 8 节）。
8. **阶段 7 暴力**：超长命令行（1000 字符）、超长参数（9000 字符）、特殊字符、数值边界、深路径、进程洪水（run loop ×8）、大输出连续滚动、大文件、空输入。
9. **阶段 8 兼容性**：UEFI（OVMF）启动、256MB 低内存启动；其余维度（安全审计/并发/死锁/中断安全等）由静态 18 路覆盖，性能受 TCG 无 KVM 限制单独标注。

### 2.3 诚实声明

- 审查为静态逐行阅读 + QEMU 动态实测结合；**未在真实硬件上测试**（所有 NIC/SND/USB P1 级寄存器编程问题均标注"静态确认，需真机验证"）。
- dhtest 在 TCG 环境下 120 秒未跑完（前 2 向量 PASS），完整 DH 测试未验证。
- bcm57xx/ixgbe 等 P1 的寄存器布局与 datasheet/Linux 对照确认，未运行时复现。
- 数据头文件按抽读策略，未逐字节读完（策略在各 findings 声明）。
- 每路 findings 均含"覆盖率与诚实声明"章节，不确定项逐条标注。

---

## 3. 阶段 1：18 路静态审查结果汇总

| 路 | 模块 | 文件 | 行数 | P0 | P1 | P2 | P3 | 合计 |
|---|---|---|---|---|---|---|---|---|
| A1 | arch+boot+mem+types | 25 | 3,176 | 0 | 3 | 7 | 20 | 30 |
| A2 | syscall+usermode | 5 | 15,771 | 4 | 4 | 8 | 12 | 28 |
| A3 | core 调度/同步/电源/RTC/定时器+main | 11 | 4,489 | 0 | 4 | 10 | 16 | 30 |
| A4 | crypto 全部+host tests | 16 | 5,103 | 1 | 3 | 7 | 16 | 27 |
| A5 | lib+ota+conf | 16 | 5,132 | 4 | 5 | 7 | 15 | 31 |
| A6 | drivers/block 全部 | 18 | 4,427 | 1 | 5 | 12 | 26 | 44 |
| A7 | display+pci+input | 15 | 1,614 | 0 | 4 | 10 | 18 | 32 |
| A8 | drivers/nic 全部 | 9 | 3,159 | 0 | 7 | 10 | 16 | 33 |
| A9 | drivers/snd 全部 | 12 | 3,075 | 0 | 6 | 9 | 16 | 31 |
| A10 | USB 核心+XHCI（含 UHCI） | 3 | 3,142 | 0 | 4 | 16 | 15 | 35 |
| A11 | USB EHCI/OHCI/HID/MSC/串口/音频 | 10 | 3,183 | 0 | 7 | 19 | 28 | 54 |
| A12 | fs 全部 | 10 | 4,916 | 4 | 8 | 23 | 16 | 51 |
| A13 | net_core+tcp_cc+ld_so | 5 | 6,145 | 2 | 10 | 17 | 12 | 41 |
| A14 | ssh+tls+sshd | 6 | 4,314 | 21 | 10 | 18 | 10 | 59 |
| A15 | shell 全部 | 20 | 7,693 | 3 | 5 | 12 | 20 | 40 |
| A16 | l1+userprogs+构建文件 | 42 | 7,436 | 0 | 5 | 13 | 12 | 30 |
| A17 | docs 一致性 | 43 | 8,743 | 0 | 3 | 12 | 14 | 29 |
| A18 | website+发布链 | ~70 | ~6,100 | 0 | 2 | 8 | 6 | 16 |
| RUNTIME | QEMU 实测发现 | — | — | 1 | 6 | 5 | 1 | 13 |
| **合计** | | **~330** | **~100,000** | **41** | **94** | **214** | **258** | **607** |

### 静态审查关键发现（P0 摘要）

- **A2-1**（core_syscall.c:957）：sys_poll `nfds*sizeof(pollfd_t)` 整数回绕绕过校验 → 内核写未映射用户页 → **用户态可触发内核 HALT**。
- **A2-2**（core_usermode.c:221）：SYS_EXIT 用 `char n[8]` 接无界 u64_to_str → 内核栈溢出。
- **A2-3**（core_syscall.c:1089-1231）：sys_execve 在旧地址空间销毁后构造 argv/用户栈（4GiB 恒等映射窗内）→ argv 丢失/物理内存损坏。
- **A2-4**（core_syscall.c:1794）：sys_ps 栈上 3584B 表 vs 单页内核栈 + trap 门嵌套 → 越页损坏。
- **A4-01**（crypto_x509.c:44-53）：DER 4 字节长度溢出为 -1 → ECDSA r/s `memcpy(r+(hlen-rlen),body,(size_t)-1)`——**恶意 TLS 证书即可内核内存破坏（POC 复现 SIGSEGV）**。
- **A5-01/02/03/04**（lib_config/ota_update/ota_ab）：config 值无界拷贝堆溢出、OTA 网络字段栈溢出、URL 栈溢出、tar 路径遍历任意文件写。
- **A6-1**（blk+nvme）：块层硬编码 512B 扇区 vs NVMe 4Kn LBADS → 4K 扇区盘每次缓存读写越界 3584 字节。
- **A12-001~004**：mount 消息栈溢出、**BUG-019 根因确认（ramfs rmdir 误释放 FAT32 挂载根）**、ext4 除零 panic、FAT32 簇号无上界越卷写盘。
- **A13-1/2**：tcptest 双 16.6KB 栈结构 vs 16KB boot 栈；发送路径三层嵌套 1.5KB 栈缓冲 vs 4KB kthread 栈（OTA checkupdate kthread 一做 DNS/TCP 即溢出）。
- **A14-01~21**：SSH/TLS/sshd 预认证长度驱动溢出 21 处（详见 P0 清单）。
- **A15-1/2/3**：shell 通配符 strcpy 栈溢出（env 展开可达 287 字符进 256 缓冲）、fsck 输出缓冲无条件溢出 74 字节（每次执行都在溢出）、mv 跨文件系统 1MiB 截断后无条件删源（数据丢失）。

---

## 4. 阶段 2：编译验证（原样输出）

```
$ make clean && make
[完整输出见 /tmp/build-full.log，193 行]
关键行：
cc -ffreestanding -fno-stack-protector -fno-pie -fno-pic -mno-red-zone -mno-sse
   -mno-mmx -mno-3dnow -mcmodel=kernel -fno-asynchronous-unwind-tables
   -Wall -Wextra -Werror -O2 -g -std=gnu11 ... -DOC_RELEASE_VERSION=\"WP-10-project_restructure-fix1\" ...
ld -n -nostdlib -T linker.ld -z max-page-size=0x1000 -z noexecstack -o build/opencube.elf [全部 .o]
strip --strip-debug build/opencube.elf
退出码 0；grep -ci warning = 0；真实 error（排除 -Werror 标志串）= 0

$ make iso
xorriso ... El Torito boot img : 1 BIOS y none 0x0000 0x00 4 579
El Torito boot img : 2 UEFI y none 0x0000 0x00 2048 67
退出码 0；build/opencube.iso = 11,335,680 字节
```

- 编译结论：**0 error / 0 warning**（-Werror 全开，任何警告都会使构建失败）。
- 附带确认：默认 `OC_RELEASE_VERSION` 停在 `WP-10-project_restructure-fix1`（预登记线索①实锤，启动横幅与 uname -a 同样显示）。

---

## 5. 阶段 3：QEMU 逐命令实测（168 条清单；实际总数 172，见 BUG-0348 更正注）

### 5.1 覆盖与分组

| 组 | 内容 | 条数 | 会话 |
|---|---|---|---|
| G1 | 信息/状态/内核自检类 | 70 | 单会话顺序 |
| G1b | 引擎修正后重测（set/export/alias/unalias/nice/kill/config/help 测试/exc/timer/run/ldd） | 20 | 单会话 |
| G2 | 文件操作链 + 全部设备类 *_test | 66 | 单会话 |
| G3/G3b/G3c | 网络与长时（dhcp/dns/ping/wget/ssh/sshd/sleep/tcptest/checkupdate 系列/dhtest/update_local_test） | 26 | 3 个会话（sshd 卡死后重开） |
| G4 | 危险类（poweroff/reboot/shutdown/halt/suspend/update/rollback/install/abdisk/fs_mount_test/real_hw_test/update_*_test/power_*_test） | 19 | **每条独立全新会话** |
| G5 系列 | 交互类（nano/vi/edit）+ run 用户程序 11 个 + ush | 30+ | 专用会话 |

**168 条命令全部执行**（帮助清单 `help -a` 输出 = 静态注册表 = 168，双向比对无差异）。【更正（WP-AUDIT-01-p0fix2 复核 2026-10-05）：p0fix2 ISO 重跑 `help -a` 内核自打印 `Total: 172 commands`、输出提取 172 条；静态注册表 per-file 重计 172 unique，双向 comm 空集差异；审计期 168 系清单提取遗漏（与 docs/INTERFACES.md §4 旧表加总一致），实际总数 172。】

### 5.2 结果分类

| 结果 | 数量 | 说明 |
|---|---|---|
| 正常返回且行为符合预期 | 141 | 含自检类全 PASS（tcpcc/nf/dnstest/cryptotest/config_test/help 三测/checkupdate_test/update_pkg_test/update_check_test/update_status_test/l1test/fstest/synctest/exc 3/3/vmtest/memtest/pftest/cr3test 等） |
| 无设备/无盘环境的正确降级 | 22 | 设备类 *_test 全部输出 "not present => SKIPPED" 或 "presence => FAIL"（QEMU 无对应硬件，行为正确） |
| 真实关机/重启（预期 EOF） | 4 | poweroff/reboot/shutdown/poweroff_test |
| 阻塞不可中断 | 1 | **sshd**（Ctrl+C 字节未被消费，shell 永久失去响应） |
| **内核崩溃** | 1 | **tcptest**（详见 5.3） |
| 超时（环境性能限制） | 1 | dhtest（TCG 下 120s+ 未完成，前 2 向量 PASS） |

### 5.3 实测崩溃：tcptest（RUN-01 / BUG-0041）

```
oc> tcptest
tcptest: ALL PASS (syn-opts=ok parser=ok; live negotiation covered by HTTPS E2E)

*** EXCEPTION 14: #PF Page Fault ***
  error_code=0x0000000000000000  rip=0x00000000001154A0  ...
  rsp=0x00000000003F29E8  cr2=0x00000000FD141000  (faulting address)
*** HALTING (kernel exception) ***

*** EXCEPTION 14: #PF Page Fault ***        ← 异常处理器自身再次 #PF
  error_code=0x0000000000000002  rip=0x0000000000141C14
  rsp=0x00000000003F27B8  cr2=0x00000000FD1CF480  (faulting address)
*** HALTING (kernel exception) ***
[同样条目重复 7+ 次，rsp 每次下降 0x230 —— 异常处理递归压栈]
→ 最终三重故障，QEMU 退出（-no-reboot）
```

分析：
- cr2=0xFD1CF480 = fb 基址 0xFD000000 + 0x1CF480（第 592 行），**正是 KNOWN_ISSUES §6.1 记录的"滚动边缘 #PF"地址**——该已知问题在本次实测中 100% 复现。
- 静态根因（A13-1）：tcptest 在 boot 栈（16KB，boot.S:34）上放置两个各 ~16.6KB 的 `net_tcp_conn_t`，命令自身"ALL PASS"后返回路径/后续输出触发溢出区故障。
- 连锁缺陷：#PF 处理器在故障路径上再次 #PF 时无保护（无 ist 切换/无递归阈值），递归压栈直至三重故障。

### 5.4 其他实测异常事件

1. **sshd 阻塞卡死**（RUN-02）：`[sshd] listening on port 22 (waiting for one connection)` 后完全阻塞；Ctrl+C 无法中断（字节未被消费）；后续所有命令不可达。设计为单会话监听，但**无超时、无取消通道**——用户误运行后只能重启。
2. **umount / 无防护**（RUN-03）：实测 `umount /` → "umounted /" → mount 表空 → ramfs 全部数据（含 /etc）丢失 → write/cat/mkdir/cd 全部失败，仅重启可恢复。
3. **run loop 进程洪水**（RUN-04）：连续 8 个 `run loop` 后，shell 响应从 0.1s 恶化至 30s+（ps 超时）；loop 为死循环进程，shell 无对应 kill 途径说明，无并发上限。
4. **引号不解析**（RUN-07）：`echo "special ; | & > < ..."` → `echo: cannot open file`（带空格参数被当作文件名走 cat 语义）。
5. **sleep 语义**（RUN-08）：`sleep 2` → `Suspending... Suspend not supported (ACPI required)`——sleep 是 ACPI 挂起而非延时。
6. **vi 即 nano**（RUN-05）：`vi /n1` 打开的界面与 nano 完全相同（头、状态栏、按键绑定）；`i`/`:wq` 作为文本插入。
7. **nano 双重渲染**（RUN-06）：每次按键渲染两遍，第二遍行内容只显示到光标处（保存内容正确）。
8. **用户程序输出 NUL 字节**（RUN-11）：`parent: pid=\x001` 形式，数字转字符串函数前置 NUL。

### 5.5 正面验证结果（实测通过）

- 用户程序：hello/loop/badapp（#PF 被拦截且内核存活）/fork_test/exec_test/pipe_test/mmap_test/mmap_multi/mprotect_test/p3_test/select_test/signal_test **全部 PASS**。
- ush：启动 → help（内置命令清单）→ echo → exit 回 oc>，全链路正常（但无 nano/vi）。
- 网络：dhcp（IP=10.0.2.15/gw/DNS 全获取）、dns localhost/example.com（真实解析）、ping 10.0.2.2（reply received ×4）、checkupdate（真实 TLS 拉取线上 update.json 并报版本）。
- 编辑器：nano 编辑+^O 保存+^X 退出全链路可用；edit 行编辑器 :p/:i/:w/:q 全可用。
- 危险命令防护：见 1.8。
- UEFI（OVMF）启动 ✓；256MB 内存启动 ✓。
- crashlog 随 exc 正确累积（3 → 6 entries）。

---

## 6. 阶段 4：功能缺失与申报差异

| 申报项 | 申报值 | 实测/复核值 | 裁决 |
|---|---|---|---|
| shell 命令数 | 172 | **168**（审计期记录；help -a = 注册表，双向一致） | **不符，差 4**（RUN-10；**【p0fix2 复核更正 2026-10-05：实测 172 = 172，双向 diff 空，内核自打印 Total: 172；168 不可复现，源自 docs/INTERFACES.md §4 旧表加总 + 清单提取遗漏。申报 172 正确，本行按 172 更正，BUG-0348 撤销】**） |
| L1 接口数 | 138 | 138（A16：1-57 显式 + 58-122 隐式 + 123-129 + 130-138，算术闭合） | 相符（口径为"条目"而非可调用函数；可调用函数 66 个，条目 33-57 大部为无调用方的声明式接口层） |
| syscall | 44+2=46 | 46 个 SYS_ 全部注册（ioctl 为 stub；INTERFACES.md 写 37 过期） | 相符，文档过期 |
| .c 文件 | 108 | 主树 105 + tests 10 + tools 1 = 116（含 tests） | 口径差（申报口径不明） |
| .h 文件 | 89 | 91 | 差 2 |
| .asm 文件 | 23 | 13（userprogs 12 + archive 1） | **不符**（疑为 userprogs 文件总数 21 误记） |
| 源码行数 | 90,705 | 主树 82,465（+docs 8,232 = 90,697 最接近） | 无法精确复现申报口径 |
| 工作包 | 15 | 15（README 覆盖 14，WP-10-wp08fix1 无章节） | 相符，文档覆盖 14 |
| 编译 | 0 err 0 warn | 0 err 0 warn | **相符** |
| vi 编辑器 | WP-08 宣称 nano/vi 双编辑器 | vi=nano 同一实现，无 vi 模式 | **不符**（RUN-05） |
| ush 15 工具 | syscall 96-102 桥接 | 桥接存在（NETCMD 走 shell_execute_captured），但 ush 无 nano（RUN-12），且捕获态下管道/重定向命令失效（A15-4） | 部分不符 |

### 6 处申报差异的裁决（第一步候补线索）

1. .c 108 vs 116：口径差（是否含 tests/tools），登记 P3 文档问题。
2. .h 89 vs 91：实际 91，申报少 2，登记 P3。
3. .asm 23 vs 13：**申报错误**（实际 13）。
4. 行数 90,705 vs 82,465：申报口径无法复现（最接近组合 90,697=主树+docs），登记 P3。
5. 工作包 15 vs 14：项目实际 15 个 WP，README 只覆盖 14（A17-7）。
6. tag 不在私密仓库：tag wp10-wp08-shell-and-tools-completion-fix1 属公开仓/GitHub Release，私库标签体系为 private-archive-*（26 个）。登记 P3 发布链问题（A18）。

### 9 条预登记线索的证实情况

| # | 线索 | 裁决 |
|---|---|---|
| 1 | Makefile 默认版本串过期 | **证实**（A16 + 编译输出 + 启动横幅 + RUN-09 恒报新版） |
| 2 | CONFIG.md 键名 ota_update_url vs update_url | **证实**（A17-001，P1） |
| 3 | NOTICE 旧文件名 kernel/font_data.c | **证实**（A17 记录，P3） |
| 4 | 双 website 副本不同步 | **证实**（A18-4：根=WP-10d-fix2 代、oc-os=wp08fix1 代、公开仓 main=实际部署源；根副本引用不存在组件不可构建） |
| 5 | 仓库内与线上 update.json 不一致 | **证实**（A18-2：三代 manifest 并存，线上 r2 从未归档，重建即回滚一代） |
| 6 | README/MANIFEST 滞后 | **证实**（A17-7/8：README 三代并存、MANIFEST.md 停在 WP-10b、docs/MANIFEST.txt 停在 WP-08b） |
| 7 | KNOWN_ISSUES 4 个 OPEN 项 | **证实并深化**：BUG-019 根因已定位（A12-002 ramfs rmdir 误释放挂载根）；§6.1 已实测 100% 复现（RUN-01）；KI-SH-01 rtl8139 首要嫌疑锁定（A8-4 TX 等待死逻辑） |
| 8 | 私密仓库提交了 build/ 产物 | **证实**（A18 表三：~215 个二进制，18 个关键产物哈希实测） |
| 9 | oc-os/website/ 提交了发布二进制 | **证实**（A18-10：website/.gitignore 否定规则故意入库 159MB） |

---

## 7. 阶段 5+7：组合与暴力测试结果

| 场景 | 结果 |
|---|---|
| mount→umount /→mount 周期 | **umount / 成功卸载根**（无防护）→ 后续全部文件操作失败（RUN-03） |
| 网络激活（dhcp）后文件操作 | 正常交叉无异常 |
| 连续 run fork_test ×5 | 全部 PASS，pid 递增正常，无泄漏迹象（短序列） |
| alias zz=echo → zz → unalias | 全链路正常 |
| exc 后 crashlog | 3→6 entries 正确累积 |
| 超长命令行（1000 字符） | unknown command 安全拒绝，无崩溃 |
| 超长参数（echo + 9000 字符） | 输入被截断处理（行编辑缓冲限制），无崩溃，会话存活 |
| 特殊字符（; \| & > < ` $ \\ /） | 引号不解析（RUN-07），但无崩溃 |
| 纯空格/空命令 | 无害处理 |
| kill -1 / kill 0 / nice 边界值 | 全部正确拒绝（invalid tid / invalid prio） |
| 深目录 mkdir ×3 层 | 正常创建/进入（干净会话验证） |
| vmtest/memtest/frag 内存压力 | 全 PASS |
| run loop ×8 进程洪水 | 响应劣化 10-100×，无自愈（RUN-04） |
| help -a ×3 连续大输出滚动 | 无崩溃（fb 崩溃仅在 tcptest 后复现，与 §6.1 触发条件差异待查） |
| write 500B + cat + cp + du | 正常 |

---

## 8. 阶段 6：UX 审查（六问）

### 用户能用吗？
- **基本 shell 体验良好**：172 命令覆盖广（审计期记录 168，已经 p0fix2 复核更正，见 BUG-0348）、行编辑/历史/别名工作、help/help -a/help -w 分组清晰、开机横幅带 Try 提示。
- **致命断路器**：`sshd` 误运行即失去整个 shell（无取消通道）；`umount /` 一条命令丢失全部文件数据；`tcptest` 直接崩溃内核。
- `sleep` 语义反直觉（挂起而非延时）；引号不可用使复杂参数无法表达。

### 用户知道吗？
- 危险命令有 DESTROYS 警告（install/abdisk/fs_mount_test）✓；但 `umount /` 无警告、`tcptest` 看名字像测试但会崩溃、`sshd` 未提示阻塞不可取消。

### 用户理解吗？
- `vi` 名不副实（实为 nano）直接误导 Unix 用户；nano 双重渲染造成编辑困扰；dhtest 长时间无输出无进度提示。

### 用户能找到文档吗？
- docs/ 40 份文档齐全但**版本口径分裂**（四代并存：README 标题 WP-10c/统计 WP-10d/Makefile WP-10-project_restructure-fix1/HEAD wp08fix1）；INTERFACES.md 停在 WP-10d-fix2（缺 130-138）；CONFIG.md 教错误键名（ota_update_url）；UPDATE-HOWTO 引用不存在的脚本路径。

### 用户能恢复吗？
- A/B 更新与 rollback 机制存在（无盘环境正确拒绝）✓。
- 但 `umount /`、sshd 卡死、tcptest 崩溃均**只能重启**；crashlog 可事后查看崩溃记录 ✓。

### 用户能反馈吗？
- README 有仓库地址、NOTICE 有版权与邮箱（cubestudio@qq.com）✓；FEATURE_REQUESTS.md 存在；issues 渠道依赖 GitHub。

---

## 9. 阶段 8：兼容性与其他

- **UEFI 启动**（OVMF）：完整启动到 oc>，boot complete OK ✓
- **256MB 内存**：正常启动 ✓（mem 显示 131040 页可用）
- **性能**：TCG 无 KVM 环境限制，dhtest（1024-bit modexp）>120s 未完成；SSH 类 2048-bit modexp 单次 26-30s（第一步实测）；此两项**无法在本环境给出性能结论**。
- **回归**：项目自带 6 个回归套件中的内核侧（tcpcc/nf/dns/crypto/config/help/l1test/fstest/synctest 等）实测全 PASS。
- **安全审计**：密码学常量时间多项不符（A4-04 时间侧信道）、随机数可预测（A4-02）、SSH TOFU 无锚点（A14-22）、内嵌万能 RSA 私钥（A14-24）、firewall 默认 ACCEPT（实测）。
- **数据完整性**：FAT32/exFAT 多处可造成跨文件系统数据损坏（A12 路）；OTA 链哈希校验逻辑存在但版本串污染使其恒报新版（RUN-09）。

---

## 10. 完整 bug 清单（607 条）

### 10.1 P0（41 条）——安全漏洞/内核崩溃/数据丢失

| BUG | 来源 | 位置 | 摘要 |
|---|---|---|---|
| BUG-0001 | A12-001 | fs_vfs.c:329-336 |   栈缓冲区溢出 |
| BUG-0002 | A12-002 | fs_ramfs.c:177-192 | （配合 fs_vfs.c:799-819、fs_vfs.c:303-324）  rmdir/umount 跨文件系统误释放挂载根 —— BUG-019 根因 |
| BUG-0003 | A12-003 | fs_ext4.c:703、fs_ext4.c:279 | mount 时除零 panic |
| BUG-0004 | A12-004 | fs_fat32.c:189-194 | 、262-267、211-224、1295-1296、1268-1273   簇号/保留扇区/扇区大小无校验 → 越出卷边界写盘 / 覆写引导扇区 |
| BUG-0005 | A13-1 | net_core.c:5020-5035 | 内核栈溢出（确定性内存破坏） |
| BUG-0006 | A13-2 | net_core.c:1685 | +1232+868+1995（发送路径三层嵌套 1.5KB 栈缓冲）vs core_sched.c:257-264（kthread 栈 4KB）  4KB 内核线程栈必然溢出 |
| BUG-0007 | A14-01 | net/net_ssh.c:131-148 | 长度字段驱动的物理页溢出（SSH 客户端，预认证） |
| BUG-0008 | A14-02 | net/net_ssh.c:180-191 | server_banner[64] 溢出（SSH 客户端，预认证） |
| BUG-0009 | A14-03 | net/net_ssh.c:283-292 | （配合 202-212）  KEXINIT name-list 长度整数溢出 → OOB 读循环（SSH 客户端，预认证） |
| BUG-0010 | A14-04 | net/net_ssh.c:338-345 | curve25519 路径 KEX_ECDH_REPLY 的 ks_len 负值 → 巨型 memcpy（SSH 客户端，预认证） |
| BUG-0011 | A14-05 | net/net_ssh.c:428-464 | group14 路径 KEXDH_REPLY 的 ks_len/f_len 负值 → 野指针巨型 memcpy（SSH 客户端，预认证） |
| BUG-0012 | A14-06 | net/net_ssh.c:576-628 | 交换哈希 H 输入溢出 4096B 物理页（SSH 客户端，预认证） |
| BUG-0013 | A14-07 | net/net_ssh.c:1179-1235 | 加密收包 rest_buf/dec_rest 溢出（SSH 客户端，NEWKEYS 后） |
| BUG-0014 | A14-08 | net/net_sshd.c:170-196 | 未认证收包 35000 字节读入 4096B 页（sshd，监听端口，预认证） |
| BUG-0015 | A14-09 | net/net_sshd.c:1099-1111 | KEXDH_INIT e_len 负值 → 野指针巨型 memcpy（sshd，预认证） |
| BUG-0016 | A14-10 | net/net_sshd.c:643-654 | KEXINIT name-list q+L 溢出 → 野地址读（sshd，预认证） |
| BUG-0017 | A14-11 | net/net_sshd.c:484-518 | 交换哈希 H 输入溢出 4096B 页（sshd，预认证） |
| BUG-0018 | A14-12 | net/net_sshd.c:310-373 | 加密收包 rest_buf/dec_rest/body/mac_input 四重溢出（sshd，KEX 后、认证前） |
| BUG-0019 | A14-13 | net/net_sshd.c:838-841 | 与 965-969   USERAUTH 负长度 → 巨型 memcpy（sshd，凭证校验之前） |
| BUG-0020 | A14-14 | net/net_sshd.c:1178-1185 | CHANNEL_OPEN_FAILURE 的 fail[16] 栈溢出（sshd，认证后；默认凭证 oc/oc） |
| BUG-0021 | A14-15 | net/net_tls.c:1352-1362 | https_get req[1024] 栈溢出（OTA 路径，远端内容驱动，4KB kthread 栈上） |
| BUG-0022 | A14-16 | net/net_tls.c:152-158 | TLS1.3 记录长度检查比缓冲大 256 → 溢出（预认证，握手期明文记录即可） |
| BUG-0023 | A14-17 | net/net_tls.c:783-823 | TLS1.2 记录长度检查 cap+2080 → 最高 2080 字节溢出；合法最大 CBC 记录也溢出（预认证） |
| BUG-0024 | A14-18 | net/net_tls.c:939-942 | TLS1.2 Certificate 消息 mlen 拷入 body[12288] 溢出（证书校验之前，无需有效证书） |
| BUG-0025 | A14-19 | net/net_tls.c:971-974 | TLS1.2 ServerKeyExchange 的 mlen 完全未检查（需有效证书链） |
| BUG-0026 | A14-20 | net/net_tls.c:984-1008 | TLS1.2 DHE ServerKeyExchange 的 sbuf[384] 溢出（需有效证书） |
| BUG-0027 | A14-21 | net/net_tls.c:656-671 | TLS1.3 CertificateVerify ECDSA 签名 DER r/s 长度未检查 → 栈下溢写（需有效 ECDSA 证书链） |
| BUG-0028 | A15-1 | shell.c:875-885 | 字符串缓冲（栈溢出） |
| BUG-0029 | A15-2 | shell_cmds_disk.c:380-394 | （二次使用 434-439）  字符串缓冲（无条件栈溢出） |
| BUG-0030 | A15-3 | shell_cmds_file.c:344-346 | + 379-382   数据丢失 |
| BUG-0031 | A2-1 | core_syscall.c:957-991 | sys_poll 的 nfds * sizeof(pollfd_t) 整数回绕绕过校验 → 内核对未映射用户地址写 → ring-0 #PF → 内核 HALT（用户态可触发 panic）   |
| BUG-0032 | A2-2 | core_usermode.c:221-226 | SYS_EXIT(0) 用 char n[8] 接收无界 u64_to_str(用户可控 code) → 内核栈缓冲区溢出最多 13 字节   |
| BUG-0033 | A2-3 | core_syscall.c:1089-1231 | sys_execve 在 CR3 已切到内核 AS、旧 AS 已销毁之后构造 argv/envp 与用户栈内容 → 所有用户 VA 读写走 0-4GiB 恒等映射窗口：argv 读到垃圾/丢失，栈写入落在物理 ~0x3FFFxxxx（≥1GiB 机器=破坏活物理帧；512MiB QEMU=静默丢失， |
| BUG-0034 | A2-4 | core_syscall.c:1787-1802 | sys_ps 栈上 ktab[64]=3584B，而内核线程栈只有 1 页 4096B（core_sched.c:264），入口已耗 ~3990B，余量 ~100B；0x80 为 trap 门(0xEE) IF=1，嵌套定时器中断(≥184B)必越页 → 相邻物理帧损坏（间歇性）   |
| BUG-0035 | A4-01 | crypto_x509.c:44-53 | + crypto_x509.c:456-467   整数溢出 → 负长度 memcpy → 内核内存破坏（远程可触发） |
| BUG-0036 | A5-01 | kernel/lib/lib_config.c:285 | ,303-318   内存管理/堆溢出 |
| BUG-0037 | A5-02 | kernel/ota/ota_update.c:692 | ,707-709   字符串缓冲/栈溢出（网络触发） |
| BUG-0038 | A5-03 | kernel/ota/ota_update.c:272-278 | 字符串缓冲/栈溢出（URL 路径） |
| BUG-0039 | A5-04 | kernel/ota/ota_ab.c:790-794 | ,880-886   路径遍历/任意文件写 |
| BUG-0040 | A6-1 | driver_block_blk.c:96-109 | + driver_block_nvme.c:519-524, 634-646   块层/缓存层硬编码 512B 扇区 vs NVMe 注册非 512 sector_size → 4K 扇区盘上每次缓存读越界写内存 |
| BUG-0041 | RUN-01 | net_core.c:5020/5034 + vmm | 实测复现：tcptest 命令完成后触发连环 #PF（cr2=0xFD1CF480 为 fb 区未映射页，即 KNOWN_ISSUES §6.1 地址），异常处理器自身递归 #PF（rsp 每次 -0x230）直至三重故障，QEMU 退出。100% 复现。 |

### 10.2 P1（94 条）——功能不工作/明显错误

| BUG | 来源 | 位置 | 摘要 |
|---|---|---|---|
| BUG-0042 | A1-1 | kernel/arch/x86_64/arch_context_switch.S:75-115 | （全仓缺失）  ⑥并发/资源管理 |
| BUG-0043 | A1-2 | kernel/mem/mem_pmm.c:193-202 | （及 229-247）  ⑥并发/中断安全 |
| BUG-0044 | A1-3 | kernel/mem/mem_vmm.c:404-448 | ③⑤⑩（缺页处理语义错误） |
| BUG-0045 | A10-20 | driver_usb_xhci.c:300-312 | , 1084-1097 |
| BUG-0046 | A10-21 | driver_usb_xhci.c:965-976 | vs 564-575 |
| BUG-0047 | A10-22 | driver_usb_xhci.c:415-419 | , 651, 682 |
| BUG-0048 | A10-4 | driver_usb.c | :468-471 |
| BUG-0049 | A11-1 | driver_usb_ehci.c | :637-639 |
| BUG-0050 | A11-16 | driver_usb_ohci.c:676-704 | , 452-506 |
| BUG-0051 | A11-17 | driver_usb_ohci.c:407-413 | , 430-449 |
| BUG-0052 | A11-18 | driver_usb_ohci.c | :728-731 |
| BUG-0053 | A11-35 | driver_usb_msc.c:131-150 | , 178-200 |
| BUG-0054 | A11-36 | driver_usb_msc.c:243-249 | , 375-380 |
| BUG-0055 | A11-43 | driver_usb_serial.c:167-169 | , 135-138 |
| BUG-0056 | A12-005 | fs_fat32.c:696-708 | rmdir 对含 ./.. 的标准目录永远失败 |
| BUG-0057 | A12-006 | fs_fat32.c:1321 | 、1367-1381   g_last_ctx 在 umount 后悬挂 → df 触发 UAF |
| BUG-0058 | A12-008 | fs_fat32.c:251-259、389、443、696；fs_exfat.c:229-236 | 、319、576-580、801、406   FAT/exFAT 簇链遍历无环检测 → 内核死循环（挂死） |
| BUG-0059 | A12-009 | fs_exfat.c:213-236 | （设计面）  exFAT 分配位图（0x81）从不读写 → 位图与 FAT 不一致 |
| BUG-0060 | A12-010 | fs_ext4.c:317 | 、348-349   extent 条目起始偏移错误（root +16 字节、child +8 字节，正确均为 +12）→ extent 卷读错数据 |
| BUG-0061 | A12-011 | fs_ramfs.c:224-243；fs_fat32.c:812-907 | unlink 后仍打开的 fd 继续写：ramfs UAF 写 / FAT32 复活已释放簇链（可破坏他文件） |
| BUG-0062 | A12-012 | fs_ext4.c:253-273 | 、276-297、444-472   crafted 卷多处越界读（栈/堆） |
| BUG-0063 | A13-10 | net_core.c:3540-3578 | + 2212-2224 vs 2362-2395   IRQ 与线程对 TCP rtx/rx 状态的无锁竞态 |
| BUG-0064 | A13-11 | net_core.c:566-573 | 与 645-657   e1000_init 对未初始化栈缓冲调用 strcat |
| BUG-0065 | A13-12 | ld_so.c:371-379 | , 419-426, 493-500, 508-514, 549-560, 590-597, 616-623   .dynamic 遍历无界（d_tag 循环仅靠 DT_NULL 终止） |
| BUG-0066 | A13-3 | net_core.c:1520 | , 1695-1712, 2823-2843, 3077-3199   IP/UDP 长度字段未与实际帧长核对 → 远程可触发 OOB 读 |
| BUG-0067 | A13-4 | net_core.c:2359 | , 2425, 2481, 2487, 2495   TCP 序号比较无回绕保护（before/after 宏缺失） |
| BUG-0068 | A13-5 | net_core.c:2334-2338 | RST 零验证盲注 |
| BUG-0069 | A13-6 | net_core.c:2299-2327 | + 2143-2149   SYN_RCVD 永不超时 → 32 个 SYN 永久打满连接表（远程 DoS）；服务端 SYN 选项不解析 |
| BUG-0070 | A13-7 | net_core.c:1669-1678 | + 3204/3239/3319/3369/3394/3416/3439 + 2881   net_udp_bind 无去重、无解绑，DNS 每次解析重复绑定，返回值全部被忽略 |
| BUG-0071 | A13-8 | net_core.c:2084 | + 2049-2057   窗口缩放错配：通告 scale=7 但窗口值不缩放 → 对端以为有 1MB 缓冲（实际 8KB） |
| BUG-0072 | A13-9 | net_core.c:2271-2606 | （全 RX 路径）  IP/TCP/UDP/ICMP 接收校验和一概不验证 |
| BUG-0073 | A14-22 | net/net_ssh.c:484-571 | （配合 net_ssh.h:21-23,31）  SSH 客户端主机密钥验证是"仅签名、无锚点"的 TOFU → 无 MITM 防护 |
| BUG-0074 | A14-23 | net/net_ssh.c:320 | ,389 / net_sshd.c:587-587,685,743 / net_tls.c:247-251,875,896   A4-02（xorshift32 PRNG）在协议层的完整影响面 |
| BUG-0075 | A14-24 | net/net_sshd_rsa_key.h:7-43 | + net_sshd.c:854-950 + net_ssh.c:870-957   内嵌"万能"RSA 私钥同时充当 sshd 主机密钥、sshd 授权用户密钥、SSH 客户端身份密钥 |
| BUG-0076 | A14-25 | net/net_tls.c:133-136 | + 1124   AES-256-GCM / ChaCha20-Poly1305 套件密钥长度硬编码 16 字节 → 选中即失败 |
| BUG-0077 | A14-26 | net/net_tls.c:587-588 | TLS1.3 CertificateEntry 扩展只跳长度不跳数据 → 带 SCT 的常见证书链解析错位 |
| BUG-0078 | A14-27 | net/net_tls.c:106-116 | + 420-424   transcript/hs_log 9216 字节静默截断 → 大证书链 Finished 必败 |
| BUG-0079 | A14-28 | net/net_tls.c:476-507 | ServerHello 解析无边界（sid_len/ext_total 不设限）→ OOB 读至 #PF |
| BUG-0080 | A14-29 | net/net_tls.c:382-407 | 0 长度记录导致握手无限循环（远程挂死） |
| BUG-0081 | A14-30 | net/net_tls.c:1314-1318 | net_tls_recv 对 KEY_UPDATE/NEW_SESSION_TICKET 无界递归 → 远程栈耗尽 |
| BUG-0082 | A14-31 | net/net_tls.c:583 | ,592,957,963   A4-01（X509 DER 负长度 P0）从本路四个入口全部可达（影响面确认） |
| BUG-0083 | A15-4 | shell.c:1125-1129 | + 1361-1391   嵌套 capture 逻辑错误（可远程触发，含数据污染） |
| BUG-0084 | A15-5 | shell.c:892 | 别名/自覆盖（相对目录通配符全坏） |
| BUG-0085 | A15-6 | shell_cmds_file.c:860 | , 918 + 863-865   edit 命令三重缺陷（数据丢失） |
| BUG-0086 | A15-7 | shell_cmds_file.c:425-427 | , 436-439   cp 静默截断 |
| BUG-0087 | A15-8 | shell_cmds_file.c:132-139 | （ls）、482-489（tree_walk）、602-609（du_walk）  无界子路径拼接（条件性栈溢出） |
| BUG-0088 | A16-1 | userprogs/ush.c:803-812 | unalias 无参数时 NULL 指针解引用 |
| BUG-0089 | A16-2 | userprogs/ush.c:466 | 、1158、1189   写目标文件缺 O_TRUNC：nano/vi 保存、cp、mv 在覆盖较短内容时残留旧尾字节（数据损坏） |
| BUG-0090 | A16-3 | userprogs/ush.c:2014-2058 | 重定向路径 fd 泄漏 + 双重 close + stdin 永久改绑 |
| BUG-0091 | A16-4 | l1/l1_ext.h:111-128 | + l1/l1_ext.c:80-84 + drivers/display/screen_console.c:91-93   console hook 的"抑制字符"契约未实现 |
| BUG-0092 | A16-5 | l1/l1_wp8cd.c:39-81 | 、84-106 + l1/l1_wp8cd.h:26-46   WP-08cd"注册"类 L1 接口虚设：文档承诺 oc> 集成 / 可 exec，实为孤立静态表 |
| BUG-0093 | A17-001 | docs/ | ** CONFIG.md 全文把配置键写成 ota_update_url，代码实际解析 update_url。 |
| BUG-0094 | A17-002 | docs/ | ** TRY-IT.md OTA 演练第 4 节 config set ota_update_url ... 静默无效。 |
| BUG-0095 | A17-003 | docs/ | ** UPDATE-HOWTO.md 让用户运行不存在的 tools/ota_update_server.py（实际 tools/update_server.py）。 |
| BUG-0096 | A18-1 | 线上站点 ↔ GitHub Release | "三处 SHA256 字节级一致"声明已失效 |
| BUG-0097 | A18-2 | update.json 全部副本 | 三代 manifest 并存，仓库非权威源，重建即回滚 |
| BUG-0098 | A2-5 | core_syscall.c:580-612 | /347-356/1437-1465   VFS fd(kind 1) 无引用计数：dup/dup2/fork 共享 fs_vfs_fd，任一方 close 即全局释放 → 幸存 fd 悬空（写静默失败或串写他文件）；ush.c:2084-2088 的 dup2+close 触发外置命令 > fi |
| BUG-0099 | A2-6 | core_syscall.c:388 | /414; core_usermode.c:1048   陈旧 tid：子任务 EXITED 后调度器随时回收并复用槽位，wait4/kill/user_process_kill 再对旧 tid 调 core_kthread_destroy/core_sched_task_exited → 误杀无关 |
| BUG-0100 | A2-7 | core_syscall.c:467-474 | /519-543/933-951   pipe/select 丢失唤醒竞态：数据检查与入队+block 之间可被定时器抢占，写者 wake 时读者未入队 → 读者永眠（数据已就绪）   |
| BUG-0101 | A2-8 | core_syscall.c:897-953 | sys_select timeout_ms==0 语义颠倒（POSIX=立即返回，实现=永久阻塞）；未打开的 fd（stdin 0）既不 ready 也不入等待队列   |
| BUG-0102 | A3-01 | core_sched.c:623-639 | 调度器逻辑 — yield 自弹出后任务孤儿化 |
| BUG-0103 | A3-02 | arch_context_switch.S:127-156 | （经 core_sched.c:486、core_timer.c:180 触发）  上下文切换不恢复 RFLAGS — IF=0 泄漏 |
| BUG-0104 | A3-03 | core_sync.c:82-92 | sem_wait 等待表满回退路径自死锁 |
| BUG-0105 | A3-04 | core_sync.c:202-233 | cond_wait 等待表满时未注册即阻塞 → 永久睡眠 |
| BUG-0106 | A4-02 | crypto_core.c:433-442 | 非密码学 PRNG 用于全部 TLS/SSH 密钥材料 |
| BUG-0107 | A4-03 | crypto_x509.c:456-467 | ECDSA r/s 左侧未清零，使用未初始化栈数据验证 |
| BUG-0108 | A4-04 | crypto_ec_nist.c:270-309 | + 468-483（另 crypto_core.c:618-656）  私钥标量乘/模幂非常量时间（时间侧信道） |
| BUG-0109 | A5-05 | kernel/ota/ota_ab.c:1059-1063 | + kernel/ota/ota_update.c:559-563   整数安全/栈溢出 |
| BUG-0110 | A5-06 | kernel/ota/ota_ab.c:1108 | ,1165,1117,1174   逻辑：更新目标槽硬编码 B |
| BUG-0111 | A5-07 | kernel/ota/ota_update.c:487-499 | ,691-693（配合 core_sched.c:257-264）  资源管理：4 KiB 线程栈装不下 OTA 检查调用链 |
| BUG-0112 | A5-08 | kernel/lib/lib_string.c:74-79 | 内存管理：strncpy 语义破坏（n+1 越界写） |
| BUG-0113 | A6-2 | driver_block_part.c:120-134 | GPT entry_size 无上界 → 栈越界读 / #PF panic |
| BUG-0114 | A6-3 | driver_block_nvme.c:533-534 | vs 337/351   I/O 队列按 MQES 缩小创建但回绕固定 %64 → SQE 越界写 + 门铃值非法 |
| BUG-0115 | A6-4 | driver_block_ata_dma.c:369 | （对照 ahci.c:567 的正确写法）  init_ctrl 无控制器表上界检查 → 重复/L1 扩展调用时 g_ctrls[2] 越界写 |
| BUG-0116 | A6-5 | driver_block_cache.c:47-54 | + driver_block_blk.c:112-118   淘汰脏页回写失败被忽略 + 写路径恒返回 0 → 设备错误时静默丢数据 |
| BUG-0117 | A6-6 | driver_block_part.c:223-224 | + driver_block_disk_setup.c:376/513   register_child 名字冲突返回旧几何子设备 → abdisk/install 二次布局沿用过期 start/sectors → mkfs 按旧尺寸跨分区格式化 |
| BUG-0118 | A7-01 | screen_console.c:48-51 | 整数安全（除零 panic） |
| BUG-0119 | A7-02 | screen_console.c:25-42 | （+ screen_font.c:34-39）  指针安全（滚动 memcpy 越界 #PF） |
| BUG-0120 | A7-12 | screen_fb.c:62-64 | （fill_rect）、74-76（blit）  整数安全（裁剪溢出绕过 → 越界写） |
| BUG-0121 | A7-21 | driver_pci.c:104-124 | 逻辑/整数（64 位 BAR 截断 + bar_index 无校验） |
| BUG-0122 | A8-1 | driver_nic_rtl8169.c:167-172 | 探测逻辑死代码：rtl8168/rtl8125/rtl810x 三个家族永远无法初始化 |
| BUG-0123 | A8-2 | driver_nic_other.c:97-99 | , 199-203   同类死代码：3c59x 与 nForce 家族永远无法初始化 |
| BUG-0124 | A8-3 | driver_nic_other.c:292-305 | , 390-431（另见 213-226, 117-130）  "假发送"存根：send 返回成功但不发送任何字节；AR81xx/Yukon 以全零 MAC 注册 |
| BUG-0125 | A8-4 | driver_nic_rtl8139.c:272-278 | , 293-301   发送路径三缺陷叠加：失效等待死代码 + 多余的 TSD=0 写 + 超时仍推进槽位（KI-SH-01 首要嫌疑，见 §4） |
| BUG-0126 | A8-5 | driver_nic_ixgbe.c:286-287 | , 305-315   依据 82598/82599 datasheet（及 Linux ixgbe 布局）：TX 命令位写错字、RX 写回字段偏移全错 → 真硬件上 TX 读越界 / RX 永不工作 |
| BUG-0127 | A8-6 | driver_nic_rtl8169.c:331-332 | （对比 146 行 RX 有 EOR）  TX 描述符环从不设置 EOR → 真硬件上第 32 帧后发送机跑出环外永久停摆 |
| BUG-0128 | A8-7 | driver_nic_bcm57xx.c:259-266 | , 277-286   TX 无任何完成回收检查（环回绕即覆盖在途描述符）+ RX 缓冲从未提交给硬件 |
| BUG-0129 | A9-03 | driver_snd_virtio.c | :230-241 |
| BUG-0130 | A9-04 | driver_snd_hda.c:279-283 | 、690-701 |
| BUG-0131 | A9-05 | driver_snd_hda.c:225-271 | （243 行）、296-363（359 行） |
| BUG-0132 | RUN-02 | net_sshd.c | 实测：sshd 启动后阻塞监听，Ctrl+C 无法中断，shell 完全失去响应（^C 字节未被消费），只能重启虚拟机。 |
| BUG-0133 | RUN-03 | fs_vfs.c/shell umount | 实测：umount / 无任何防护（不检查根/忙），执行后 mount 表为空，ramfs 全部数据（含 /etc 配置）丢失，所有文件操作失败，无恢复路径只能重启。 |
| BUG-0134 | RUN-04 | core_sched/shell | 实测：连续 run loop × 8 后系统响应从 0.1s 恶化到 30s+（ps 超时），loop 进程为死循环且无便捷 kill 途径（run 输出 pid 与 kill 需要的 tid 对应关系不明确），无并发限制。 |
| BUG-0135 | RUN-05 | shell/editor.c | 实测：vi 命令打开的是与 nano 完全相同的界面（同一实现），不存在 vi 双模式；发送 ithree-fox 与 :wq 全被当作文本插入。宣称的 vi 编辑器功能不实。 |

### 10.3 P2（214 条）——边界条件/质量问题

| BUG | 来源 | 位置 | 摘要 |
|---|---|---|---|
| BUG-0136 | A1-10 | kernel/mem/mem_vmm.c:282-377 | ②⑦（destroy 的"USER=用户私帧"脆弱约定） |
| BUG-0137 | A1-4 | kernel/arch/x86_64/arch_idt_stub.S:81-88 | ⑧栈对齐（SysV 16 字节） |
| BUG-0138 | A1-5 | kernel/arch/x86_64/arch_idt_stub.S:57-87 | ⑥⑧（DF 标志） |
| BUG-0139 | A1-6 | kernel/arch/x86_64/arch_exceptions.c:226-265 | （配合 arch_idt.c:195-196）  ⑥⑦（IST 栈被挂起重用） |
| BUG-0140 | A1-7 | kernel/mem/mem_heap.c:200-204 |   ③整数溢出 |
| BUG-0141 | A1-8 | kernel/mem/mem_heap.c:75-119 | ,210-218   ②④⑤（碎片化下大分配永久失败 + 池槽泄漏） |
| BUG-0142 | A1-9 | kernel/arch/x86_64/arch_multiboot2.c:20-72 | （及 kernel/mem/mem_pmm.c:69-70）  ①④（畸形 mbi 越界读/除零） |
| BUG-0143 | A10-10 | driver_usb.c | :114-127 |
| BUG-0144 | A10-11 | driver_usb.c:902 | , 957, 976, 1237-1249, 1320 |
| BUG-0145 | A10-12 | driver_usb.c:921-929 | , 1124-1130 |
| BUG-0146 | A10-23 | driver_usb_xhci.c:280-294 | , 328-334, 869-875 |
| BUG-0147 | A10-24 | driver_usb_xhci.c | :701-702 |
| BUG-0148 | A10-25 | driver_usb_xhci.c:465-467 | , 494-496, 863-864 |
| BUG-0149 | A10-26 | driver_usb_xhci.c:1 | 047-1050 |
| BUG-0150 | A10-27 | driver_usb_xhci.c:1 | 001-1008 |
| BUG-0151 | A10-28 | driver_usb_xhci.c:610-619 | , 950-963 |
| BUG-0152 | A10-29 | driver_usb_xhci.c:758 | , 862, 869-875 |
| BUG-0153 | A10-30 | driver_usb_xhci.c:381-392 | , 749, 789 |
| BUG-0154 | A10-5 | driver_usb.c:961-991 | + 906-932 |
| BUG-0155 | A10-6 | driver_usb.c:942 | ,970-983 |
| BUG-0156 | A10-7 | driver_usb.c | :669-734 |
| BUG-0157 | A10-8 | driver_usb.c | :554-571 |
| BUG-0158 | A10-9 | driver_usb.c:649 | -658, :73 |
| BUG-0159 | A11-19 | driver_usb_ohci.c:720-722 | , 289, 308, 344, 409, 477 等 |
| BUG-0160 | A11-2 | driver_usb_ehci.c:209-216 | , 617-622, 674-701 |
| BUG-0161 | A11-20 | driver_usb_ohci.c:359 | -366, 181 |
| BUG-0162 | A11-21 | driver_usb_ohci.c | :242-251 |
| BUG-0163 | A11-22 | driver_usb_ohci.c:394 | , 402, 417-418, 446 |
| BUG-0164 | A11-23 | driver_usb_ohci.c | :662-675 |
| BUG-0165 | A11-24 | driver_usb_ohci.c:253-263 | , 261, 420 |
| BUG-0166 | A11-3 | driver_usb_ehci.c | :318-324 |
| BUG-0167 | A11-37 | driver_usb_msc.c | :182-196 |
| BUG-0168 | A11-38 | driver_usb_msc.c | :375-376 |
| BUG-0169 | A11-4 | driver_usb_ehci.c:410 | -424, 418 |
| BUG-0170 | A11-44 | driver_usb_serial.c:261-274 | （对照 234-258） |
| BUG-0171 | A11-45 | driver_usb_serial.c | :214-215 |
| BUG-0172 | A11-49 | driver_usb_audio.c:149-153 | , 165-169 |
| BUG-0173 | A11-5 | driver_usb_ehci.c | :239-242 |
| BUG-0174 | A11-50 | driver_usb_audio.c:183 | -192, 202 |
| BUG-0175 | A11-6 | driver_usb_ehci.c:495-499 | , 556-559 |
| BUG-0176 | A11-7 | driver_usb_ehci.c | :642-648 |
| BUG-0177 | A11-8 | driver_usb_ehci.c:282 | , 288, 297（对照 270 的 QH_EPCHAR_DTC） |
| BUG-0178 | A12-013 | fs_vfs.c:640 | 只读 fd 检查用全等可被绕过 |
| BUG-0179 | A12-014 | fs_vfs.c:462-468 | 节点缓存命中用 strcasecmp，与大小写敏感 fs 冲突 |
| BUG-0180 | A12-015 | fs_ramfs.c:111-127 | 稀疏洞未清零 → 内核堆内容泄漏进文件 |
| BUG-0181 | A12-016 | fs_vfs.c:897-908 | list_mounts 行缓冲极限溢出 |
| BUG-0182 | A12-017 | fs_vfs.c:768-783 | 权限位只存不查 |
| BUG-0183 | A12-018 | fs_vfs.c:681 | seek 返回值 int 截断 |
| BUG-0184 | A12-019 | fs_vfs.c:293-297 | + 303-324   umount "/" 后 g_global_root 悬挂；挂载点遮蔽产生重复子节点 |
| BUG-0185 | A12-020 | fs_fat32.c:211-224；fs_exfat.c | （mount 998 区）  FAT#1 镜像 / exFAT number_of_fats 从不更新 |
| BUG-0186 | A12-021 | fs_fat32.c:229-243 | FSINFO 结构从不读写；alloc 每次从簇 2 线性扫描 |
| BUG-0187 | A12-022 | fs_fat32.c:606-622 | 、576-583   LFN 别名恒 "XXXXXX~1"：不查冲突、丢扩展名；读取不校验 checksum/序号 |
| BUG-0188 | A12-023 | fs_fat32.c:331-339 | mark_entry_deleted 只回溯同簇 LFN |
| BUG-0189 | A12-024 | fs_fat32.c:1049-1051 | read_dir_entries 4096 条（128KiB 目录项）硬上限静默截断 |
| BUG-0190 | A12-025 | fs_fat32.c:846 | 、879   append_cluster 返回值忽略 |
| BUG-0191 | A12-026 | fs_fat32.c:306-314 | file_size 写入 u32 截断 |
| BUG-0192 | A12-027 | fs_exfat.c:503-508 | O_TRUNC 未实现 |
| BUG-0193 | A12-028 | fs_exfat.c:581-588 | 扩链计数起点错：current_bytes 初始化为 1 簇 |
| BUG-0194 | A12-029 | fs_exfat.c:573-589 | 扩展出的新簇不清零 → 洞读出陈旧磁盘数据 |
| BUG-0195 | A12-030 | fs_exfat.c:694-707 | create() 构建 VFS 节点但不挂树 → 每次 O_CREAT 泄漏 |
| BUG-0196 | A12-031 | fs_exfat.c:1021-1030；fs_ext4.c:719-728 | unmount 只释放根节点，缓存子节点泄漏 |
| BUG-0197 | A12-032 | fs_exfat.c:995-998；fs_ext4.c:26-27 | exFAT 忽略 partition_offset；exFAT/ext4 只支持整盘 LBA0 |
| BUG-0198 | A12-033 | fs_ext4.c:669-717 | 、695   mount 无 incompat 特征检查；log_block_size 移位 UB；inode_size 不验证 |
| BUG-0199 | A12-034 | fs_ext4.c:515-516 | >2GB 文件 read 直接返回 0 |
| BUG-0200 | A12-035 | fs_ext4.c:328-368 | extent 深度 >1 不支持且不检测 |
| BUG-0201 | A13-13 | net_core.c:33-50 | dma_alloc：先查余量后对齐 → 最多 15+size 字节越页写；>4KB 路径单帧无校验 |
| BUG-0202 | A13-14 | net_core.c:390-404 | , 447-448, 463   virtio TX/RX 用硬编码 VIRTIO_NUM_DESC=256 取模，而非协商出的 rx_size/tx_size |
| BUG-0203 | A13-15 | net_core.c:2280-2284 | TCP data_offset 未验证 |
| BUG-0204 | A13-16 | net_core.c:1024-1044 | , 1046-1081, 1083-1114   ARP：无老化（timestamp 字段从未赋值/检查）、满表固定覆盖 0 号、单次请求无重试、报文长度被 (void)len 忽略 |
| BUG-0205 | A13-17 | net_core.c:2200-2225 | net_tcp_send：rtx_buf 满时照发但不入重传队列（静默丢可靠性）；无 Nagle；peer 零窗口时 sendable=0 返回 0 |
| BUG-0206 | A13-18 | net_core.c:2685-2712 | net_accept 超时单位错误：注释 "120 s @1000 Hz"，实际 OC_TIMER_HZ=100 → 120*1000 ticks = 1200 秒（20 分钟） |
| BUG-0207 | A13-19 | net_core.c:2070 | 客户端本地端口 = 40000 + (总连接数 % 10000)，无在用冲突检查 |
| BUG-0208 | A13-20 | net_core.c:2228-2247 | net_tcp_close 只等 1 秒即释放；LAST_ACK 状态定义了但从未进入；无 TIME_WAIT |
| BUG-0209 | A13-21 | net_core.c:2341-2348 | SYN_SENT 收 SYN+ACK 不验证 ack==our_seq 即建立 |
| BUG-0210 | A13-22 | net_core.c:1489-1514 | , 1516-1520   无 IP 分片重组（flags_frag 完全忽略）、无 IP 选项处理、目的地址以"低字节==0xFF"当广播接受、版本号不校验 |
| BUG-0211 | A13-23 | net_core.c:3218-3232 | , 3343-3356   DNS 查询构造无总长上界（(void)buf_len 明示忽略）写入 buf[512] |
| BUG-0212 | A13-24 | net_core.c:2200-2209 | + tcp_cc 集成   拥塞窗口实际不生效：sendable 恒被钳到 1 MSS |
| BUG-0213 | A13-25 | ld_so.c:506-514 | , 196-219   DT_NEEDED 只计数不加载（无依赖递归）；符号查找范围仅 libfoo.so；硬编码 4096 条 dynsym 上限；强未定义符号静默解析为 0+addend |
| BUG-0214 | A13-26 | ld_so.c:647-656 | 跳转 main 入口前不构造 argc/argv/envp/auxv，也无返回蹦床 |
| BUG-0215 | A13-27 | ld_so.c:364-394 | vs 405-411   ldso_dlopen 不校验 ELF 魔数（dlsym 校验了）且 phnum 无界 |
| BUG-0216 | A13-28 | ld_so.c:7-11 | , 142-144   无加载基址随机化（固定 0x20000000/0x30000000/0x50000000 bump）、全部 PT_LOAD 映射 R+W+E（无 W^X） |
| BUG-0217 | A13-29 | net_core.c:1695-1712 | , 2629-2645   UDP：未绑定端口不发 ICMP 端口不可达；socket rx 满即丢包；同端口多 socket 只有第一个收到 |
| BUG-0218 | A14-32 | net/net_ssh.c:725-1041 | 握手失败路径泄漏 TCP socket |
| BUG-0219 | A14-33 | net/net_ssh.c | （全文）  无密钥重交换（rekey）支持 |
| BUG-0220 | A14-34 | net/net_ssh.c | （KEX/NEWKEYS 段）  无 strict-kex（Terrapin，RFC 9144）加固 |
| BUG-0221 | A14-35 | net/net_ssh.c:786-790 | + net_sshd.c:689 + net_tls.c:530   X25519 共享密钥全零不检查 |
| BUG-0222 | A14-36 | net/net_sshd.c:1130-1153 | USERAUTH 无失败次数上限/延迟 → 无限口令爆破 |
| BUG-0223 | A14-37 | net/net_sshd.c:975-976 | 口令非常量时间比较 + 用户名实际不校验 |
| BUG-0224 | A14-38 | net/net_sshd.c:1002-1011 | handle_exec 负 reqlen → 负偏移 OOB 读 |
| BUG-0225 | A14-39 | net/net_sshd.c:1080-1099 | + 627-637   嵌套栈帧 ~12KB 逼近 16KB 引导栈 |
| BUG-0226 | A14-40 | net/net_sshd.c:1212-1257 | 单连接服务器：并发会话数 = 1 |
| BUG-0227 | A14-41 | net/net_tls.c:480-482 | + 1234   ServerHello 选择的套件不对照报价单校验 |
| BUG-0228 | A14-42 | net/net_tls.c:1309-1313 | 告警与 close_notify 不可区分 → 截断攻击无检测 |
| BUG-0229 | A14-43 | net/net_tls.c:797-823 | TLS1.2 CBC 填充预言（Lucky13 类） |
| BUG-0230 | A14-44 | net/net_tls.c:609-611 | + 1074   CertificateVerify/SKE 的 sig_len 不与消息长度核对 |
| BUG-0231 | A14-45 | net/net_tls.c:856-925 | net_tls12_send_record 对静态 rec[16640] 无长度校验 |
| BUG-0232 | A14-46 | net/net_tls.c | （全文）  无重协商处理（RFC 5746） |
| BUG-0233 | A14-47 | net/net_tls.c:508-521 | + 1223-1237   TLS1.2 回退无降级哨兵检查 |
| BUG-0234 | A14-48 | net/net_tls.c:1333 | net_tls_close 有效性判断写错（fd 0 有效却提前返回） |
| BUG-0235 | A14-49 | net/net_ssh.c:953-957 | ,1010-1014（对照 net_sshd.c:1127-1148 注释）  SSH 客户端不发 SERVICE_REQUEST 即发 USERAUTH |
| BUG-0236 | A15-10 | shell.c:566 | 单帧 8 KiB 栈数组逼近 16 KiB 内核栈 |
| BUG-0237 | A15-11 | shell.c:275 | help -w 潜伏越界读 + 未知 tag |
| BUG-0238 | A15-12 | shell.c:1145-1157 | alias 目标含操作符被静默截断 |
| BUG-0239 | A15-13 | shell_cmds_disk.c:179-197 | mkfs.* 无任何确认 |
| BUG-0240 | A15-14 | shell_cmds_disk_test.c:302-307 | disk_rw_test 用未初始化栈数据"恢复"扇区 |
| BUG-0241 | A15-15 | shell_cmds_file.c:708-716 | write 失败误报成功 |
| BUG-0242 | A15-16 | editor.c:148-163 | , 167-172   nano/vi 大文件静默截断 + 读错误当 EOF |
| BUG-0243 | A15-17 | shell_cmds_snd_test.c:479 | play 潜在除零 |
| BUG-0244 | A15-18 | shell_cmds_disk.c:212-219 | mkfs.exfat 无最小尺寸检查 |
| BUG-0245 | A15-19 | shell.c:61-67 | 注册"替换"路径不保证 NUL |
| BUG-0246 | A15-20 | shell_cmds_disk.c:53 | parted 边界检查顺序 |
| BUG-0247 | A15-9 | shell.c:1333-1350 | capture 缓冲泄漏 |
| BUG-0248 | A16-10 | l1/l1_wp8b.c:431-435 | 自测断言过期：BUG-007 修复后 so_unload(0) 返回 -1，"always succeeds"测试必失败；且整个 ext_wp8b_selftest 无调用方 |
| BUG-0249 | A16-11 | l1/l1_wp8cd.c:113-186 | job_create 取"最高 pid 活进程"的竞态启发式；fg 不等待 |
| BUG-0250 | A16-12 | userprogs/ush.c:1068 | 、1230、1693   tail/sort/sed 实际只读前 12KB（16KB 缓冲只用到 12288） |
| BUG-0251 | A16-13 | userprogs/ush.c:1812-1816 | awk 模式过滤：带右斜杠的 /pat/ 反而把过滤整个禁用 |
| BUG-0252 | A16-14 | userprogs/ush.c:2014-2072 | 别名不在重定向路径展开 |
| BUG-0253 | A16-15 | userprogs/ush.c:679-682 | exit [code] 的退出码被丢弃 |
| BUG-0254 | A16-18 | l1/l1_wp8a.c:9-29 | WP-08a 全部 21 个 int 0x80 包装编进内核二进制却不可从内核态调用（死层） |
| BUG-0255 | A16-6 | userprogs/ush.c:916 | wc 以 WRONLY CREAT 打开只读用途的文件 |
| BUG-0256 | A16-7 | l1/l1_wp8b.c:159-184 | so_load 的 BSS 清零跳过"已映射"的边界页（该页尾部为脏物理内存） |
| BUG-0257 | A16-8 | l1/l1_wp8b.c:257 | 、312、333   symbol_resolve / reloc_apply 符号表扫描无边界 |
| BUG-0258 | A16-9 | l1/l1_wp8b.c:357-408 | elf_get_needed 无缓冲尺寸参数，越界读 + vaddr 当文件偏移 |
| BUG-0259 | A17-004 | docs/ | ** README 统计区：129 接口（实际 138）、14 WP（实际 15，WP-10-wp08fix1 无章节）、75,806 行（其自带验证命令现在返回 46,595）。 |
| BUG-0260 | A17-005 | docs/ | ** README/INTERFACES.md "37 syscalls" vs core_syscall.h 实际 46 个 SYS_。 |
| BUG-0261 | A17-008 | docs/ | ** 版本口径分裂：README 标题 WP-10c / 统计 WP-10d / Makefile 默认 WP-10-project_restructure-fix1 / HEAD 为 WP-10-wp08fix1；TRY-IT 承诺 uname -a→WP-10c 与默认构建不符。 |
| BUG-0262 | A17-009 | docs/ | ** KNOWN_ISSUES §2A.2/§2A.4/§5.2 声称"不验证证书/主机密钥/公网 TLS 被拒"，代码已实现 TLS1.3+X.509 链验证+Finished 验证+SSH 主机密钥签名验证。 |
| BUG-0263 | A17-011 | docs/ | ** EXTENSIONS_WP10d.md 尾表 OHCI=open 与同文 §9 及 README "ALL PASS" 直接矛盾。 |
| BUG-0264 | A17-012 | docs/ | ** INTERFACES.md（"as of WP-10d-fix2"）缺接口 130-138 等，§4 文件名为重构前名字、计数 4 处不符。 |
| BUG-0265 | A17-013 | docs/ | ** STATUS.md 停在 WP-09+fix5，15 个 WP 只覆盖 2 个，违反 WORKFLOW §5 第 10 项自己的流程要求。 |
| BUG-0266 | A18-10 | .gitignore 体系 | worklog.md 声明不跟踪却实际跟踪；否定规则把 159MB 二进制提交进公开仓 |
| BUG-0267 | A18-3 | releases/isos/ 归档资产 | 同名文件多重哈希，归档与任何 manifest 都对不上 |
| BUG-0268 | A18-4 | 双 website 副本 | 三方不同步 + 根副本含不可构建的遗留文件 |
| BUG-0269 | A18-5 | oc-os/website 内部 | i18n / site.ts / home.ts 三处数据互相矛盾；site.STATS 是死代码 |
| BUG-0270 | A18-6 | docs-zh/ | 中文翻译滞后英文原文约两代（结构性漂移） |
| BUG-0271 | A18-7 | 页面 metadata | 全线过期（SEO/分享摘要与内容不符） |
| BUG-0272 | A18-8 | 发布脚本 | 硬编码路径 + 时代错位的写死提交信息 + 无部署前哈希校验 |
| BUG-0273 | A18-9 | 归档说明三件套 + releases/notes | 与现实严重脱节 + note SHA 自相矛盾 |
| BUG-0274 | A2-10 | core_syscall.c:296-363 | sys_fork 不继承 mmap_base/next_solib_addr |
| BUG-0275 | A2-11 | core_usermode.c:215-249 | SYS_EXIT(0) 清理路径与 EXIT2 不一致 |
| BUG-0276 | A2-12 | core_syscall.c:1525-1575 | sys_write2(72) 管道分支缺"无读者"检查 + 控制台回退无原子窗口 |
| BUG-0277 | A2-13 | core_syscall.c:993-1236 | ; core_usermode.c:284-299   exec 不重置信号状态；信号 handler 无栈上 restorer |
| BUG-0278 | A2-14 | core_syscall.c:113-141 | , 870-888   chdir/getcwd/相对路径解析基于全局 g_cwd，无进程隔离 |
| BUG-0279 | A2-15 | core_usermode.c:544-567 | , 444-522   launcher 死眠泄漏线程槽；fork AS 拷贝 OOM 返回半成品 |
| BUG-0280 | A2-16 | core_syscall.c:1261-1345 | sys_map_solib 失败不回滚；内联 ELF 解析无 bounds 校验 |
| BUG-0281 | A2-9 | core_syscall.c:614-656 | , 671-733   mmap/munmap/mprotect 区域上限不一致；prot/addr 被忽略 |
| BUG-0282 | A3-05 | core_sched.c:608-621 | （对照 489-494、623-626）  reap 无互斥 → 栈双重释放窄窗口 |
| BUG-0283 | A3-06 | core_sched.c:164-168 | idle 栈分配失败未检查 |
| BUG-0284 | A3-07 | core_sched.c:451-455 | switch_to 违反"idle 永不入队"不变量 |
| BUG-0285 | A3-08 | core_sync.c:28-46 | 自旋锁非中断安全（有文档的设计决定） |
| BUG-0286 | A3-09 | core_sync.c:172-192 | （对照 core_sync.h:40-46）  mutex 无优先级继承、无等待者管理 |
| BUG-0287 | A3-10 | core_rtc.c:63-79 | 12 小时制换算错误 |
| BUG-0288 | A3-11 | core_power.c:70-75 | （对照 58-64、81-95）  halt 不刷块设备缓存 |
| BUG-0289 | A3-12 | core_timer.c:128-142 | one-shot 注册与 IRQ0 扫描的竞态 |
| BUG-0290 | A3-13 | main.c:1813-1823（l1/l1_wp8cd.c:60-64 | 同）  非 volatile 标志自旋等待 |
| BUG-0291 | A3-14 | main.c:1382-1383 | cr3test 不检查 alloc_frame 失败 |
| BUG-0292 | A4-05 | crypto_sha512.c:143-181 | crypto_hmac_sha384 实为 HMAC-SHA-512 截断（休眠缺陷，POC 证实） |
| BUG-0293 | A4-06 | crypto_aead.c:500-531 | g_mac_buf 静态共享缓冲 + 超限静默垃圾 tag |
| BUG-0294 | A4-07 | crypto_bn.c:199-201 | （+ crypto_ec_nist.c:91-92、crypto_core.c:39-40）  静态工作区/惰性初始化无锁，不可重入 |
| BUG-0295 | A4-08 | crypto_x509.c:470-472 | + crypto_ec_nist.c:485-552   ecdsa_verify 不校验公钥在曲线上（防御深度缺失） |
| BUG-0296 | A4-09 | crypto_curve25519.c:175-231 | + crypto_curve25519.h:16-19   X25519 无全零共享密钥检查，且调用方也未检查 |
| BUG-0297 | A4-10 | crypto_bn.c:282-286 | crypto_bn_mod_bytes：上限检查在使用之后（潜在栈溢出写） |
| BUG-0298 | A4-11 | crypto_core.c:386-393 | + 596-607   分配失败静默返回（密钥材料为垃圾）+ 帧大小假设 |
| BUG-0299 | A5-10 | kernel/ota/ota_ab.c:64 | ,343-350（+ l1/l1_ext.h:160、ota_ab.c:1005）  版本缓冲 64B 修复不完整（任务专项核对项） |
| BUG-0300 | A5-11 | kernel/lib/lib_tar.c:152-158 | （另 96-106）  逻辑：非普通条目带 body 时不同步跳过 |
| BUG-0301 | A5-12 | kernel/lib/lib_tar.c:165-169 | + kernel/ota/ota_ab.c:822-847   逻辑：空文件被安装器丢弃 |
| BUG-0302 | A5-13 | kernel/ota/ota_ab.c:1010-1013 | ,1106-1115   错误处理/安全设计：--local 校验形同虚设 |
| BUG-0303 | A5-14 | tools/host_gzip_test.c:14-34 | 工具损坏（重构遗留） |
| BUG-0304 | A5-15 | kernel/ota/ota_ab.c:497 | ,510-511,637-641,646,653-659   错误处理：下载路径不查写返回值 + Content-Length 整型溢出 |
| BUG-0305 | A5-16 | kernel/ota/ota_ab.h:69-71 | + grub-ab.cfg:25-38   设计：无启动尝试计数，bootfail 兜不住"起不来"的 B |
| BUG-0306 | A6-10 | driver_block_virtio_blk.c:373-377 | used ring 轮询无超时 → 设备不完成即整机死循环 |
| BUG-0307 | A6-11 | driver_block_virtio_blk.c:226-229 | , 323-333, 405-408   完全不读 host features：FLUSH 未协商就下发、RO 盘不识别 |
| BUG-0308 | A6-12 | driver_block_virtio_blk.c:391 | , 401   count * 512u u32 乘法溢出（重点整数安全类，当前堆上限下不可达） |
| BUG-0309 | A6-13 | driver_block_part.c:144-146 | , 118-124   GPT 项校验不足：无 CRC32、无 first/last 排序校验、不与盘容量核对 |
| BUG-0310 | A6-14 | driver_block_part.c:189-199 | 分区子设备读写不做 lba+count ≤ sectors 边界检查 |
| BUG-0311 | A6-15 | driver_block_disk_setup.c:333-350 | （对照 install 的 495 行）  abdisk 不检查父盘整盘挂载 |
| BUG-0312 | A6-16 | driver_block_disk_setup.c:508 | install 分区大小 64→32 位截断，>2TiB 盘不拒绝 |
| BUG-0313 | A6-17 | driver_block_blk.c:32 | /53-57/125   unregister 后 g_blk_count 不回缩：满表注销一个后无法再注册；注销不清 name/ops/stats |
| BUG-0314 | A6-18 | driver_block_cache.c | 全文件 + driver_block_blk.c 缓存路径   块缓存全程无锁（并发任务 I/O 竞态） |
| BUG-0315 | A6-7 | driver_block_ata_dma.c:99-103 | , 221-225, 391   BMDMA PRD 构造违反 PCI IDE 规范：EOT 位放错 + 计数 off-by-one + 未用表项不清零 |
| BUG-0316 | A6-8 | driver_block_ahci.c:428-436 | IDENTIFY 容量只取 words 100/101（32 位）→ >2TiB SATA 盘容量截断 |
| BUG-0317 | A6-9 | driver_block_nvme.c:450-451 | , 434-437   admin 队列固定 64 深不按 MQES 收缩（I/O 队列收缩了） |
| BUG-0318 | A7-03 | screen_console.c:50-53 | 整数安全（cols/rows 为 0 时状态回绕） |
| BUG-0319 | A7-04 | screen_console.c | 全文件（putc/scroll_up_one）+ driver_input_keyboard.c:239-245   并发/中断安全 |
| BUG-0320 | A7-08 | screen_console_in.c:62-66 | + 92-99   逻辑（inject 双跑 hook） |
| BUG-0321 | A7-09 | screen_console_in.c:158-167 | 并发/中断（readline lost-wakeup） |
| BUG-0322 | A7-13 | screen_fb.c:12-38 | 错误处理（fb_init 校验不足） |
| BUG-0323 | A7-18 | screen_serial_in.c:33 | 循环边界（drain 无逃生） |
| BUG-0324 | A7-22 | driver_pci.c:20-32 | , 171-175   并发（0xCF8/0xCFC 无锁） |
| BUG-0325 | A7-26 | driver_input_keyboard.c:152-171 | 逻辑（E0 扩展码不处理右 Ctrl/AltGr） |
| BUG-0326 | A7-27 | driver_input_keyboard.c:39-52 | + 191-193   逻辑（NumLock 无效、小键盘三键无映射） |
| BUG-0327 | A7-28 | driver_input_keyboard.c:91-111 | 并发（ring 多生产者无锁） |
| BUG-0328 | A8-10 | driver_nic_e1000e.c:352-356 | TX 超时不报错：等待失败仍返回 len（虚假成功） |
| BUG-0329 | A8-11 | driver_nic_rtl8139.c:313-318 | 坏头部恢复策略错误：CAPR 清零导致与芯片写指针永久失步 |
| BUG-0330 | A8-12 | driver_nic_rtl8139.c | （全文件）  RX 溢出标志（RXOVW/FOVW）从不检查与清除；默认混杂模式加剧溢出概率 |
| BUG-0331 | A8-13 | driver_nic_ixgbe.c:45 | , 59, 50-51, 204-207   寄存器偏移/位定义与 datasheet 不符：HLREG0=0x05000（实为 0x0424）、LU=bit8（实为 bit7）、FCTRL 与 SRRCTL 完全未编程 |
| BUG-0332 | A8-14 | driver_nic_e1000e.c:199-200；driver_nic_bcm57xx.c:130-131 | / igb.c:211-212 / ixgbe.c:131-132 / other.c:284-285   MMIO 驱动缺少有效的 I/O BAR 防护（检查是死代码或缺失） |
| BUG-0333 | A8-15 | driver_nic_igb.c:74 | , 201-202   SRRCTL 缓冲尺寸编码存疑：(2u << 10) 落在 BSIZEHDR 区而非 BSIZEPKT（不确定，需 datasheet 复核） |
| BUG-0334 | A8-16 | driver_nic.c | （框架）+ 全部驱动实现 + net_core.c:3540-3578, 5083-5089   shell 线程直接调用 driver_nic_send/recv 与定时器 IRQ 的 net_poll 之间无任何互斥 |
| BUG-0335 | A8-17 | driver_nic_e1000e.c:366-368；driver_nic_igb.c:391-395 | RX 错误标志被忽略：坏帧照常上送协议栈 |
| BUG-0336 | A8-8 | driver_nic_igb.c:307-309；driver_nic_ixgbe.c:235-237；driver_nic_bcm57xx | , 364   pdev 白名单逻辑失效：只验厂商不验设备号 |
| BUG-0337 | A8-9 | driver_nic_igb.c:358-362 | 每个发送槽首次使用都要空转 100 万次 |
| BUG-0338 | A9-07 | driver_snd_sb16.c:211-215、driver_snd_es1370.c:184-188、driver_snd_virti | :440-443 |
| BUG-0339 | A9-09 | driver_snd_hda.c:502 | -516、522 |
| BUG-0340 | A9-10 | driver_snd_ac97.c:336-349、driver_snd_hda.c | :666-670 |
| BUG-0341 | A9-11 | driver_snd_sb16.c:301-309、driver_snd_es1370.c | :283-294 |
| BUG-0342 | A9-13 | driver_snd_sb16.c:150 | -158、293 |
| BUG-0343 | A9-15 | driver_snd_es1370.c:61-62 | 、218-230 |
| BUG-0344 | RUN-06 | shell/editor.c | 实测：nano 每次按键触发两次重绘，且第二次重绘行内容只显示到光标处（内容截断）。保存内容正确但显示损坏。 |
| BUG-0345 | RUN-07 | shell/shell.c | 实测：双引号不被 shell 解析——echo "special ; / &" 报 echo: cannot open file（带引号参数被当文件名走 cat 语义）。 |
| BUG-0346 | RUN-08 | shell power/sleep | 实测：sleep 2 输出 Suspending... Suspend not supported (ACPI required)——sleep 命令是 ACPI 挂起语义而非延时，与常识相反且无文档说明。 |
| BUG-0347 | RUN-09 | Makefile:42 + ota | 实测：默认构建版本串 WP-10-project_restructure-fix1 过旧，checkupdate 对线上 wp08fix1 恒报 New version available，对用户造成永久误报。 |
| BUG-0348 | RUN-10 | 申报差异 | 实测复核：help -a 与 shell_register_command 注册数均为 168（双向 diff 为空），申报的 172 无法复现，差异 4 条。第一步报告的 172 为提取假阳性未剔净。**【更正（WP-AUDIT-01-p0fix2 复核 2026-10-05）：p0fix2 ISO b40c1b40 实跑 help -a，内核自打印 Total: 172 commands、输出提取 172 条；静态注册表 12 文件 per-file 计 172 unique（52/18/18/17/16/10/9/8/7/7/6/4）；双向 comm 空集差异。168 不可复现——与 docs/INTERFACES.md §4 旧表（重构前文件名、缺 WP-10-wp08fix1 注册点）加总一致，RUN-10 清单提取遗漏 4 条。结论：命令数 = 172，申报正确，本条 RUN-10 发现撤销。】** |
| BUG-0349 | RUN-13 | 性能标注 | 实测：dhtest（1024-bit modexp）在 TCG 无 KVM 环境下 120 秒未完成（前 2 向量 PASS），无法在合理时间内验证完整 DH 测试。环境限制，非功能缺陷结论。 |

### 10.4 P3（258 条）——文档/注释/风格

| BUG | 来源 | 位置 | 摘要 |
|---|---|---|---|
| BUG-0350 | A1-11 | kernel/arch/x86_64/arch_idt.c:149-157 | ⑩注释与代码矛盾（GDT 布局） |
| BUG-0351 | A1-12 | kernel/arch/x86_64/arch_idt_stub.S:41 | ④误差码向量清单缺 21/29 |
| BUG-0352 | A1-13 | kernel/arch/x86_64/arch_idt.c:291-307 | ⑤未知向量静默丢弃且无 EOI |
| BUG-0353 | A1-14 | kernel/arch/x86_64/arch_exceptions.c:174-180 | vs 190-194   ⑩崩溃日志语义不一致 |
| BUG-0354 | A1-15 | kernel/arch/x86_64/arch_exceptions.c:240-246 | ,273-292   ①崩溃路径无 NULL 防护 |
| BUG-0355 | A1-16 | kernel/arch/x86_64/arch_exceptions.c:226-269 | ⑩ring3 异常但无 proc 时误报"kernel exception"并 halt |
| BUG-0356 | A1-17 | kernel/arch/x86_64/arch_multiboot2.c:10 | ,17 + kernel/main.c:2328   ①把栈变量地址存进文件级静态指针 |
| BUG-0357 | A1-18 | kernel/mem/mem_heap.c:186-198 | ⑧对 u64 误用 bool 原子内建 |
| BUG-0358 | A1-19 | kernel/mem/mem_heap.c:232 | ,271   ⑥分配钩子在持锁+关中断中回调 |
| BUG-0359 | A1-20 | kernel/mem/mem_heap.c:313-314 | ⑩死判别式 + 合并不完全 |
| BUG-0360 | A1-21 | kernel/mem/mem_heap.c:353-369 | ⑥krealloc 锁外读块头 |
| BUG-0361 | A1-22 | kernel/mem/mem_vmm.c:44-48 | ,420-422,47   ②死代码遗留 |
| BUG-0362 | A1-23 | kernel/mem/mem_vmm.c:141-171 | ⑧walk_pt 大页拆分丢 NX/PAT；create=0 遇大页一律"未映射" |
| BUG-0363 | A1-24 | kernel/mem/mem_vmm.h:71-72 | ⑩文档与代码矛盾 |
| BUG-0364 | A1-25 | kernel/mem/mem_pmm.c:45-55 | ,74-87   ③依赖 bootloader 数据良构 |
| BUG-0365 | A1-26 | kernel/arch/x86_64/arch_context_switch.S:18-40 | ,89-90   ⑩注释漂移 |
| BUG-0366 | A1-27 | kernel/arch/x86_64/arch_enter_ring3_fork.S:58-73 | ⑩fork 子进程不恢复调用方保存寄存器 |
| BUG-0367 | A1-28 | boot/boot.S:106-118 | ⑩注释矛盾 + 性能意图未实现（PGE） |
| BUG-0368 | A1-29 | kernel/arch/x86_64/arch_irq.c:37-57 | ⑥注销压缩与派发的窗口竞态 |
| BUG-0369 | A1-30 | kernel/types.h:42-44 | ③align_up 无防御 |
| BUG-0370 | A10-1 | driver_usb.h | :150-157 |
| BUG-0371 | A10-13 | driver_usb.c | :457-471 |
| BUG-0372 | A10-14 | driver_usb.c:1252-1254 | , 1363-1371 |
| BUG-0373 | A10-15 | driver_usb.c:1 | 277-1304 |
| BUG-0374 | A10-16 | driver_usb.c | :913-918 |
| BUG-0375 | A10-17 | driver_usb.c:328-333 | , 1100-1141, 1165-1170 |
| BUG-0376 | A10-18 | driver_usb.c:231-237 | , 312-319, 653-655 |
| BUG-0377 | A10-19 | driver_usb.c:597 | , 1202-1204, 1306-1311 |
| BUG-0378 | A10-2 | driver_usb.h | :236-239 |
| BUG-0379 | A10-3 | driver_usb.h:250-254 | , :220-223 |
| BUG-0380 | A10-33 | driver_usb_xhci.c | :804, 826 |
| BUG-0381 | A10-34 | driver_usb_xhci.c | :411, 481 |
| BUG-0382 | A10-35 | driver_usb_xhci.c:1102-1112 | , 1035-1044, 1132-1137 |
| BUG-0383 | A11-10 | driver_usb_ehci.c | :578-587 |
| BUG-0384 | A11-11 | driver_usb_ehci.c | :450-452 |
| BUG-0385 | A11-12 | driver_usb_ehci.c:254-257 | （对照 337） |
| BUG-0386 | A11-13 | driver_usb_ehci.c:112 | , 627-628 |
| BUG-0387 | A11-26 | driver_usb_ohci.c | :508-540 |
| BUG-0388 | A11-28 | driver_usb_ohci.c | :645-659 |
| BUG-0389 | A11-29 | driver_usb_ohci.c:28 | 8 vs 409 |
| BUG-0390 | A11-30 | driver_usb_hid.c:40-45 | , 98-143 |
| BUG-0391 | A11-31 | driver_usb_hid.c | :173-179 |
| BUG-0392 | A11-33 | driver_usb_hid.c:215-217 | , 249-251 |
| BUG-0393 | A11-34 | driver_usb_hid.c | :146-147 |
| BUG-0394 | A11-39 | driver_usb_msc.c | :243-248 |
| BUG-0395 | A11-40 | driver_usb_msc.c | :424-428 |
| BUG-0396 | A11-47 | driver_usb_serial.c | :240-253 |
| BUG-0397 | A11-48 | driver_usb_serial.c | :122-127 |
| BUG-0398 | A11-51 | driver_usb_audio.c:132-171 | , 306-314 |
| BUG-0399 | A11-52 | driver_usb_audio.c | :226-235 |
| BUG-0400 | A11-53 | driver_usb_audio.c | :116-118 |
| BUG-0401 | A11-54 | driver_usb_audio.c:215-221 | , 302-304 |
| BUG-0402 | A11-9 | driver_usb_ehci.c | :633-636 |
| BUG-0403 | A12-036 | fs_vfs.c:294 | 注释 "Carry over any children of the placeholder global root" 与实现不符（直接丢弃占位根，见 A12-019①）。 |
| BUG-0404 | A12-037 | fs_vfs.c:139-185 | normalize 对 >63 字符组件静默截断成两个组件（非报错）；路径 >16 层返回 -1（未文档化的限制）。 |
| BUG-0405 | A12-038 | fs_vfs.c:566 | 注释** O_CREAT 回退注释仍称"ramfs honors this; fat32 returns -1 (read-only)"——fat32 已是读写且有 create（注释过期）。 |
| BUG-0406 | A12-039 | fs_ramfs.c:123 | g_total_size += (int)(need_end - ri->size) —— >2GB 后 int 回绕，统计失真。 |
| BUG-0407 | A12-040 | fs_ramfs.c:309-319 | rename 可改名挂载根（mv /mnt /mnt2 后挂载表仍记 /mnt，readdir 显示 mnt2，状态漂移）。 |
| BUG-0408 | A12-041 | fs_fat32.c:1274-1282 | FAT 类型判定用 root_entries/fat_size16 双零（实践可行）但不按簇数阈值复核，也不校验 boot_signature/bytes_per_sector 为 2 的幂。 |
| BUG-0409 | A12-042 | fs_fat32.c:391-423 | readdir/lookup 会把 "." 和 ".." 当普通项列出（ramfs/ext4 都过滤了，fat32 没有；ls 观感问题）。 |
| BUG-0410 | A12-043 | fs_fat32.c:864-866 | write 中读簇失败 memset(0) 后照样把整簇写回——IO 故障下用零覆盖数据（错误传播）。 |
| BUG-0411 | A12-044 | fs_fat32.c:1415-1423 | fs_fat32_get_stats 的 total_sectors 实为数据区扇区数（命名误导）；且多挂载时只反映最后挂载的 ctx。 |
| BUG-0412 | A12-045 | fs_fat32.c:277 | /293/381/438/691** 每次目录/簇操作都 kmalloc 整簇缓冲（大簇卷 128KB 级）——性能。 |
| BUG-0413 | A12-046 | fs_exfat.c:379-400 | add_entry 不写任何时间戳（全 0 = 1980-00-00 非法日期）、set_checksum 恒 0、写后从不更新时间戳/10ms 字段（字段有定义但从未使用——对应任务书"时间戳 10ms 字段"核对项）。 |
| BUG-0414 | A12-047 | fs_exfat.c:291-302 | name_hash 仅 ASCII a-z 大写化，UPCASE 表不加载——非 ASCII 名的 hash 与规范不一致（跨 OS 查找优化路径可能失配）。 |
| BUG-0415 | A12-048 | fs_exfat.c:978-987 | mount 不校验 must_be_zero[53]/boot_signature/fs_revision/volume_flags。 |
| BUG-0416 | A12-049 | fs_exfat.c:481-499 | 、460-478** delete_entry/update_stream 假定 entry set 不跨簇（本驱动创建的 set 满足；外来跨簇 set 在 find_in_dir 被当畸形跳过 → 文件"隐形"）。 |
| BUG-0417 | A12-050 | fs_ext4.c:547-559 | seek 的 SEEK_END 分支为死代码（VFS 恒传 SEEK_SET——见 fs_vfs.c:674-680 BUG-029 修复注释），且若被直接调用语义还是错的（sz-offset）；ext4/ext4 驱动未接 blk 层（仅 ATA 0..3），WP-10a 的 AHCI/virti |
| BUG-0418 | A12-051 | fs_ext4.c:476-496 | S_IFLNK 未映射 VFS_TYPE_SYMLINK（符号链接被当普通文件，读出块指针垃圾）；fast symlink 目标存在 i_block 里被当块号解析。 |
| BUG-0419 | A13-30 | net_core.c:82-95 | internet_checksum 以 u16* 顺序读——仅 x86 安全的未对齐读（可移植性）；TCP 伪头部和算法本身正确 |
| BUG-0420 | A13-31 | net_core.c:3586-3600 | parse_ip 接受 >255 八位组、空八位组、尾部垃圾；"0.0.0.0" 与解析失败同为 0 无法区分 |
| BUG-0421 | A13-32 | net_core.c:3618-3625 | , 52   format_mac 依赖调用方先置 out[0]=0（脆弱约定，当前 3 处调用都做了）；n_tmp 共享静态缓冲非重入 |
| BUG-0422 | A13-33 | net_core.c:2926-2946 | , 2890, 2976-2978   DHCP 每次 DISCOVER 打 64 字节 hex 调试转储；xid 固定 0x12345678；*(u32*)(opts+i) 未对齐写（x86 可） |
| BUG-0423 | A13-34 | net_core.c:3555-3577 | net_poll 每 tick 最多处理 8 帧 → RX 上限约 800 pps（风暴时良性限流，但吞吐受限；任务书"风暴时饿死"项的反向注记） |
| BUG-0424 | A13-35 | net_core.c:2072 | , 2308, 1575-1599   ISN 固定（0x1000/1000，可预测助长伪造）；SYN/SYN-ACK 无重传；ICMP echo reply 不校验 id/seq/源（任意 echo reply 都算 ping 成功）；无 ICMP 差错报文送 TCP 层 |
| BUG-0425 | A13-36 | net_core.c:1425-1434 | netfilter hook 只认 DROP/ACCEPT，hook 返回 REJECT 被无视；hook 只传 dport；FORWARD 链 dormant（g_ip_forward=0） |
| BUG-0426 | A13-37 | net_core.c:2647-2658 | , 2660-2665   net_socket 不校验 type（垃圾 type 按 UDP 走）；net_bind 无端口冲突检查 |
| BUG-0427 | A13-38 | net_tcp_cc.c | /h   CC_CUBIC_C/BETA/CC_SCALE 宏定义未用（.c 硬编码 4/10、7/10）；compute_k 的 (u32)(target*1000) 超大 w_max 回绕（实际不可达）；on_ack 中 tk>~1e6 ticks（数小时长流）时 w_cubic u32 回绕得 |
| BUG-0428 | A13-39 | ld_so.c:59-75 | , 205, 254-283, 351, 446-449, 451-456   strlen_/streq 对 strtab 派生字符串无 NUL 保证（恶意 .so → 无界扫描）；r_offset/r_addend 未验证（恶意 .so 自我任意写）；dlopen flags 忽略；dlclos |
| BUG-0429 | A13-40 | net_core.c:3889-3903 | 等   firewall/policy/dns 子命令解析大量 p += N 定长跳步，串短时越过 NUL 读行缓冲内垃圾（不越界但脆弱） |
| BUG-0430 | A13-41 | net_core.c:4057 | , 4544-4551   tcpstats 的 if (TCP_MAX_CONNS == 0) 恒假死代码；wget TLS 路径找不到 \r\n\r\n 时 body_start=0 把响应头当正文存盘 |
| BUG-0431 | A14-50 | net/net_ssh.c:154-158 | + 630-654   误导性调试文本 + 常开敏感信息打印 |
| BUG-0432 | A14-51 | net/net_ssh.c:122-130 | 等 + net_sshd.c:158-168 等   有效空闲超时与代码不符 |
| BUG-0433 | A14-52 | net/net_ssh.c:729-730 | + 1415-1422   凭证静默截断 + 会话密钥/口令不擦除 + write_seq 失败仍自增 |
| BUG-0434 | A14-53 | net/net_ssh.c:177-193 | + 1305-1308 + 1256-1258   杂项 |
| BUG-0435 | A14-54 | net/net_sshd.c:1210 | ,1236,246-254,199-205   杂项 |
| BUG-0436 | A14-55 | net/net_sshd.c:1165-1166 | + 990-1037 + 1215-1216   杂项 |
| BUG-0437 | A14-56 | net/net_tls.c | （全文）  无会话恢复、无 ALPN |
| BUG-0438 | A14-57 | net/net_tls.c:337 | + 469-473 + 604-611   杂项 |
| BUG-0439 | A14-58 | net/net_tls.c:807-820 | + 1125-1126   杂项 |
| BUG-0440 | A14-59 | net/net_sshd_rsa_key.h:1-43 | 头文件工程性缺陷（格式核对通过） |
| BUG-0441 | A15-21 | shell_cmds_usb_test.h:8-10 | 与 .c:10-18 头注释   命令名与注册名不一致 |
| BUG-0442 | A15-22 | shell_cmds_update_test.c:8-20 | 文件头   同类命名不一致 |
| BUG-0443 | A15-23 | shell.c:1611-1613 | PATH 环境变量无消费者 |
| BUG-0444 | A15-24 | shell_lineedit.c |   历史无持久化 |
| BUG-0445 | A15-25 | shell_lineedit.c:510 | , 147-161   补全与重绘的边界 |
| BUG-0446 | A15-26 | shell_cmds_usb_test.c:431 | hotplug_test 越过 NUL 读 |
| BUG-0447 | A15-27 | shell_cmds_usb_test.c:88-95 | usbdev 参数不校验 |
| BUG-0448 | A15-28 | shell_cmds_file.c:641-675 | mount 两个小问题 |
| BUG-0449 | A15-29 | shell_cmds_disk.c:304-321 | fsck 绕过块层 |
| BUG-0450 | A15-30 | shell_cmds_file.c:201-213 | cat 打开失败返回 0 |
| BUG-0451 | A15-31 | shell_cmds_file.c:157-161 | cd 错误信息不区分 |
| BUG-0452 | A15-32 | shell_cmds_file.c:774-776 | , 817-819   grep 长行丢弃 |
| BUG-0453 | A15-33 | shell_cmds_nic_test.c:101-142 | 未初始化 mac 继续发探针 + 网关硬编码 |
| BUG-0454 | A15-34 | shell.c:1285-1312 | > file（无命令）不创建文件 |
| BUG-0455 | A15-35 | shell_cmds_power_test.c:41-48 | poweroff_test 直接关机 |
| BUG-0456 | A15-36 | shell_cmds_usb_test.c:37-51 | + 309-315   t_pass/t_fail 尺寸模式脆弱 |
| BUG-0457 | A15-37 | shell_cmds_file.c:918-926 | , 941-943   edit 细节 |
| BUG-0458 | A15-39 | shell_cmds_update_test.c:503-529 | 失败时打印空字段（已核实无害） |
| BUG-0459 | A15-40 | shell.c:705-762 | tokenizer 不剥换行 |
| BUG-0460 | A16-20 | userprogs/ush.c:365 | 注释称支持双引号，实现只有单引号 |
| BUG-0461 | A16-21 | userprogs/ush.c:6 | 、31、145   头注释与死宏：SYS_READLINE 未用于输入、sys_readlink/SYS_DUP 定义未用 |
| BUG-0462 | A16-22 | userprogs/ush.c:2267 | 、731、2414-2422   PATH 未参与查找 + help 误导（fg/jobs）+ Tab 补全表缺 help/env/set/stat |
| BUG-0463 | A16-23 | userprogs/ush.c:312-331 | 、2312-2319   历史与草稿截断为 255 字节，行缓冲却是 511 |
| BUG-0464 | A16-27 | userprogs/ush.c:1435-1436 | + Makefile:166   注释 "512 MiB VM" vs QEMU -m 256M；另 INTERFACES.md:127 "170 commands" vs 实测 172 |
| BUG-0465 | A16-28 | userprogs/ush.c:2082-2095 | 死代码：第二个 fork 里的子进程重定向设置不可达（并纠正 A2-5 的位置引用） |
| BUG-0466 | A16-29 | userprogs/ush.c:2588-2592 | 、1552-1576、1220/1277   杂项边界：jobs 表永不回收 active；du 目录深度 16 静默截断；sort/uniq 以 flags=0 打开（VFS 不查模式故能读） |
| BUG-0467 | A16-30 | userprogs/ush.c:410-421 | 、2549-2551   杂项死代码/未用变量：unano_prefix 的 num[12] 从未写入；if (k == '&' && llen == 0) 空块带误导注释 |
| BUG-0468 | A18-11 | site.ts 行数声明 | 数字与自家验证命令不复现 |
| BUG-0469 | A18-12 | 私库 Release 政策 | "每版本完整 zip"只执行过一次 |
| BUG-0470 | A18-13 | website-snapshot/ | 无文档说明的 WP-09 构建快照入库 |
| BUG-0471 | A18-14 | oc-os/NOTICE | 引用旧文件名 |
| BUG-0472 | A18-15 | 根部遗留 page.tsx/layout.tsx | 内容停在 WP-08 前期代 |
| BUG-0473 | A18-16 | 线上 update-v2.json | changes 文本与私库副本不同（线上编辑未归档） |
| BUG-0474 | A2-17 | core_syscall.c:890-893 | sys_ioctl 永久 stub |
| BUG-0475 | A2-19 | userprogs_data.h:2700-2710 | , 3558-3571   数据头注释尺寸过期（数据本身核对全部一致 ✓） |
| BUG-0476 | A2-20 | core_syscall.c:82-95 | access_ok_str 的 sanity 检查是死代码 |
| BUG-0477 | A2-21 | core_syscall.c:98-111 | copy_from_user/copy_to_user 的 check-then-copy TOCTOU |
| BUG-0478 | A2-22 | core_syscall.c:31-39 | valid_user_buf 的 64KiB 上限与"读检查用于写" |
| BUG-0479 | A2-23 | core_syscall.c:993-1083 | ; core_usermode.c:1019   execve 仅内嵌程序表；路径截断不拒绝；两种启动路径栈契约不一致 |
| BUG-0480 | A2-24 | core_syscall.c:398-428 | , 792-800   kill/signal 缺参数与权限细节 |
| BUG-0481 | A2-25 | core_syscall.c:368-396 | wait4 忽略 options；pid 参数符号语义未定义 |
| BUG-0482 | A2-26 | core_usermode.c:268-299 | 信号仅在系统调用返回时投递 |
| BUG-0483 | A2-27 | core_syscall.c:1583-1621 | sys_readline 键盘独占与 sti |
| BUG-0484 | A2-28 | core_syscall.c:236-245 | , 347-356, 580-612   管道引用计数无中断保护 |
| BUG-0485 | A3-15 | core_sched.c:22-34 | 、135-140、317-324   destroyed-hook 死代码 + 误导注释 |
| BUG-0486 | A3-16 | core_sched.c:19 | 、151   g_next_tid 死变量 |
| BUG-0487 | A3-17 | core_sched.c:167-224 | idle 任务初始上下文为死代码 |
| BUG-0488 | A3-18 | core_sched.c:78-80 | 、106-108   就绪队列 O(n) 搬移 |
| BUG-0489 | A3-19 | core_sched.c:534-566 |   饥饿保护粒度粗 |
| BUG-0490 | A3-20 | core_sync.h:17、core_sync.c:263 | vs 141-154   死字段与持锁唤醒策略不一致 |
| BUG-0491 | A3-21 | core_timer.c:44-47 | 、90-110   PIT 精度与 format_hms 边界 |
| BUG-0492 | A3-22 | core_timer.h:10 | 、14   注释乱码 |
| BUG-0493 | A3-23 | core_rtc.c:41 | 、51-52、91-100   RTC 健壮性 |
| BUG-0494 | A3-24 | core_power.c:58-64 | 、92-95   flush 返回值忽略 + reboot 回退循环未关中断 |
| BUG-0495 | A3-25 | main.c:754-760 | 、869-875   ssh/sshd 端口解析无防护 |
| BUG-0496 | A3-26 | main.c:1730 | run 的 usage 漏列程序 |
| BUG-0497 | A3-27 | main.c:294-303 | （代表）  统计命令缓冲区余量 |
| BUG-0498 | A3-28 | main.c:1230 | 、1271   pftest 双重注册 L1 fault handler 且不注销 |
| BUG-0499 | A3-29 | main.c:2432-2618 | 后段 init 返回值普遍未检查 |
| BUG-0500 | A3-30 | main.c:337-355 | echo 重定向细节 |
| BUG-0501 | A4-12 | crypto_core.c:612-616 | modexp base 归约只减一次**：if (cmp>=0) sub(b,mod) 一次，base >= 2*mod 时结果错。DH base=2/对端公钥 < p 不触发。API 层缺陷。 |
| BUG-0502 | A4-13 | crypto_core.c:450-459 | group14 注释块整段重复两遍**（复制粘贴残留）。 |
| BUG-0503 | A4-14 | crypto_core.c:407-423 | net_tls13_ks_expand_label 无边界检查**：u8 info[100]，label_len/ctx_len 超限（6+label_len 或总长 > 100）时溢出；(u8)(6+label_len)、(u8)ctx_len 截断。当前调用点（label ≤ 13、 |
| BUG-0504 | A4-15 | crypto_x509.c:182-183 | , 259-260   sig_input/spki 假定 4 字节 DER 头**：tbs.p - 4 / spki.p - 4，TBS 或 SPKI < 256 字节（2/3 字节头）时签名输入错位。真实证书均远超 256 字节，不触发。 |
| BUG-0505 | A4-16 | crypto_x509.c:521-546 | issuer 指向循环体局部 root 的悬垂指针**：crypto_x509_cert_t root; 声明在 for 循环体内，issuer = &root; break; 后 C 作用域已结束。实践中 anchored 路径随即 return 且栈槽未被覆写，风险低，但属 UB。 |
| BUG-0506 | A4-17 | crypto_x509.c:401-420 | host_match 通配分支 strcmp 大小写敏感**（DNS 名应不敏感，非通配分支已做 lower-case）；不支持 iPAddress SAN（用 IP 直连 TLS 的站点将 HOSTNAME 失败）；单标签通配（保守，安全方向 ✓）。 |
| BUG-0507 | A4-18 | crypto_rsa.c:125-136 | + 137   PSS 边界**：①modBits % 8 == 1 的模数（如 2049 位）EM 取 m[0..em_len) 错位（应跳过最高字节），真实 RSA 模数位长均为 8 的倍数；②salt 长度硬编码 = hlen，拒绝其它合法 salt 的证书（保守）；③PSS/PKCS1 均要 |
| BUG-0508 | A4-20 | crypto_ec_nist.c:444-465 | keygen 细节**：d[sz-1]  = 0x01 强制私钥奇数（无解释、非标准、无害）；d == n 的全等比较通过（应 < n，概率 2^-256）；crypto_random 本身见 A4-02。 |
| BUG-0509 | A4-21 | crypto_x509.c:180 | 死代码**：if (cert.len != d.p - (der)) { /* allow trailing padding; not enforced */ } 空语句；尾部垃圾字节不检测（多证书串流时依赖上层切分正确）。 |
| BUG-0510 | A4-22 | crypto_x509.c:232-233 | + 511-553   内外层 sigAlg 一致性不校验**；无 keyUsage/EKU 检查（最小实现，文档未声明该省略）；chain_len 无上限（深链 = 慢速 DoS，每 RSA 验证 QEMU 下 26-30s）。 |
| BUG-0511 | A4-23 | tests/host_gcm_probe.c:1-37 | 只打印不 assert**：main 恒 return 0，"want" 依赖人眼比对；文件尾死声明 int probe2(void);。其向量已被 host_aead_test 官方向量覆盖，应删除或并入。 |
| BUG-0512 | A4-24 | tests/host_rsa_test.c:4 | + tests/host_x509_test.c:2-6 + host_tls13_ks_test.c(注释)   fixture 不可复现**：/tmp/rsa_fix、/tmp/chain_fix 不在仓库，"regenerate via the script in this test's so |
| BUG-0513 | A4-26 | crypto_curve25519.c:27-31 | 未对齐 u64 解引用**（in+6/+12/+19/+24）：x86_64 可行，严格 C UB、不可移植（该文件自述面向本内核 x86_64，影响低）。 |
| BUG-0514 | A4-27 | crypto_ec_nist.c:148-149 | fe_inv 错误静默**：mod_exp 失败 memset(out,0) 继续跑（0 的"逆"=0），上层无感知。 |
| BUG-0515 | A5-17 | kernel/lib/lib_gzip.c:610 | ,775-777** — 多成员 gzip：if (g->done) return 0; 使后续 member 被静默丢弃，只解压第一个 member（gzip 拼接文件/pigz 输出会被无声截断；单 member 的 GNU tar.gz 不受影响）。 |
| BUG-0516 | A5-18 | kernel/lib/lib_gzip.c:340-346 | — FHCRC（头 CRC16）读 2 字节但不验证。 |
| BUG-0517 | A5-19 | kernel/lib/lib_gzip.c:405-414 | — CL 重复码（16/17/18）越出 hlit+hdist 时 if (g->t_repeat_left > 0) return 0; 永远"等输入"，finish() 误报 ERR_TRUNC 而非 ERR_TABLE（畸形流报错类别错，无死循环）。 |
| BUG-0518 | A5-20 | kernel/lib/lib_gzip.c:558-605 | ,828-829** — lib_gzip_init 不重置 h_flg（与自家"re-init 无副作用"注释矛盾；靠调用者 memset 兜底）；gunzip 的 kmalloc 失败返回 OC_GZIP_ERR_ARGS（误导性错误码）。 |
| BUG-0519 | A5-21 | kernel/lib/lib_string.c:39 | ,53,56,65** — memcmp/strcmp/strncmp 对 ≥0x80 字节按 signed char 比较，与 libc（unsigned）符号相反；sha256 比较只用相等性无碍，但任何依赖正负序的调用方语义漂移。 |
| BUG-0520 | A5-22 | kernel/lib/lib_config.c:141 | ,234-235,441** — 读路径对 >255 的值静默截断（写路径却拒绝，不对称）；read_default 把 E_TOOLONG 也当"缺失"回退默认值（用户配的长 URL 被无声换成官方 URL）；shell config set 把 >63 的键静默截断而非拒绝。 |
| BUG-0521 | A5-23 | kernel/lib/lib_config.h:22 | vs :69** — package_url 默认值文档写 ""（no offline base），编译默认实为 https://github.com/…/releases/latest。 |
| BUG-0522 | A5-24 | kernel/ota/ota_update.c:103-131 | — json_string 对"值串恰好等于键名"的假阳性匹配会提前 return -1（如 {"a":"version","version":"2.0"} 找 version 直接失败），应 continue 而非终止。 |
| BUG-0523 | A5-25 | kernel/ota/ota_update.c:67-82 | — 端口解析 int 可溢出（999…9 端口）；http://host:abc/x 的畸形端口使余下路径被丢弃、请求打到 "/"。 |
| BUG-0524 | A5-26 | kernel/ota/ota_ab.c:141 | — strcpy(g_ab_disk_name[16], dev->name) 无长度检查（块设备名当前都短）。 |
| BUG-0525 | A5-27 | kernel/ota/ota_ab.c:799-801 | — ensure_parent_dirs 的 tmp[128] 小于 target[160]：目标路径 >127 时父目录建不全 → open 失败报 E_IO（静默功能边界）。 |
| BUG-0526 | A5-28 | kernel/ota/ota_ab.c:850-863 | — 包裹目录前缀只从第一个条目学习；混合布局（首个文件在根、其余在包裹目录下）会把内容装到错误路径（files_installed>0、校验照过，槽不可启动，靠 bootfail 兜底）。 |
| BUG-0527 | A5-29 | kernel/ota/ota_update.c:187 | / ota_ab.c:367,405,534 + net/tls.c 单例 g_tls** — 静态 cur_url/req 与 TLS 单上下文在"auto-check 线程与 shell 网络命令并发"时会互踩（代码注释自认 single-threaded shell；auto-check 线程 |
| BUG-0528 | A5-30 | kernel/ota/ota_update.c:983-995 | + ota_ab.c:1005-1009** — l1_ext_check_update 按 sizeof(out->version)=32 原样拷贝 info.version 中 NUL 之后的未初始化栈字节（L1 可读的内核栈信息泄露；无越界）；安装期 mver[32] 对 >31 字符版本拒装 |
| BUG-0529 | A5-31 | kernel/lib/lib_log.h:9-13 | + docs/CONFIG.md:59** — lib_log.h 头注释仍描述 WP-01 假计时器（.c 已是 WP-02 真时间戳）；CONFIG.md 称 "TLS 1.3/1.2"，实际客户端仅 TLS 1.2（ota_update.c:9）。 |
| BUG-0530 | A6-19 | driver_block_ahci.c:149-159 | 注释错误：声称真机 AHCI 1.3.1 是"8 字节 PRDT 条目"，实际规范即 16 字节（代码本身正确） |
| BUG-0531 | A6-20 | driver_block_ahci.c:283-299 | 命令头 W 位（dword0 bit6）从未置位，is_write 参数被 (void) 丢弃 |
| BUG-0532 | A6-21 | driver_block_ahci.c:342-350 | , 315-322   超时恢复写 PxCI = read&~1 无效（写 0 不清 CI）；TFE 返回后不清 PxSERR、不重启端口 |
| BUG-0533 | A6-22 | driver_block_ahci.c:237-244 | page_aligned 丢弃 raw 指针（无法 kfree），端口初始化失败也不回收 |
| BUG-0534 | A6-23 | driver_block_ahci.c:458-464 | FLUSH CACHE EXT（非数据命令）携带 512 字节 PRD |
| BUG-0535 | A6-24 | driver_block_ahci.c:446 | /454   lba + count > p->sectors u64 加法在 lba=UINT64_MAX 时回绕绕过检查 |
| BUG-0536 | A6-25 | driver_block_ata.c:242 | , 267   driver_block_ata_drive_select(drive); 返回值丢弃、未写 DRIVE 寄存器 |
| BUG-0537 | A6-26 | driver_block_ata.c:169 | , 199   out + s * 512 int 乘法（大 count 理论溢出 UB） |
| BUG-0538 | A6-27 | driver_block_ata.c:203-206 | 每扇区 0xE7 flush；最后扇区 flush 失败返回 -4（数据已写却报失败） |
| BUG-0539 | A6-28 | driver_block_ata_dma.c:134-135 | 与 253-256   g_xfer_src/g_xfer_dst 全局重复定义两处（复制粘贴痕迹）+ 全局中转变量不可重入 |
| BUG-0540 | A6-29 | driver_block_ata_dma.c:93-95 | , 380-385   第二个 IDE 控制器仍用 legacy 0x1F0/0x170 任务文件寄存器 |
| BUG-0541 | A6-30 | driver_block_virtio_blk.c:273 | outl(io_base + VIRTIO_REG_STATUS, 0x07) 32 位写覆盖 ISR(0x13)+config(0x14-0x15) |
| BUG-0542 | A6-31 | driver_block_virtio_blk.c:379-380 | 注释 "legacy ISR @ 0x19" 错误（实际 0x13，代码正确） |
| BUG-0543 | A6-32 | driver_block_virtio_blk.c:104-124 | , 219, 236-241   杂项：net_virtq_* 命名系网络驱动复制；init 失败路径留下 io_base≠0、qsz=0 → 后续 idx % d->qsz 除零（未注册故当前不可达）；avail ring 未设 NO_INTERRUPT（轮询驱动却允许设备拉 INTx，靠完成 |
| BUG-0544 | A6-33 | driver_block_nvme.c:497-504 | , 484   Identify Controller 的 NN 读了不用（仅支持 NSID 1）；id_ctrl/id_ns 各 4KiB 不释放 |
| BUG-0545 | A6-34 | driver_block_nvme.c:560 | Create I/O CQ 设 NVME_CQ_IEN（开中断）而驱动纯轮询、MSI-X 从未配置 |
| BUG-0546 | A6-35 | driver_block_nvme.c:600-602 | 重复调用 init 会注册第二个同名 "nvme0"（register_device 不查重名；find_device 只返回第一个） |
| BUG-0547 | A6-36 | driver_block_part.c:98-104 | MBR 扩展分区（type 0x05/0x0F/0x0F 链）完全不解析 |
| BUG-0548 | A6-37 | driver_block_part.c:279-283 | partscan 用 num_devices()（计数）当槽位上界迭代 |
| BUG-0549 | A6-38 | driver_block_part.c:79-91 | MBR 项 sectors==0 且 start>0 仍被接受（end=start ≤ 容量）→ 0 扇区子设备 |
| BUG-0550 | A6-39 | driver_block_disk_setup.c:252-253 | memcpy(boot, grub_boot_img, 512) 未校验 grub_boot_img_len >= 512 |
| BUG-0551 | A6-40 | driver_block_disk_setup.c:433 | , 535   (unsigned int)kself_size 64→32 位截断（>4GB 内核不现实，登记） |
| BUG-0552 | A6-41 | driver_block_blk.c:143 | , 53-57   if (dev) dev->index = idx; 冗余判空（dev 早已解引用）；unregister 不清 stats（与 A6-17 合并看） |
| BUG-0553 | A6-42 | driver_block_blk.c:178-199 | lsblk char line[120] 5 连 strcat 无长度控制，理论最坏 ~134 字节（31 字符设备名 + 20 位容量 ×2） |
| BUG-0554 | A6-43 | driver_block_part.c:307-327 | part_print line[120] 理论最坏 ~124（两列 20 位数字 + 39 字符名）；现实 ≤114 |
| BUG-0555 | A6-44 | driver_block_cache.h:15-23 | 缓存仅 64 槽×512B=32KiB、按单扇区粒度操作（命中率/性能设计局限，非缺陷，登记为文档性说明） |
| BUG-0556 | A7-05 | screen_console.c:40-41 | + screen_console_init:51   逻辑/边界（底部 8 行余数区） |
| BUG-0557 | A7-06 | screen_console.c:121-125 | 逻辑（退格不跨行） |
| BUG-0558 | A7-07 | screen_console.h:8-9 |   注释与实现不符 |
| BUG-0559 | A7-10 | screen_console_in.c:134 | （+ screen_serial_in.c:58-64 注释）  逻辑/跨层语义 |
| BUG-0560 | A7-11 | screen_console_in.c:14-16 | ,104-176   并发（单实例行缓冲无保护） |
| BUG-0561 | A7-14 | screen_fb.c:73-84 | 接口契约（blit 无 src 校验） |
| BUG-0562 | A7-15 | screen_font.c:12-22 | 性能（每像素两次 get_info） |
| BUG-0563 | A7-16 | screen_font.c:1 | 5   指针算术顺序 |
| BUG-0564 | A7-17 | screen_font_data.c | （271 行）+ screen_font_data.h   数据验证 |
| BUG-0565 | A7-19 | screen_serial_in.c:19-21 |   注释与硬件语义 |
| BUG-0566 | A7-20 | screen_serial_in.h | :7-8   注释乱码 |
| BUG-0567 | A7-23 | driver_pci.c:34-50 | 逻辑边界（vendor=0xFFFF 匹配空槽） |
| BUG-0568 | A7-24 | driver_pci.c:126-128 | vs driver_pci.h:57-58   注释与实现不符 |
| BUG-0569 | A7-25 | driver_pci.c:139-152 | 字符串缓冲（strcpy 连环拼接） |
| BUG-0570 | A7-29 | driver_input_keyboard.c:188-196 | 逻辑（锁 LED 从不更新） |
| BUG-0571 | A7-30 | driver_input_keyboard.c:208 | -210   死代码 |
| BUG-0572 | A7-31 | driver_input_keyboard.c:234 | 时序（不读 0x64 状态寄存器） |
| BUG-0573 | A7-32 | driver_input_keyboard.c:233 | 状态机（extended 跨中断悬挂） |
| BUG-0574 | A8-18 | driver_nic_e1000e.c:97-98 |   注释位值写反 |
| BUG-0575 | A8-19 | driver_nic_e1000e.c:160-167 | EERD 轮询的 DONE 位存疑 + 无超时判定 |
| BUG-0576 | A8-20 | driver_nic.h:16 | vs driver_nic_e1000e.c:119-124   头文件声明与实现不符 |
| BUG-0577 | A8-21 | driver_nic_rtl8169.c:78 | , 194-195   C+ 命令位错标 |
| BUG-0578 | A8-22 | driver_nic_rtl8169.c:377-379 | PHYSR 链路位存疑（不确定） |
| BUG-0579 | A8-23 | driver_nic_rtl8139.c:321-326 | RX 上送帧含 4 字节 CRC |
| BUG-0580 | A8-24 | driver_nic_rtl8139.c:189 | TCR=0x03000800 的 bit11 归属存疑（不确定） |
| BUG-0581 | A8-25 | driver_nic_other.c:170-180 | 误导性命名 + 符号污染 |
| BUG-0582 | A8-26 | driver_nic_other.c:14-16 | 文件头夸大实现程度 |
| BUG-0583 | A8-27 | 全部驱动（bcm57xx.c:161-175、e1000e.c:216-247、igb.c:160-193、ixgbe.c:163-174、 | ）  setup 失败路径泄漏已分配页 |
| BUG-0584 | A8-28 | driver_nic_bcm57xx.c:100-101 | dma_alloc 的 >PAGE 分支无 NULL 检查 |
| BUG-0585 | A8-29 | driver_nic_ixgbe.c:42 | IMC 偏移存疑 |
| BUG-0586 | A8-30 | driver_nic_rtl8139.c:239 | Accton 克隆记录为错误厂商号 |
| BUG-0587 | A8-31 | rtl8139.c:135-138 | / rtl8169.c:181-184 / igb.c:257-259 / e1000e.c:164-167   复位/就绪轮询超时后静默继续 |
| BUG-0588 | A8-32 | driver_nic_e1000e.c:146 | 非必要全局符号 |
| BUG-0589 | A8-33 | driver_nic_igb.c:248-261；driver_nic.c:150-173 | 杂项：PHY 强制 100M 广告 + 2 秒阻塞式链路轮询；probe_all 单 NIC 限制的文档口径 |
| BUG-0590 | A9-16 | driver_snd.c:193-215 | int need = frames * channels * 2; 在 need > cap_bytes 钳位前用 int 计算：ms ≥ ~5.6e6（或 channels 无上界，仅 <1 被拒）时溢出为负 → 钳位失效 → 按 frames*channels*2 字节越界写调用 |
| BUG-0591 | A9-17 | driver_snd_hda.c:461-462、489-497；driver_snd_ac97.c:196-198；driver_snd_ | 、548-553 |
| BUG-0592 | A9-18 | driver_snd_ac97.c:311-327；driver_snd_hda.c:633-651 | len % 4 != 0 时 sw_pos 按任意 chunk 前进而硬件按帧消费 → 环内出现奇偏移，立体声帧错位 → 之后所有播放 L/R 声道互换/半周期错位（不越界，纯音质）。AC97/HDA 未强制 chunk 4 对齐（SB16/ES1370/virtio 有 &~3 但引入 |
| BUG-0593 | A9-19 | driver_snd_sb16.c:138-146 | IRQ handler 不读 DSP 状态即无条件 ack 0x22F 并计数：IRQ5 被其他设备共享时误吞/误计（arch_irq 为链式共享）。ES1370/HDA/AC97 均有源检查，SB16 没有。 |
| BUG-0594 | A9-20 | driver_snd_hda.c:561-564 | pdev 路径类检查 ((cls & 0xff0000) != 0x040000) 只比 BaseClass=0x04，未比 SubClass=0x03（HDA）：Intel 多媒体视频设备（0x0400）也会通过（需同时 VID 8086）。NULL 扫描路径用 find_class_mas |
| BUG-0595 | A9-21 | driver_snd_hda.c:332-349 | 连接表解析假设 long form（每响应字节=1 NID）。widget cap 表明 short form（NID>0x7F，2 字节带范围编码）的 codec 上 (entry & 0xff) == dac_nid 恒不成立 → "pin cannot route to DAC" → in |
| BUG-0596 | A9-22 | driver_snd_hda.c:100-101 | 、396-403 |
| BUG-0597 | A9-23 | driver_snd_ac97.c:134-140 | CAS 等待循环超时后不报错、直接读 NAM 寄存器（应在超时时返回失败/重试）。codec 不存在时读到的是 0xFFFF，仅靠上层 vendor-id 全 1 判断兜底。 |
| BUG-0598 | A9-24 | driver_snd_es1370.c:113-122 | 、205-216 |
| BUG-0599 | A9-25 | driver_snd_es1370.c:152-163 | 每块编程时 CONTROL 里 DAC2_EN 仍可能置位（上一块停止后从未清 EN，仅超时路径清）→ 帧寄存器在 EN=1 期间改写。真 ES1370 要求先清 EN 再写 FRAMEADR/FRAMECNT/SCOUNT（"ES1370 时序"命中）；QEMU 宽容。另块间存在 IRQ+me |
| BUG-0600 | A9-26 | driver_snd_es1370.c:143-176；driver_snd_sb16.c:177-202 | 单块 single-cycle 模式：块完成 IRQ → 调度返回 → memcpy 下一块 → 再编程，块间 DAC 无数据 → 每 8KiB/16KiB 一次欠载爆音。框架层无预取双缓冲。功能可用、音质瑕疵。 |
| BUG-0601 | A9-27 | driver_snd_virtio.c:530 | -531、571 |
| BUG-0602 | A9-28 | driver_snd_virtio.c:331-343 | 、453-454 |
| BUG-0603 | A9-29 | driver_snd_hda.c:104 | -108、544 |
| BUG-0604 | A9-30 | driver_snd_ac97.c:311-328；driver_snd_hda.c:633-651 | play 流控 free==0 → yield → continue 无超时：硬件停走（DCH/链路故障）时任务永久自旋（协作调度不饿死他人但 play 永不返回）。SB16/ES1370/virtio 均有 2s 超时，AC97/HDA 没有。 |
| BUG-0605 | A9-31 | driver_snd_ac97.c:269、es1370.c:303、hda.c:592、virtio.c:582 | d->irq == -1 时 (u64)(d->irq & 0xff) 打印 "irq ff"，应为 "-"/"none"。纯显示。另 HDA amp_max 提取 (amp >> 8) & 0x7f 多含保留位 bit14（步进字段为 bits13:8），值域巧合下无害。 |
| BUG-0606 | RUN-11 | userprogs 输出 | 实测：用户程序输出含 NUL 字节（parent: pid=\x001 形式），数字转字符串函数在缓冲前置 NUL。 |
| BUG-0607 | RUN-12 | userprogs/ush.c | 实测：ush 内置命令无 nano（command not found: nano），与 oc> 的 nano/vi/edit 编辑器能力不对称。 |

> 每条的完整详情（原样代码片段、复现步骤、预期 vs 实际、复现思路）见对应来源路报告：`audit/findings/A1.md` ~ `A18.md`。

---

## 11. 交付物索引

| 文件 | 内容 |
|---|---|
| report.md | 本报告（Markdown 权威版） |
| report.html | 本报告 HTML 版（内含 MD 下载按钮） |
| audit/findings/A1.md ~ A18.md | 18 路逐文件审查详细报告（每条发现的代码片段/行号/复现思路/诚实声明） |
| audit/bugs_final.json | 607 条统一编号清单（机器可读） |
| audit/g1.json ~ g5d.json、g6.json | QEMU 实测逐命令结果（命令/状态/耗时/输出） |
| /tmp/qemu-*.log | QEMU 会话原始串口日志（含 tcptest 崩溃转储全文） |
| /tmp/build-full.log、build-iso.log | 编译原样输出 |

---

## 12. 结语

Open Cube OS 在 15 个工作包的迭代中建立了惊人的广度（172 命令【审计期记录 168，经 p0fix2 复核更正，见 BUG-0348】、46 syscall、138 接口层、六族声卡、九族网卡、四类 USB 控制器、SSH/TLS/OTA/A-B 分区），编译零警告、自检套件全绿、UEFI/低内存兼容良好、危险命令防护意识到位。

但本次完整审查揭示了自检绿灯之下的系统性风险：**网络栈预认证解析路径的 21 处内存破坏**、**可预测随机数**、**文件系统校验缺失**、**栈预算失配**（tcptest 实测崩溃）、**shell 交互死角**（sshd/umount）。这些问题多数处于"文档宣称已验证"与"实际可触发"的夹层中——建议开发 AI 优先处理 P0 清单中的 A14 全组（网络栈）与 A4-01（X509），随后是 A12（fs 校验）与 RUN-01/02/03（实测崩溃与卡死）。

**审查全程未修改任何项目代码。**
