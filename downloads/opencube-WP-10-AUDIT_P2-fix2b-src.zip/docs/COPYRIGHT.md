# Copyright

Copyright 2026 cubestudio-dev <cubestudio@qq.com>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

## Copyright Holder

- **Name**: cubestudio-dev
- **Contact**: cubestudio@qq.com
- **Year**: 2026

## AI Disclosure

This project was developed by cubestudio-dev with the assistance
of AI tools. All design decisions, architecture, specifications,
project management, code review, quality assurance, and acceptance
testing were performed by cubestudio-dev. AI tools were used as
implementation assistants.

All source files contain the following header:

```
SPDX-License-Identifier: Apache-2.0
Copyright 2026 cubestudio-dev <cubestudio@qq.com>
```

## Third-Party Components

See [NOTICE](../NOTICE) for third-party component information.
