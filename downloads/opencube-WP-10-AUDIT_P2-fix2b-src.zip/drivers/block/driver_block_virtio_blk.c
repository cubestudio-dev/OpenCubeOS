/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
/* Open Cube OS - WP-07
 * File: kernel/virtio_blk.c
 * Purpose: virtio-blk PCI legacy transport driver.
 *
 * Probes for a virtio-blk PCI device (vendor 0x1AF4, device 0x1001 legacy
 * or 0x1042 modern-transitional), brings it online via the legacy I/O
 * transport, sets up the request virtqueue (queue 0), and registers a
 * block device "vda" with the blk layer.
 *
 * Transport notes
 * ---------------
 * QEMU's virtio-blk-pci exposes a legacy I/O BAR at BAR0.  All registers
 * listed below are accessed via inl/outl on (io_base + offset).  The
 * legacy device-config region for virtio-blk lives at I/O offset 0x64.
 *
 * Virtqueue layout (legacy, page-aligned)
 * ---------------------------------------
 *   [desc table]            qsz * 16 bytes
 *   [avail ring]            6 + qsz*2 bytes
 *   (padding to next page)
 *   [used ring]             6 + qsz*8 bytes
 *
 * The QueuePFN register takes the physical page number (phys >> 12) of
 * the descriptor table; the avail and used rings are at fixed offsets
 * from it.
 *
 * The driver is single-threaded: it submits one 3-descriptor request at
 * a time and busy-polls the used ring until completion.  No locking.
 */

#include "driver_block_virtio_blk.h"
#include "types.h"
#include "mem_heap.h"
#include "lib_string.h"
#include "screen_console.h"
#include "driver_pci.h"
#include "driver_block_blk.h"

/* ---- I/O port accessors (static inline, file-local) ---- */
static inline void outb(u16 p, u8 v)  { __asm__ volatile("outb %0, %1" :: "a"(v),  "Nd"(p)); }
static inline void outl(u16 p, u32 v) { __asm__ volatile("outl %0, %1" :: "a"(v),  "Nd"(p)); }
static inline u8   inb(u16 p)         { u8 v;  __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v; }
static inline u32  inl(u16 p)         { u32 v; __asm__ volatile("inl %1, %0" : "=a"(v) : "Nd"(p)); return v; }
static inline void outw(u16 p, u16 v) { __asm__ volatile("outw %0, %1" :: "a"(v), "Nd"(p)); }

/* ---- virtio legacy register offsets within BAR0 I/O space ----
 * Per the legacy (virtio 0.9.x) PCI layout used by QEMU and Linux
 * (include/standard-headers/linux/virtio_pci.h):
 *   0x00 host features (32)      0x04 guest features (32)
 *   0x08 queue PFN (32)          0x0C queue size (32 read)
 *   0x0E queue select (16)       0x10 queue notify (16)
 *   0x12 status (8)              0x13 ISR (8)
 *   0x14 device-specific config (MSI-X off; capacity lives here)
 * WP-10a FIX: the first draft used 0x10/0x14/0x18/0x1C/0x64, which
 * misfired: the capacity read landed on the config area (0), and the
 * status/notify writes were silently dropped.
 * Queue select/notify are 16-bit fields -> outw; status/ISR are 8-bit. */
#define VIRTIO_REG_HOST_FEATURES   0x00u
#define VIRTIO_REG_GUEST_FEATURES  0x04u
#define VIRTIO_REG_QUEUE_PFN       0x08u
#define VIRTIO_REG_QUEUE_SIZE      0x0Cu
#define VIRTIO_REG_QUEUE_SELECT    0x0Eu
#define VIRTIO_REG_QUEUE_NOTIFY    0x10u
#define VIRTIO_REG_STATUS          0x12u
#define VIRTIO_REG_ISR             0x13u
#define VIRTIO_REG_DEV_CFG         0x14u

/* Status bits. */
#define VIRTIO_STATUS_ACK          0x01u
#define VIRTIO_STATUS_DRIVER       0x02u
#define VIRTIO_STATUS_DRIVER_OK    0x04u
#define VIRTIO_STATUS_FAILED       0x80u

/* Descriptor flags. */
#define VRING_DESC_F_NEXT          0x01u
#define VRING_DESC_F_WRITE         0x02u

/* virtio-blk request types. */
#define VIRTIO_BLK_T_IN            0u   /* read  */
#define VIRTIO_BLK_T_OUT           1u   /* write */
#define VIRTIO_BLK_T_FLUSH         4u   /* flush (legacy spec) */

#define VIRTIO_BLK_SECTOR_SIZE     512u
#define VIRTIO_BLK_QUEUE_SIZE_MAX  1024u
#define VIRTIO_PAGE_SIZE           4096u

/* ---- on-wire structures (packed) ---- */

/* virtio-blk legacy device config (relevant prefix only). */
typedef struct __attribute__((packed)) {
    u64 capacity;   /* total sectors (read-only) */
    u32 size_max;
    u32 seg_max;
} driver_block_virtio_blk_cfg_t;

/* Virtqueue descriptor (16 bytes). */
typedef struct __attribute__((packed)) {
    u64 addr;
    u32 len;
    u16 flags;
    u16 next;
} net_virtq_desc_t;

/* Available ring header.  Followed by qsz u16 ring entries. */
typedef struct __attribute__((packed)) {
    u16 flags;
    u16 idx;
    u16 ring[1];   /* flexible placeholder; index with ring[idx % qsz] */
} net_virtq_avail_t;

/* Used ring element (8 bytes). */
typedef struct __attribute__((packed)) {
    u32 id;
    u32 len;
} net_virtq_used_elem_t;

/* Used ring header.  Followed by qsz used_elem entries. */
typedef struct __attribute__((packed)) {
    u16 flags;
    u16 idx;
    net_virtq_used_elem_t ring[1];  /* flexible placeholder */
} net_virtq_used_t;

/* Block request header (16 bytes, sent to device). */
typedef struct __attribute__((packed)) {
    u32 type;
    u32 reserved;
    u64 sector;
} driver_block_virtio_blk_outhdr_t;

/* ---- per-device state ---- */
typedef struct {
    u32  io_base;          /* BAR0 I/O base */
    u16  qsz;              /* negotiated queue size */
    void *driver_snd_virtio_vq_mem_raw;      /* original kmalloc pointer (for potential kfree) */
    volatile net_virtq_desc_t  *desc;
    volatile net_virtq_avail_t *avail;
    volatile net_virtq_used_t  *used;
    u16  avail_idx;        /* monotonic next slot in avail ring */
    u16  last_used_idx;    /* last seen used->idx */
    /* Per-request scratch (single-threaded; addresses must persist). */
    volatile driver_block_virtio_blk_outhdr_t hdr;
    volatile u8  status;
} driver_block_virtio_blk_dev_t;

static driver_block_virtio_blk_dev_t g_dev;

/* Forward declarations for driver_block_ops. */
static int driver_block_virtio_blk_read (driver_block_device_t *dev, u64 lba, u32 count, void *buf);
static int driver_block_virtio_blk_write(driver_block_device_t *dev, u64 lba, u32 count, const void *buf);
static int driver_block_virtio_blk_flush(driver_block_device_t *dev);
static const driver_block_ops_t driver_block_virtio_blk_ops = {
    .read  = driver_block_virtio_blk_read,
    .write = driver_block_virtio_blk_write,
    .flush = driver_block_virtio_blk_flush,
};

/* ---- helpers ---- */

/* Over-allocate then page-align: kmalloc returns 16-byte aligned memory
 * (see heap.c, HEAP_ALIGN=16), but the virtqueue requires 4 KiB
 * alignment.  We lose track of the original pointer (small one-time
 * leak; the queue lives for the kernel's lifetime). */
static void *kmalloc_page_aligned(u64 size) {
    u8 *raw = (u8 *)kmalloc(size + VIRTIO_PAGE_SIZE);
    if (!raw) return NULL;
    uintptr_t a = (uintptr_t)raw;
    a = (a + (VIRTIO_PAGE_SIZE - 1)) & ~(uintptr_t)(VIRTIO_PAGE_SIZE - 1);
    return (void *)a;
}

static void driver_block_virtio_blk_status_set(u32 io_base, u8 v) {
    outb((u16)(io_base + VIRTIO_REG_STATUS), v);
}

static void driver_block_virtio_blk_log(const char *s) { screen_console_puts(s); }

static void driver_block_virtio_blk_log_pci(const char *prefix, u8 bus, u8 dev, u8 func) {
    char buf[64]; char n[20];
    strcpy(buf, prefix);
    u64_to_hex((u64)bus, n, 2); strcpy(buf + strlen(buf), n);
    strcpy(buf + strlen(buf), ":");
    u64_to_hex((u64)dev, n, 2); strcpy(buf + strlen(buf), n);
    strcpy(buf + strlen(buf), ".");
    u64_to_hex((u64)func, n, 1); strcpy(buf + strlen(buf), n);
    strcpy(buf + strlen(buf), "\n");
    driver_block_virtio_blk_log(buf);
}

/* ---- init ---- */

void driver_block_virtio_blk_init(void) {
    u8 bus = 0, dev = 0, func = 0;
    /* P1 FIX: only accept legacy device IDs (0x1001 legacy, 0x1042 transitional).
     * The modern non-transitional ID (0x1041) uses MMIO transport which our
     * legacy I/O driver doesn't support. QEMU's virtio-blk-pci with
     * disable-modern=on exposes the legacy/transitional ID. */
    int found = driver_pci_find_device(0x1AF4, 0x1001, &bus, &dev, &func);
    if (found != 0) {
        found = driver_pci_find_device(0x1AF4, 0x1042, &bus, &dev, &func);
    }
    if (found != 0) {
        driver_block_virtio_blk_log("virtio-blk: no legacy PCI device found (modern-only devices not supported)\n");
        return;
    }
    driver_block_virtio_blk_log_pci("virtio-blk: found at ", bus, dev, func);

    /* Enable bus mastering + I/O + MEM access. */
    driver_pci_enable_device(bus, dev, func);

    /* BAR0 = I/O base. */
    u32 io_base = driver_pci_read_bar(bus, dev, func, 0);
    if (io_base == 0) {
        driver_block_virtio_blk_log("virtio-blk: BAR0 invalid\n");
        return;
    }
    g_dev.io_base = io_base;

    /* 1. Reset. */
    driver_block_virtio_blk_status_set(io_base, 0);
    /* 2-3. ACK | DRIVER. */
    driver_block_virtio_blk_status_set(io_base, (u8)(VIRTIO_STATUS_ACK | VIRTIO_STATUS_DRIVER));

    /* 4. Feature negotiation: we accept none of the optional features.
     * Reset already cleared the guest feature mask, so no write to
     * GUEST_FEATURES is needed (an explicit 0 write here clears the
     * device status on QEMU 10, so it is deliberately skipped). */

    /* 5. Select queue 0, read size.  (WP-10a: DRIVER_OK is set only
     * AFTER the queue is live -- setting it before the queue is active
     * makes QEMU refuse to process requests.) */
    outw((u16)(io_base + VIRTIO_REG_QUEUE_SELECT), 0);
    u32 qsz = inl((u16)(io_base + VIRTIO_REG_QUEUE_SIZE));
    if (qsz == 0 || qsz > VIRTIO_BLK_QUEUE_SIZE_MAX) {
        driver_block_virtio_blk_log("virtio-blk: invalid queue size\n");
        driver_block_virtio_blk_status_set(io_base, VIRTIO_STATUS_FAILED);
        return;
    }
    g_dev.qsz = (u16)qsz;

    /* 7. Allocate the virtqueue with the legacy page-aligned layout. */
    u32 desc_size  = qsz * 16u;
    u32 avail_size = 6u + qsz * 2u;
    u32 used_off   = (desc_size + avail_size + (VIRTIO_PAGE_SIZE - 1)) &
                     ~(VIRTIO_PAGE_SIZE - 1);
    u32 used_size  = 6u + qsz * 8u;
    u32 total      = used_off + used_size;

    u8 *vq = (u8 *)kmalloc_page_aligned(total);
    if (!vq) {
        driver_block_virtio_blk_log("virtio-blk: out of memory\n");
        driver_block_virtio_blk_status_set(io_base, VIRTIO_STATUS_FAILED);
        return;
    }
    memset(vq, 0, total);
    g_dev.driver_snd_virtio_vq_mem_raw = vq;
    g_dev.desc  = (volatile net_virtq_desc_t *)vq;
    g_dev.avail = (volatile net_virtq_avail_t *)(vq + desc_size);
    g_dev.used  = (volatile net_virtq_used_t *)(vq + used_off);
    g_dev.avail_idx = 0;
    g_dev.last_used_idx = 0;
    g_dev.hdr.type = 0;
    g_dev.hdr.reserved = 0;
    g_dev.hdr.sector = 0;
    g_dev.status = 0xFFu;

    /* 8. Write PFN to activate the queue. */
    outl((u16)(io_base + VIRTIO_REG_QUEUE_PFN), (u32)((u64)vq >> 12));

    /* 9. Queue live -> DRIVER_OK. */
    outl((u16)(io_base + VIRTIO_REG_STATUS), 0x07);   /* TEMP: 32-bit write */

    /* Read device config (capacity) - WP-10a FIX: the legacy device
     * config starts at I/O 0x14 when MSI-X is off (verified empirically:
     * reading 0x14 returns the low 32 bits of capacity).  Was 0x64, which
     * read past the config area and always returned 0. */
    u32 cap_lo = inl((u16)(io_base + VIRTIO_REG_DEV_CFG + 0));
    u32 cap_hi = inl((u16)(io_base + VIRTIO_REG_DEV_CFG + 4));
    u64 capacity = (u64)cap_lo | ((u64)cap_hi << 32);
    /* P1-26 FIX: if capacity reads as all-ones, the device config is not
     * accessible via legacy I/O. Fall back to a default (0 = unknown). */
    if (capacity == 0xFFFFFFFFFFFFFFFFULL) {
        driver_block_virtio_blk_log("virtio-blk: WARNING: capacity read failed (legacy config not available?)\n");
        capacity = 0;
    }

    {
        char buf[80]; char n[24];
        strcpy(buf, "virtio-blk: capacity=");
        u64_to_str(capacity, n); strcpy(buf + strlen(buf), n);
        strcpy(buf + strlen(buf), " sectors, qsz=");
        u64_to_str((u64)qsz, n); strcpy(buf + strlen(buf), n);
        strcpy(buf + strlen(buf), "\n");
        driver_block_virtio_blk_log(buf);
    }

    driver_block_register_device("vda", BLK_TYPE_VIRTIO, capacity,
                        VIRTIO_BLK_SECTOR_SIZE, &driver_block_virtio_blk_ops, &g_dev);
}

/* ---- I/O ---- */

/* Submit one 3-descriptor request and poll for completion.
 * type      : VIRTIO_BLK_T_IN (read) / T_OUT (write) / T_FLUSH.
 * sector    : starting LBA.
 * data_buf  : identity-mapped buffer of `data_len` bytes (512*count).
 *             May be NULL for T_FLUSH (data_len 0, no data descriptor).
 * data_len  : number of bytes to transfer.
 * Returns 0 on success, -1 on device error. */
static int driver_block_virtio_blk_xfer(driver_block_virtio_blk_dev_t *d, u32 type, u64 sector,
                           void *data_buf, u32 data_len) {
    /* Build the request header. */
    d->hdr.type     = type;
    d->hdr.reserved = 0;
    d->hdr.sector   = sector;
    d->status       = 0xFFu;

    u64 hdr_phys    = (u64)(uintptr_t)(void *)&d->hdr;
    u64 status_phys = (u64)(uintptr_t)(void *)&d->status;

    if (type == VIRTIO_BLK_T_FLUSH) {
        /* Flush: header + status only (no data descriptor). */
        d->desc[0].addr  = hdr_phys;
        d->desc[0].len   = (u32)sizeof(driver_block_virtio_blk_outhdr_t);
        d->desc[0].flags = VRING_DESC_F_NEXT;
        d->desc[0].next  = 1;

        d->desc[1].addr  = status_phys;
        d->desc[1].len   = 1;
        d->desc[1].flags = VRING_DESC_F_WRITE;
        d->desc[1].next  = 0;
    } else {
        u64 data_phys   = (u64)(uintptr_t)data_buf;

        /* Descriptor 0: header (device reads from memory). */
        d->desc[0].addr  = hdr_phys;
        d->desc[0].len   = (u32)sizeof(driver_block_virtio_blk_outhdr_t);
        d->desc[0].flags = VRING_DESC_F_NEXT;
        d->desc[0].next  = 1;

        /* Descriptor 1: data buffer.
         *  - read  (T_IN):  device writes to memory -> set WRITE flag.
         *  - write (T_OUT): device reads from memory -> no WRITE flag. */
        d->desc[1].addr  = data_phys;
        d->desc[1].len   = data_len;
        d->desc[1].flags = (u16)(VRING_DESC_F_NEXT |
                                 (type == VIRTIO_BLK_T_IN ? VRING_DESC_F_WRITE : 0));
        d->desc[1].next  = 2;

        /* Descriptor 2: 1-byte status (device always writes to memory). */
        d->desc[2].addr  = status_phys;
        d->desc[2].len   = 1;
        d->desc[2].flags = VRING_DESC_F_WRITE;
        d->desc[2].next  = 0;
    }

    /* Publish the chain head (descriptor 0) to the avail ring. */
    u16 idx = d->avail_idx;
    /* ring[idx % qsz] = 0 (head of our chain). */
    u16 *ring_base = (u16 *)((u8 *)d->avail + 4);
    ring_base[idx % d->qsz] = 0;

    /* Compiler/CPU ordering: store ring entry before publishing idx. */
    __asm__ volatile("" ::: "memory");
    d->avail->idx = (u16)(idx + 1);
    d->avail_idx  = (u16)(idx + 1);

    /* Notify the queue. outl is serialising on x86 -> full barrier. */
    outw((u16)(d->io_base + VIRTIO_REG_QUEUE_NOTIFY), 0);

    /* Poll the used ring until the device advances its idx. */
    while (d->last_used_idx == d->used->idx) {
        /* spin */
    }
    d->last_used_idx = d->used->idx;

    /* Acknowledge the interrupt (read ISR to clear, legacy ISR @ 0x19). */
    (void)inb((u16)(d->io_base + VIRTIO_REG_ISR));

    /* status byte == 0 means success per virtio-blk spec. */
    return (d->status == 0) ? 0 : -1;
}

static int driver_block_virtio_blk_read(driver_block_device_t *dev, u64 lba, u32 count, void *buf) {
    driver_block_virtio_blk_dev_t *d = (driver_block_virtio_blk_dev_t *)dev->priv;
    if (!d || !d->io_base) return -1;
    if (count == 0) return 0;
    return driver_block_virtio_blk_xfer(d, VIRTIO_BLK_T_IN, lba, buf,
                           count * VIRTIO_BLK_SECTOR_SIZE);
}

static int driver_block_virtio_blk_write(driver_block_device_t *dev, u64 lba, u32 count, const void *buf) {
    driver_block_virtio_blk_dev_t *d = (driver_block_virtio_blk_dev_t *)dev->priv;
    if (!d || !d->io_base) return -1;
    if (count == 0) return 0;
    /* Cast away const: the device reads from this memory during a write
     * request, so we never mutate it. */
    return driver_block_virtio_blk_xfer(d, VIRTIO_BLK_T_OUT, lba, (void *)buf,
                           count * VIRTIO_BLK_SECTOR_SIZE);
}

/* WP-10a: flush hook - issue VIRTIO_BLK_T_FLUSH. */
static int driver_block_virtio_blk_flush(driver_block_device_t *dev) {
    driver_block_virtio_blk_dev_t *d = (driver_block_virtio_blk_dev_t *)dev->priv;
    if (!d || !d->io_base) return -1;
    return driver_block_virtio_blk_xfer(d, VIRTIO_BLK_T_FLUSH, 0, NULL, 0);
}
