/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
/* Open Cube OS - WP-07
 * File: fs/fs_exfat.c
 * Purpose: exFAT filesystem driver (read + write) for the VFS.
 *
 * Uses the ORIGINAL WP-05 VFS interface (3 separate ops structs:
 * fs_vfs_fs_ops_t, fs_vfs_file_ops_t, fs_vfs_dir_ops_t). The fs-wide state lives
 * in an fs_exfat_ctx_t stored off the root node's private (via the root
 * inode). Each looked-up node carries an fs_exfat_inode_t in its private.
 *
 * exFAT stores filenames as UTF-16LE in 0xC1 name entries; this driver
 * flattens them to ASCII by taking the low byte of each UTF-16 code unit
 * (sufficient for ASCII filenames).
 *
 * On-disk structures use #pragma pack(push, 1). All functions are static
 * except fs_exfat_init. Memory comes from kmalloc/kfree; sector I/O goes
 * through the generic blk layer (driver_block_read_sectors_raw /
 * driver_block_write_sectors_raw) so exFAT can live on ANY registered
 * block device - whole disks ("hda", "sda", "vda", "nvme0", ...) as well
 * as partition sub-devices created by driver_block_part.c ("hdap1",
 * "sdap2", ...).
 *
 * BUG-0197 FIX (A12-032): the `device` string passed to mount is resolved
 * through driver_block_find_device() (with legacy "ata0".."ata3" aliases
 * mapped onto the corresponding "hd?" block device). All LBAs used below
 * are VOLUME-relative, exactly as the exFAT spec defines fat_offset /
 * cluster_heap_offset; the partition mapping is the blk layer's job, so
 * the BPB PartitionOffset field is deliberately not added to I/O
 * addresses (it is boot-chain information, not a mapping input).
 */
#include "fs_exfat.h"
#include "types.h"
#include "mem_heap.h"
#include "lib_string.h"
#include "screen_console.h"
#include "fs_vfs.h"
#include "driver_block_blk.h"

#pragma pack(push, 1)
typedef struct {
    u8  jump[3];
    u8  fs_name[8];              /* "EXFAT   " */
    u8  must_be_zero[53];
    u64 partition_offset;        /* in sectors */
    u64 volume_length;           /* in sectors */
    u32 fat_offset;              /* in sectors, relative to vol start */
    u32 fat_length;              /* in sectors */
    u32 cluster_heap_offset;     /* in sectors */
    u32 cluster_count;           /* number of allocatable clusters */
    u32 first_cluster_of_root_directory;
    u32 volume_serial_number;
    u16 fs_revision;
    u16 volume_flags;
    u8  bytes_per_sector_shift;  /* sector size = 1 << this */
    u8  sectors_per_cluster_shift;
    u8  number_of_fats;
    u8  drive_select;
    u8  percent_in_use;
    u8  reserved[7];
    u8  boot_code[390];
    u16 boot_signature;          /* 0xAA55 */
} fs_exfat_bpb_t;

/* Generic 32-byte directory entry. */
typedef struct {
    u8  type;
    u8  data[31];
} fs_exfat_dentry_t;

/* 0x85 - file directory entry (32 bytes). */
typedef struct {
    u8  type;                    /* 0x85 */
    u8  secondary_count;
    u16 set_checksum;
    u16 attributes;
    u16 reserved1;
    u32 created_timestamp;
    u32 last_modified_timestamp;
    u32 last_accessed_timestamp;
    u8  created_10ms_increment;
    u8  last_modified_10ms_increment;
    u8  last_accessed_10ms_increment;
    u8  reserved2[9];
} fs_exfat_file_entry_t;

/* 0xC0 - stream extension entry (32 bytes). */
typedef struct {
    u8  type;                    /* 0xC0 */
    u8  flags;
    u8  reserved1;
    u8  name_length;             /* in UTF-16 chars */
    u16 name_hash;
    u16 reserved2;
    u64 valid_data_length;
    u32 reserved3;
    u32 first_cluster;
    u64 data_length;
} fs_exfat_stream_entry_t;

/* 0xC1 - file name entry (32 bytes). */
typedef struct {
    u8  type;                    /* 0xC1 */
    u8  flags;
    u16 filename[15];            /* UTF-16LE */
} fs_exfat_name_entry_t;
#pragma pack(pop)

#define EXFAT_EOC                    0xFFFFFFFFu
#define EXFAT_FREE_CLUSTER           0x00000000u
#define EXFAT_BAD_CLUSTER            0xFFFFFFF7u
#define EXFAT_TYPE_UNUSED            0x00
#define EXFAT_TYPE_BITMAP            0x81
#define EXFAT_TYPE_UPCASE            0x82
#define EXFAT_TYPE_VOL_LABEL         0x83
#define EXFAT_TYPE_FILE              0x85
#define EXFAT_TYPE_STREAM            0xC0
#define EXFAT_TYPE_NAME              0xC1
#define EXFAT_FILE_FLAG_DIR          0x0001
#define EXFAT_STREAM_FLAG_ALLOC_OK   0x02

/* FS-wide state. Lives in the root node's inode->ctx. */
typedef struct {
    int  dev_idx;                /* BUG-0197: blk-layer device index (any
                                    driver, any partition sub-device) */
    u32  sector_size;
    u32  sectors_per_cluster;
    u32  cluster_size;
    u32  fat_start_lba;
    u32  fat_size_sectors;
    u32  mem_heap_start_lba;
    u32  cluster_count;
    /* BUG-0059: allocation bitmap (0x81 entry) state, kept in cache and
     * synced to the volume on alloc/free/unmount. */
    u32  bitmap_cluster;         /* first cluster of the allocation bitmap */
    u64  bitmap_bytes;           /* bitmap size in bytes */
    u8   *bitmap_cache;          /* NULL = no bitmap found on the volume */
    u32  root_cluster;
    u32  last_alloc;
    /* BUG-0185 FIX (A12-020): exFAT may carry two FATs (TexFAT) and the
     * VolumeFlags.ActiveFat bit selects the one in use. The driver used
     * to hard-code FAT #0 and ignore both fields. */
    u8   number_of_fats;
    u8   active_fat;
} fs_exfat_ctx_t;

/* Per-node state (file or directory). Lives in fs_vfs_node_t->private. */
typedef struct {
    fs_exfat_ctx_t *ctx;
    u32  first_cluster;          /* first cluster of file/dir data (0 if empty) */
    int  is_dir;
    u32  entry_cluster;          /* where the file entry set lives in parent */
    u32  entry_offset;           /* byte offset within entry_cluster */
} fs_exfat_inode_t;

static fs_vfs_fs_type_t  g_exfat_fs_type;
static fs_vfs_fs_ops_t   g_exfat_fs_ops;
static fs_vfs_file_ops_t g_exfat_file_ops;
static fs_vfs_dir_ops_t  g_exfat_dir_ops;

/* ---- Device string parsing ---- */

/* BUG-0197 FIX (A12-032): resolve the device through the generic blk
 * layer so exFAT can mount ANY registered block device - whole disks
 * ("hda", "sda", "vda", "nvme0", ...) and partition sub-devices created
 * by driver_block_part.c ("hdap1", "sdap2", ...) alike. The primary form
 * is the exact registry name. Legacy aliases kept for compatibility:
 * "ata0".."ata3" / "ata" / "0".."3" map to the corresponding "hd?" ATA
 * block device, so existing whole-disk mount commands keep working.
 * Returns a blk device index or -1 on bad input (mirrors
 * fs_fat32_parse_device). */
static int fs_exfat_parse_device(const char *device) {
    if (!device || !device[0]) return -1;
    /* Any registered block-device name (incl. partition children). */
    int idx = driver_block_find_device(device);
    if (idx >= 0) return idx;
    /* Legacy: "ataN" / "ata" / "N" -> hdX name. */
    char hd[6] = "hd?";
    if (strcmp(device, "ata") == 0) { hd[2] = 'a'; return driver_block_find_device(hd); }
    if (strncmp(device, "ata", 3) == 0) {
        char c = device[3];
        if (c >= '0' && c <= '3' && device[4] == 0) {
            hd[2] = (char)('a' + (c - '0'));
            return driver_block_find_device(hd);
        }
        return -1;
    }
    if (device[0] >= '0' && device[0] <= '3' && device[1] == 0) {
        hd[2] = (char)('a' + (device[0] - '0'));
        return driver_block_find_device(hd);
    }
    return -1;
}

/* ---- Sector I/O wrappers ---- */

/* BUG-0197 FIX (A12-032): go through the generic blk layer (any driver,
 * any partition sub-device) instead of the legacy ATA drive 0..3 path.
 * Both wrappers return 0 on success, negative on error. */
static int fs_exfat_read_sectors(fs_exfat_ctx_t *ctx, u64 lba, u32 count, void *buf) {
    return driver_block_read_sectors_raw(ctx->dev_idx, lba, count, buf);
}

static int fs_exfat_write_sectors(fs_exfat_ctx_t *ctx, u64 lba, u32 count,
                               const void *buf) {
    return driver_block_write_sectors_raw(ctx->dev_idx, lba, count, buf);
}

/* ---- FAT entry get/set ---- */
/* exFAT FAT entries are 32-bit; 0 = free, 0xFFFFFFFF = EOC.
 * BUG-0185: fat_start_lba points at the ACTIVE FAT (selected from
 * VolumeFlags at mount), so every get/set below automatically works on
 * the FAT the volume declares to be in use - per the exFAT spec only
 * the active FAT is maintained, so no mirroring is performed. */

static u32 fs_exfat_fat_get(fs_exfat_ctx_t *ctx, u32 cluster) {
    u64 off = (u64)cluster * 4;
    u64 sec = ctx->fat_start_lba + (off / ctx->sector_size);
    u32 off_in_sec = (u32)(off % ctx->sector_size);
    /* WP-10-tui-qa: refuse clusters whose FAT entry lives beyond the
     * FAT region the volume declares (mkfs.exfat used to ship
     * fat_length=1 with thousands of clusters, so entries past #127
     * landed in the cluster heap - reads returned heap bytes as chain
     * links and writes corrupted data).  EOC signals "no chain" to
     * the callers, the same as a read failure. */
    if ((u64)cluster * 4 + 4 > (u64)ctx->fat_size_sectors * ctx->sector_size)
        return EXFAT_EOC;
    /* P1-7 FIX: allocate sector_size bytes (may be > 512) to avoid stack overflow. */
    u8 *buf = (u8*)kmalloc(ctx->sector_size);
    if (!buf) return EXFAT_EOC;
    if (fs_exfat_read_sectors(ctx, sec, 1, buf) != 0) { kfree(buf); return EXFAT_EOC; }
    u32 val;
    memcpy(&val, buf + off_in_sec, 4);
    kfree(buf);
    return val;
}

static int fs_exfat_fat_set(fs_exfat_ctx_t *ctx, u32 cluster, u32 value) {
    u64 off = (u64)cluster * 4;
    u64 sec = ctx->fat_start_lba + (off / ctx->sector_size);
    u32 off_in_sec = (u32)(off % ctx->sector_size);
    /* WP-10-tui-qa: same FAT-region bound as fat_get - refuse writes
     * that would land in the cluster heap instead of the FAT. */
    if ((u64)cluster * 4 + 4 > (u64)ctx->fat_size_sectors * ctx->sector_size)
        return -1;
    /* P1-7 FIX: allocate sector_size bytes (may be > 512) to avoid stack overflow. */
    u8 *buf = (u8*)kmalloc(ctx->sector_size);
    if (!buf) return -1;
    if (fs_exfat_read_sectors(ctx, sec, 1, buf) != 0) { kfree(buf); return -1; }
    memcpy(buf + off_in_sec, &value, 4);
    int rc = fs_exfat_write_sectors(ctx, sec, 1, buf);
    kfree(buf);
    return rc;
}

static u64 fs_exfat_cluster_sector(fs_exfat_ctx_t *ctx, u32 cluster);

/* BUG-0059: allocation bitmap maintenance. The exFAT spec keeps the
 * free/used state of every cluster in the allocation bitmap (the FAT
 * only records chains); skipping it means the on-disk bitmap drifts
 * out of sync with what the driver actually allocated, so any other
 * implementation (or fsck) reads the volume wrong. */
static inline int fs_exfat_bitmap_get(const fs_exfat_ctx_t *ctx, u32 cluster) {
    if (!ctx->bitmap_cache || cluster < 2 || cluster >= ctx->cluster_count + 2)
        return -1;
    u64 bit = (u64)(cluster - 2);
    return (ctx->bitmap_cache[bit >> 3] >> (bit & 7)) & 1;
}
static void fs_exfat_bitmap_set(fs_exfat_ctx_t *ctx, u32 cluster, int val) {
    if (!ctx->bitmap_cache || cluster < 2 || cluster >= ctx->cluster_count + 2)
        return;
    u64 bit = (u64)(cluster - 2);
    u8 mask = (u8)(1u << (bit & 7));
    if (val) ctx->bitmap_cache[bit >> 3] |= mask;
    else     ctx->bitmap_cache[bit >> 3] &= (u8)~mask;
}
static int fs_exfat_bitmap_writeback(fs_exfat_ctx_t *ctx) {
    if (!ctx->bitmap_cache) return 0;
    u32 spc = ctx->sectors_per_cluster;
    u64 sectors = (ctx->bitmap_bytes + ctx->sector_size - 1) / ctx->sector_size;
    for (u64 done = 0; done < sectors; ) {
        u32 chunk = (sectors - done > spc) ? spc : (u32)(sectors - done);
        if (fs_exfat_write_sectors(ctx,
                fs_exfat_cluster_sector(ctx, ctx->bitmap_cluster) + done,
                chunk, ctx->bitmap_cache + done * ctx->sector_size) != 0)
            return -1;
        done += chunk;
    }
    return 0;
}
static void fs_exfat_bitmap_load(fs_exfat_ctx_t *ctx) {
    /* walk the root directory looking for the first allocation-bitmap
     * entry (type 0x81) */
    ctx->bitmap_cluster = 0;
    ctx->bitmap_bytes = 0;
    u32 oc_hops = 0;
    u32 cluster = ctx->root_cluster;
    while (cluster >= 2 && cluster != EXFAT_EOC &&
           oc_hops++ < ctx->cluster_count + 2u) {
        u64 sector = fs_exfat_cluster_sector(ctx, cluster);
        for (u32 s = 0; s < ctx->sectors_per_cluster; s++) {
            u8 sec[4096];
            if (ctx->sector_size > sizeof(sec) ||
                fs_exfat_read_sectors(ctx, sector + s, 1, sec) != 0) return;
            for (u32 off = 0; off + 32 <= ctx->sector_size; off += 32) {
                if (sec[off] == 0x00) return;          /* end of directory */
                if (sec[off] == EXFAT_TYPE_BITMAP) {
                    u32 fc = (u32)sec[off+20] | ((u32)sec[off+21] << 8) |
                             ((u32)sec[off+22] << 16) | ((u32)sec[off+23] << 24);
                    u64 len = (u64)sec[off+24] | ((u64)sec[off+25] << 8) |
                              ((u64)sec[off+26] << 16) | ((u64)sec[off+27] << 24);
                    if (fc < 2 || len == 0 ||
                        len < (u64)((ctx->cluster_count + 7) / 8))
                        return;                        /* bogus entry */
                    ctx->bitmap_cluster = fc;
                    ctx->bitmap_bytes = len;
                    goto found;
                }
            }
        }
        cluster = fs_exfat_fat_get(ctx, cluster);
    }
    return;
found:
    ctx->bitmap_cache = (u8 *)kmalloc((u32)ctx->bitmap_bytes);
    if (!ctx->bitmap_cache) { ctx->bitmap_cluster = 0; return; }
    u64 sectors = (ctx->bitmap_bytes + ctx->sector_size - 1) / ctx->sector_size;
    for (u64 done = 0; done < sectors; ) {
        u32 chunk = (sectors - done > ctx->sectors_per_cluster)
                        ? ctx->sectors_per_cluster : (u32)(sectors - done);
        if (fs_exfat_read_sectors(ctx,
                fs_exfat_cluster_sector(ctx, ctx->bitmap_cluster) + done,
                chunk, ctx->bitmap_cache + done * ctx->sector_size) != 0) {
            kfree(ctx->bitmap_cache);
            ctx->bitmap_cache = NULL;
            ctx->bitmap_cluster = 0;
            return;
        }
        done += chunk;
    }
    screen_console_puts("exfat: allocation bitmap loaded (");
    { char n[16]; u64_to_str((u64)ctx->cluster_count, n);
      screen_console_puts(n); screen_console_puts(" clusters)\n"); }
}

static u32 fs_exfat_alloc_cluster(fs_exfat_ctx_t *ctx) {
    u32 start = ctx->last_alloc ? ctx->last_alloc + 1 : 2;
    if (start < 2 || start >= ctx->cluster_count + 2) start = 2;
    for (u32 i = 0; i < ctx->cluster_count; i++) {
        u32 c = start + i;
        if (c >= ctx->cluster_count + 2) c -= ctx->cluster_count;
        if (c < 2) c = 2;
        /* BUG-0197 FIX (A12-032) follow-up, mkfs.exfat compatibility:
         * the shell's mkfs.exfat stamps only a boot sector, a FAT and a
         * root directory - there is NO allocation-bitmap entry (0x81) on
         * such volumes, so bitmap_get() answers -1 ("no bitmap"). The
         * old condition required the bitmap bit to be CLEAR, which made
         * every allocation (and therefore every write) fail on freshly
         * formatted volumes. With no bitmap on the volume the FAT is
         * the sole allocation authority (bitmap_set / writeback are
         * no-ops without a cache): accept -1 as "free". */
        int bitmap_used = fs_exfat_bitmap_get(ctx, c);
        if (fs_exfat_fat_get(ctx, c) == EXFAT_FREE_CLUSTER &&
            bitmap_used <= 0) {
            fs_exfat_fat_set(ctx, c, EXFAT_EOC);
            /* BUG-0059: keep the on-disk bitmap in sync with the FAT. */
            fs_exfat_bitmap_set(ctx, c, 1);
            fs_exfat_bitmap_writeback(ctx);
            ctx->last_alloc = c;
            return c;
        }
    }
    return 0;
}

static void fs_exfat_free_chain(fs_exfat_ctx_t *ctx, u32 first) {
    u32 cur = first;
    while (cur >= 2 && cur != EXFAT_EOC && cur < EXFAT_BAD_CLUSTER) {
        u32 next = fs_exfat_fat_get(ctx, cur);
        fs_exfat_fat_set(ctx, cur, EXFAT_FREE_CLUSTER);
        /* BUG-0059: free the matching bitmap bit as well. */
        fs_exfat_bitmap_set(ctx, cur, 0);
        cur = next;
    }
    /* one writeback for the whole freed chain */
    fs_exfat_bitmap_writeback(ctx);
}

static u64 fs_exfat_cluster_sector(fs_exfat_ctx_t *ctx, u32 cluster) {
    return ctx->mem_heap_start_lba + (u64)(cluster - 2) * ctx->sectors_per_cluster;
}

/* ---- Name handling ---- */

/* Extract UTF-16 filename from a sequence of 0xC1 name entries.
 * ASCII is flattened by taking the low byte of each code unit. */
static int fs_exfat_extract_name(const u8 *entries, int n_entries,
                              char *out, int out_len) {
    int out_pos = 0;
    for (int i = 0; i < n_entries; i++) {
        const fs_exfat_name_entry_t *ne =
            (const fs_exfat_name_entry_t *)(entries + i * 32);
        for (int j = 0; j < 15; j++) {
            u16 ch = ne->filename[j];
            if (ch == 0) { out[out_pos] = 0; return out_pos; }
            if (out_pos >= out_len - 1) { out[out_pos] = 0; return out_pos; }
            out[out_pos++] = (char)(ch & 0xFF);
        }
    }
    out[out_pos] = 0;
    return out_pos;
}

/* Build a sequence of 0xC1 name entries from an ASCII name. Returns the
 * number of name entries written (1..17) or -1 if too long. */
static int fs_exfat_make_name_entries(const char *name, u8 *entries, int max_entries) {
    int name_len = (int)strlen(name);
    int n_entries = (name_len + 14) / 15;
    if (n_entries == 0) n_entries = 1;
    if (n_entries > max_entries) return -1;
    int pos = 0;
    for (int i = 0; i < n_entries; i++) {
        fs_exfat_name_entry_t *ne = (fs_exfat_name_entry_t *)(entries + i * 32);
        memset(ne, 0, 32);
        ne->type = EXFAT_TYPE_NAME;
        ne->flags = (u8)(i + 1);  /* ordinal; last entry gets 0x40 below */
        for (int j = 0; j < 15; j++) {
            if (pos < name_len) {
                ne->filename[j] = (u16)(u8)name[pos++];
            } else {
                ne->filename[j] = 0;
            }
        }
    }
    fs_exfat_name_entry_t *last =
        (fs_exfat_name_entry_t *)(entries + (n_entries - 1) * 32);
    last->flags = (u8)(n_entries | 0x40);
    return n_entries;
}

/* Compute exFAT name hash (16-bit, per spec). ASCII-only upcase. */
static u16 fs_exfat_name_hash(const u16 *name, int name_len) {
    u16 hash = 0;
    for (int i = 0; i < name_len; i++) {
        u16 ch = name[i];
        if (ch >= 'a' && ch <= 'z') ch = (u16)(ch - 32);
        hash = (u16)(((hash >> 1) | (hash << 15)) & 0xFFFF);
        hash = (u16)((hash + ch) & 0xFFFF);
        hash = (u16)(((hash >> 1) | (hash << 15)) & 0xFFFF);
        hash = (u16)((hash + (u16)((ch << 8) | (ch >> 8))) & 0xFFFF);
    }
    return hash;
}

/* ---- Directory iteration ---- */

/* Find a file/dir named `name` in the directory whose first cluster is
 * dir_cluster. Returns 1 if found (fills out_*), 0 if not found, -1 on
 * I/O error. Name comparison is case-insensitive. */
static int fs_exfat_find_in_dir(fs_exfat_ctx_t *ctx, u32 dir_cluster,
                             const char *name,
                             fs_exfat_file_entry_t *out_file,
                             fs_exfat_stream_entry_t *out_stream,
                             u32 *out_cluster, u32 *out_offset,
                             char *out_name, int out_name_len) {
    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) return -1;
    u32 cluster = dir_cluster;
    int result = 0;
    u32 oc_hops = 0;   /* BUG-0058: bound the walk (corrupt chain = cycle) */
    while (cluster >= 2 && cluster != EXFAT_EOC && oc_hops++ < ctx->cluster_count + 2u) {
        u64 sector = fs_exfat_cluster_sector(ctx, cluster);
        if (fs_exfat_read_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0) {
            kfree(cbuf);
            return -1;
        }
        u32 n_entries = ctx->cluster_size / 32;
        u32 e = 0;
        while (e < n_entries) {
            fs_exfat_dentry_t *de = (fs_exfat_dentry_t *)(cbuf + e * 32);
            u8 type = de->type;
            if (type == EXFAT_TYPE_UNUSED) { goto done; }
            if (type == EXFAT_TYPE_FILE) {
                fs_exfat_file_entry_t *fe = (fs_exfat_file_entry_t *)de;
                u8 sec_count = fe->secondary_count;
                if (e + 1 + sec_count > n_entries) { e++; continue; }
                fs_exfat_stream_entry_t *se =
                    (fs_exfat_stream_entry_t *)(cbuf + (e + 1) * 32);
                int name_entries = (int)sec_count - 1;
                if (name_entries < 0) name_entries = 0;
                char entry_name[256];
                int got = 0;
                if (name_entries > 0) {
                    if (fs_exfat_extract_name(cbuf + (e + 2) * 32, name_entries,
                                           entry_name, sizeof(entry_name)) > 0) {
                        got = 1;
                    }
                }
                if (got && strcasecmp(entry_name, name) == 0) {
                    if (out_file) *out_file = *fe;
                    if (out_stream) *out_stream = *se;
                    if (out_cluster) *out_cluster = cluster;
                    if (out_offset) *out_offset = e * 32;
                    if (out_name && out_name_len > 0) {
                        strncpy(out_name, entry_name, out_name_len - 1);
                        out_name[out_name_len - 1] = 0;
                    }
                    result = 1;
                    goto done;
                }
                e += 1 + (u32)sec_count;
                continue;
            }
            e++;
        }
        cluster = fs_exfat_fat_get(ctx, cluster);
    }
done:
    kfree(cbuf);
    return result;
}

/* Add a new file entry set (0x85 + 0xC0 + N x 0xC1) to a directory.
 * Grows the directory by one cluster if no free run of slots is found.
 * Returns 0 on success; fills *out_cluster / *out_offset with the file
 * entry location. */
static int fs_exfat_add_entry(fs_exfat_ctx_t *ctx, u32 dir_cluster,
                           const char *name, int is_dir,
                           u32 first_cluster, u64 data_length,
                           u32 *out_cluster, u32 *out_offset) {
    u8 set_buf[32 * 18];  /* 1 file + 1 stream + up to 16 name entries */
    memset(set_buf, 0, sizeof(set_buf));
    int name_len = (int)strlen(name);
    int n_name = fs_exfat_make_name_entries(name, set_buf + 2 * 32, 16);
    if (n_name < 0) return -1;
    int total_entries = 2 + n_name;

    fs_exfat_file_entry_t *fe = (fs_exfat_file_entry_t *)(set_buf + 0);
    fe->type = EXFAT_TYPE_FILE;
    fe->secondary_count = (u8)(1 + n_name);
    fe->attributes = is_dir ? EXFAT_FILE_FLAG_DIR : 0;

    fs_exfat_stream_entry_t *se = (fs_exfat_stream_entry_t *)(set_buf + 32);
    se->type = EXFAT_TYPE_STREAM;
    se->flags = EXFAT_STREAM_FLAG_ALLOC_OK;
    se->name_length = (u8)name_len;
    u16 wname[256];
    for (int i = 0; i < name_len; i++) wname[i] = (u16)(u8)name[i];
    se->name_hash = fs_exfat_name_hash(wname, name_len);
    se->valid_data_length = data_length;
    se->first_cluster = first_cluster;
    se->data_length = data_length;

    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) return -1;
    u32 cluster = dir_cluster;
    u32 prev_cluster = 0;
    u32 oc_hops = 0;   /* BUG-0058: bound the walk (corrupt chain = cycle) */
    while (cluster >= 2 && cluster != EXFAT_EOC && oc_hops++ < ctx->cluster_count + 2u) {
        u64 sector = fs_exfat_cluster_sector(ctx, cluster);
        if (fs_exfat_read_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0) {
            kfree(cbuf);
            return -1;
        }
        u32 n_entries = ctx->cluster_size / 32;
        u32 e = 0;
        while (e < n_entries) {
            u32 run = 0;
            while (e + run < n_entries && run < (u32)total_entries) {
                fs_exfat_dentry_t *de =
                    (fs_exfat_dentry_t *)(cbuf + (e + run) * 32);
                if (de->type != EXFAT_TYPE_UNUSED) break;
                run++;
            }
            if (run >= (u32)total_entries) {
                memcpy(cbuf + e * 32, set_buf, (u32)total_entries * 32);
                if (fs_exfat_write_sectors(ctx, sector,
                                        ctx->sectors_per_cluster, cbuf) != 0) {
                    kfree(cbuf);
                    return -1;
                }
                *out_cluster = cluster;
                *out_offset = e * 32;
                kfree(cbuf);
                return 0;
            }
            e += run + 1;
        }
        prev_cluster = cluster;
        cluster = fs_exfat_fat_get(ctx, cluster);
    }
    /* Extend the directory by one cluster. */
    u32 new_cluster = fs_exfat_alloc_cluster(ctx);
    if (new_cluster == 0) { kfree(cbuf); return -1; }
    if (prev_cluster >= 2 && prev_cluster != EXFAT_EOC) {
        fs_exfat_fat_set(ctx, prev_cluster, new_cluster);
    }
    memset(cbuf, 0, ctx->cluster_size);
    memcpy(cbuf, set_buf, (u32)total_entries * 32);
    u64 sector = fs_exfat_cluster_sector(ctx, new_cluster);
    if (fs_exfat_write_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0) {
        kfree(cbuf);
        return -1;
    }
    *out_cluster = new_cluster;
    *out_offset = 0;
    kfree(cbuf);
    return 0;
}

/* Update the stream extension entry (first_cluster + data_length) of an
 * already-located file entry set. */
static int fs_exfat_update_stream(fs_exfat_ctx_t *ctx, u32 entry_cluster,
                               u32 entry_offset, u32 first_cluster,
                               u64 data_length, u64 valid_data_length) {
    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) return -1;
    u64 sector = fs_exfat_cluster_sector(ctx, entry_cluster);
    if (fs_exfat_read_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0) {
        kfree(cbuf);
        return -1;
    }
    fs_exfat_stream_entry_t *se =
        (fs_exfat_stream_entry_t *)(cbuf + entry_offset + 32);
    se->first_cluster = first_cluster;
    se->data_length = data_length;
    se->valid_data_length = valid_data_length;
    int rc = fs_exfat_write_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf);
    kfree(cbuf);
    return rc;
}

/* Mark a file entry set's entries as unused (type=0x00). */
static int fs_exfat_delete_entry(fs_exfat_ctx_t *ctx, u32 entry_cluster,
                              u32 entry_offset) {
    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) return -1;
    u64 sector = fs_exfat_cluster_sector(ctx, entry_cluster);
    if (fs_exfat_read_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0) {
        kfree(cbuf);
        return -1;
    }
    fs_exfat_file_entry_t *fe = (fs_exfat_file_entry_t *)(cbuf + entry_offset);
    u8 sec_count = fe->secondary_count;
    for (u8 i = 0; i <= sec_count && entry_offset + i * 32 < ctx->cluster_size;
         i++) {
        cbuf[entry_offset + i * 32] = EXFAT_TYPE_UNUSED;
    }
    int rc = fs_exfat_write_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf);
    kfree(cbuf);
    return rc;
}

/* ---- VFS file operations ---- */

static int fs_exfat_open(fs_vfs_node_t *node, int flags) {
    if (!node) return -1;
    if (node->type == VFS_TYPE_DIR) return -2;
    /* BUG-0192 FIX (A12-027): O_TRUNC used to be ignored - the VFS layer
     * only cleared the in-memory node->size, so the on-disk stream
     * entry kept the old data_length and the cluster chain stayed
     * allocated: open(O_TRUNC) + close (+ remount) resurrected the old
     * file size and the file kept occupying its clusters. Truncate for
     * real (same semantics as fs_fat32_open): free the cluster chain,
     * zero the stream entry's first cluster / data length / valid data
     * length on disk, and clear the cached inode state. */
    if (flags & VFS_O_TRUNC) {
        fs_exfat_inode_t *ino = (fs_exfat_inode_t *)node->private;
        if (!ino || !ino->ctx) return -2;
        fs_exfat_ctx_t *ctx = ino->ctx;
        if (ino->first_cluster >= 2) {
            fs_exfat_free_chain(ctx, ino->first_cluster);
            ino->first_cluster = 0;
        }
        node->size = 0;
        if (ino->entry_cluster != 0) {
            /* exFAT spec 7.4 "Stream Extension Directory Entry": a
             * zero-length file has FirstCluster = 0 and both
             * DataLength and ValidDataLength = 0. */
            if (fs_exfat_update_stream(ctx, ino->entry_cluster,
                                    ino->entry_offset, 0, 0, 0) != 0) {
                return -3;
            }
        }
    }
    return 0;
}

static int fs_exfat_read(fs_vfs_node_t *node, u64 offset, void *buf, int size) {
    if (!node || !buf || size < 0) return -1;
    fs_exfat_inode_t *ino = (fs_exfat_inode_t *)node->private;
    if (!ino || !ino->ctx) return -2;
    if (ino->is_dir) return -3;
    if (ino->first_cluster < 2) return 0;     /* empty file */
    u64 file_size = node->size;
    if (offset >= file_size) return 0;
    u64 avail = file_size - offset;
    int want = (int)(avail < (u64)size ? avail : (u64)size);

    fs_exfat_ctx_t *ctx = ino->ctx;
    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) return -4;

    /* Walk the chain to find the cluster containing `offset`. */
    u32 cluster = ino->first_cluster;
    u64 bpc = ctx->cluster_size;
    u64 skip_clusters = offset / bpc;
    u64 off_in_cluster = offset % bpc;
    for (u64 i = 0; i < skip_clusters; i++) {
        if (cluster < 2 || cluster == EXFAT_EOC) {
            kfree(cbuf);
            return 0;
        }
        cluster = fs_exfat_fat_get(ctx, cluster);
    }

    int copied = 0;
    while (copied < want) {
        if (cluster < 2 || cluster == EXFAT_EOC) break;
        u64 sector = fs_exfat_cluster_sector(ctx, cluster);
        if (fs_exfat_read_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0)
            break;
        u64 in_this = bpc - off_in_cluster;
        u64 need = (u64)(want - copied);
        u64 to_copy = in_this < need ? in_this : need;
        memcpy((u8 *)buf + copied, cbuf + off_in_cluster, (usize)to_copy);
        copied += (int)to_copy;
        cluster = fs_exfat_fat_get(ctx, cluster);
        off_in_cluster = 0;
    }
    kfree(cbuf);
    return copied;
}

static int fs_exfat_write(fs_vfs_node_t *node, u64 offset, const void *buf, int size) {
    if (!node || !buf || size <= 0) return -1;
    fs_exfat_inode_t *ino = (fs_exfat_inode_t *)node->private;
    if (!ino || !ino->ctx) return -2;
    if (ino->is_dir) return -3;
    if (ino->entry_cluster == 0) return -4;  /* root or no parent entry */
    fs_exfat_ctx_t *ctx = ino->ctx;

    /* The scratch cluster buffer doubles as the zero-fill buffer for
     * every newly-allocated cluster below. */
    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) return -6;

    /* Allocate the first cluster if the file is empty. */
    if (ino->first_cluster < 2) {
        u32 fc = fs_exfat_alloc_cluster(ctx);
        if (fc == 0) { kfree(cbuf); return -5; }
        ino->first_cluster = fc;
        /* BUG-0194 FIX (A12-029): the first cluster of a formerly-empty
         * file is fresh disk space - zero it so unwritten bytes (and
         * later holes) read as 0, matching FAT32/ramfs hole semantics. */
        memset(cbuf, 0, ctx->cluster_size);
        if (fs_exfat_write_sectors(ctx, fs_exfat_cluster_sector(ctx, fc),
                                ctx->sectors_per_cluster, cbuf) != 0) {
            kfree(cbuf);
            return -6;
        }
    }

    u64 new_end = offset + (u64)size;
    u64 cur_size = node->size;
    u64 chain_bytes = 0;   /* chain capacity after the extend below */
    if (new_end > cur_size) {
        /* BUG-0193 FIX (A12-028): the extend loop used to start its byte
         * accounting at ONE full cluster (`current_bytes =
         * ctx->cluster_size`) regardless of how many clusters the file
         * already owned, so a file with k clusters grew by k extra
         * clusters on every append - the chain became longer than
         * ceil(data_length / cluster_size) (spec violation; chkdsk
         * complains; space leak accumulates per append). Count the
         * EXISTING chain first (bounded by the volume's cluster count
         * so a corrupt FAT loop terminates), then append only the
         * missing clusters. */
        u64 n_clusters = 1;             /* first_cluster ensured above */
        u32 last = ino->first_cluster;
        u32 hops = 0;
        while (hops++ < ctx->cluster_count + 2u) {
            u32 next = fs_exfat_fat_get(ctx, last);
            if (next < 2 || next == EXFAT_EOC || next >= EXFAT_BAD_CLUSTER)
                break;
            last = next;
            n_clusters++;
        }
        chain_bytes = n_clusters * (u64)ctx->cluster_size;
        while (chain_bytes < new_end) {
            u32 nc = fs_exfat_alloc_cluster(ctx);
            if (nc == 0) break;                    /* volume full */
            if (fs_exfat_fat_set(ctx, last, nc) != 0) {
                /* Un-link the orphan so FAT/bitmap stay consistent. */
                fs_exfat_free_chain(ctx, nc);
                break;
            }
            last = nc;
            /* BUG-0194 FIX (A12-029): every newly-allocated cluster is
             * zeroed on disk. The old code only chained the FAT and
             * left stale disk contents in every hole (reads of the
             * unwritten gap returned old file data - info leak). */
            memset(cbuf, 0, ctx->cluster_size);
            if (fs_exfat_write_sectors(ctx, fs_exfat_cluster_sector(ctx, nc),
                                    ctx->sectors_per_cluster, cbuf) != 0) {
                break;
            }
            chain_bytes += ctx->cluster_size;
        }
    }

    /* Walk the chain to the cluster containing `offset`. */
    u32 cluster = ino->first_cluster;
    u64 target_idx = offset / ctx->cluster_size;
    for (u64 i = 0; i < target_idx; i++) {
        if (cluster < 2 || cluster == EXFAT_EOC) {
            kfree(cbuf);
            return 0;
        }
        cluster = fs_exfat_fat_get(ctx, cluster);
    }
    u64 off_in_cluster = offset % ctx->cluster_size;

    int total = 0;
    const u8 *src = (const u8 *)buf;
    while (total < size) {
        if (cluster < 2 || cluster == EXFAT_EOC) break;
        u64 sector = fs_exfat_cluster_sector(ctx, cluster);
        u64 bytes_this = ctx->cluster_size - off_in_cluster;
        u64 need = (u64)(size - total);
        if (bytes_this > need) bytes_this = need;
        if (off_in_cluster != 0 || bytes_this != ctx->cluster_size) {
            if (fs_exfat_read_sectors(ctx, sector, ctx->sectors_per_cluster,
                                   cbuf) != 0) {
                break;
            }
        } else {
            memset(cbuf, 0, ctx->cluster_size);
        }
        memcpy(cbuf + off_in_cluster, src + total, (usize)bytes_this);
        if (fs_exfat_write_sectors(ctx, sector, ctx->sectors_per_cluster,
                                cbuf) != 0) {
            break;
        }
        total += (int)bytes_this;
        cluster = fs_exfat_fat_get(ctx, cluster);
        off_in_cluster = 0;
    }
    kfree(cbuf);

    /* Update on-disk stream entry if the file grew. */
    if (new_end > cur_size) {
        /* Never publish a data_length the cluster chain cannot back
         * (partial extension, e.g. disk full): clamp the new end to the
         * extended capacity. Extended clusters are zeroed, so the
         * clamped range still reads as defined data. */
        u64 end = offset + (u64)total;
        if (end > chain_bytes) end = chain_bytes;
        if (end > cur_size) {
            fs_exfat_update_stream(ctx, ino->entry_cluster, ino->entry_offset,
                                ino->first_cluster, end, end);
            node->size = end;
        }
    }
    return total;
}

static u64 fs_exfat_seek(fs_vfs_node_t *node, u64 offset, int whence) {
    if (!node) return 0;
    u64 sz = node->size;
    u64 new_off = offset;
    switch (whence) {
        case VFS_SEEK_SET: new_off = offset; break;
        case VFS_SEEK_CUR: break;
        case VFS_SEEK_END: new_off = (sz > offset) ? (sz - offset) : 0; break;
        default: break;
    }
    if (new_off > sz) new_off = sz;
    return new_off;
}

static int fs_exfat_close(fs_vfs_node_t *node) {
    (void)node;
    return 0;
}

static int fs_exfat_stat(fs_vfs_node_t *node, fs_vfs_stat_t *st) {
    if (!node || !st) return -1;
    st->type = node->type;
    st->size = node->size;
    strncpy(st->name, node->name, VFS_NAME_LEN - 1);
    st->name[VFS_NAME_LEN - 1] = 0;
    return 0;
}

/* ---- VFS directory operations ---- */

/* P1-2 FIX: create a regular file (not a directory) in the exFAT on-disk
 * directory. Unlike the old VFS approach (call mkdir then patch the in-memory
 * node type), this creates the on-disk entry with FILE attributes (not DIR),
 * so a later readdir/ls correctly reports it as a regular file. */
static int fs_exfat_create(fs_vfs_node_t *parent, const char *name) {
    if (!parent || !name) return -1;
    fs_exfat_inode_t *pino = (fs_exfat_inode_t *)parent->private;
    if (!pino || !pino->ctx) return -2;
    if (!pino->is_dir) return -3;
    fs_exfat_ctx_t *ctx = pino->ctx;
    /* Already exists? */
    if (fs_exfat_find_in_dir(ctx, pino->first_cluster, name,
                          NULL, NULL, NULL, NULL, NULL, 0) == 1) {
        return -4;
    }
    /* Create a file entry with is_dir=0 (no cluster allocated yet —
     * first_cluster=0, data_length=0. Data will be allocated on write.) */
    u32 ec, eo;
    if (fs_exfat_add_entry(ctx, pino->first_cluster, name, 0 /*is_dir*/,
                        0 /*first_cluster*/, 0 /*data_length*/, &ec, &eo) != 0) {
        return -5;
    }
    /* BUG-0195 FIX (A12-030): the old tail of this function built a VFS
     * node + inode for the new file but never attached it to the tree
     * (no fs_vfs_attach_child) and never freed it either. The VFS
     * O_CREAT path re-looks the name up right after create() returns
     * (fs_exfat_lookup builds its own node there), so the node built
     * here leaked on EVERY O_CREAT (~200 B). Match fs_fat32_create:
     * create the on-disk entry only - node lifecycle belongs to the
     * lookup/resolve paths, which attach and track their nodes. Repeat
     * create on the same name fails above (-4), so no duplicates. */
    (void)ec;
    (void)eo;
    return 0;
}

static int fs_exfat_mkdir(fs_vfs_node_t *parent, const char *name) {
    if (!parent || !name) return -1;
    fs_exfat_inode_t *pino = (fs_exfat_inode_t *)parent->private;
    if (!pino || !pino->ctx) return -2;
    if (!pino->is_dir) return -3;
    fs_exfat_ctx_t *ctx = pino->ctx;
    /* Already exists? */
    if (fs_exfat_find_in_dir(ctx, pino->first_cluster, name,
                          NULL, NULL, NULL, NULL, NULL, 0) == 1) {
        return -4;
    }
    /* Allocate one cluster for the new (empty) directory. */
    u32 new_cluster = fs_exfat_alloc_cluster(ctx);
    if (new_cluster == 0) return -5;
    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) {
        fs_exfat_fat_set(ctx, new_cluster, EXFAT_FREE_CLUSTER);
        return -6;
    }
    memset(cbuf, 0, ctx->cluster_size);
    u64 sector = fs_exfat_cluster_sector(ctx, new_cluster);
    if (fs_exfat_write_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0) {
        kfree(cbuf);
        fs_exfat_fat_set(ctx, new_cluster, EXFAT_FREE_CLUSTER);
        return -7;
    }
    kfree(cbuf);
    u32 ec, eo;
    if (fs_exfat_add_entry(ctx, pino->first_cluster, name, 1 /*is_dir*/,
                        new_cluster, 0, &ec, &eo) != 0) {
        fs_exfat_fat_set(ctx, new_cluster, EXFAT_FREE_CLUSTER);
        return -8;
    }
    return 0;
}

static int fs_exfat_rmdir(fs_vfs_node_t *parent, const char *name) {
    if (!parent || !name) return -1;
    fs_exfat_inode_t *pino = (fs_exfat_inode_t *)parent->private;
    if (!pino || !pino->ctx) return -2;
    fs_exfat_ctx_t *ctx = pino->ctx;
    fs_exfat_file_entry_t fe;
    fs_exfat_stream_entry_t se;
    u32 entry_cluster = 0, entry_offset = 0;
    if (fs_exfat_find_in_dir(ctx, pino->first_cluster, name,
                          &fe, &se, &entry_cluster, &entry_offset, NULL, 0) != 1)
        return -3;
    if (!(fe.attributes & EXFAT_FILE_FLAG_DIR)) return -4;
    u32 dir_cluster = se.first_cluster;
    /* Check emptiness: scan dir for any non-unused, non-bitmap/upcase entry. */
    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) return -5;
    u32 cluster = dir_cluster;
    int is_empty = 1;
    u32 oc_hops = 0;   /* BUG-0058: bound the walk (corrupt chain = cycle) */
    while (cluster >= 2 && cluster != EXFAT_EOC && oc_hops++ < ctx->cluster_count + 2u) {
        u64 sector = fs_exfat_cluster_sector(ctx, cluster);
        if (fs_exfat_read_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0) {
            kfree(cbuf);
            return -6;
        }
        u32 n_entries = ctx->cluster_size / 32;
        for (u32 e = 0; e < n_entries; e++) {
            fs_exfat_dentry_t *de = (fs_exfat_dentry_t *)(cbuf + e * 32);
            if (de->type == EXFAT_TYPE_UNUSED) goto done_check;
            if (de->type == EXFAT_TYPE_BITMAP || de->type == EXFAT_TYPE_UPCASE)
                continue;
            is_empty = 0;
            goto done_check;
        }
        cluster = fs_exfat_fat_get(ctx, cluster);
    }
done_check:
    kfree(cbuf);
    if (!is_empty) return -7;
    if (dir_cluster >= 2) fs_exfat_free_chain(ctx, dir_cluster);
    fs_exfat_delete_entry(ctx, entry_cluster, entry_offset);
    return 0;
}

static int fs_exfat_readdir(fs_vfs_node_t *dir, int index, fs_vfs_dirent_t *entry) {
    if (!dir || !entry || index < 0) return -1;
    fs_exfat_inode_t *ino = (fs_exfat_inode_t *)dir->private;
    if (!ino || !ino->ctx) return -2;
    if (!ino->is_dir) return -3;
    fs_exfat_ctx_t *ctx = ino->ctx;
    if (ino->first_cluster < 2) return -4;
    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) return -5;
    u32 cluster = ino->first_cluster;
    int cur_idx = 0;
    int result = -6;
    u32 oc_hops = 0;   /* BUG-0058: bound the walk (corrupt chain = cycle) */
    while (cluster >= 2 && cluster != EXFAT_EOC && oc_hops++ < ctx->cluster_count + 2u) {
        u64 sector = fs_exfat_cluster_sector(ctx, cluster);
        if (fs_exfat_read_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0) {
            kfree(cbuf);
            return -7;
        }
        u32 n_entries = ctx->cluster_size / 32;
        u32 e = 0;
        while (e < n_entries) {
            fs_exfat_dentry_t *de = (fs_exfat_dentry_t *)(cbuf + e * 32);
            u8 type = de->type;
            if (type == EXFAT_TYPE_UNUSED) { result = -8; goto done; }
            if (type == EXFAT_TYPE_FILE) {
                fs_exfat_file_entry_t *fe = (fs_exfat_file_entry_t *)de;
                u8 sec_count = fe->secondary_count;
                if (e + 1 + sec_count > n_entries) { e++; continue; }
                fs_exfat_stream_entry_t *se =
                    (fs_exfat_stream_entry_t *)(cbuf + (e + 1) * 32);
                int name_entries = (int)sec_count - 1;
                if (name_entries < 0) name_entries = 0;
                char entry_name[256];
                int got = 0;
                if (name_entries > 0) {
                    if (fs_exfat_extract_name(cbuf + (e + 2) * 32, name_entries,
                                           entry_name, sizeof(entry_name)) > 0) {
                        got = 1;
                    }
                }
                if (got && cur_idx == index) {
                    memset(entry, 0, sizeof(*entry));
                    strncpy(entry->name, entry_name, VFS_NAME_LEN - 1);
                    entry->name[VFS_NAME_LEN - 1] = 0;
                    entry->type = (fe->attributes & EXFAT_FILE_FLAG_DIR)
                                      ? VFS_TYPE_DIR : VFS_TYPE_FILE;
                    entry->inode = se->first_cluster;
                    result = 0;
                    goto done;
                }
                if (got) cur_idx++;
                e += 1 + (u32)sec_count;
                continue;
            }
            e++;
        }
        cluster = fs_exfat_fat_get(ctx, cluster);
    }
done:
    kfree(cbuf);
    return result;
}

static fs_vfs_node_t *fs_exfat_lookup(fs_vfs_node_t *parent, const char *name) {
    /* P2-20: cycle detection — limit cluster chain traversal to prevent
     * infinite loops on corrupt exFAT images. */
    if (!parent || !name) return NULL;
    fs_exfat_inode_t *pino = (fs_exfat_inode_t *)parent->private;
    if (!pino || !pino->ctx) return NULL;
    fs_exfat_ctx_t *ctx = pino->ctx;
    fs_exfat_file_entry_t fe;
    fs_exfat_stream_entry_t se;
    u32 entry_cluster = 0, entry_offset = 0;
    char display[VFS_NAME_LEN];
    display[0] = 0;
    if (fs_exfat_find_in_dir(ctx, pino->first_cluster, name,
                          &fe, &se, &entry_cluster, &entry_offset,
                          display, sizeof(display)) != 1) {
        return NULL;
    }
    int is_dir = (fe.attributes & EXFAT_FILE_FLAG_DIR) ? 1 : 0;
    fs_exfat_inode_t *child_ino = (fs_exfat_inode_t *)kmalloc(sizeof(fs_exfat_inode_t));
    if (!child_ino) return NULL;
    memset(child_ino, 0, sizeof(*child_ino));
    child_ino->ctx = ctx;
    child_ino->first_cluster = se.first_cluster;
    child_ino->is_dir = is_dir;
    child_ino->entry_cluster = entry_cluster;
    child_ino->entry_offset = entry_offset;
    fs_vfs_node_t *cn = fs_vfs_alloc_node(display,
                                    is_dir ? VFS_TYPE_DIR : VFS_TYPE_FILE,
                                    &g_exfat_fs_type);
    if (!cn) {
        kfree(child_ino);
        return NULL;
    }
    cn->private = child_ino;
    cn->size = se.data_length;
    cn->parent = parent;
    return cn;
}

static int fs_exfat_unlink(fs_vfs_node_t *parent, const char *name) {
    if (!parent || !name) return -1;
    fs_exfat_inode_t *pino = (fs_exfat_inode_t *)parent->private;
    if (!pino || !pino->ctx) return -2;
    fs_exfat_ctx_t *ctx = pino->ctx;
    fs_exfat_file_entry_t fe;
    fs_exfat_stream_entry_t se;
    u32 entry_cluster = 0, entry_offset = 0;
    if (fs_exfat_find_in_dir(ctx, pino->first_cluster, name,
                          &fe, &se, &entry_cluster, &entry_offset, NULL, 0) != 1)
        return -3;
    if (fe.attributes & EXFAT_FILE_FLAG_DIR) return -4;  /* use rmdir for dirs */
    if (se.first_cluster >= 2) fs_exfat_free_chain(ctx, se.first_cluster);
    fs_exfat_delete_entry(ctx, entry_cluster, entry_offset);
    return 0;
}

static int fs_exfat_rename(fs_vfs_node_t *parent, const char *oldname,
                        const char *newname) {
    if (!parent || !oldname || !newname) return -1;
    fs_exfat_inode_t *pino = (fs_exfat_inode_t *)parent->private;
    if (!pino || !pino->ctx) return -2;
    fs_exfat_ctx_t *ctx = pino->ctx;
    /* If newname already exists, fail. */
    if (fs_exfat_find_in_dir(ctx, pino->first_cluster, newname,
                          NULL, NULL, NULL, NULL, NULL, 0) == 1) return -3;
    fs_exfat_file_entry_t ofe;
    fs_exfat_stream_entry_t ose;
    u32 entry_cluster = 0, entry_offset = 0;
    if (fs_exfat_find_in_dir(ctx, pino->first_cluster, oldname,
                          &ofe, &ose, &entry_cluster, &entry_offset,
                          NULL, 0) != 1) return -4;
    int old_name_entries = (int)ofe.secondary_count - 1;
    if (old_name_entries < 0) old_name_entries = 0;
    /* Build new name entries; if the count differs we fall back to
     * delete + re-add (preserving first_cluster and data_length). */
    u8 new_names[32 * 17];
    int new_n = fs_exfat_make_name_entries(newname, new_names, 17);
    if (new_n < 0) return -5;
    if (new_n != old_name_entries) {
        u32 ec, eo;
        if (fs_exfat_add_entry(ctx, pino->first_cluster, newname,
                            (ofe.attributes & EXFAT_FILE_FLAG_DIR) ? 1 : 0,
                            ose.first_cluster, ose.data_length, &ec, &eo) != 0)
            return -6;
        fs_exfat_delete_entry(ctx, entry_cluster, entry_offset);
        return 0;
    }
    /* Same number of name entries - overwrite in place. */
    u8 *cbuf = (u8 *)kmalloc(ctx->cluster_size);
    if (!cbuf) return -7;
    u64 sector = fs_exfat_cluster_sector(ctx, entry_cluster);
    if (fs_exfat_read_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf) != 0) {
        kfree(cbuf);
        return -8;
    }
    memcpy(cbuf + entry_offset + 2 * 32, new_names, (u32)new_n * 32);
    fs_exfat_stream_entry_t *se =
        (fs_exfat_stream_entry_t *)(cbuf + entry_offset + 32);
    int name_len = (int)strlen(newname);
    se->name_length = (u8)name_len;
    u16 wname[256];
    for (int i = 0; i < name_len; i++) wname[i] = (u16)(u8)newname[i];
    se->name_hash = fs_exfat_name_hash(wname, name_len);
    int rc = fs_exfat_write_sectors(ctx, sector, ctx->sectors_per_cluster, cbuf);
    kfree(cbuf);
    return rc;
}

/* ---- Mount / unmount ---- */

static fs_vfs_node_t *fs_exfat_fs_mount(const char *device) {
    /* BUG-0197 FIX (A12-032): mount through the generic blk layer - any
     * registered block device works, including partition sub-devices.
     * The legacy whole-disk aliases ("ata0".."ata3") still resolve. */
    int dev_idx = fs_exfat_parse_device(device);
    if (dev_idx < 0) {
        screen_console_puts("exfat: invalid device string\n");
        return NULL;
    }
    driver_block_device_t *bdev = driver_block_get_device(dev_idx);
    if (!bdev || !bdev->present) {
        screen_console_puts("exfat: drive not present\n");
        return NULL;
    }
    u8 boot[512];
    if (driver_block_read_sectors_raw(dev_idx, 0, 1, boot) != 0) {
        screen_console_puts("exfat: read boot sector failed\n");
        return NULL;
    }
    fs_exfat_bpb_t *bpb = (fs_exfat_bpb_t *)boot;
    if (strncmp((const char *)bpb->fs_name, "EXFAT   ", 8) != 0) {
        screen_console_puts("exfat: not an exFAT volume\n");
        return NULL;
    }
    if (bpb->bytes_per_sector_shift > 12 ||
        bpb->sectors_per_cluster_shift > 25 -
        bpb->bytes_per_sector_shift) {
        screen_console_puts("exfat: impossible sector/cluster shift\n");
        return NULL;
    }
    /* BUG-0197 FIX (A12-032): the blk layer transfers fixed 512-byte
     * sectors (BLK_SECTOR_SIZE, same as the ATA driver this fs used to
     * talk to directly). A volume with a different sector size would
     * silently read only a fraction of every sector buffer, so refuse
     * it cleanly instead of corrupting data (mirrors the FAT32 mount
     * check bytes_per_sector != 512). */
    if (bpb->bytes_per_sector_shift != 9) {
        screen_console_puts("exfat: sector size must be 512 bytes\n");
        return NULL;
    }
    /* BUG-0185 FIX (A12-020): exFAT spec 3.1.16 NumberOfFats - must be
     * 1 or 2 (2 only for TexFAT); 3.1.13 VolumeFlags - bit 0 ActiveFat
     * selects the FAT in use, bit 1 VolumeDirty marks an uncleanly
     * unmounted volume. The old mount ignored both fields and always
     * worked on FAT #0. */
    if (bpb->number_of_fats == 0 || bpb->number_of_fats > 2) {
        screen_console_puts("exfat: invalid number_of_fats\n");
        return NULL;
    }
    if (bpb->volume_flags & 0x0002u) {
        screen_console_puts("exfat: warning - volume was not cleanly unmounted\n");
    }
    fs_exfat_ctx_t *ctx = (fs_exfat_ctx_t *)kmalloc(sizeof(fs_exfat_ctx_t));
    if (!ctx) return NULL;
    memset(ctx, 0, sizeof(*ctx));
    ctx->dev_idx = dev_idx;
    ctx->sector_size = (u32)1 << bpb->bytes_per_sector_shift;
    ctx->sectors_per_cluster = (u32)1 << bpb->sectors_per_cluster_shift;
    ctx->cluster_size = ctx->sector_size * ctx->sectors_per_cluster;
    ctx->fat_size_sectors = bpb->fat_length;
    /* Active FAT: honour VolumeFlags.ActiveFat on 2-FAT volumes. On a
     * 1-FAT volume the bit is meaningless - force FAT #0 instead of
     * pointing past the only copy (honest handling of 1-FAT volumes). */
    ctx->number_of_fats = bpb->number_of_fats;
    ctx->active_fat = (bpb->number_of_fats == 2 && (bpb->volume_flags & 0x0001u))
                          ? 1 : 0;
    ctx->fat_start_lba = bpb->fat_offset +
                         (u32)ctx->active_fat * bpb->fat_length;
    ctx->mem_heap_start_lba = bpb->cluster_heap_offset;
    ctx->cluster_count = bpb->cluster_count;
    ctx->root_cluster = bpb->first_cluster_of_root_directory;
    ctx->last_alloc = 0;
    fs_exfat_bitmap_load(ctx);

    fs_exfat_inode_t *root_ino = (fs_exfat_inode_t *)kmalloc(sizeof(fs_exfat_inode_t));
    if (!root_ino) { kfree(ctx); return NULL; }
    memset(root_ino, 0, sizeof(*root_ino));
    root_ino->ctx = ctx;
    root_ino->first_cluster = ctx->root_cluster;
    root_ino->is_dir = 1;
    root_ino->entry_cluster = 0;
    root_ino->entry_offset = 0;

    fs_vfs_node_t *root = fs_vfs_alloc_node("", VFS_TYPE_DIR, &g_exfat_fs_type);
    if (!root) {
        kfree(root_ino);
        kfree(ctx);
        return NULL;
    }
    root->private = root_ino;
    return root;
}

/* BUG-0196 FIX (A12-031): recursively free the whole cached VFS subtree
 * (every node lookup resolved through this mount was attached under the
 * root by fs_vfs_resolve). The old unmount released only the root node,
 * leaking every cached child node + inode. fs_vfs_umount guarantees the
 * subtree is quiescent before calling here: open fds are refused (EBUSY)
 * and nested mounts deeper than this mount point must be unmounted
 * first, so every child below `root` belongs to this fs. The fs-wide
 * context (ctx) is shared by all inodes and is freed separately below,
 * exactly once. */
static void fs_exfat_free_subtree(fs_vfs_node_t *node) {
    if (!node) return;
    fs_vfs_node_t *child = node->first_child;
    while (child) {
        fs_vfs_node_t *next = child->next_sibling;
        fs_exfat_free_subtree(child);
        child = next;
    }
    fs_exfat_inode_t *ino = (fs_exfat_inode_t *)node->private;
    if (ino) kfree(ino);
    kfree(node);
}

static int fs_exfat_fs_unmount(fs_vfs_node_t *root) {
    /* BUG-0059: flush the allocation bitmap before the context dies. */
    if (!root) return -1;
    fs_exfat_inode_t *ino = (fs_exfat_inode_t *)root->private;
    if (ino && ino->ctx) {
        fs_exfat_bitmap_writeback(ino->ctx);
        if (ino->ctx->bitmap_cache) kfree(ino->ctx->bitmap_cache);
        kfree(ino->ctx);
    }
    /* BUG-0196 FIX (A12-031): free the entire cached subtree, not just
     * the root node (ctx is already released, and freeing it here does
     * not touch the per-node inodes). */
    fs_exfat_free_subtree(root);
    return 0;
}

/* ---- Init ---- */

void fs_exfat_init(void) {
    memset(&g_exfat_fs_type, 0, sizeof(g_exfat_fs_type));
    strncpy(g_exfat_fs_type.name, "exfat", sizeof(g_exfat_fs_type.name) - 1);
    g_exfat_fs_ops.mount   = fs_exfat_fs_mount;
    g_exfat_fs_ops.unmount = fs_exfat_fs_unmount;
    g_exfat_file_ops.open  = fs_exfat_open;
    g_exfat_file_ops.read  = fs_exfat_read;
    g_exfat_file_ops.write = fs_exfat_write;
    g_exfat_file_ops.seek  = fs_exfat_seek;
    g_exfat_file_ops.close = fs_exfat_close;
    g_exfat_file_ops.stat  = fs_exfat_stat;
    g_exfat_dir_ops.mkdir   = fs_exfat_mkdir;
    g_exfat_dir_ops.create  = fs_exfat_create;  /* P1-2 FIX */
    g_exfat_dir_ops.rmdir   = fs_exfat_rmdir;
    g_exfat_dir_ops.readdir = fs_exfat_readdir;
    g_exfat_dir_ops.lookup  = fs_exfat_lookup;
    g_exfat_dir_ops.unlink  = fs_exfat_unlink;
    g_exfat_dir_ops.rename  = fs_exfat_rename;
    g_exfat_fs_type.fs_ops   = &g_exfat_fs_ops;
    g_exfat_fs_type.file_ops = &g_exfat_file_ops;
    g_exfat_fs_type.dir_ops  = &g_exfat_dir_ops;

    fs_vfs_register_fs("exfat", &g_exfat_fs_ops, &g_exfat_file_ops,
                    &g_exfat_dir_ops);
    /* BUG-0179 FIX (A12-014): exFAT name matching is case-insensitive
     * (fs_exfat_find_in_dir uses strcasecmp) - mirror that in the VFS
     * node cache. */
    g_exfat_fs_type.case_insensitive = 1;
    fs_vfs_set_fs_case_insensitive("exfat", 1);
    screen_console_puts("exfat: registered (read/write)\n");
}
