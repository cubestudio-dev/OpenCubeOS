/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2026 cubestudio-dev <cubestudio@qq.com> */
/* Open Cube OS - WP-04/WP-08a
 * File: kernel/core/core_usermode.h
 * Purpose: Userspace support - ring 3, syscalls, ELF loader, process table.
 */
#ifndef OC_USERMODE_H
#define OC_USERMODE_H

#include "types.h"
#include "mem_vmm.h"
#include "core_sched.h"
#include "core_syscall.h"

/* Maximum user processes. */
#define MAX_USER_PROCS 16

/* User address space layout:
 *   0x400000    - code/data (ELF load address)
 *   0x500000    - brk heap start (grows up)
 *   0x3FFF0000  - user stack (grows down from 0x40000000)
 *   0x60000000  - mmap region (grows up from here)
 *
 * NOTE: The stack is in PDPT[0] (0-1GiB), which has a per-process PD.
 * This is critical for fork() — the child's copy of the stack must be
 * in the child's own page tables, not in a shared kernel PD.
 */
#define USER_CODE_BASE  0x400000ULL
#define USER_STACK_TOP  0x40000000ULL
#define USER_STACK_SIZE 0x10000ULL  /* 64 KiB */
#define USER_BRK_BASE   0x500000ULL
#define USER_MMAP_BASE  0x3C000000ULL

/* BUG-0281 (A2-9) FIX: ONE authoritative mmap window for mmap, munmap and
 * mprotect. The three syscalls used to enforce different limits (mmap had
 * none at all and could grow its bump base past the reach of its own
 * teardown calls; munmap/mprotect accepted up to USER_MMAP_BASE+256 MiB,
 * which includes the user stack). The window now ends exactly where the
 * 64 KiB user stack begins, so a mapping can never overlap the stack and
 * everything mmap produces is reachable by munmap/mprotect. */
#define USER_MMAP_WINDOW_END (USER_STACK_TOP - USER_STACK_SIZE)  /* 0x3FFF0000 */
#define USER_MMAP_WINDOW     (USER_MMAP_WINDOW_END - USER_MMAP_BASE)

/* BUG-0281: per-process bookkeeping for the mmap window. mmap records
 * every allocation so munmap/mprotect can verify that the caller owns the
 * pages it tears down or re-protects (foreign/unmapped window ranges are
 * rejected instead of silently ignored). Regions are NOT inherited across
 * fork, matching sys_fork's documented non-inheritance of mmap_base
 * (A2-10): the child restarts the bump at USER_MMAP_BASE with an empty
 * table. start == 0 marks a free slot (the window starts at 0x3C000000). */
#define PROC_MAX_MMAP_REGIONS 16
typedef struct {
    u64 start;   /* page-aligned VA of the region; 0 = slot free */
    u64 pages;   /* region length in 4 KiB pages */
} proc_mmap_region_t;

/* WP-08b Batch 5: dynamic linking address space layout:
 *   0x08000000  - ld.so API table (R+W page, 1 page)
 *   0x10000000  - ld.so itself (R+E, fixed)
 *   0x20000000  - main program ELF (mapped by kernel)
 *   0x30000000  - pre-mapped libfoo.so (for DT_NEEDED case)
 *   0x38000000  - dlopen'd .so bump allocator (per-process)
 *   0x3C000000  - mmap base (per-process)
 * All addresses below 0x40000000 (1GB) are in PDPT[0], which is
 * per-process (each process has its own PDPT[0]). Addresses above
 * 1GB use shared kernel page tables and are NOT isolated per-process.
 * BUG-010 FIX: moved from 0x50000000/0x60000000 (above 1GB, shared)
 * to 0x38000000/0x3C000000 (below 1GB, per-process). */
#define LDSO_API_TABLE_ADDR 0x08000000ULL
#define USER_SOLIB_BASE     0x38000000ULL

/* Maximum FDs per process (includes VFS fds + pipe fds) */
#define PROC_MAX_FDS 32

/* BUG-0278 FIX (A2-14): per-process working directory buffer length.
 * Matches the kernel shell's SHELL_CWD_LEN so a cwd built by either
 * side always fits the other side's buffers. */
#define USER_CWD_LEN 256

/* PID type. */
typedef int pid_t;

/* Per-process file descriptor entry.
 * kind: 0=free, 1=VFS fd, 2=pipe-read, 3=pipe-write */
typedef struct {
    int kind;
    int fs_vfs_fd;
    int pipe_id;
} sys_proc_fd_t;

/* User process structure. */
typedef struct user_proc {
    pid_t      pid;
    pid_t      ppid;
    tid_t      tid;
    tid_t      parent_tid;
    mem_vmm_as_t   as;
    u64        entry_point;
    u64        user_rsp;
    u64        brk;
    int        alive;
    int        exit_code;
    int        waited;
    int        pending_signal;
    char       name[32];

    /* BUG-0278 FIX (A2-14): per-process working directory. chdir/getcwd
     * and relative-path resolution use THIS copy, not the kernel shell's
     * global g_cwd, so one process's cd can no longer move every other
     * process's path base. Fork copies it, exec preserves it (POSIX). */
    char       cwd[USER_CWD_LEN];

    /* WP-08a: per-process file descriptor table */
    sys_proc_fd_t  fds[PROC_MAX_FDS];

    /* WP-08a: signal handlers */
    signal_handler_fn sig_handlers[NSIG];

    /* P3-12: Saved user-mode register frame for sigreturn.
     * When a signal is delivered (in core_syscall_dispatch, after the syscall
     * returns but before iretq), the kernel saves the current IRQ frame
     * here, then modifies the live frame to call the user's handler.
     * When the handler invokes SYS_SIGRETURN (42), the kernel copies
     * this saved frame back into the live frame so iretq restores the
     * pre-signal RIP/RSP/RFLAGS/registers.
     * sig_in_progress: 1 = saved frame is valid (next sigreturn restores it). */
    u64 sig_saved_frame[22];
    int sig_in_progress;

    /* WP-11-crash_recovery 4.5: SIGSEGV delivery guard. A handler
     * that sigreturns back onto the SAME faulting instruction would
     * ping-pong forever (fault -> deliver -> handler -> sigreturn ->
     * fault ...). POSIX force-kills the second fault; we count
     * deliveries per process and kill after 3 (plenty for a handler
     * that fixes the mapping or exits; impossible to satisfy a
     * genuine infinite loop). Reset to 0 on exec (new program). */
    u32 sigsegv_delivered;

    /* WP-08a: fork-child state. When is_fork_child=1, the launcher
     * enters ring 3 at fork_rip/fork_rsp with fork_rax in RAX,
     * implementing true POSIX fork semantics (child continues from
     * the fork() call point). */
    int        is_fork_child;
    u64        fork_rip;
    u64        fork_rsp;
    u64        fork_rflags;
    u64        fork_rax;
    u64        fork_regs[22];  /* WP-08cd: full saved register array (22 u64) */

    /* WP-08b Batch 5: per-process bump allocator for dlopen'd .so files.
     * Starts at USER_SOLIB_BASE (0x38000000) and grows up. */
    u64        next_solib_addr;

    /* BUG-010 FIX: per-process mmap base (was global static, causing
     * cross-process memory corruption). Initialized to USER_MMAP_BASE
     * on first mmap call. */
    u64        mmap_base;

    /* BUG-0281 (A2-9): mmap window region table (see above). Zeroed with
     * the rest of the struct when a process slot is claimed. */
    proc_mmap_region_t mmap_regions[PROC_MAX_MMAP_REGIONS];
} user_proc_t;

/* Syscall handler function type. */
typedef u64 (*core_syscall_handler_fn)(u64 arg1, u64 arg2, u64 arg3, u64 arg4);

/* WP-08a: exposed for syscall.c */
mem_vmm_as_t create_user_address_space(void);
int map_user_pages(mem_vmm_as_t as, u64 vaddr, const void *src, u64 size);
void user_task_launcher(void *arg);

/* WP-08a: global process table (used by syscall.c) */
extern user_proc_t g_procs[MAX_USER_PROCS];

/* Copy all user-accessible pages from src_as to a new address space. */
mem_vmm_as_t copy_user_address_space(mem_vmm_as_t src_as);

/* Initialize userspace subsystem. */
void usermode_init(void);

/* Create a user process from an ELF binary. */
pid_t user_process_create(const u8 *elf_data, u64 elf_size, const char *name);

/* BUG-0134 FIX: look up the kernel task id (tid) behind an alive user
 * process, so the shell can print a `kill`-ready tid next to the pid.
 * Returns the tid, or -1 when no alive process owns the pid. */
int user_process_get_tid(pid_t pid);

/* Kill a user process. */
int user_process_kill(pid_t pid);

/* WP-10-tui-unified: kill a user process by its kernel task id - the
 * same unified-reaper path the `kill <tid>` shell command uses (fds +
 * address space reclaimed, parent woken, task exited on the scheduler).
 * Returns 0 ok, -1 no live user process owns this tid, -2 self-kill. */
int user_process_kill_by_tid(tid_t tid);

/* List all user processes. */
void user_process_list(void);

/* Register a syscall handler. */
int core_syscall_register(int num, core_syscall_handler_fn handler);

/* Default syscall handlers. */
u64 core_syscall_write(u64 buf, u64 len, u64 arg3, u64 arg4);
u64 core_syscall_exit(u64 code, u64 arg2, u64 arg3, u64 arg4);

/* Called from the int 0x80 entry stub. */
void core_syscall_dispatch(u64 *regs);

/* Enter ring 3 for the first time. */
void enter_ring3(u64 entry_point, u64 user_rsp, u64 user_cr3);

/* WP-08a: Enter ring 3 with a saved fork frame (pure assembly).
 * Arguments: rdi=rip, rsi=rsp, rdx=rflags, rcx=rax, r8=cr3 */
void enter_ring3_fork(u64 *frame, u64 cr3);

/* WP-08a: Get the current process. */
user_proc_t *user_process_current(void);

/* WP-08a: Save/restore the current interrupt frame (for fork). */
void user_set_current_frame(u64 *frame_regs);
u64 *user_get_current_frame(void);

/* P3-11: Unified resource reaper — called from sys_exit2, sys_kill,
 * and exception kill. Closes all fds + destroys the user AS. */
void user_process_reap_resources(user_proc_t *p, int exit_code);

/* WP-11-crash_recovery 4.5: deliver a signal directly into a live
 * exception frame (used by the syscall-return path for pending_signal
 * and by arch_exc_dispatch for SIGSEGV on ring-3 faults). Caller
 * checks: proc is current, handler registered, not already inside a
 * handler. Returns 0 on success (iretq enters the handler).
 * (arch_irq_frame_t is forward-declared: arch_idt.h is not included
 * here to keep this header's include graph flat.) */
struct arch_irq_frame;
int user_signal_deliver(user_proc_t *proc, struct arch_irq_frame *f, int sig);

#endif /* OC_USERMODE_H */
